import asyncio
import random
from datetime import datetime
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

CRYPTO_PRICES = {
    "btc": 85000,      # بيتكوين
    "eth": 4200,       # إيثيريوم
    "usdt": 1,         # تيثر
    "bnb": 580,        # بايننس كوين
    "xrp": 2.10,       # ريبل
    "ada": 0.75,       # كاردانو
    "sol": 150,        # سولانا
    "doge": 0.30,      # دوجكوين
    "dot": 12,         # بولكادوت
    "matic": 1.20,     # بوليجون
    "shib": 0.000025,  # شيبا
    "ltc": 95,         # لايتكوين
    "trx": 0.22,       # ترون
    "avax": 38,        # أفالانش
    "link": 18,        # تشين لينك
    "ton": 5.5,        # تون كوين
    "not": 0.008,      # نوت كوين
}

CRYPTO_NAMES = {
    "btc": "بيتكوين", "eth": "إيثيريوم", "usdt": "تيثر",
    "bnb": "بايننس كوين", "xrp": "ريبل", "ada": "كاردانو",
    "sol": "سولانا", "doge": "دوجكوين", "dot": "بولكادوت",
    "matic": "بوليجون", "shib": "شيبا", "ltc": "لايتكوين",
    "trx": "ترون", "avax": "أفالانش", "link": "تشين لينك",
    "ton": "تون كوين", "not": "نوت كوين",
}

CURRENCY_SYMBOLS = {
    "btc": "₿", "eth": "Ξ", "usdt": "$", "bnb": "BNB",
    "xrp": "XRP", "ada": "ADA", "sol": "SOL", "doge": "Ð",
    "dot": "DOT", "matic": "MATIC", "shib": "SHIB", "ltc": "Ł",
    "trx": "TRX", "avax": "AVAX", "link": "LINK", "ton": "TON", "not": "NOT",
}

# ==================== عرض قائمة الأوامر (.م27) ====================
@client.on(events.NewMessage(pattern=r'\.م27', outgoing=True))
async def show_crypto_menu(event):
    menu_text = """⟪───── العملات والحساب ─────⟫

│ `.عملات`
│ ← يعرض كم تساوي 1 دولار مقابل العملات الرقمية

│ `.عملات <المبلغ>`
│ ← يعرض كم تساوي 100 دولار مثلًا مقابل العملات الرقمية
│ ← مثال: .عملات 100

│ `.سعر <الكمية> <العملة>`
│ ← يحول الكمية من العملة الرقمية إلى دولار
│ ← مثال: .سعر 2 eth

│ `.عملات_مقارنة`
│ ← يعرض مقارنة بين العملات الرقمية

│ `.تحديث_العملات`
│ ← لتحديث أسعار العملات
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 1. أمر .عملات ====================
@client.on(events.NewMessage(pattern=r'\.عملات(?:\s+(\d+\.?\d*))?', outgoing=True))
async def show_crypto_prices(event):
    amount = 1.0
    if event.pattern_match.group(1):
        try:
            amount = float(event.pattern_match.group(1).strip())
        except:
            await event.edit("❌ **يرجى إدخال مبلغ صحيح**\n📝 **مثال:** `.عملات 100`")
            return
    
    text = f"💰 **{amount:,.2f} دولار أمريكي تساوي:**\n\n"
    
    main_coins = ["btc", "eth", "bnb", "sol", "xrp", "doge", "ton"]
    
    for coin in main_coins:
        if coin in CRYPTO_PRICES:
            price = CRYPTO_PRICES[coin]
            coin_amount = amount / price
            
            if coin_amount < 0.0001:
                formatted = f"{coin_amount:.8f}"
            elif coin_amount < 0.01:
                formatted = f"{coin_amount:.6f}"
            elif coin_amount < 1:
                formatted = f"{coin_amount:.4f}"
            else:
                formatted = f"{coin_amount:.2f}"
            
            symbol = CURRENCY_SYMBOLS.get(coin, "")
            name = CRYPTO_NAMES.get(coin, coin.upper())
            text += f"{symbol} **{name}:** `{formatted}`\n"
    
    text += "\n📊 **عملات أخرى:**\n"
    other_coins = ["ada", "matic", "dot", "link", "ltc", "trx", "avax"]
    
    for coin in other_coins:
        if coin in CRYPTO_PRICES:
            price = CRYPTO_PRICES[coin]
            coin_amount = amount / price
            
            if coin_amount < 0.01:
                formatted = f"{coin_amount:.4f}"
            elif coin_amount < 1:
                formatted = f"{coin_amount:.3f}"
            else:
                formatted = f"{coin_amount:.2f}"
            
            symbol = CURRENCY_SYMBOLS.get(coin, "")
            name = CRYPTO_NAMES.get(coin, coin.upper())
            text += f"{symbol} **{name}:** `{formatted}`\n"
    
    text += "\n🐕 **عملات الميم:**\n"
    meme_coins = ["shib", "not"]
    
    for coin in meme_coins:
        if coin in CRYPTO_PRICES:
            price = CRYPTO_PRICES[coin]
            coin_amount = amount / price
            
            symbol = CURRENCY_SYMBOLS.get(coin, "")
            name = CRYPTO_NAMES.get(coin, coin.upper())
            text += f"{symbol} **{name}:** `{coin_amount:,.0f}`\n"
    
    text += f"\n📅 **آخر تحديث:** {datetime.now().strftime('%Y-%m-%d %I:%M %p')}"
    
    await event.edit(text)

# ==================== 2. أمر .سعر ====================
@client.on(events.NewMessage(pattern=r'\.سعر\s+(\d+\.?\d*)\s+(\w+)', outgoing=True))
async def convert_crypto_to_usd(event):
    try:
        amount = float(event.pattern_match.group(1).strip())
    except:
        await event.edit("❌ **يرجى إدخال كمية صحيحة**")
        return
    
    coin = event.pattern_match.group(2).strip().lower()
    
    if coin not in CRYPTO_PRICES:
        found = False
        for key, name in CRYPTO_NAMES.items():
            if coin in name.lower() or coin == key:
                coin = key
                found = True
                break
        
        if not found:
            available = ", ".join(CRYPTO_PRICES.keys())
            await event.edit(f"❌ **العملة غير مدعومة**\n\n📋 **العملات المتاحة:**\n{available}")
            return
    
    price = CRYPTO_PRICES[coin]
    usd_value = amount * price
    name = CRYPTO_NAMES.get(coin, coin.upper())
    symbol = CURRENCY_SYMBOLS.get(coin, "")
    
    if usd_value >= 1:
        formatted_usd = f"{usd_value:,.2f}"
    elif usd_value >= 0.01:
        formatted_usd = f"{usd_value:.4f}"
    else:
        formatted_usd = f"{usd_value:.8f}"
    
    change = random.uniform(-5, 5)
    trend = "📈" if change > 0 else "📉"
    
    await event.edit(
        f"💱 **تحويل العملات**\n\n"
        f"{symbol} **{amount:,.4f} {name}**\n"
        f"💰 **= {formatted_usd} دولار أمريكي**\n\n"
        f"📊 **سعر {name}:** ${price:,.2f}\n"
        f"{trend} **التغير (24س):** {change:+.2f}%"
    )

# ==================== 3. أمر .عملات_مقارنة ====================
@client.on(events.NewMessage(pattern=r'\.عملات_مقارنة', outgoing=True))
async def compare_crypto(event):
    text = "📊 **مقارنة العملات الرقمية**\n\n"
    text += "| العملة | السعر ($) | التغير 24س |\n"
    text += "|--------|-----------|------------|\n"
    
    main_coins = ["btc", "eth", "bnb", "sol", "xrp", "doge"]
    
    for coin in main_coins:
        if coin in CRYPTO_PRICES:
            price = CRYPTO_PRICES[coin]
            change = random.uniform(-8, 8)
            trend = "🟢" if change > 0 else "🔴"
            
            if price >= 1000:
                price_str = f"${price:,.0f}"
            elif price >= 1:
                price_str = f"${price:,.2f}"
            else:
                price_str = f"${price:.4f}"
            
            symbol = CURRENCY_SYMBOLS.get(coin, coin.upper())
            text += f"| {symbol} | {price_str} | {trend} {change:+.2f}% |\n"
    
    text += f"\n📅 **آخر تحديث:** {datetime.now().strftime('%I:%M %p')}"
    
    await event.edit(text)

# ==================== 4. أمر .تحديث_العملات ====================
@client.on(events.NewMessage(pattern=r'\.تحديث_العملات', outgoing=True))
async def update_crypto_prices(event):
    await event.edit("🔄 **جاري تحديث أسعار العملات...**")
    await asyncio.sleep(2)
    
    await event.edit(
        "✅ **تم تحديث أسعار العملات**\n\n"
        "📌 *الأسعار تقريبية ويتم تحديثها دورياً*\n"
        "💡 *للعرض:* `.عملات`"
    )