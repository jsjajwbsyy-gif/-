from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

mimic_settings = {}
simulate_settings = {}

# ==================== عرض قائمة الأوامر (.م10) ====================
@client.on(events.NewMessage(pattern=r'\.م10', outgoing=True))
async def show_mimic_menu(event):
    menu_text = """⟪───── أوامر التقليد والمحاكاة ─────⟫

│ `.تقليد`
│ ← بالرد على رسالة، يقوم بتقليد جميع رسائل الشخص

│ `.الغاء التقليد`
│ ← لإيقاف تقليد رسائل الشخص

│ `.محاكي [اليوزر]`
│ ← لتفعيل محاكاة بوت معين

│ `.نمط المحاكاة` [بالرد على رسالة تحتوي على النمط]
│ ← لتحديد نمط استخراج الكلمات من رسائل البوت

│ `.ايقاف المحاكي`
│ ← لإيقاف محاكاة البوت

│ `.تفكيك`
│ ← لفصل حروف الكلمة

│ `.كلمات`
│ ← لإرسال الكلمة كما هي

│ `.رياضيات`
│ ← لإجراء عمليات حسابية

│ `.انقليزي`
│ ← لترجمة الكلمات إلى العربية

│ `.الاسرع`
│ ← لإرسال الرموز التعبيرية في ألعاب الاسرع
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 1. أمر .تقليد ====================
@client.on(events.NewMessage(pattern=r'\.تقليد', outgoing=True))
async def start_mimic(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص الذي تريد تقليده**")
        return
    
    target_user = await reply.get_sender()
    chat_id = event.chat_id
    my_id = event.sender_id
    
    if my_id not in mimic_settings:
        mimic_settings[my_id] = {}
    
    mimic_settings[my_id][chat_id] = {
        "enabled": True,
        "target_id": target_user.id
    }
    
    target_name = f"@{target_user.username}" if target_user.username else target_user.first_name
    await event.edit(f"🎭 **تم تفعيل تقليد** {target_name}\n*سيتم تقليد جميع رسائله في هذه الدردشة*")

@client.on(events.NewMessage(pattern=r'\.الغاء التقليد', outgoing=True))
async def stop_mimic(event):
    chat_id = event.chat_id
    my_id = event.sender_id
    
    if my_id in mimic_settings and chat_id in mimic_settings[my_id]:
        mimic_settings[my_id][chat_id]["enabled"] = False
        await event.edit("🛑 **تم إيقاف التقليد**")
    else:
        await event.edit("❌ **التقليد غير مفعل حالياً**")

# ==================== معالج التقليد ====================
@client.on(events.NewMessage(incoming=True))
async def mimic_handler(event):
    chat_id = event.chat_id
    sender_id = event.sender_id
    
    for my_id, settings in mimic_settings.items():
        if chat_id in settings and settings[chat_id].get("enabled", False):
            if sender_id == settings[chat_id].get("target_id"):
                if event.text:
                    await event.reply(event.text)
                elif event.sticker:
                    await client.send_file(chat_id, event.sticker)
                elif event.photo:
                    await client.send_file(chat_id, event.photo, caption=event.text or "")
                elif event.video:
                    await client.send_file(chat_id, event.video, caption=event.text or "")
                elif event.voice:
                    await client.send_file(chat_id, event.voice)
                elif event.audio:
                    await client.send_file(chat_id, event.audio)
                elif event.gif:
                    await client.send_file(chat_id, event.gif)

# ==================== 2. أمر .محاكي ====================
@client.on(events.NewMessage(pattern=r'\.محاكي\s+(@\w+)', outgoing=True))
async def start_simulate(event):
    bot_username = event.pattern_match.group(1).strip()
    chat_id = event.chat_id
    my_id = event.sender_id
    
    if my_id not in simulate_settings:
        simulate_settings[my_id] = {}
    
    simulate_settings[my_id][chat_id] = {
        "enabled": True,
        "bot": bot_username,
        "pattern": "default"
    }
    
    await event.edit(f"🤖 **تم تفعيل محاكاة البوت:** {bot_username}")

@client.on(events.NewMessage(pattern=r'\.نمط المحاكاة', outgoing=True))
async def set_simulate_pattern(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على رسالة تحتوي على النمط المطلوب**")
        return
    
    pattern_text = reply.text
    chat_id = event.chat_id
    my_id = event.sender_id
    
    if my_id in simulate_settings and chat_id in simulate_settings[my_id]:
        simulate_settings[my_id][chat_id]["pattern"] = pattern_text
        await event.edit(f"✅ **تم تعيين نمط المحاكاة:**\n`{pattern_text[:100]}...`")
    else:
        await event.edit("❌ **المحاكي غير مفعل، استخدم `.محاكي` أولاً**")

@client.on(events.NewMessage(pattern=r'\.ايقاف المحاكي', outgoing=True))
async def stop_simulate(event):
    chat_id = event.chat_id
    my_id = event.sender_id
    
    if my_id in simulate_settings and chat_id in simulate_settings[my_id]:
        simulate_settings[my_id][chat_id]["enabled"] = False
        await event.edit("🛑 **تم إيقاف المحاكاة**")
    else:
        await event.edit("❌ **المحاكي غير مفعل حالياً**")

# ==================== معالج المحاكاة ====================
@client.on(events.NewMessage(incoming=True))
async def simulate_handler(event):
    chat_id = event.chat_id
    
    for my_id, settings in simulate_settings.items():
        if chat_id in settings and settings[chat_id].get("enabled", False):
            bot_username = settings[chat_id].get("bot")
            sender = await event.get_sender()
            if sender and sender.username and f"@{sender.username}" == bot_username:
                if event.text:
                    await event.reply(event.text)

# ==================== 3. أمر .تفكيك ====================
@client.on(events.NewMessage(pattern=r'\.تفكيك\s+([\s\S]+)', outgoing=True))
async def separate_letters(event):
    word = event.pattern_match.group(1).strip()
    separated = " • ".join(list(word))
    await event.edit(f"🔤 **تفكيك الكلمة:**\n\n{separated}")

# ==================== 4. أمر .كلمات ====================
@client.on(events.NewMessage(pattern=r'\.كلمات\s+([\s\S]+)', outgoing=True))
async def send_word_as_is(event):
    word = event.pattern_match.group(1).strip()
    await event.edit(word)

# ==================== 5. أمر .رياضيات ====================
@client.on(events.NewMessage(pattern=r'\.رياضيات\s+([\s\S]+)', outgoing=True))
async def calculate_math(event):
    expression = event.pattern_match.group(1).strip()
    
    try:
        allowed_chars = set("0123456789+-*/.() ")
        if all(c in allowed_chars for c in expression):
            result = eval(expression)
            await event.edit(f"🧮 **العملية:** `{expression}`\n📊 **الناتج:** `{result}`")
        else:
            await event.edit("❌ **العملية تحتوي على رموز غير مسموحة**")
    except Exception as e:
        await event.edit(f"❌ **خطأ في العملية الحسابية:** {str(e)}")

# ==================== 6. أمر .انقليزي ====================
@client.on(events.NewMessage(pattern=r'\.انقليزي\s+(\w+)', outgoing=True))
async def translate_to_arabic(event):
    word = event.pattern_match.group(1).strip().lower()
    translated = translation_dict.get(word, f"*لم يتم العثور على ترجمة لـ* `{word}`")
    await event.edit(f"🌐 **ترجمة:** `{word}`\n📝 **بالعربية:** {translated}")

# ==================== 7. أمر .الاسرع ====================
@client.on(events.NewMessage(pattern=r'\.الاسرع(?:\s+([\s\S]+))?', outgoing=True))
async def send_fast_emojis(event):
    emoji_groups = {
        "حيوانات": "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮",
        "فواكه": "🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍",
        "وجوه": "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃",
        "رياضة": "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🏒 🏑",
        "طعام": "🍕 🍔 🍟 🌭 🍿 🥨 🥖 🥐 🥯 🥞 🧇 🍦",
    }
    
    group_name = event.pattern_match.group(1)
    
    if not group_name:
        groups = "\n".join([f"• {name}" for name in emoji_groups.keys()])
        await event.edit(f"🎮 **مجموعات الاسرع المتاحة:**\n\n{groups}\n\n📌 **استخدم:** `.الاسرع [اسم المجموعة]`")
        return
    
    group_name = group_name.strip()
    
    if group_name in emoji_groups:
        await event.edit(f"🎯 **مجموعة {group_name}:**\n\n{emoji_groups[group_name]}")
    else:
        await event.edit(f"❌ **المجموعة غير موجودة**\n*المجموعات المتاحة:* {', '.join(emoji_groups.keys())}")