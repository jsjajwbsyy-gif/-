from main import client
from telethon import events

# ========== M39: أوامر التصنيف والترتيب ==========

@client.on(events.NewMessage(pattern=r'\.م39', outgoing=True))
async def show_m39_menu(event):
    menu_text = """⟪───── أوامر التصنيف والترتيب ─────⟫

│ `.توب المجموعات`
│ ← ترتيب المجموعات حسب عدد الأعضاء

│ `.توب الخاص`
│ ← أكثر الأشخاص مراسلة لك

│ `.توب الرسائل`
│ ← أكثر الأشخاص إرسالاً في المجموعة

│ `.توب التفاعل`
│ ← أكثر الأشخاص تفاعلاً في المجموعة

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== أمر .توب المجموعات ==========
@client.on(events.NewMessage(pattern=r'\.توب المجموعات', outgoing=True))
async def top_groups(event):
    await event.edit("📊 **جاري تحليل المجموعات...**")
    
    groups_list = []
    
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            try:
                participant_count = dialog.entity.participants_count if hasattr(dialog.entity, 'participants_count') else 0
                groups_list.append({
                    "name": dialog.name,
                    "count": participant_count
                })
            except:
                groups_list.append({"name": dialog.name, "count": 0})
    
    groups_list.sort(key=lambda x: x["count"], reverse=True)
    top = groups_list[:15]
    
    if top:
        text = "👥 **أعلى المجموعات أعضاءً:**\n\n"
        for i, g in enumerate(top, 1):
            medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
            text += f"{medal} **{g['name']}** - {g['count']} عضو\n"
    else:
        text = "📭 **لا توجد مجموعات**"
    
    await event.edit(text)


# ========== أمر .توب الخاص ==========
@client.on(events.NewMessage(pattern=r'\.توب الخاص', outgoing=True))
async def top_private(event):
    await event.edit("📊 **جاري تحليل المحادثات... (قد يستغرق قليلاً)**")
    
    private_stats = {}
    processed = 0
    
    async for dialog in client.iter_dialogs():
        if dialog.is_user and not dialog.entity.bot:
            try:
                messages = await client.get_messages(dialog.id, limit=50)
                count = len([m for m in messages if m.out])
                if count > 0:
                    private_stats[dialog.name] = count
                processed += 1
                if processed >= 30:
                    break
            except:
                pass
    
    sorted_stats = sorted(private_stats.items(), key=lambda x: x[1], reverse=True)[:15]
    
    if sorted_stats:
        text = "💬 **أكثر الأشخاص مراسلة:**\n\n"
        for i, (name, count) in enumerate(sorted_stats, 1):
            medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
            text += f"{medal} **{name}** - {count} رسالة\n"
    else:
        text = "📭 **لا توجد محادثات كافية**"
    
    await event.edit(text)


# ========== أمر .توب الرسائل ==========
@client.on(events.NewMessage(pattern=r'\.توب الرسائل', outgoing=True))
async def top_messages(event):
    if not event.is_group:
        await event.edit("❌ **هذا الأمر يعمل في المجموعات فقط**")
        return
    
    await event.edit("📊 **جاري تحليل رسائل المجموعة...**")
    
    chat_id = event.chat_id
    sender_stats = {}
    
    async for msg in client.iter_messages(chat_id, limit=200):
        if msg.sender_id:
            try:
                sender = await msg.get_sender()
                name = sender.first_name or "مستخدم"
                sender_stats[name] = sender_stats.get(name, 0) + 1
            except:
                pass
    
    sorted_stats = sorted(sender_stats.items(), key=lambda x: x[1], reverse=True)[:15]
    
    if sorted_stats:
        text = "📊 **أكثر الأعضاء إرسالاً:**\n\n"
        for i, (name, count) in enumerate(sorted_stats, 1):
            medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
            text += f"{medal} **{name}** - {count} رسالة\n"
    else:
        text = "📭 **لا توجد رسائل كافية**"
    
    await event.edit(text)


# ========== أمر .توب التفاعل ==========
@client.on(events.NewMessage(pattern=r'\.توب التفاعل', outgoing=True))
async def top_reactions(event):
    if not event.is_group:
        await event.edit("❌ **هذا الأمر يعمل في المجموعات فقط**")
        return
    
    await event.edit("📊 **جاري تحليل التفاعلات...**")
    
    chat_id = event.chat_id
    reaction_stats = {}
    
    async for msg in client.iter_messages(chat_id, limit=200):
        if msg.reactions and msg.sender_id:
            try:
                sender = await msg.get_sender()
                name = sender.first_name or "مستخدم"
                count = 0
                if hasattr(msg.reactions, 'results'):
                    for r in msg.reactions.results:
                        count += r.count
                reaction_stats[name] = reaction_stats.get(name, 0) + count
            except:
                pass
    
    sorted_stats = sorted(reaction_stats.items(), key=lambda x: x[1], reverse=True)[:15]
    
    if sorted_stats:
        text = "⭐ **أكثر الأعضاء تفاعلاً:**\n\n"
        for i, (name, count) in enumerate(sorted_stats, 1):
            medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
            text += f"{medal} **{name}** - {count} تفاعل\n"
    else:
        text = "📭 **لا توجد تفاعلات كافية**"
    
    await event.edit(text)