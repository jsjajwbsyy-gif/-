import random
import requests
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client


# ==================== عرض قائمة الأوامر (.م48) ====================
@client.on(events.NewMessage(pattern=r'\.م48', outgoing=True))
async def show_gif_menu(event):
    menu_text = """⟪───── أوامر الصور المتحركة ─────⟫

│ `.متحركه`
│ ← إرسال GIF عشوائي تماماً

│ `.متحركه + كلمة`
│ ← إرسال GIF حسب كلمة البحث
│ ← مثال: .متحركه قطة

│ `.متحركه + عدد`
│ ← إرسال عدد من الصور العشوائية (1-20)
│ ← مثال: .متحركه 5

│ `.متحركه + كلمة + عدد`
│ ← إرسال عدد حسب كلمة البحث
│ ← مثال: .متحركه ضحك 5

ملاحظة:
↢ الصور تُجلب من موقع Giphy
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== دالة مساعدة: جلب مفتاح API ====================
def get_api_key():
    try:
        res = requests.get("https://giphy.com/")
        res = res.text.split("GIPHY_FE_WEB_API_KEY =")[1].split("\n")[0]
        return res[2:-1]
    except Exception:
        return None


# ==================== دالة مساعدة: جلب صور عشوائية ====================
def get_random_gif_url(api_key, search_term=None, limit=50):
    if search_term:
        url = f"https://api.giphy.com/v1/gifs/search?q={search_term}&api_key={api_key}&limit={limit}"
    else:
        url = f"https://api.giphy.com/v1/gifs/trending?api_key={api_key}&limit={limit}"
    
    try:
        r = requests.get(url).json()
        list_id = [r["data"][i]["id"] for i in range(len(r["data"]))]
        if list_id:
            return list_id
        return None
    except Exception:
        return None


# ==================== أمر .متحركه ====================
@client.on(events.NewMessage(pattern=r'\.متحركه(?:\s|$)([\s\S]*)', outgoing=True))
async def send_gifs(event):
    """إرسال صور GIF من Giphy"""
    inpt = event.pattern_match.group(1).strip() if event.pattern_match.group(1) else ""
    
    # جلب مفتاح API
    api_key = get_api_key()
    if not api_key:
        await event.edit("✘ **فشل الاتصال بـ Giphy، حاول لاحقاً**")
        return
    
    # تحليل المدخلات
    search_term = None
    count = 1
    
    if inpt:
        parts = inpt.split()
        # إذا كان الجزء الأخير رقماً
        if parts[-1].isdigit():
            count = int(parts[-1])
            if count < 1:
                count = 1
            elif count > 20:
                count = 20
            # إذا كان هناك أكثر من جزء، فالأجزاء المتبقية هي كلمة البحث
            if len(parts) > 1:
                search_term = " ".join(parts[:-1])
        else:
            search_term = inpt
    
    await event.edit(f"⎙ **جاري جلب الصور...**")
    
    list_id = get_random_gif_url(api_key, search_term, 50)
    
    if not list_id:
        await event.edit("✘ **لم يتم العثور على صور**")
        return
    
    # اختيار صور عشوائية
    if count > len(list_id):
        count = len(list_id)
    rlist = random.sample(list_id, count)
    
    # إرسال الصور
    sent_count = 0
    for items in rlist:
        try:
            await event.client.send_file(
                event.chat_id,
                f"https://media.giphy.com/media/{items}/giphy.gif",
                reply_to=event.message.id,
            )
            sent_count += 1
        except Exception:
            pass
    
    # حذف الرسالة الأصلية
    await event.delete()