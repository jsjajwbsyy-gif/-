import asyncio
import os
import re
from datetime import datetime, timedelta
from telethon import events
from telethon.sessions import StringSession
from telethon import TelegramClient

from main import client

# الإعدادات
API_ID = 27503848
API_HASH = "a08a570b86888fecda16e0e5e0bdf2a5"

# المتغيرات
active_sessions = {}
session_expiry = {}
session_counter = {}
session_permissions = {}

# ==================== عرض قائمة الأوامر (.م17) ====================
@client.on(events.NewMessage(pattern=r'\.م17', outgoing=True))
async def show_install_menu(event):
    menu_text = """⟪───── أوامر التنصيب وإدارة الجلسات ─────⟫

① استخرج ملف الجلسة من البوت استخراج جلسات .

② قم بالرد على الملف المستخرج بأحد الأوامر التالية:
─────────────────
│ للتنصيب 

│  `.تنصيب` ↢ تنصيب دائم
│ `.تنصيب تجريبي`  ← 4 ساعات فقط
│ `.تنصيب اسبوعي`  ← 7 أيام
│ `.تنصيب شهري`   ← 30 يوم
│ `.تنصيب + رقم`  ← حسب الأيام
│ مثال: .تنصيب 5 ← 5 أيام
╰───────────────────

│ إدارة الجلسات 

│ `.جلساتي`    ← عرض الجلسات النشطة
│ `.انهاء + رقم`  ← إنهاء جلسة محددة
│ `.kill`      ← إنهاء جميع الجلسات

│ صلاحيات الجلسات (للمطور فقط)
│ `.قفل/فتح النشر + رقم`  ← قفل/فتح النشر لجلسة
│ `.قفل/فتح الصيد + رقم`  ← قفل/فتح الصيد لجلسة
│ `.قفل/فتح الميوزك + رقم` ← قفل/فتح الميوزك لجلسة
│ `.قفل/فتح الفيديو + رقم` ← قفل/فتح الفيديو لجلسة
│ `.صلاحيات الجلسة + رقم` ← عرض صلاحيات جلسة
╰───────────────────"""
    await event.edit(menu_text)


def extract_session_string(content):
    if content.strip().startswith('1') and len(content.strip()) > 200:
        return content.strip()
    patterns = [
        r'(1[0-9A-Za-z_-]{200,})',
        r'(1[0-9A-Za-z_\-]+={0,2})',
        r'[0-9A-Za-z_\-]{200,}',
    ]
    for pattern in patterns:
        match = re.search(pattern, content)
        if match:
            session_str = match.group(1)
            if len(session_str) > 200:
                return session_str
    return None


async def install_session(event, session_type, days=None, hours=None):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على ملف الجلسة أو رسالة تحتوي على نص الجلسة**")
        return

    await event.edit("🔄 **جاري قراءة الجلسة...**")

    try:
        session_string = None

        if reply.document:
            try:
                session_path = await client.download_media(reply.document)
                with open(session_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                os.remove(session_path)
                session_string = extract_session_string(content)
            except Exception as e:
                await event.edit(f"❌ **فشل قراءة الملف:** {str(e)}")
                return
        elif reply.text:
            session_string = extract_session_string(reply.text)

        if not session_string:
            await event.edit("❌ **لم يتم العثور على جلسة صالحة في الرد**")
            return

        await event.edit("🔄 **جاري التحقق من الجلسة...**")

        try:
            new_client = TelegramClient(StringSession(session_string), API_ID, API_HASH)
            await new_client.connect()
            if not await new_client.is_user_authorized():
                await new_client.disconnect()
                await event.edit("❌ **الجلسة غير صالحة أو منتهية الصلاحية**")
                return
            me = await new_client.get_me()
        except Exception as e:
            await event.edit(f"❌ **فشل الاتصال بالجلسة:** {str(e)[:100]}")
            return

        my_id = event.sender_id

        if my_id not in session_counter:
            session_counter[my_id] = 1
        else:
            session_counter[my_id] += 1

        session_num = session_counter[my_id]

        if my_id not in active_sessions:
            active_sessions[my_id] = {}

        active_sessions[my_id][session_num] = {
            "client": new_client,
            "user": me,
            "type": session_type,
            "started": datetime.now(),
            "string": session_string
        }

        if my_id not in session_permissions:
            session_permissions[my_id] = {}
        session_permissions[my_id][session_num] = {
            "publish": True,
            "hunt": True,
            "music": True,
            "video": True,
        }

        expiry = None
        if days:
            expiry = datetime.now() + timedelta(days=days)
        elif hours:
            expiry = datetime.now() + timedelta(hours=hours)

        if expiry:
            if my_id not in session_expiry:
                session_expiry[my_id] = {}
            session_expiry[my_id][session_num] = expiry

        user_info = f"@{me.username}" if me.username else (me.first_name or "بدون")

        if session_type == "permanent":
            duration = "دائم"
        elif session_type == "trial":
            duration = "4 ساعات"
        elif session_type == "weekly":
            duration = "7 أيام"
        elif session_type == "monthly":
            duration = "30 يوم"
        else:
            duration = f"{days} أيام"

        success_text = f"""✅ **تم التنصيب بنجاح**

📋 **معلومات الجلسة:**
👤 **المستخدم:** {me.first_name or 'بدون'}
📎 **اليوزر:** {user_info}
🆔 **الآيدي:** `{me.id}`
🔢 **رقم الجلسة:** {session_num}
⏰ **المدة:** {duration}
📅 **تاريخ البدء:** {datetime.now().strftime('%Y-%m-%d %I:%M %p')}

📌 **الأوامر المتاحة للشخص:** جميع أوامر السورس متاحة له (م1 إلى م32)"""

        if expiry:
            success_text += f"\n⏳ **تاريخ الانتهاء:** {expiry.strftime('%Y-%m-%d %I:%M %p')}"

        await event.edit(success_text)

        asyncio.create_task(monitor_session(my_id, session_num))
        asyncio.create_task(clone_all_commands_to_session(new_client, my_id, session_num))

    except Exception as e:
        await event.edit(f"❌ **فشل التنصيب:** {str(e)[:200]}")


async def clone_all_commands_to_session(session_client, owner_id, session_num):
    import modules.m1_youtube
    import modules.m2_ai
    import modules.m3_time
    import modules.m4_group
    import modules.m5_private
    import modules.m6_delete
    import modules.m7_shortcuts
    import modules.m8_impersonate
    import modules.m9_fun
    import modules.m10_mimic
    import modules.m11_publish
    import modules.m12_force_subscribe
    import modules.m13_self_destruct
    import modules.m14_font_translate
    import modules.m15_tts_download
    import modules.m16_protection_convert
    import modules.m18_hunt
    import modules.m19_collect
    import modules.m20_customize
    import modules.m21_zakhrafa
    import modules.m22_flush
    import modules.m23_report
    import modules.m24_games
    import modules.m25_fake_session
    import modules.m26_ban_words
    import modules.m27_crypto
    import modules.m28_music_video
    import modules.m29_streak_reaction
    import modules.m31_voice
    import modules.m32_useful

    try:
        me = await session_client.get_me()
        welcome_msg = f"""✅ **تم تفعيل سورس Zero على حسابك بنجاح!**

👤 **مرحباً:** {me.first_name}

📋 **جميع أوامر السورس متاحة لك:**

• `.الاوامر` - عرض القائمة الرئيسية
• `.م1` إلى `.م32` - جميع أوامر السورس
• `.مفتاح` - إضافة مفتاح الذكاء الاصطناعي
• `.يوت` - تحميل من اليوتيوب
• `.انتحال` - نسخ حساب (بالرد)
• `.تقليد` - تقليد شخص (بالرد)
• `.صيد` - صيد يوزرات
• `.تجميع` - تجميع من بوتات
• `.انشر` - نشر تلقائي
• وغيرها الكثير...

⚠️ **ملاحظة:** أوامر المطور فقط غير متاحة لك

🎉 **استمتع باستخدام السورس!**"""
        await session_client.send_message(me.id, welcome_msg)
    except:
        pass


async def monitor_session(owner_id, session_num):
    await asyncio.sleep(10)
    while True:
        await asyncio.sleep(60)
        if owner_id not in active_sessions:
            break
        if session_num not in active_sessions[owner_id]:
            break
        if owner_id in session_expiry and session_num in session_expiry[owner_id]:
            expiry = session_expiry[owner_id][session_num]
            if datetime.now() > expiry:
                try:
                    session = active_sessions[owner_id][session_num]
                    await session["client"].disconnect()
                except:
                    pass
                del active_sessions[owner_id][session_num]
                del session_expiry[owner_id][session_num]
                if owner_id in session_permissions and session_num in session_permissions[owner_id]:
                    del session_permissions[owner_id][session_num]
                try:
                    await client.send_message(owner_id, f"⏰ **انتهت صلاحية الجلسة رقم {session_num}**")
                except:
                    pass
                break


# ==================== أوامر التنصيب ====================
@client.on(events.NewMessage(pattern=r'\.تنصيب$', outgoing=True))
async def install_permanent(event):
    await install_session(event, "permanent")

@client.on(events.NewMessage(pattern=r'\.تنصيب تجريبي', outgoing=True))
async def install_trial(event):
    await install_session(event, "trial", hours=4)

@client.on(events.NewMessage(pattern=r'\.تنصيب اسبوعي', outgoing=True))
async def install_weekly(event):
    await install_session(event, "weekly", days=7)

@client.on(events.NewMessage(pattern=r'\.تنصيب شهري', outgoing=True))
async def install_monthly(event):
    await install_session(event, "monthly", days=30)

@client.on(events.NewMessage(pattern=r'\.تنصيب\s+(\d+)', outgoing=True))
async def install_custom_days(event):
    days = int(event.pattern_match.group(1).strip())
    if days <= 0:
        await event.edit("❌ **يجب أن يكون عدد الأيام أكبر من صفر**")
        return
    await install_session(event, f"{days}_days", days=days)


# ==================== إدارة الجلسات ====================
@client.on(events.NewMessage(pattern=r'\.جلساتي', outgoing=True))
async def show_my_sessions(event):
    my_id = event.sender_id
    if my_id not in active_sessions or not active_sessions[my_id]:
        await event.edit("📭 **لا توجد جلسات نشطة حالياً**")
        return

    text = "📋 **الجلسات النشطة:**\n\n"
    for num, session in active_sessions[my_id].items():
        user = session["user"]
        session_type = session["type"]
        started = session["started"].strftime("%Y-%m-%d %I:%M %p")

        if session_type == "permanent":
            duration = "♾️ دائم"
        elif session_type == "trial":
            duration = "🧪 تجريبي (4 ساعات)"
        elif session_type == "weekly":
            duration = "📅 اسبوعي (7 أيام)"
        elif session_type == "monthly":
            duration = "📆 شهري (30 يوم)"
        else:
            duration = f"⏰ {session_type}"

        expiry_text = ""
        if my_id in session_expiry and num in session_expiry[my_id]:
            expiry = session_expiry[my_id][num]
            remaining = expiry - datetime.now()
            days_left = remaining.days
            hours_left = remaining.seconds // 3600
            if days_left > 0:
                expiry_text = f"\n   ⏳ **متبقي:** {days_left} يوم و {hours_left} ساعة"
            else:
                expiry_text = f"\n   ⏳ **متبقي:** {hours_left} ساعة"

        user_display = f"@{user.username}" if user.username else user.first_name
        text += f"""**{num}.** 👤 {user.first_name}
   📎 {user_display}
   🆔 `{user.id}`
   ⏰ {duration}{expiry_text}
   📅 بدأ: {started}

"""
    text += f"\n📊 **إجمالي الجلسات:** {len(active_sessions[my_id])}\n\n📌 **لإنهاء جلسة:** `.انهاء + رقم`"
    await event.edit(text)


@client.on(events.NewMessage(pattern=r'\.انهاء\s+(\d+)', outgoing=True))
async def end_session(event):
    session_num = int(event.pattern_match.group(1).strip())
    my_id = event.sender_id

    if my_id not in active_sessions or session_num not in active_sessions[my_id]:
        await event.edit(f"❌ **الجلسة رقم {session_num} غير موجودة**")
        return

    session = active_sessions[my_id][session_num]
    user = session["user"]
    try:
        await session["client"].disconnect()
    except:
        pass
    del active_sessions[my_id][session_num]
    if my_id in session_expiry and session_num in session_expiry[my_id]:
        del session_expiry[my_id][session_num]
    if my_id in session_permissions and session_num in session_permissions[my_id]:
        del session_permissions[my_id][session_num]

    user_name = f"@{user.username}" if user.username else user.first_name
    await event.edit(f"✅ **تم إنهاء الجلسة رقم {session_num}**\n👤 **المستخدم:** {user_name}")


@client.on(events.NewMessage(pattern=r'\.kill', outgoing=True))
async def kill_all_sessions(event):
    my_id = event.sender_id
    if my_id not in active_sessions or not active_sessions[my_id]:
        await event.edit("📭 **لا توجد جلسات نشطة حالياً**")
        return

    count = len(active_sessions[my_id])
    for session_num, session in active_sessions[my_id].items():
        try:
            await session["client"].disconnect()
        except:
            pass
    active_sessions[my_id] = {}
    if my_id in session_expiry:
        session_expiry[my_id] = {}
    if my_id in session_permissions:
        session_permissions[my_id] = {}
    await event.edit(f"💀 **حاضـر ايها الـمطـور**\n✅ **تـم أنهاء جميع الجلسات ({count} جلسة)**")


# ==================== صلاحيات الجلسات ====================
def has_installed_sessions(user_id):
    return user_id in active_sessions and active_sessions[user_id]


@client.on(events.NewMessage(pattern=r'\.قفل النشر\s+(\d+)', outgoing=True))
async def lock_publish(event):
    session_num = int(event.pattern_match.group(1).strip())
    owner_id = event.sender_id
    if not has_installed_sessions(owner_id):
        await event.edit("❌ **لا توجد جلسات منصبة**")
        return
    if session_num not in active_sessions[owner_id]:
        await event.edit(f"❌ **الجلسة رقم {session_num} غير موجودة**")
        return
    session_permissions[owner_id][session_num]["publish"] = False
    session_user = active_sessions[owner_id][session_num]["user"]
    user_name = f"@{session_user.username}" if session_user.username else session_user.first_name
    await event.edit(f"🔒 **تم قفل النشر للجلسة رقم {session_num}**\n👤 **المستخدم:** {user_name}")


@client.on(events.NewMessage(pattern=r'\.فتح النشر\s+(\d+)', outgoing=True))
async def unlock_publish(event):
    session_num = int(event.pattern_match.group(1).strip())
    owner_id = event.sender_id
    if not has_installed_sessions(owner_id):
        await event.edit("❌ **لا توجد جلسات منصبة**")
        return
    if session_num not in active_sessions[owner_id]:
        await event.edit(f"❌ **الجلسة رقم {session_num} غير موجودة**")
        return
    session_permissions[owner_id][session_num]["publish"] = True
    session_user = active_sessions[owner_id][session_num]["user"]
    user_name = f"@{session_user.username}" if session_user.username else session_user.first_name
    await event.edit(f"🔓 **تم فتح النشر للجلسة رقم {session_num}**\n👤 **المستخدم:** {user_name}")


@client.on(events.NewMessage(pattern=r'\.قفل الصيد\s+(\d+)', outgoing=True))
async def lock_hunt(event):
    session_num = int(event.pattern_match.group(1).strip())
    owner_id = event.sender_id
    if not has_installed_sessions(owner_id):
        await event.edit("❌ **لا توجد جلسات منصبة**")
        return
    if session_num not in active_sessions[owner_id]:
        await event.edit(f"❌ **الجلسة رقم {session_num} غير موجودة**")
        return
    session_permissions[owner_id][session_num]["hunt"] = False
    session_user = active_sessions[owner_id][session_num]["user"]
    user_name = f"@{session_user.username}" if session_user.username else session_user.first_name
    await event.edit(f"🔒 **تم قفل الصيد للجلسة رقم {session_num}**\n👤 **المستخدم:** {user_name}")


@client.on(events.NewMessage(pattern=r'\.فتح الصيد\s+(\d+)', outgoing=True))
async def unlock_hunt(event):
    session_num = int(event.pattern_match.group(1).strip())
    owner_id = event.sender_id
    if not has_installed_sessions(owner_id):
        await event.edit("❌ **لا توجد جلسات منصبة**")
        return
    if session_num not in active_sessions[owner_id]:
        await event.edit(f"❌ **الجلسة رقم {session_num} غير موجودة**")
        return
    session_permissions[owner_id][session_num]["hunt"] = True
    session_user = active_sessions[owner_id][session_num]["user"]
    user_name = f"@{session_user.username}" if session_user.username else session_user.first_name
    await event.edit(f"🔓 **تم فتح الصيد للجلسة رقم {session_num}**\n👤 **المستخدم:** {user_name}")


@client.on(events.NewMessage(pattern=r'\.قفل الميوزك\s+(\d+)', outgoing=True))
async def lock_music(event):
    session_num = int(event.pattern_match.group(1).strip())
    owner_id = event.sender_id
    if not has_installed_sessions(owner_id):
        await event.edit("❌ **لا توجد جلسات منصبة**")
        return
    if session_num not in active_sessions[owner_id]:
        await event.edit(f"❌ **الجلسة رقم {session_num} غير موجودة**")
        return
    session_permissions[owner_id][session_num]["music"] = False
    session_user = active_sessions[owner_id][session_num]["user"]
    user_name = f"@{session_user.username}" if session_user.username else session_user.first_name
    await event.edit(f"🔒 **تم قفل الميوزك للجلسة رقم {session_num}**\n👤 **المستخدم:** {user_name}")


@client.on(events.NewMessage(pattern=r'\.فتح الميوزك\s+(\d+)', outgoing=True))
async def unlock_music(event):
    session_num = int(event.pattern_match.group(1).strip())
    owner_id = event.sender_id
    if not has_installed_sessions(owner_id):
        await event.edit("❌ **لا توجد جلسات منصبة**")
        return
    if session_num not in active_sessions[owner_id]:
        await event.edit(f"❌ **الجلسة رقم {session_num} غير موجودة**")
        return
    session_permissions[owner_id][session_num]["music"] = True
    session_user = active_sessions[owner_id][session_num]["user"]
    user_name = f"@{session_user.username}" if session_user.username else session_user.first_name
    await event.edit(f"🔓 **تم فتح الميوزك للجلسة رقم {session_num}**\n👤 **المستخدم:** {user_name}")


@client.on(events.NewMessage(pattern=r'\.قفل الفيديو\s+(\d+)', outgoing=True))
async def lock_video(event):
    session_num = int(event.pattern_match.group(1).strip())
    owner_id = event.sender_id
    if not has_installed_sessions(owner_id):
        await event.edit("❌ **لا توجد جلسات منصبة**")
        return
    if session_num not in active_sessions[owner_id]:
        await event.edit(f"❌ **الجلسة رقم {session_num} غير موجودة**")
        return
    session_permissions[owner_id][session_num]["video"] = False
    session_user = active_sessions[owner_id][session_num]["user"]
    user_name = f"@{session_user.username}" if session_user.username else session_user.first_name
    await event.edit(f"🔒 **تم قفل الفيديو للجلسة رقم {session_num}**\n👤 **المستخدم:** {user_name}")


@client.on(events.NewMessage(pattern=r'\.فتح الفيديو\s+(\d+)', outgoing=True))
async def unlock_video(event):
    session_num = int(event.pattern_match.group(1).strip())
    owner_id = event.sender_id
    if not has_installed_sessions(owner_id):
        await event.edit("❌ **لا توجد جلسات منصبة**")
        return
    if session_num not in active_sessions[owner_id]:
        await event.edit(f"❌ **الجلسة رقم {session_num} غير موجودة**")
        return
    session_permissions[owner_id][session_num]["video"] = True
    session_user = active_sessions[owner_id][session_num]["user"]
    user_name = f"@{session_user.username}" if session_user.username else session_user.first_name
    await event.edit(f"🔓 **تم فتح الفيديو للجلسة رقم {session_num}**\n👤 **المستخدم:** {user_name}")


@client.on(events.NewMessage(pattern=r'\.صلاحيات الجلسة\s+(\d+)', outgoing=True))
async def show_session_permissions_cmd(event):
    session_num = int(event.pattern_match.group(1).strip())
    owner_id = event.sender_id
    if not has_installed_sessions(owner_id):
        await event.edit("❌ **لا توجد جلسات منصبة**")
        return
    if session_num not in active_sessions[owner_id]:
        await event.edit(f"❌ **الجلسة رقم {session_num} غير موجودة**")
        return

    perms = session_permissions[owner_id][session_num]
    session_user = active_sessions[owner_id][session_num]["user"]
    user_name = f"@{session_user.username}" if session_user.username else session_user.first_name

    status_text = f"""🔐 **صلاحيات الجلسة رقم {session_num}**

👤 **المستخدم:** {user_name}

📊 **الصلاحيات:**
📤 **النشر:** {'✅ مفتوح' if perms['publish'] else '🔒 مقفول'}
🎣 **الصيد:** {'✅ مفتوح' if perms['hunt'] else '🔒 مقفول'}
🎵 **الميوزك:** {'✅ مفتوح' if perms['music'] else '🔒 مقفول'}
🎥 **الفيديو:** {'✅ مفتوح' if perms['video'] else '🔒 مقفول'}"""
    await event.edit(status_text)
    