import os
import asyncio
import re
from telethon import events, Button
from telethon.errors import BotMethodInvalidError

from main import client, tgbot

xo_bot_settings = {}
games = {}

DEFAULT_XO_BOT = "@XOUHbot"
GAMEE_BOT = "@gamee"
T4TTTT_BOT = "@T4TTTTBOT"

# قائمة الألعاب مع الروابط الصحيحة
GAMES_LIST = {
    "1": {"name": "🛸 حرب الفضاء", "command": "ATARIAsteroids", "bot": GAMEE_BOT},
    "2": {"name": "🐦 فلابي بيرد", "command": "FlappyBird", "bot": GAMEE_BOT},
    "3": {"name": "😺 القط المشاكس", "command": "CrazyCat", "bot": GAMEE_BOT},
    "4": {"name": "🎣 صيد الاسماك", "command": "SpikyFish3", "bot": GAMEE_BOT},
    "5": {"name": "🚲 سباق الدراجات", "command": "MotoFX2", "bot": GAMEE_BOT},
    "6": {"name": "🏎️ سباق سيارات", "command": "F1Racer", "bot": GAMEE_BOT},
    "7": {"name": "♟️ شطرنج", "command": "chess", "bot": T4TTTT_BOT},
    "8": {"name": "⚽ كرة القدم", "command": "FootballStar", "bot": GAMEE_BOT},
    "9": {"name": "🏀 كرة السلة", "command": "BasketBoyRush", "bot": GAMEE_BOT},
    "10": {"name": "🏀 سلة 2", "command": "DoozieDunks", "bot": GAMEE_BOT},
    "11": {"name": "🏹 ضرب الاسهم", "command": "NeonBlaster", "bot": GAMEE_BOT},
    "12": {"name": "🎨 لعبة الألوان", "command": "color", "bot": T4TTTT_BOT},
    "13": {"name": "🥋 كونج فو", "command": "KungFuInc", "bot": GAMEE_BOT},
    "14": {"name": "🐍 لعبة الافعى", "command": "snake", "bot": T4TTTT_BOT},
    "15": {"name": "🚀 لعبة الصواريخ", "command": "rocket", "bot": T4TTTT_BOT},
    "16": {"name": "🏐 كيب اب", "command": "KeepitUP", "bot": GAMEE_BOT},
    "17": {"name": "🌌 جيت واي", "command": "Getaway", "bot": GAMEE_BOT},
    "18": {"name": "🎨 الألوان 2", "command": "ColorHit", "bot": GAMEE_BOT},
    "19": {"name": "❌ اكس او", "command": "xo", "bot": "xo"},
    "20": {"name": "🚔 المحبيس", "command": "Prison", "bot": GAMEE_BOT},
    "21": {"name": "🤝 وعد", "command": "Promise", "bot": GAMEE_BOT},
}

# ==================== عرض قائمة الأوامر (.م24) ====================
@client.on(events.NewMessage(pattern=r'\.م24', outgoing=True))
async def show_games_menu(event):
    menu_text = """⟪───── أوامر الالعاب ووعد ─────⟫

│ `.العاب`
│ ← لعرض قائمة الألعاب المتاحة مع روابطها

│ `.لعبة + الرقم/الاسم`
│ ← لبدء لعبة محددة

│ `.خمنها`
│ ← لعبة أكيناتور لتخمين الشخصية

│ `.xo`
│ ← لبدء لعبة X O (بالرد على شخص للتحدي)

│ `.تبديل xo @البوت`
│ ← لتغيير بوت لعبة XO

│ `.عرض بوت xo`
│ ← لعرض بوت XO الحالي

│ `.وعد + النص`
│ ← للعبة الوعد

│ `.فلابي` | `.شطرنج` | `.سباق` | `.المحبيس`
│ ← اختصارات لبدء الألعاب مباشرة
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 1. أمر .العاب ====================
@client.on(events.NewMessage(pattern=r'\.العاب', outgoing=True))
async def show_games_list(event):
    text = "🎮 **قائمة الألعاب المتاحة:**\n\n"
    
    for num, game in GAMES_LIST.items():
        text += f"{num}. **{game['name']}**\n"
    
    text += "\n📌 **للعب:** اختر لعبة من الأسفل"
    
    buttons = []
    row = []
    for num, game in GAMES_LIST.items():
        row.append(Button.inline(game["name"], data=f"game_{num}"))
        if len(row) == 2:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)
    
    await event.edit(text, buttons=buttons)

# ==================== معالج أزرار الألعاب ====================
@client.on(events.CallbackQuery(pattern=r'game_(.+)'))
async def game_callback(event):
    game_num = event.pattern_match.group(1).decode() if isinstance(event.pattern_match.group(1), bytes) else event.pattern_match.group(1)
    
    if game_num not in GAMES_LIST:
        await event.answer("✘ اللعبة غير موجودة", alert=True)
        return
    
    game = GAMES_LIST[game_num]
    game_command = game["command"]
    game_name = game["name"]
    game_bot = game["bot"]
    
    # لعبة XO لها معالجة خاصة
    if game_bot == "xo":
        await xo_game_from_callback(event)
        return
    
    bot_username = game_bot[1:] if game_bot.startswith("@") else game_bot
    
    text = f"🎮 **{game_name}**\n\n"
    text += f"1️⃣ **للعب الفردي:** [اضغط هنا](https://t.me/{bot_username}?game={game_command})\n"
    text += f"2️⃣ **للعب مع الأصدقاء:** اضغط الزر أدناه 👇\n"
    
    buttons = [
        [Button.switch_inline(f"🎮 اختر محادثة للعب", query=f"{game_command}", same_peer=False)],
        [Button.url("🔗 رابط اللعبة المباشر", f"https://t.me/{bot_username}?game={game_command}")]
    ]
    
    await event.edit(text, buttons=buttons)
    await event.answer()

# ==================== دالة بدء لعبة XO من الأزرار ====================
async def xo_game_from_callback(event):
    user_id = event.sender_id
    xo_bot = xo_bot_settings.get(user_id, DEFAULT_XO_BOT)
    
    await event.edit(f"⎙ **جاري بدء لعبة XO...**\n⌔ **البوت:** {xo_bot}")
    
    try:
        async with client.conversation(xo_bot) as conv:
            await conv.send_message("/start")
            await asyncio.sleep(1)
            await conv.send_message("/new")
            
            response = await conv.get_response()
            
            if response.text:
                game_link = re.search(r"(https?://[^\s]+)", response.text)
                
                if game_link:
                    game_url = game_link.group(1)
                    
                    text = f"🎮 **لعبة XO**\n\n"
                    text += f"⌔ **اللاعب الأول:** أنت\n"
                    text += f"⌔ **اللاعب الثاني:** خصمك\n\n"
                    text += f"🔗 **رابط اللعبة:**\n{game_url}\n\n"
                    text += "📌 *اضغط على الرابط للبدء*"
                    
                    await event.edit(text)
                else:
                    await event.edit("✘ **لم يتم العثور على رابط اللعبة في رد البوت**")
            else:
                await event.edit("✘ **لم يتم استلام رد من البوت**")
                
    except Exception as e:
        error_msg = str(e)
        if "PEER_ID_INVALID" in error_msg or "Cannot find any entity" in error_msg:
            await event.edit(f"✘ **البوت {xo_bot} غير موجود**\n⌔ *استخدم* `.تبديل xo` *لتغيير البوت*")
        else:
            await event.edit(f"✘ **فشل بدء اللعبة:** {error_msg[:100]}")

# ==================== 2. أمر .لعبة ====================
@client.on(events.NewMessage(pattern=r'\.لعبة\s+([\s\S]+)', outgoing=True))
async def start_game(event):
    query = event.pattern_match.group(1).strip().lower()
    
    game_command = None
    game_name = None
    
    if query in GAMES_LIST:
        game = GAMES_LIST[query]
        game_command = game["command"]
        game_name = game["name"]
        game_bot = game["bot"]
    else:
        for num, game in GAMES_LIST.items():
            if query in game["name"].lower() or query in game["command"].lower():
                game_command = game["command"]
                game_name = game["name"]
                game_bot = game["bot"]
                break
    
    if not game_command:
        await event.edit(f"✘ **لم يتم العثور على اللعبة:** `{query}`\n\n⌔ *استخدم* `.العاب` *لعرض القائمة*")
        return
    
    # لعبة XO لها معالجة خاصة
    if game_bot == "xo":
        await xo_game_from_command(event)
        return
    
    bot_username = game_bot[1:] if game_bot.startswith("@") else game_bot
    
    text = f"🎮 **{game_name}**\n\n"
    text += f"1️⃣ **للعب الفردي:** [اضغط هنا](https://t.me/{bot_username}?game={game_command})\n"
    text += f"2️⃣ **للعب مع الأصدقاء:** اضغط الزر أدناه 👇\n"
    
    buttons = [
        [Button.switch_inline(f"🎮 اختر محادثة للعب", query=f"{game_command}", same_peer=False)],
        [Button.url("🔗 رابط اللعبة المباشر", f"https://t.me/{bot_username}?game={game_command}")]
    ]
    
    await event.edit(text, buttons=buttons)

# ==================== دالة بدء لعبة XO من الأمر ====================
async def xo_game_from_command(event):
    user_id = event.sender_id
    xo_bot = xo_bot_settings.get(user_id, DEFAULT_XO_BOT)
    
    await event.edit(f"⎙ **جاري بدء لعبة XO...**\n⌔ **البوت:** {xo_bot}")
    
    try:
        async with client.conversation(xo_bot) as conv:
            await conv.send_message("/start")
            await asyncio.sleep(1)
            await conv.send_message("/new")
            
            response = await conv.get_response()
            
            if response.text:
                game_link = re.search(r"(https?://[^\s]+)", response.text)
                
                if game_link:
                    game_url = game_link.group(1)
                    
                    text = f"🎮 **لعبة XO**\n\n"
                    text += f"⌔ **اللاعب الأول:** أنت\n"
                    text += f"⌔ **اللاعب الثاني:** خصمك\n\n"
                    text += f"🔗 **رابط اللعبة:**\n{game_url}\n\n"
                    text += "📌 *اضغط على الرابط للبدء*"
                    
                    await event.edit(text)
                else:
                    await event.edit("✘ **لم يتم العثور على رابط اللعبة في رد البوت**")
            else:
                await event.edit("✘ **لم يتم استلام رد من البوت**")
                
    except Exception as e:
        error_msg = str(e)
        if "PEER_ID_INVALID" in error_msg or "Cannot find any entity" in error_msg:
            await event.edit(f"✘ **البوت {xo_bot} غير موجود**\n⌔ *استخدم* `.تبديل xo` *لتغيير البوت*")
        else:
            await event.edit(f"✘ **فشل بدء اللعبة:** {error_msg[:100]}")


# ==================== 3. أمر .خمنها (أكيناتور) ====================
@client.on(events.NewMessage(pattern=r'\.خمنها', outgoing=True))
async def akinator_start(event):
    try:
        import akinator
    except ImportError:
        os.system("pip install akinator.py")
        import akinator

    sta = akinator.Akinator()
    games.update({event.chat_id: {event.id: sta}})

    try:
        m = await client.inline_query(
            "zero_bot",
            f"aki_{event.chat_id}_{event.id}"
        )
        await m[0].click(event.chat_id)
    except BotMethodInvalidError:
        await event.edit("**حـاول مجـدداً مـرة اخـرى**")
        return

    if event.out:
        await event.delete()


# ==================== استقبال ضغطات أزرار أكيناتور ====================
@tgbot.on(events.CallbackQuery(data=re.compile(b"aki_?(.*)")))
async def akinator_callback(event):
    adt = event.pattern_match.group(1).strip().decode("utf-8")
    dt = adt.split("_")
    ch = int(dt[0])
    mid = int(dt[1])

    await event.edit("**جـارِ التحقق الان انتظـر ...**")

    try:
        qu = games[ch][mid].start_game(child_mode=True)
    except KeyError:
        await event.answer("تم إنهاء اللعبة", alert=True)
        return

    bts = [Button.inline(o, f"aka_{adt}_{o}") for o in ["نعم", "لا", "لا اعرف"]]
    cts = [Button.inline(o, f"aka_{adt}_{o}") for o in ["ربما", "ربما لا"]]

    bts = [bts, cts]
    await event.edit(f"س. {qu}", buttons=bts)


@tgbot.on(events.CallbackQuery(data=re.compile(b"aka_?(.*)")))
async def akinator_answer(event):
    mk = event.pattern_match.group(1).decode("utf-8").split("_")
    ch = int(mk[0])
    mid = int(mk[1])
    ans = mk[2]

    try:
        gm = games[ch][mid]
    except KeyError:
        await event.answer("- انتهـى الوقت")
        return

    text = gm.answer(ans)

    if gm.progression >= 80:
        gm.win()
        gs = gm.first_guess
        text = "انه " + gs["name"] + "\n " + gs["description"]
        return await event.edit(text, file=gs["absolute_picture_path"])

    bts = [Button.inline(o, f"aka_{ch}_{mid}_{o}") for o in ["نعم", "لا", "لا اعرف"]]
    cts = [Button.inline(o, f"aka_{ch}_{mid}_{o}") for o in ["ربما", "ربما لا"]]

    bts = [bts, cts]
    await event.edit(text, buttons=bts)

# ==================== استقبال InlineQuery من البوت المساعد ====================
@tgbot.on(events.InlineQuery)
async def akinator_inline(event):
    query_user_id = event.query.user_id
    query = event.text
    string = query.lower()

    if string.startswith("aki"):
        ans = [
            await event.builder.photo(
                "https://graph.org/file/b0ff07069e8637783fdae.jpg",
                text=query,
                buttons=[Button.inline("ابدأ اللعب", data=event.text)],
            )
        ]
        await event.answer(ans)
        
# ==================== 4. أمر .xo ====================
@client.on(events.NewMessage(pattern=r'\.xo', outgoing=True))
async def xo_game(event):
    await xo_game_from_command(event)

# ==================== 5. أمر .تبديل xo ====================
@client.on(events.NewMessage(pattern=r'\.تبديل xo\s+(@\w+)', outgoing=True))
async def switch_xo_bot(event):
    bot_username = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    xo_bot_settings[user_id] = bot_username
    
    await event.edit(f"✓ **تم تغيير بوت XO إلى:** {bot_username}")

# ==================== 6. أمر .عرض بوت xo ====================
@client.on(events.NewMessage(pattern=r'\.عرض بوت xo', outgoing=True))
async def show_xo_bot(event):
    user_id = event.sender_id
    current_bot = xo_bot_settings.get(user_id, DEFAULT_XO_BOT)
    
    await event.edit(
        f"🎮 **بوت XO الحالي:** {current_bot}\n\n"
        f"📌 **لتغييره:** `.تبديل xo @البوت`"
    )

# ==================== 7. أمر .وعد ====================
@client.on(events.NewMessage(pattern=r'\.وعد\s+([\s\S]+)', outgoing=True))
async def promise_game(event):
    promise_text = event.pattern_match.group(1).strip()
    
    text = f"🤝 **الوعد:**\n\n{promise_text}\n\n"
    text += f"1️⃣ **للعب الفردي:** [اضغط هنا](https://t.me/gamee?game=Promise)\n"
    text += f"2️⃣ **للعب مع الأصدقاء:** اضغط الزر أدناه 👇\n"
    
    buttons = [
        [Button.switch_inline(f"🎮 اختر محادثة للعب", query="Promise", same_peer=False)],
        [Button.url("🔗 رابط اللعبة المباشر", "https://t.me/gamee?game=Promise")]
    ]
    
    await event.edit(text, buttons=buttons)

# ==================== 8. اختصارات الألعاب ====================
@client.on(events.NewMessage(pattern=r'\.فلابي', outgoing=True))
async def flappy_game(event):
    await start_game_direct(event, "FlappyBird", "🐦 فلابي بيرد")

@client.on(events.NewMessage(pattern=r'\.شطرنج', outgoing=True))
async def chess_game(event):
    await start_game_direct_t4(event, "chess", "♟️ شطرنج")

@client.on(events.NewMessage(pattern=r'\.سباق', outgoing=True))
async def race_game(event):
    await start_game_direct(event, "F1Racer", "🏎️ سباق سيارات")

@client.on(events.NewMessage(pattern=r'\.المحبيس', outgoing=True))
async def prison_game(event):
    await start_game_direct(event, "Prison", "🚔 المحبيس")

# ==================== دوال مساعدة: بدء لعبة مباشرة ====================
async def start_game_direct(event, game_command, game_name):
    text = f"🎮 **{game_name}**\n\n"
    text += f"1️⃣ **للعب الفردي:** [اضغط هنا](https://t.me/gamee?game={game_command})\n"
    text += f"2️⃣ **للعب مع الأصدقاء:** اضغط الزر أدناه 👇\n"
    
    buttons = [
        [Button.switch_inline(f"🎮 اختر محادثة للعب", query=f"{game_command}", same_peer=False)],
        [Button.url("🔗 رابط اللعبة المباشر", f"https://t.me/gamee?game={game_command}")]
    ]
    
    await event.edit(text, buttons=buttons)

async def start_game_direct_t4(event, game_command, game_name):
    text = f"🎮 **{game_name}**\n\n"
    text += f"1️⃣ **للعب الفردي:** [اضغط هنا](https://t.me/T4TTTTBOT?game={game_command})\n"
    text += f"2️⃣ **للعب مع الأصدقاء:** اضغط الزر أدناه 👇\n"
    
    buttons = [
        [Button.switch_inline(f"🎮 اختر محادثة للعب", query=f"{game_command}", same_peer=False)],
        [Button.url("🔗 رابط اللعبة المباشر", f"https://t.me/T4TTTTBOT?game={game_command}")]
    ]
    
    await event.edit(text, buttons=buttons)