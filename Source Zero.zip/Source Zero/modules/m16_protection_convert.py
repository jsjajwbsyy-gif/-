import os
import subprocess
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

protection_settings = {}
exceptions_list = {}

# ==================== الأمر الرئيسي .م16 ====================
@client.on(events.NewMessage(pattern=r'\.م16', outgoing=True))
async def show_m16_menu(event):
    menu_text = """⌯━━〔 🛡️ * الحماية والتحويل* 〕━━⌯

✶ اختر امراً فرعياً:
   ↢  `.اوامر الحماية` 
   ↢  `.اوامر التحويل`"""
    await event.edit(menu_text)

# ==================== 1. أمر .اوامر الحماية ====================
@client.on(events.NewMessage(pattern=r'\.اوامر الحماية', outgoing=True))
async def show_protection_commands(event):
    menu_text = """⟪───── حماية الخاص ─────⟫

│ `.قفل/فتح الصور`
│ ← يمنع أي صور جديدة توصلك

│ `.قفل/فتح المتحركة`
│ ← يمنع أي متحركات جديدة

│ `.قفل/فتح الملصقات`
│ ← يمنع أي ملصقات جديدة

│ `.قفل/فتح التحويل`
│ ← يمنع أي رسائل محولة جديدة

│ `.قفل/فتح الفيديوهات`
│ ← يمنع أي فيديوهات جديدة

│ `.قفل/فتح الخاص`
│ ← يحظر كل الرسائل الواردة

│ `.قفل/فتح الصوت`
│ ← يمنع أي فويزات جديدة

│ `.استثناء | .حذف الاستثناء`
│ ← يسمح لك بمحادثة شخص اثناء القفل
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 2. أمر .اوامر التحويل ====================
@client.on(events.NewMessage(pattern=r'\.اوامر التحويل', outgoing=True))
async def show_convert_commands(event):
    menu_text = """⟪───── أوامر تحويل الصيغ ─────⟫

│ `.ملصق`
│ ← بالرد على صورة لتحويلها لملصق

│ `.صوره`
│ ← بالرد على ملصق لتحويله لصورة

│ `.متحركة`
│ ← بالرد على فيديو، صورة، أو ملصق لتحويله لمتحركة

│ `.صوت`
│ ← بالرد على فيديو لاستخراج الصوت فقط

│ `.تحويل`
│ ← بالرد على أي نص لتحويله لملصق
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== دالة مساعدة: تهيئة إعدادات الحماية ====================
def init_protection_settings(user_id):
    if user_id not in protection_settings:
        protection_settings[user_id] = {
            "photos": False,
            "animations": False,
            "stickers": False,
            "forwarded": False,
            "videos": False,
            "private_lock": False,
            "voice": False
        }

# ==================== أوامر الحماية ====================
@client.on(events.NewMessage(pattern=r'\.قفل الصور', outgoing=True))
async def lock_photos(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["photos"] = True
    await event.edit("🔒 **تم قفل الصور**")

@client.on(events.NewMessage(pattern=r'\.فتح الصور', outgoing=True))
async def unlock_photos(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["photos"] = False
    await event.edit("🔓 **تم فتح الصور**")

@client.on(events.NewMessage(pattern=r'\.قفل المتحركة', outgoing=True))
async def lock_animations(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["animations"] = True
    await event.edit("🔒 **تم قفل المتحركة**")

@client.on(events.NewMessage(pattern=r'\.فتح المتحركة', outgoing=True))
async def unlock_animations(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["animations"] = False
    await event.edit("🔓 **تم فتح المتحركة**")

@client.on(events.NewMessage(pattern=r'\.قفل الملصقات', outgoing=True))
async def lock_stickers(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["stickers"] = True
    await event.edit("🔒 **تم قفل الملصقات**")

@client.on(events.NewMessage(pattern=r'\.فتح الملصقات', outgoing=True))
async def unlock_stickers(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["stickers"] = False
    await event.edit("🔓 **تم فتح الملصقات**")

@client.on(events.NewMessage(pattern=r'\.قفل التحويل', outgoing=True))
async def lock_forwarded(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["forwarded"] = True
    await event.edit("🔒 **تم قفل التحويل**")

@client.on(events.NewMessage(pattern=r'\.فتح التحويل', outgoing=True))
async def unlock_forwarded(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["forwarded"] = False
    await event.edit("🔓 **تم فتح التحويل**")

@client.on(events.NewMessage(pattern=r'\.قفل الفيديوهات', outgoing=True))
async def lock_videos(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["videos"] = True
    await event.edit("🔒 **تم قفل الفيديوهات**")

@client.on(events.NewMessage(pattern=r'\.فتح الفيديوهات', outgoing=True))
async def unlock_videos(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["videos"] = False
    await event.edit("🔓 **تم فتح الفيديوهات**")

@client.on(events.NewMessage(pattern=r'\.قفل الخاص', outgoing=True))
async def lock_private(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["private_lock"] = True
    await event.edit("🔒 **تم قفل الخاص - سيتم حظر كل الرسائل الواردة**")

@client.on(events.NewMessage(pattern=r'\.فتح الخاص', outgoing=True))
async def unlock_private(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["private_lock"] = False
    await event.edit("🔓 **تم فتح الخاص**")

@client.on(events.NewMessage(pattern=r'\.قفل الصوت', outgoing=True))
async def lock_voice(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["voice"] = True
    await event.edit("🔒 **تم قفل الصوت**")

@client.on(events.NewMessage(pattern=r'\.فتح الصوت', outgoing=True))
async def unlock_voice(event):
    user_id = event.sender_id
    init_protection_settings(user_id)
    protection_settings[user_id]["voice"] = False
    await event.edit("🔓 **تم فتح الصوت**")

# ==================== أوامر الاستثناء ====================
@client.on(events.NewMessage(pattern=r'\.استثناء', outgoing=True))
async def add_exception(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص الذي تريد استثناءه**")
        return
    
    target_user = await reply.get_sender()
    my_id = event.sender_id
    
    if my_id not in exceptions_list:
        exceptions_list[my_id] = []
    
    if target_user.id not in exceptions_list[my_id]:
        exceptions_list[my_id].append(target_user.id)
        name = f"@{target_user.username}" if target_user.username else target_user.first_name
        await event.edit(f"✅ **تم استثناء:** {name}")
    else:
        await event.edit("❌ **هذا الشخص مستثنى بالفعل**")

@client.on(events.NewMessage(pattern=r'\.حذف الاستثناء', outgoing=True))
async def remove_exception(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return
    
    target_user = await reply.get_sender()
    my_id = event.sender_id
    
    if my_id in exceptions_list and target_user.id in exceptions_list[my_id]:
        exceptions_list[my_id].remove(target_user.id)
        name = f"@{target_user.username}" if target_user.username else target_user.first_name
        await event.edit(f"✅ **تم حذف الاستثناء:** {name}")
    else:
        await event.edit("❌ **هذا الشخص ليس في قائمة الاستثناءات**")

# ==================== معالج الحماية ====================
@client.on(events.NewMessage(incoming=True))
async def protection_handler_private(event):
    if not event.is_private:
        return
    
    my_id = (await client.get_me()).id
    sender_id = event.sender_id
    
    if sender_id == my_id:
        return
    
    if my_id not in protection_settings:
        return
    
    settings = protection_settings[my_id]
    
    if my_id in exceptions_list and sender_id in exceptions_list[my_id]:
        return
    
    if settings.get("private_lock", False):
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("photos", False) and event.photo:
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("animations", False) and event.gif:
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("stickers", False) and event.sticker:
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("forwarded", False) and event.forward:
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("videos", False) and event.video:
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("voice", False) and event.voice:
        try:
            await event.delete()
        except:
            pass
        return

# ==================== أوامر التحويل ====================
@client.on(events.NewMessage(pattern=r'\.ملصق', outgoing=True))
async def convert_to_sticker(event):
    reply = await event.get_reply_message()
    if not reply or not reply.photo:
        await event.edit("❌ **يرجى الرد على صورة**")
        return
    
    await event.edit("🎯 **جاري تحويل الصورة إلى ملصق...**")
    
    try:
        photo_bytes = await client.download_file(reply.photo)
        await client.send_file(event.chat_id, photo_bytes, force_document=False)
        await event.delete()
    except Exception as e:
        await event.edit(f"❌ **فشل التحويل:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.صوره', outgoing=True))
async def convert_to_photo(event):
    reply = await event.get_reply_message()
    if not reply or not reply.sticker:
        await event.edit("❌ **يرجى الرد على ملصق**")
        return
    
    await event.edit("🖼️ **جاري تحويل الملصق إلى صورة...**")
    
    try:
        sticker_bytes = await client.download_file(reply.sticker)
        await client.send_file(event.chat_id, sticker_bytes, force_document=False)
        await event.delete()
    except Exception as e:
        await event.edit(f"❌ **فشل التحويل:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.متحركة', outgoing=True))
async def convert_to_gif(event):
    reply = await event.get_reply_message()
    
    if not reply:
        await event.edit("❌ **يرجى الرد على فيديو، صورة، أو ملصق**")
        return
    
    if not (reply.video or reply.gif or reply.photo or reply.sticker):
        await event.edit("❌ **الرسالة لا تحتوي على فيديو، صورة، أو ملصق**")
        return
    
    await event.edit("🎬 **جاري التحويل إلى متحركة...**")
    
    try:
        if reply.video:
            media = reply.video
        elif reply.gif:
            media = reply.gif
        elif reply.photo:
            media = reply.photo
        else:
            media = reply.sticker
        
        media_bytes = await client.download_file(media)
        await client.send_file(event.chat_id, media_bytes, force_document=False)
        await event.delete()
    except Exception as e:
        await event.edit(f"❌ **فشل التحويل:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.صوت', outgoing=True))
async def extract_audio(event):
    reply = await event.get_reply_message()
    
    if not reply or not reply.video:
        await event.edit("❌ **يرجى الرد على فيديو**")
        return
    
    await event.edit("🎵 **جاري استخراج الصوت...**")
    
    try:
        video_bytes = await client.download_file(reply.video)
        
        input_path = "input_video.mp4"
        output_path = "output_audio.mp3"
        
        with open(input_path, "wb") as f:
            f.write(video_bytes)
        
        subprocess.run(["ffmpeg", "-i", input_path, "-q:a", "0", "-map", "a", output_path, "-y"], check=True, capture_output=True)
        
        await client.send_file(event.chat_id, output_path, force_document=False)
        await event.delete()
        
        os.remove(input_path)
        os.remove(output_path)
        
    except Exception as e:
        await event.edit(f"❌ **فشل استخراج الصوت:**\n*تأكد من تثبيت ffmpeg*")

@client.on(events.NewMessage(pattern=r'\.تحويل', outgoing=True))
async def convert_text_to_sticker_cmd(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على نص**")
        return
    
    await event.edit("🎯 **جاري تحويل النص إلى ملصق...**")
    
    try:
        from PIL import Image, ImageDraw, ImageFont
        
        text = reply.text[:100]
        
        img = Image.new('RGB', (512, 512), color=(255, 255, 255))
        draw = ImageDraw.Draw(img)
        
        try:
            font = ImageFont.truetype("arial.ttf", 40)
        except:
            font = ImageFont.load_default()
        
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        x = (512 - text_width) // 2
        y = (512 - text_height) // 2
        draw.text((x, y), text, fill=(0, 0, 0), font=font)
        
        img_path = "text_sticker.png"
        img.save(img_path)
        
        await client.send_file(event.chat_id, img_path, force_document=False)
        await event.delete()
        
        os.remove(img_path)
        
    except Exception as e:
        await event.edit(f"❌ **فشل التحويل:**\n*تأكد من تثبيت Pillow* (`pip install Pillow`)")