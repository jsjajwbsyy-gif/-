import requests
from telethon import events, Button
from telethon.tl.functions.messages import ExportChatInviteRequest

from main import client, tgbot, TG_BOT_TOKEN

force_subscribe_channels = {}
force_subscribe_enabled = {}
force_subscribe_message = {}

# ==================== عرض قائمة الأوامر (.م12) ====================
@client.on(events.NewMessage(pattern=r'\.م12', outgoing=True))
async def show_force_subscribe_menu(event):
    menu_text = """⟪───── أوامر الاشتراك الإجباري ─────⟫

│ `.اضف_اشتراك` @اليوزر
│ ← اضافة قناة للاشتراك الاجباري

│ `.حذف_قناة` @اليوزر
│ ← حذف قناة محددة من الاشتراك

│ `.تعطيل الاشتراك`
│ ← تعطيل الاشتراك الاجباري وحذف الكل

│ `.قنوات_الاشتراك`
│ ← عرض القنوات المفعلة

│ `.تحقق`
│ ← تحقق يدوي من حالة اشتراكك

│ `.تعيين كليشة الاشتراك` (بالرد على نص)
│ ← تعيين رسالة مخصصة للاشتراك الاجباري

│ `.عرض الكليشة`
│ ← عرض كليشة الاشتراك الحالية
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 1. أمر .اضف_اشتراك ====================
@client.on(events.NewMessage(pattern=r'\.اضف_اشتراك\s+(@\w+)', outgoing=True))
async def add_force_subscribe(event):
    channel_username = event.pattern_match.group(1).strip()
    user_id = event.sender_id

    try:
        channel = await client.get_entity(channel_username)

        if user_id not in force_subscribe_channels:
            force_subscribe_channels[user_id] = []

        if channel_username not in force_subscribe_channels[user_id]:
            force_subscribe_channels[user_id].append(channel_username)

        force_subscribe_enabled[user_id] = True

        channels_list = "\n".join([f"• {ch}" for ch in force_subscribe_channels[user_id]])

        await event.edit(f"✅ **تم تعيين القناة:** {channel_username}\n\n📋 **القنوات المفعلة:**\n{channels_list}")

    except Exception as e:
        await event.edit(f"❌ **القناة غير موجودة**\n*تأكد من اليوزر*")

# ==================== 2. أمر .تعطيل الاشتراك ====================
@client.on(events.NewMessage(pattern=r'\.تعطيل الاشتراك', outgoing=True))
async def disable_force_subscribe(event):
    user_id = event.sender_id

    if user_id in force_subscribe_channels:
        del force_subscribe_channels[user_id]

    force_subscribe_enabled[user_id] = False

    if user_id in force_subscribe_message:
        del force_subscribe_message[user_id]

    await event.edit("🗑 **تم تعطيل الاشتراك الاجباري وحذف جميع القنوات والكليشة**")

# ==================== 3. أمر .حذف_قناة ====================
@client.on(events.NewMessage(pattern=r'\.حذف_قناة\s+(@\w+)', outgoing=True))
async def remove_force_subscribe_channel(event):
    channel_username = event.pattern_match.group(1).strip()
    user_id = event.sender_id

    if user_id in force_subscribe_channels and channel_username in force_subscribe_channels[user_id]:
        force_subscribe_channels[user_id].remove(channel_username)

        if force_subscribe_channels[user_id]:
            channels_list = "\n".join([f"• {ch}" for ch in force_subscribe_channels[user_id]])
            await event.edit(f"✅ **تم حذف القناة:** {channel_username}\n\n📋 **القنوات المتبقية:**\n{channels_list}")
        else:
            force_subscribe_enabled[user_id] = False
            await event.edit(f"✅ **تم حذف القناة:** {channel_username}\n\n📭 **لا توجد قنوات مفعلة**")
    else:
        await event.edit(f"❌ **القناة غير موجودة:** {channel_username}")

# ==================== 4. أمر .قنوات_الاشتراك ====================
@client.on(events.NewMessage(pattern=r'\.قنوات_الاشتراك', outgoing=True))
async def show_force_subscribe_channels(event):
    user_id = event.sender_id

    if user_id in force_subscribe_channels and force_subscribe_channels[user_id]:
        channels_list = "\n".join([f"• {ch}" for ch in force_subscribe_channels[user_id]])
        status = "✅ مفعل" if force_subscribe_enabled.get(user_id, False) else "🔴 معطل"
        await event.edit(f"📋 **قنوات الاشتراك الإجباري**\n\n**الحالة:** {status}\n\n{channels_list}")
    else:
        await event.edit("📭 **لا توجد قنوات مفعلة**")

# ==================== 5. أمر .تحقق ====================
@client.on(events.NewMessage(pattern=r'\.تحقق', outgoing=True))
async def manual_check_subscribe(event):
    my_id = event.sender_id

    if my_id not in force_subscribe_channels or not force_subscribe_channels[my_id]:
        await event.edit("ℹ️ **الاشتراك الإجباري غير مفعل**")
        return

    channels = force_subscribe_channels[my_id]
    status_list = []

    for channel_username in channels:
        is_subscribed = await check_subscription(event.sender_id, channel_username)
        if is_subscribed:
            status_list.append(f"✅ {channel_username} - مشترك")
        else:
            status_list.append(f"❌ {channel_username} - غير مشترك")

    await event.edit("\n".join(status_list))

# ==================== 6. أمر .تعيين كليشة الاشتراك (بالرد على نص) ====================
@client.on(events.NewMessage(pattern=r'\.تعيين كليشة الاشتراك', outgoing=True))
async def set_subscribe_message(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على رسالة تحتوي على الكليشة المطلوبة**")
        return

    user_id = event.sender_id
    force_subscribe_message[user_id] = reply.text

    await event.edit(f"✅ **تم تعيين كليشة الاشتراك:**\n\n{reply.text[:200]}...")

# ==================== 7. أمر .عرض الكليشة ====================
@client.on(events.NewMessage(pattern=r'\.عرض الكليشة', outgoing=True))
async def show_subscribe_message(event):
    user_id = event.sender_id

    if user_id in force_subscribe_message:
        msg = force_subscribe_message[user_id]
        await event.edit(f"📋 **كليشة الاشتراك الحالية:**\n\n{msg}")
    else:
        await event.edit("📭 **لا توجد كليشة مخصصة**\n*يتم استخدام الكليشة الافتراضية*")

# ==================== دالة التحقق السريع بالبوت المساعد ====================
async def check_subscription(user_id, channel_username):
    try:
        url = f"https://api.telegram.org/bot{TG_BOT_TOKEN}/getChatMember?chat_id={channel_username}&user_id={user_id}"
        req = requests.get(url, timeout=5)
        data = req.json()

        if data.get("ok"):
            status = data["result"]["status"]
            if status in ["member", "administrator", "creator"]:
                return True
        return False
    except:
        try:
            participants = await client.get_participants(channel_username)
            participant_ids = [p.id for p in participants]
            return user_id in participant_ids
        except:
            return False

# ==================== معالج التحقق التلقائي ====================
@client.on(events.NewMessage(incoming=True))
async def auto_check_force_subscribe(event):
    if not event.is_private:
        return

    my_id = (await client.get_me()).id
    sender_id = event.sender_id

    if sender_id == my_id:
        return

    if my_id not in force_subscribe_enabled or not force_subscribe_enabled[my_id]:
        return

    if my_id not in force_subscribe_channels or not force_subscribe_channels[my_id]:
        return

    channels = force_subscribe_channels[my_id]
    not_subscribed = []

    for channel_username in channels:
        is_subscribed = await check_subscription(sender_id, channel_username)
        if not is_subscribed:
            not_subscribed.append(channel_username)

    if not_subscribed:
        channels_text = "\n".join([f"• {ch}" for ch in not_subscribed])

        buttons = []
        for ch in not_subscribed:
            try:
                ch_entity = await client.get_entity(ch)
                if ch_entity.username:
                    link = f"https://t.me/{ch_entity.username}"
                else:
                    invite = await client(ExportChatInviteRequest(ch))
                    link = invite.link if hasattr(invite, 'link') else f"https://t.me/joinchat/{invite.invite_hash}"
                buttons.append([Button.url(f"اشترك في {ch}", link)])
            except:
                pass

        # استخدام الكليشة المخصصة أو الافتراضية
        if my_id in force_subscribe_message:
            warning_message = force_subscribe_message[my_id]
        else:
            warning_message = f"""⚠️ **عذراً، لا يمكنك مراسلتي حالياً**

📢 **يجب عليك الاشتراك في القنوات التالية أولاً:**

{channels_text}

✅ **بعد الاشتراك، أرسل أي رسالة للمتابعة**"""

        if buttons:
            await event.reply(warning_message, buttons=buttons)
        else:
            await event.reply(warning_message)

        try:
            await event.delete()
        except:
            pass