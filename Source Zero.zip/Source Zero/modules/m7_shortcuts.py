from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

shortcuts = {}
shortcuts_enabled = {}

# ==================== عرض قائمة الأوامر (.م7) ====================
@client.on(events.NewMessage(pattern=r'\.م7', outgoing=True))
async def show_shortcuts_menu(event):
    menu_text = """⟪───── أوامر الاختصارات ─────⟫

│ `.اختصار + كلمة او حرف`
│ ← بالرد على رسالة لحفظها كاختصار بالكلمة المحددة.

│ `.اختصاراتي`
│ ← لعرض جميع اختصاراتك.

│ `.حذف اختصاراتي`
│ ← لحذف كل الاختصارات.

│ `.حذف اختصار+الحرف`
│ ← لحذف اختصار محدد فقط.

│ `.تشغيل الاختصارات`
│ ← لتفعيل عمل الاختصارات.

│ `.ايقاف الاختصارات`
│ ← لتعطيل عمل الاختصارات.
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 1. أمر .اختصار ====================
@client.on(events.NewMessage(pattern=r'\.اختصار\s+(\S+)', outgoing=True))
async def add_shortcut(event):
    keyword = event.pattern_match.group(1).strip()
    reply = await event.get_reply_message()
    
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة لحفظها كاختصار**")
        return
    
    user_id = event.sender_id
    
    if user_id not in shortcuts:
        shortcuts[user_id] = {}
    
    shortcut_data = {"type": "text", "content": None, "media_id": None, "caption": None}
    
    if reply.text:
        shortcut_data["type"] = "text"
        shortcut_data["content"] = reply.text
    elif reply.photo:
        shortcut_data["type"] = "photo"
        shortcut_data["media_id"] = reply.photo.id
        shortcut_data["caption"] = reply.text or ""
    elif reply.video:
        shortcut_data["type"] = "video"
        shortcut_data["media_id"] = reply.video.id
        shortcut_data["caption"] = reply.text or ""
    elif reply.audio:
        shortcut_data["type"] = "audio"
        shortcut_data["media_id"] = reply.audio.id
        shortcut_data["caption"] = reply.text or ""
    elif reply.voice:
        shortcut_data["type"] = "voice"
        shortcut_data["media_id"] = reply.voice.id
        shortcut_data["caption"] = reply.text or ""
    elif reply.sticker:
        shortcut_data["type"] = "sticker"
        shortcut_data["media_id"] = reply.sticker.id
    elif reply.gif:
        shortcut_data["type"] = "gif"
        shortcut_data["media_id"] = reply.gif.id
        shortcut_data["caption"] = reply.text or ""
    elif reply.document:
        shortcut_data["type"] = "document"
        shortcut_data["media_id"] = reply.document.id
        shortcut_data["caption"] = reply.text or ""
    else:
        await event.edit("❌ **نوع الرسالة غير مدعوم للاختصار**")
        return
    
    shortcuts[user_id][keyword] = shortcut_data
    await event.edit(f"✅ **تم حفظ الاختصار:** `{keyword}`")

# ==================== 2. أمر .اختصاراتي ====================
@client.on(events.NewMessage(pattern=r'\.اختصاراتي', outgoing=True))
async def show_my_shortcuts(event):
    user_id = event.sender_id
    
    if user_id not in shortcuts or not shortcuts[user_id]:
        await event.edit("📭 **لا توجد اختصارات محفوظة**")
        return
    
    text = "📋 **اختصاراتك:**\n\n"
    
    type_emoji = {
        "text": "📝", "photo": "🖼️", "video": "🎥", "audio": "🎵",
        "voice": "🎙️", "sticker": "🎯", "gif": "🎬", "document": "📄"
    }
    
    for i, (keyword, data) in enumerate(shortcuts[user_id].items(), 1):
        emoji = type_emoji.get(data["type"], "📌")
        text += f"{i}. {emoji} `{keyword}` ({data['type']})\n"
    
    await event.edit(text)

# ==================== 3. أمر .حذف اختصاراتي ====================
@client.on(events.NewMessage(pattern=r'\.حذف اختصاراتي', outgoing=True))
async def delete_all_shortcuts(event):
    user_id = event.sender_id
    
    if user_id in shortcuts:
        count = len(shortcuts[user_id])
        shortcuts[user_id] = {}
        await event.edit(f"✅ **تم حذف {count} اختصار**")
    else:
        await event.edit("📭 **لا توجد اختصارات للحذف**")

# ==================== 4. أمر .حذف اختصار ====================
@client.on(events.NewMessage(pattern=r'\.حذف اختصار\s+(\S+)', outgoing=True))
async def delete_single_shortcut(event):
    keyword = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id in shortcuts and keyword in shortcuts[user_id]:
        del shortcuts[user_id][keyword]
        await event.edit(f"✅ **تم حذف الاختصار:** `{keyword}`")
    else:
        await event.edit(f"❌ **الاختصار غير موجود:** `{keyword}`")

# ==================== 5. أمر .تشغيل الاختصارات ====================
@client.on(events.NewMessage(pattern=r'\.تشغيل الاختصارات', outgoing=True))
async def enable_shortcuts(event):
    chat_id = event.chat_id
    user_id = event.sender_id
    
    if user_id not in shortcuts_enabled:
        shortcuts_enabled[user_id] = {}
    
    shortcuts_enabled[user_id][chat_id] = True
    await event.edit("✅ **تم تفعيل الاختصارات في هذه الدردشة**")

# ==================== 6. أمر .ايقاف الاختصارات ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف الاختصارات', outgoing=True))
async def disable_shortcuts(event):
    chat_id = event.chat_id
    user_id = event.sender_id
    
    if user_id not in shortcuts_enabled:
        shortcuts_enabled[user_id] = {}
    
    shortcuts_enabled[user_id][chat_id] = False
    await event.edit("🔴 **تم تعطيل الاختصارات في هذه الدردشة**")

# ==================== معالج استقبال الاختصارات ====================
@client.on(events.NewMessage(outgoing=True))
async def handle_shortcuts(event):
    if not event.text:
        return
    
    chat_id = event.chat_id
    text = event.text.strip()
    my_id = (await client.get_me()).id
    
    # التحقق من تفعيل الاختصارات لهذه الدردشة
    if my_id not in shortcuts_enabled:
        return
    
    if not shortcuts_enabled[my_id].get(chat_id, False):
        return
    
    # التحقق من وجود اختصارات للمستخدم
    if my_id not in shortcuts or not shortcuts[my_id]:
        return
    
    # البحث عن الاختصار
    for keyword, data in shortcuts[my_id].items():
        if text == keyword:
            try:
                if data["type"] == "text":
                    await event.edit(data["content"])
                
                elif data["type"] == "photo":
                    await event.delete()
                    await client.send_file(chat_id, data["media_id"], caption=data.get("caption", ""))
                
                elif data["type"] == "video":
                    await event.delete()
                    await client.send_file(chat_id, data["media_id"], caption=data.get("caption", ""))
                
                elif data["type"] == "audio":
                    await event.delete()
                    await client.send_file(chat_id, data["media_id"], caption=data.get("caption", ""))
                
                elif data["type"] == "voice":
                    await event.delete()
                    await client.send_file(chat_id, data["media_id"])
                
                elif data["type"] == "sticker":
                    await event.delete()
                    await client.send_file(chat_id, data["media_id"])
                
                elif data["type"] == "gif":
                    await event.delete()
                    await client.send_file(chat_id, data["media_id"], caption=data.get("caption", ""))
                
                elif data["type"] == "document":
                    await event.delete()
                    await client.send_file(chat_id, data["media_id"], caption=data.get("caption", ""))
                
                break
                
            except Exception as e:
                pass