from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

custom_settings = {}

# ==================== عرض قائمة الأوامر (.م20) ====================
@client.on(events.NewMessage(pattern=r'\.م20', outgoing=True))
async def show_customize_menu(event):
    menu_text = """⟪───── أوامر التخصيص ─────⟫

│ `.تعيين صورة الفحص`
│ `.حذف صورة الفحص`
│ `.تعيين كليشة الفحص`

│ `.تعيين صورة الاوامر`
│ `.حذف صورة الاوامر`

│ `.تعيين كليشة الاوامر`
│ `.حذف كليشة الاوامر`

│ `.تعيين كليشة الاشتراك`
│ `.تعيين صورة الاشتراك`

│ `.تعيين صورة الرد`
│ `.تعيين كليشة الرد`

│ `.تعيين صورة الحظر`
│ `.تعيين كليشة الحظر`

│ `.تعيين كليشة الايدي`
│ `.حذف كليشة الايدي`

│ `.تعيين صورة الايدي`
│ `.حذف صورة الايدي`

ملاحظة:  
↢ كل الأوامر تستخدم بالرد  
↢ يمكنك تحديد صورة، فيديو، أو متحركة
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== دالة مساعدة: حفظ التخصيص ====================
def save_custom_setting(user_id, setting_name, value, setting_type="text"):
    if user_id not in custom_settings:
        custom_settings[user_id] = {}
    
    custom_settings[user_id][setting_name] = {
        "value": value,
        "type": setting_type
    }

# ==================== دالة مساعدة: استخراج الوسائط من الرد ====================
async def extract_media_from_reply(event):
    reply = await event.get_reply_message()
    if not reply:
        return None, None, None
    
    if reply.photo:
        return "photo", reply.photo.id, reply.text
    elif reply.video:
        return "video", reply.video.id, reply.text
    elif reply.gif:
        return "gif", reply.gif.id, reply.text
    elif reply.sticker:
        return "sticker", reply.sticker.id, None
    elif reply.text:
        return "text", reply.text, None
    
    return None, None, None

# ==================== أوامر الفحص ====================
@client.on(events.NewMessage(pattern=r'\.تعيين صورة الفحص', outgoing=True))
async def set_check_photo(event):
    media_type, file_id, caption = await extract_media_from_reply(event)
    
    if media_type not in ["photo", "video", "gif"]:
        await event.edit("✘ **يرجى الرد على صورة، فيديو، أو متحركة**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "check_photo", file_id, media_type)
    await event.edit("✓ **تم تعيين صورة الفحص بنجاح**")

@client.on(events.NewMessage(pattern=r'\.حذف صورة الفحص', outgoing=True))
async def delete_check_photo(event):
    user_id = event.sender_id
    if user_id in custom_settings and "check_photo" in custom_settings[user_id]:
        del custom_settings[user_id]["check_photo"]
        await event.edit("⌫ **تم حذف صورة الفحص**")
    else:
        await event.edit("✘ **لا توجد صورة فحص مخصصة**")

@client.on(events.NewMessage(pattern=r'\.تعيين كليشة الفحص', outgoing=True))
async def set_check_text(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("✘ **يرجى الرد على نص**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "check_text", reply.text, "text")
    await event.edit("✓ **تم تعيين كليشة الفحص بنجاح**")

# ==================== أوامر الاوامر (القائمة الرئيسية) ====================
@client.on(events.NewMessage(pattern=r'\.تعيين صورة الاوامر', outgoing=True))
async def set_menu_photo(event):
    media_type, file_id, caption = await extract_media_from_reply(event)
    
    if media_type not in ["photo", "video", "gif"]:
        await event.edit("✘ **يرجى الرد على صورة، فيديو، أو متحركة**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "menu_photo", file_id, media_type)
    await event.edit("✓ **تم تعيين صورة الاوامر بنجاح**")

@client.on(events.NewMessage(pattern=r'\.حذف صورة الاوامر', outgoing=True))
async def delete_menu_photo(event):
    user_id = event.sender_id
    if user_id in custom_settings and "menu_photo" in custom_settings[user_id]:
        del custom_settings[user_id]["menu_photo"]
        await event.edit("⌫ **تم حذف صورة الاوامر**")
    else:
        await event.edit("✘ **لا توجد صورة اوامر مخصصة**")

@client.on(events.NewMessage(pattern=r'\.تعيين كليشة الاوامر', outgoing=True))
async def set_menu_text(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("✘ **يرجى الرد على نص**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "menu_text", reply.text, "text")
    await event.edit("✓ **تم تعيين كليشة الاوامر بنجاح**")

@client.on(events.NewMessage(pattern=r'\.حذف كليشة الاوامر', outgoing=True))
async def delete_menu_text(event):
    user_id = event.sender_id
    if user_id in custom_settings and "menu_text" in custom_settings[user_id]:
        del custom_settings[user_id]["menu_text"]
        await event.edit("⌫ **تم حذف كليشة الاوامر**")
    else:
        await event.edit("✘ **لا توجد كليشة اوامر مخصصة**")

# ==================== أوامر الاشتراك ====================
@client.on(events.NewMessage(pattern=r'\.تعيين كليشة الاشتراك', outgoing=True))
async def set_subscribe_text(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("✘ **يرجى الرد على نص**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "subscribe_text", reply.text, "text")
    await event.edit("✓ **تم تعيين كليشة الاشتراك بنجاح**")

@client.on(events.NewMessage(pattern=r'\.تعيين صورة الاشتراك', outgoing=True))
async def set_subscribe_photo(event):
    media_type, file_id, caption = await extract_media_from_reply(event)
    
    if media_type not in ["photo", "video", "gif"]:
        await event.edit("✘ **يرجى الرد على صورة، فيديو، أو متحركة**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "subscribe_photo", file_id, media_type)
    await event.edit("✓ **تم تعيين صورة الاشتراك بنجاح**")

# ==================== أوامر الرد ====================
@client.on(events.NewMessage(pattern=r'\.تعيين صورة الرد', outgoing=True))
async def set_reply_photo(event):
    media_type, file_id, caption = await extract_media_from_reply(event)
    
    if media_type not in ["photo", "video", "gif"]:
        await event.edit("✘ **يرجى الرد على صورة، فيديو، أو متحركة**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "reply_photo", file_id, media_type)
    await event.edit("✓ **تم تعيين صورة الرد بنجاح**")

@client.on(events.NewMessage(pattern=r'\.تعيين كليشة الرد', outgoing=True))
async def set_reply_text(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("✘ **يرجى الرد على نص**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "reply_text", reply.text, "text")
    await event.edit("✓ **تم تعيين كليشة الرد بنجاح**")

# ==================== أوامر الحظر ====================
@client.on(events.NewMessage(pattern=r'\.تعيين صورة الحظر', outgoing=True))
async def set_ban_photo(event):
    media_type, file_id, caption = await extract_media_from_reply(event)
    
    if media_type not in ["photo", "video", "gif"]:
        await event.edit("✘ **يرجى الرد على صورة، فيديو، أو متحركة**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "ban_photo", file_id, media_type)
    await event.edit("✓ **تم تعيين صورة الحظر بنجاح**")

@client.on(events.NewMessage(pattern=r'\.تعيين كليشة الحظر', outgoing=True))
async def set_ban_text(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("✘ **يرجى الرد على نص**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "ban_text", reply.text, "text")
    await event.edit("✓ **تم تعيين كليشة الحظر بنجاح**")

# ==================== أوامر الايدي ====================
@client.on(events.NewMessage(pattern=r'\.تعيين كليشة الايدي', outgoing=True))
async def set_id_text(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("✘ **يرجى الرد على نص**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "id_text", reply.text, "text")
    await event.edit("✓ **تم تعيين كليشة الايدي بنجاح**")

@client.on(events.NewMessage(pattern=r'\.حذف كليشة الايدي', outgoing=True))
async def delete_id_text(event):
    user_id = event.sender_id
    if user_id in custom_settings and "id_text" in custom_settings[user_id]:
        del custom_settings[user_id]["id_text"]
        await event.edit("⌫ **تم حذف كليشة الايدي**")
    else:
        await event.edit("✘ **لا توجد كليشة ايدي مخصصة**")

@client.on(events.NewMessage(pattern=r'\.تعيين صورة الايدي', outgoing=True))
async def set_id_photo(event):
    media_type, file_id, caption = await extract_media_from_reply(event)
    
    if media_type not in ["photo", "video", "gif"]:
        await event.edit("✘ **يرجى الرد على صورة، فيديو، أو متحركة**")
        return
    
    user_id = event.sender_id
    save_custom_setting(user_id, "id_photo", file_id, media_type)
    await event.edit("✓ **تم تعيين صورة الايدي بنجاح**")

@client.on(events.NewMessage(pattern=r'\.حذف صورة الايدي', outgoing=True))
async def delete_id_photo(event):
    user_id = event.sender_id
    if user_id in custom_settings and "id_photo" in custom_settings[user_id]:
        del custom_settings[user_id]["id_photo"]
        await event.edit("⌫ **تم حذف صورة الايدي**")
    else:
        await event.edit("✘ **لا توجد صورة ايدي مخصصة**")