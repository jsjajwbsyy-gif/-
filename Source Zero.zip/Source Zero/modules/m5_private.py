import asyncio
import random
from datetime import datetime
from telethon import events
from telethon.tl.types import User

from main import client

private_settings = {}
normal_replies = {}
multi_replies = {}
special_replies = {}
special_multi_replies = {}
muted_users = {}
warnings_settings = {}
afk_settings = {}

# ==================== دالة مساعدة: التحقق من أن المرسل إنسان حقيقي ====================
async def is_human(sender):
    return isinstance(sender, User) and not sender.bot

# ==================== دالة مساعدة: استبدال {name} باسم المستخدم ====================
async def replace_name_in_reply(reply_text, sender_name):
    if "{name}" in reply_text:
        return reply_text.replace("{name}", sender_name)
    return reply_text

# ==================== الأمر الرئيسي .م5 ====================
@client.on(events.NewMessage(pattern=r'\.م5', outgoing=True))
async def show_m5_menu(event):
    menu_text = """⌯━━〔 🎭 * الخاص والردود* 〕━━⌯

✶ اختر امراً فرعياً:
   ↢  `.اوامر الخاص` 
   ↢  `.اوامر الردود`"""
    await event.edit(menu_text)

# ==================== 1. أمر .اوامر الخاص ====================
@client.on(events.NewMessage(pattern=r'\.اوامر الخاص', outgoing=True))
async def show_private_commands(event):
    menu_text = """⟪───── أوامر الخاص ─────⟫

│ `.تشغيل الرد | .تعطيل الرد`
│ ← لتفعيل أو تعطيل الرد التلقائي.

│ `.تعيين كليشة الرد + النص`
│ ← لتغيير نص الرد التلقائي.

│ `.عرض كليشة الرد`
│ ← لعرض الكليشة الحالية.

│ `.غياب + السبب`
│ ← تفعيل وضع الغياب الذكي (يحسب الوقت تلقائياً)

│ `.تعطيل الغياب`
│ ← إلغاء وضع الغياب

│ `.سماح | .رفض`
│ ← للسماح أو رفض الرسائل من شخص معين.

│ `.التحذيرات + العدد`
│ ← لتحديد عدد التحذيرات قبل الحظر.

│ `.عرض التحذيرات`
│ ← لعرض إعدادات التحذيرات الحالية.

│ `تفعيل التحذيرات | تعطيل التحذيرات`
│ ← لتفعيل أو تعطيل نظام التحذيرات.

│ `.اهمس + الجملة + اليوزر`
│ ← لإرسال همسة خاصة لشخص معين.

│ `.تفعيل التخزين | .تعطيل التخزين`
│ ← لتفعيل أو تعطيل مجموعة الحفظ.

│ `.تعيين مجموعة التخزين`
│ ← لتعيين مجموعة محددة للحفظ.

│ `.كتم | .الغاء الكتم`
│ ← لكتم المستخدم داخل الخاص.

│ `.المكتومين`
│ ← لعرض قائمة المكتومين في الخاص.
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 2. أمر .اوامر الردود ====================
@client.on(events.NewMessage(pattern=r'\.اوامر الردود', outgoing=True))
async def show_reply_commands(event):
    menu_text = """⟪───── أوامر الردود ─────⟫

│ `.اضف رد | .مسح رد`
│ ← لإضافة أو مسح رد فردي.

│ `.مسح الردود الفردية`
│ ← لمسح جميع الردود الفردية.

│ `.اضف رد متعدد`
│ ← لإضافة رد متعدد (نص أو ميديا).

│ `.مسح رد متعدد`
│ ← لمسح رد متعدد محدد.

│ `.مسح الردود المتعددة`
│ ← لمسح جميع الردود المتعددة.

│ `.اضف رد مميز`
│ ← لإضافة رد مميز فردي (نص أو ميديا) بمطابقة جزئية.

│ `.مسح رد مميز`
│ ← لمسح رد مميز فردي محدد.

│ `.مسح الردود المميزة`
│ ← لمسح جميع الردود المميزة الفردية.

│ `.اضف رد مميز متعدد`
│ ← لإضافة رد مميز متعدد (نص أو ميديا).

│ `.مسح رد مميز متعدد`
│ ← لمسح رد مميز متعدد محدد.

│ `.مسح الردود المميزة المتعددة`
│ ← لمسح جميع الردود المميزة المتعددة.

│ `.تفعيل/تعطيل الردود`
│ ← لتفعيل/تعطيل الردود التلقائية في هذه الدردشة.

│ `.تفعيل/تعطيل ردود الخاص`
│ ← لتفعيل/تعطيل الردود التلقائية في كل الخاص.

│ `.الردود | .الغاء`
│ ← لعرض قائمة شاملة بجميع الردود المضافة أو لإلغاء أي عملية جارية.
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== أوامر الخاص ====================

@client.on(events.NewMessage(pattern=r'\.تشغيل الرد', outgoing=True))
async def enable_auto_reply(event):
    user_id = event.sender_id
    if user_id not in private_settings:
        private_settings[user_id] = {}
    private_settings[user_id]["auto_reply"] = True
    await event.edit("✓ تم تفعيل الرد التلقائي في الخاص")

@client.on(events.NewMessage(pattern=r'\.تعطيل الرد', outgoing=True))
async def disable_auto_reply(event):
    user_id = event.sender_id
    if user_id not in private_settings:
        private_settings[user_id] = {}
    private_settings[user_id]["auto_reply"] = False
    await event.edit("✘ تم تعطيل الرد التلقائي في الخاص")

@client.on(events.NewMessage(pattern=r'\.تعيين كليشة الرد', outgoing=True))
async def set_custom_reply_text(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("✘ يرجى الرد على رسالة تحتوي على نص الكليشة")
        return
    
    reply_text = reply.text
    user_id = event.sender_id
    
    if user_id not in private_settings:
        private_settings[user_id] = {}
    
    private_settings[user_id]["custom_reply"] = reply_text
    await event.edit(f"✓ تم تعيين كليشة الرد:\n\n{reply_text[:200]}...\n\n⌔ استخدم {name} في الكليشة ليتم استبداله باسم المرسل")

@client.on(events.NewMessage(pattern=r'\.عرض كليشة الرد', outgoing=True))
async def show_custom_reply_text(event):
    user_id = event.sender_id
    custom_reply = private_settings.get(user_id, {}).get("custom_reply", None)
    
    if custom_reply:
        await event.edit(f"⌔ كليشة الرد الحالية:\n\n{custom_reply}")
    else:
        await event.edit("⌔ الكليشة الافتراضية:\n\nمرحباً!\nالرد التلقائي مفعل حالياً")

# ==================== نظام الغياب الذكي (AFK) ====================

@client.on(events.NewMessage(pattern=r'\.غياب(?:\s+([\s\S]+))?', outgoing=True))
async def enable_afk(event):
    user_id = event.sender_id
    reason = event.pattern_match.group(1).strip() if event.pattern_match.group(1) else "بدون سبب"
    
    if user_id not in afk_settings:
        afk_settings[user_id] = {}
    
    afk_settings[user_id] = {
        "enabled": True,
        "reason": reason,
        "start_time": datetime.now()
    }
    
    await event.edit(f"✓ تم تفعيل وضع الغياب\n⌔ السبب: {reason}\n\n⌔ سيتم الرد تلقائياً على كل من يراسلك مع حساب مدة الغياب\n⌔ سينتهي الوضع تلقائياً عند إرسال أي رسالة")

@client.on(events.NewMessage(pattern=r'\.تعطيل الغياب', outgoing=True))
async def disable_afk(event):
    user_id = event.sender_id
    
    if user_id in afk_settings and afk_settings[user_id].get("enabled", False):
        start_time = afk_settings[user_id].get("start_time", datetime.now())
        afk_settings[user_id]["enabled"] = False
        
        total_seconds = int((datetime.now() - start_time).total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        
        if hours > 0:
            duration = f"{hours} ساعة و {minutes} دقيقة"
        elif minutes > 0:
            duration = f"{minutes} دقيقة و {seconds} ثانية"
        else:
            duration = f"{seconds} ثانية"
        
        await event.edit(f"✓ تم إلغاء وضع الغياب\n⌔ مدة الغياب: {duration}")
    else:
        await event.edit("✘ وضع الغياب غير مفعل حالياً")

@client.on(events.NewMessage(incoming=True))
async def afk_handler(event):
    if not event.is_private:
        return
    
    sender = await event.get_sender()
    if not await is_human(sender):
        return
    
    my_id = (await client.get_me()).id
    sender_id = event.sender_id
    
    if sender_id == my_id:
        if my_id in afk_settings and afk_settings[my_id].get("enabled", False):
            start_time = afk_settings[my_id].get("start_time", datetime.now())
            total_seconds = int((datetime.now() - start_time).total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            
            if hours > 0:
                duration = f"{hours} ساعة و {minutes} دقيقة"
            elif minutes > 0:
                duration = f"{minutes} دقيقة"
            else:
                duration = f"{total_seconds} ثانية"
            
            afk_settings[my_id]["enabled"] = False
            await event.reply(f"✓ تم إلغاء وضع الغياب تلقائياً\n⌔ مدة الغياب: {duration}")
        return
    
    if my_id in afk_settings and afk_settings[my_id].get("enabled", False):
        reason = afk_settings[my_id].get("reason", "بدون سبب")
        start_time = afk_settings[my_id].get("start_time", datetime.now())
        
        total_seconds = int((datetime.now() - start_time).total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        
        if hours > 0:
            duration = f"{hours} ساعة و {minutes} دقيقة"
        elif minutes > 0:
            duration = f"{minutes} دقيقة"
        else:
            duration = f"{total_seconds} ثانية"
        
        await event.reply(f"⌔ المستخدم في وضع الغياب\n\n⌔ غائب منذ: {duration}\n⌔ السبب: {reason}")

# ==================== سماح / رفض ====================

@client.on(events.NewMessage(pattern=r'\.سماح', outgoing=True))
async def allow_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ يرجى الرد على رسالة الشخص")
        return
    
    user_id = reply.sender_id
    my_id = event.sender_id
    
    if my_id not in private_settings:
        private_settings[my_id] = {}
    if "blocked" not in private_settings[my_id]:
        private_settings[my_id]["blocked"] = []
    
    if user_id in private_settings[my_id]["blocked"]:
        private_settings[my_id]["blocked"].remove(user_id)
    
    await event.edit("✓ تم السماح لهذا المستخدم")

@client.on(events.NewMessage(pattern=r'\.رفض', outgoing=True))
async def block_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ يرجى الرد على رسالة الشخص")
        return
    
    user_id = reply.sender_id
    my_id = event.sender_id
    
    if my_id not in private_settings:
        private_settings[my_id] = {}
    if "blocked" not in private_settings[my_id]:
        private_settings[my_id]["blocked"] = []
    
    if user_id not in private_settings[my_id]["blocked"]:
        private_settings[my_id]["blocked"].append(user_id)
    
    await event.edit("✘ تم رفض الرسائل من هذا المستخدم")

# ==================== التحذيرات ====================

@client.on(events.NewMessage(pattern=r'\.التحذيرات\s+(\d+)', outgoing=True))
async def set_warnings_limit(event):
    try:
        limit = int(event.pattern_match.group(1).strip())
    except:
        await event.edit("✘ يرجى إدخال رقم صحيح")
        return
    
    user_id = event.sender_id
    if user_id not in warnings_settings:
        warnings_settings[user_id] = {}
    warnings_settings[user_id]["limit"] = limit
    
    await event.edit(f"⌔ تم تحديد عدد التحذيرات: {limit}")

@client.on(events.NewMessage(pattern=r'\.عرض التحذيرات', outgoing=True))
async def show_warnings_settings(event):
    user_id = event.sender_id
    enabled = warnings_settings.get(user_id, {}).get("enabled", False)
    limit = warnings_settings.get(user_id, {}).get("limit", 3)
    status = "✓ مفعل" if enabled else "✘ معطل"
    
    await event.edit(f"⌔ إعدادات التحذيرات:\n\nالحالة: {status}\nعدد التحذيرات قبل الحظر: {limit}")

@client.on(events.NewMessage(pattern=r'\.تفعيل التحذيرات', outgoing=True))
async def enable_warnings(event):
    user_id = event.sender_id
    if user_id not in warnings_settings:
        warnings_settings[user_id] = {}
    warnings_settings[user_id]["enabled"] = True
    await event.edit("✓ تم تفعيل نظام التحذيرات")

@client.on(events.NewMessage(pattern=r'\.تعطيل التحذيرات', outgoing=True))
async def disable_warnings(event):
    user_id = event.sender_id
    if user_id not in warnings_settings:
        warnings_settings[user_id] = {}
    warnings_settings[user_id]["enabled"] = False
    await event.edit("✘ تم تعطيل نظام التحذيرات")

# ==================== همسة ====================

@client.on(events.NewMessage(pattern=r'\.اهمس\s+(@\w+)\s+([\s\S]+)', outgoing=True))
async def whisper(event):
    target = event.pattern_match.group(1).strip()
    whisper_text = event.pattern_match.group(2).strip()
    
    try:
        target_user = await client.get_entity(target)
        await client.send_message(
            target_user.id,
            f"⌔ همسة خاصة:\n\n{whisper_text}\n\n⌔ تم إرسالها بواسطة: {(await client.get_me()).first_name}"
        )
        await event.edit(f"✓ تم إرسال الهمسة إلى {target}")
    except Exception as e:
        await event.edit(f"✘ فشل الإرسال: {str(e)}")

# ==================== التخزين ====================

@client.on(events.NewMessage(pattern=r'\.تفعيل التخزين', outgoing=True))
async def enable_storage(event):
    user_id = event.sender_id
    if user_id not in private_settings:
        private_settings[user_id] = {}
    private_settings[user_id]["storage_enabled"] = True
    private_settings[user_id]["storage_chat"] = event.chat_id
    await event.edit("✓ تم تفعيل مجموعة الحفظ\n⌔ سيتم حفظ الرسائل المهمة هنا")

@client.on(events.NewMessage(pattern=r'\.تعطيل التخزين', outgoing=True))
async def disable_storage(event):
    user_id = event.sender_id
    if user_id not in private_settings:
        private_settings[user_id] = {}
    private_settings[user_id]["storage_enabled"] = False
    await event.edit("✘ تم تعطيل مجموعة الحفظ")

@client.on(events.NewMessage(pattern=r'\.تعيين مجموعة التخزين', outgoing=True))
async def set_storage_chat(event):
    user_id = event.sender_id
    if user_id not in private_settings:
        private_settings[user_id] = {}
    private_settings[user_id]["storage_chat"] = event.chat_id
    await event.edit("✓ تم تعيين هذه الدردشة كمجموعة للحفظ")

# ==================== كتم / إلغاء الكتم ====================

@client.on(events.NewMessage(pattern=r'\.كتم', outgoing=True))
async def mute_private_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ يرجى الرد على رسالة الشخص")
        return
    
    target_user = await reply.get_sender()
    user_id = event.sender_id
    
    if user_id not in muted_users:
        muted_users[user_id] = []
    
    if target_user.id not in muted_users[user_id]:
        muted_users[user_id].append(target_user.id)
    
    user_display = f"@{target_user.username}" if target_user.username else target_user.first_name
    
    reply_text = f"""⌔ المستخدم: {user_display}
⌔ نحن بحاجة لبعض الهدوء اصمت
⌔ تم كتمه بنجاح ✓"""
    
    await event.edit(reply_text)

@client.on(events.NewMessage(pattern=r'\.الغاء الكتم', outgoing=True))
async def unmute_private_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ يرجى الرد على رسالة الشخص")
        return
    
    target_user = await reply.get_sender()
    user_id = event.sender_id
    
    if user_id in muted_users and target_user.id in muted_users[user_id]:
        muted_users[user_id].remove(target_user.id)
    
    await event.edit("✓ تم السماح لهذه المحادثة.")

@client.on(events.NewMessage(pattern=r'\.المكتومين', outgoing=True))
async def show_muted_users(event):
    user_id = event.sender_id
    
    if user_id not in muted_users or not muted_users[user_id]:
        await event.edit("⌔ لا يوجد مستخدمين مكتومين")
        return
    
    text = "⌔ قائمة المكتومين:\n\n"
    for uid in muted_users[user_id][:20]:
        try:
            u = await client.get_entity(uid)
            text += f"⦁ {u.first_name} (@{u.username or 'بدون'})\n"
        except:
            text += f"⦁ `{uid}`\n"
    
    await event.edit(text)

# ==================== أوامر الردود ====================

@client.on(events.NewMessage(pattern=r'\.اضف رد\s+(\S+)\s+([\s\S]+)', outgoing=True))
async def add_normal_reply(event):
    keyword = event.pattern_match.group(1).strip()
    reply_text = event.pattern_match.group(2).strip()
    user_id = event.sender_id
    
    if user_id not in normal_replies:
        normal_replies[user_id] = {}
    
    normal_replies[user_id][keyword] = reply_text
    await event.edit(f"✓ تم إضافة الرد: `{keyword}`\n\n⌔ استخدم {name} في الرد ليتم استبداله باسم المرسل")

@client.on(events.NewMessage(pattern=r'\.مسح رد\s+(\S+)', outgoing=True))
async def delete_normal_reply(event):
    keyword = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id in normal_replies and keyword in normal_replies[user_id]:
        del normal_replies[user_id][keyword]
        await event.edit(f"⌫ تم مسح الرد: `{keyword}`")
    else:
        await event.edit(f"✘ الرد غير موجود: `{keyword}`")

@client.on(events.NewMessage(pattern=r'\.مسح الردود الفردية', outgoing=True))
async def clear_normal_replies(event):
    user_id = event.sender_id
    if user_id in normal_replies:
        normal_replies[user_id] = {}
    await event.edit("⌫ تم مسح جميع الردود الفردية")

@client.on(events.NewMessage(pattern=r'\.اضف رد متعدد\s+(\S+)\s+([\s\S]+)', outgoing=True))
async def add_multi_reply(event):
    keyword = event.pattern_match.group(1).strip()
    reply_text = event.pattern_match.group(2).strip()
    user_id = event.sender_id
    
    if user_id not in multi_replies:
        multi_replies[user_id] = {}
    if keyword not in multi_replies[user_id]:
        multi_replies[user_id][keyword] = []
    
    multi_replies[user_id][keyword].append(reply_text)
    await event.edit(f"✓ تم إضافة رد متعدد لـ: `{keyword}`\n\n⌔ استخدم {name} في الرد ليتم استبداله باسم المرسل")

@client.on(events.NewMessage(pattern=r'\.مسح رد متعدد\s+(\S+)', outgoing=True))
async def delete_multi_reply(event):
    keyword = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id in multi_replies and keyword in multi_replies[user_id]:
        del multi_replies[user_id][keyword]
        await event.edit(f"⌫ تم مسح الردود المتعددة لـ: `{keyword}`")
    else:
        await event.edit(f"✘ لا يوجد ردود متعددة لـ: `{keyword}`")

@client.on(events.NewMessage(pattern=r'\.مسح الردود المتعددة', outgoing=True))
async def clear_multi_replies(event):
    user_id = event.sender_id
    if user_id in multi_replies:
        multi_replies[user_id] = {}
    await event.edit("⌫ تم مسح جميع الردود المتعددة")

@client.on(events.NewMessage(pattern=r'\.اضف رد مميز\s+(\S+)\s+([\s\S]+)', outgoing=True))
async def add_special_reply(event):
    keyword = event.pattern_match.group(1).strip()
    reply_text = event.pattern_match.group(2).strip()
    user_id = event.sender_id
    
    if user_id not in special_replies:
        special_replies[user_id] = {}
    
    special_replies[user_id][keyword] = reply_text
    await event.edit(f"✓ تم إضافة الرد المميز: `{keyword}`\n\n⌔ استخدم {name} في الرد ليتم استبداله باسم المرسل")

@client.on(events.NewMessage(pattern=r'\.مسح رد مميز\s+(\S+)', outgoing=True))
async def delete_special_reply(event):
    keyword = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id in special_replies and keyword in special_replies[user_id]:
        del special_replies[user_id][keyword]
        await event.edit(f"⌫ تم مسح الرد المميز: `{keyword}`")
    else:
        await event.edit(f"✘ الرد المميز غير موجود: `{keyword}`")

@client.on(events.NewMessage(pattern=r'\.مسح الردود المميزة', outgoing=True))
async def clear_special_replies(event):
    user_id = event.sender_id
    if user_id in special_replies:
        special_replies[user_id] = {}
    await event.edit("⌫ تم مسح جميع الردود المميزة")

@client.on(events.NewMessage(pattern=r'\.اضف رد مميز متعدد\s+(\S+)\s+([\s\S]+)', outgoing=True))
async def add_special_multi_reply(event):
    keyword = event.pattern_match.group(1).strip()
    reply_text = event.pattern_match.group(2).strip()
    user_id = event.sender_id
    
    if user_id not in special_multi_replies:
        special_multi_replies[user_id] = {}
    if keyword not in special_multi_replies[user_id]:
        special_multi_replies[user_id][keyword] = []
    
    special_multi_replies[user_id][keyword].append(reply_text)
    await event.edit(f"✓ تم إضافة رد مميز متعدد لـ: `{keyword}`\n\n⌔ استخدم {name} في الرد ليتم استبداله باسم المرسل")

@client.on(events.NewMessage(pattern=r'\.مسح رد مميز متعدد\s+(\S+)', outgoing=True))
async def delete_special_multi_reply(event):
    keyword = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id in special_multi_replies and keyword in special_multi_replies[user_id]:
        del special_multi_replies[user_id][keyword]
        await event.edit(f"⌫ تم مسح الردود المميزة المتعددة لـ: `{keyword}`")
    else:
        await event.edit(f"✘ لا يوجد ردود مميزة متعددة لـ: `{keyword}`")

@client.on(events.NewMessage(pattern=r'\.مسح الردود المميزة المتعددة', outgoing=True))
async def clear_special_multi_replies(event):
    user_id = event.sender_id
    if user_id in special_multi_replies:
        special_multi_replies[user_id] = {}
    await event.edit("⌫ تم مسح جميع الردود المميزة المتعددة")

@client.on(events.NewMessage(pattern=r'\.تفعيل الردود', outgoing=True))
async def enable_chat_replies(event):
    chat_id = event.chat_id
    if chat_id not in private_settings:
        private_settings[chat_id] = {}
    private_settings[chat_id]["replies_enabled"] = True
    await event.edit("✓ تم تفعيل الردود في هذه الدردشة")

@client.on(events.NewMessage(pattern=r'\.تعطيل الردود', outgoing=True))
async def disable_chat_replies(event):
    chat_id = event.chat_id
    if chat_id not in private_settings:
        private_settings[chat_id] = {}
    private_settings[chat_id]["replies_enabled"] = False
    await event.edit("✘ تم تعطيل الردود في هذه الدردشة")

@client.on(events.NewMessage(pattern=r'\.تفعيل ردود الخاص', outgoing=True))
async def enable_private_replies(event):
    user_id = event.sender_id
    if user_id not in private_settings:
        private_settings[user_id] = {}
    private_settings[user_id]["private_replies_enabled"] = True
    await event.edit("✓ تم تفعيل الردود في كل الخاص")

@client.on(events.NewMessage(pattern=r'\.تعطيل ردود الخاص', outgoing=True))
async def disable_private_replies(event):
    user_id = event.sender_id
    if user_id not in private_settings:
        private_settings[user_id] = {}
    private_settings[user_id]["private_replies_enabled"] = False
    await event.edit("✘ تم تعطيل الردود في كل الخاص")

@client.on(events.NewMessage(pattern=r'\.الردود', outgoing=True))
async def show_all_replies(event):
    user_id = event.sender_id
    text = "⌔ قائمة الردود:\n\n"
    
    if user_id in normal_replies and normal_replies[user_id]:
        text += "◈ الردود الفردية:\n"
        for k, v in list(normal_replies[user_id].items())[:10]:
            text += f"⦁ `{k}` → {v[:30]}...\n"
    
    if user_id in multi_replies and multi_replies[user_id]:
        text += "\n◈ الردود المتعددة:\n"
        for k, v in list(multi_replies[user_id].items())[:10]:
            text += f"⦁ `{k}` ({len(v)} ردود)\n"
    
    if user_id in special_replies and special_replies[user_id]:
        text += "\n◈ الردود المميزة:\n"
        for k, v in list(special_replies[user_id].items())[:10]:
            text += f"⦁ `{k}` → {v[:30]}...\n"
    
    if user_id in special_multi_replies and special_multi_replies[user_id]:
        text += "\n◈ الردود المميزة المتعددة:\n"
        for k, v in list(special_multi_replies[user_id].items())[:10]:
            text += f"⦁ `{k}` ({len(v)} ردود)\n"
    
    if text == "⌔ قائمة الردود:\n\n":
        text += "⌔ لا توجد ردود مضافة"
    
    await event.edit(text)

@client.on(events.NewMessage(pattern=r'\.الغاء', outgoing=True))
async def cancel_operation(event):
    await event.edit("⌫ تم إلغاء العملية")

# ==================== معالجة الرسائل الواردة (للردود التلقائية) ====================

@client.on(events.NewMessage(incoming=True))
async def handle_private_messages(event):
    if not event.is_private:
        return
    
    sender = await event.get_sender()
    if not await is_human(sender):
        return
    
    my_id = (await client.get_me()).id
    user_id = event.sender_id
    
    if user_id == my_id:
        return
    
    sender_name = sender.first_name or "صديقي"
    
    if my_id in muted_users and user_id in muted_users[my_id]:
        return
    
    if my_id in private_settings and "blocked" in private_settings[my_id]:
        if user_id in private_settings[my_id]["blocked"]:
            return
    
    if my_id in private_settings and private_settings[my_id].get("auto_reply", False):
        if my_id not in afk_settings or not afk_settings[my_id].get("enabled", False):
            custom_reply = private_settings[my_id].get("custom_reply", "مرحباً {name}!\nالرد التلقائي مفعل حالياً")
            custom_reply = await replace_name_in_reply(custom_reply, sender_name)
            await event.reply(custom_reply)
            return
    
    msg_text = event.text or ""
    
    if my_id in normal_replies:
        for keyword, reply in normal_replies[my_id].items():
            if msg_text == keyword:
                reply = await replace_name_in_reply(reply, sender_name)
                await event.reply(reply)
                return
    
    if my_id in special_replies:
        for keyword, reply in special_replies[my_id].items():
            if keyword in msg_text:
                reply = await replace_name_in_reply(reply, sender_name)
                await event.reply(reply)
                return
    
    if my_id in multi_replies:
        for keyword, replies in multi_replies[my_id].items():
            if msg_text == keyword:
                reply = random.choice(replies)
                reply = await replace_name_in_reply(reply, sender_name)
                await event.reply(reply)
                return
    
    if my_id in special_multi_replies:
        for keyword, replies in special_multi_replies[my_id].items():
            if keyword in msg_text:
                reply = random.choice(replies)
                reply = await replace_name_in_reply(reply, sender_name)
                await event.reply(reply)
                return