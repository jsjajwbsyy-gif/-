from main import client
from telethon import events
# ========== M40: أوامر الملفات والمرفقات ==========

import os
import zipfile
import requests
from datetime import datetime
from PIL import Image

# لتخزين الملفات مؤقتاً قبل الضغط
temp_files = {}


@client.on(events.NewMessage(pattern=r'\.م40', outgoing=True))
async def show_m40_menu(event):
    menu_text = """⟪───── أوامر الملفات والمرفقات ─────⟫

│ `.ضغط`
│ ← بدء جمع الملفات لضغطها في ZIP

│ `.اضغط`
│ ← ضغط جميع الملفات المجمعة في ملف واحد

│ `.فك_ضغط`
│ ← فك ملف ZIP (بالرد على الملف)

│ `.تحويل_صيغة`
│ ← تحويل الصور إلى PDF (بالرد)

│ `.معلومات_ملف`
│ ← عرض معلومات أي ملف (بالرد)

│ `.رفع`
│ ← رفع ملف إلى الإنترنت (بالرد)

│ `.بحث_ملف`
│ ← بحث عن ملف في محادثاتك

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== أمر .ضغط ==========
@client.on(events.NewMessage(pattern=r'\.ضغط$', outgoing=True))
async def start_compress(event):
    user_id = event.sender_id
    temp_files[user_id] = []
    await event.edit("⌯ **حسناً 𝐙𝐞𝐫𝐨، أرسل الملفات التي تريد ضغطها**\n📌 بعد الانتهاء أرسل `.اضغط`")


# ========== تجميع الملفات تلقائياً ==========
@client.on(events.NewMessage(outgoing=True))
async def collect_files(event):
    user_id = event.sender_id
    if user_id not in temp_files or not temp_files[user_id]:
        return
    
    if event.file or event.photo or event.video or event.audio or event.document:
        temp_files[user_id].append(event)
        count = len(temp_files[user_id])
        await event.reply(f"📥 **تم استلام الملف ({count})**\n📌 أرسل المزيد أو `.اضغط` للإنهاء")


# ========== أمر .اضغط ==========
@client.on(events.NewMessage(pattern=r'\.اضغط', outgoing=True))
async def compress_files(event):
    user_id = event.sender_id
    
    if user_id not in temp_files or not temp_files[user_id]:
        await event.edit("❌ **لا توجد ملفات مجمعة**\n📌 استخدم `.ضغط` أولاً")
        return
    
    files = temp_files[user_id]
    await event.edit(f"🗜 **جاري ضغط {len(files)} ملف...**")
    
    zip_path = f"compressed_{user_id}.zip"
    
    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for i, msg in enumerate(files):
                file_path = await client.download_media(msg)
                file_name = f"file_{i+1}_{os.path.basename(file_path)}"
                zipf.write(file_path, file_name)
                os.remove(file_path)
        
        zip_size = os.path.getsize(zip_path)
        size_mb = zip_size / (1024 * 1024)
        
        await client.send_file(
            event.chat_id, zip_path,
            caption=f"🗜 **تم الضغط بنجاح!**\n📦 **الملفات:** {len(files)}\n📏 **الحجم:** {size_mb:.2f} MB"
        )
        await event.delete()
        os.remove(zip_path)
        
    except Exception as e:
        await event.edit(f"❌ **فشل الضغط:** {str(e)[:100]}")
    
    temp_files[user_id] = []


# ========== أمر .فك_ضغط ==========
@client.on(events.NewMessage(pattern=r'\.فك_ضغط', outgoing=True))
async def decompress_file(event):
    reply = await event.get_reply_message()
    
    if not reply or not reply.document:
        await event.edit("❌ **يرجى الرد على ملف ZIP**")
        return
    
    if not reply.document.mime_type or 'zip' not in reply.document.mime_type:
        await event.edit("❌ **الملف ليس بصيغة ZIP**")
        return
    
    await event.edit("📂 **جاري فك الضغط...**")
    
    try:
        zip_path = await client.download_media(reply)
        extract_folder = f"extracted_{event.sender_id}"
        os.makedirs(extract_folder, exist_ok=True)
        
        with zipfile.ZipFile(zip_path, 'r') as zipf:
            files_list = zipf.namelist()
            zipf.extractall(extract_folder)
        
        os.remove(zip_path)
        
        # إرسال كل ملف
        sent_count = 0
        for file_name in files_list:
            file_path = os.path.join(extract_folder, file_name)
            if os.path.isfile(file_path):
                await client.send_file(event.chat_id, file_path, caption=f"📄 {file_name}")
                sent_count += 1
                os.remove(file_path)
        
        os.rmdir(extract_folder)
        
        await event.edit(f"✅ **تم فك الضغط!**\n📂 **عدد الملفات:** {sent_count}")
        
    except Exception as e:
        await event.edit(f"❌ **فشل فك الضغط:** {str(e)[:100]}")


# ========== أمر .تحويل_صيغة ==========
@client.on(events.NewMessage(pattern=r'\.تحويل_صيغة', outgoing=True))
async def convert_images(event):
    reply = await event.get_reply_message()
    
    if not reply or not reply.photo:
        await event.edit("❌ **يرجى الرد على صورة**")
        return
    
    await event.edit("🔄 **جاري تحويل الصورة إلى PDF...**")
    
    try:
        img_path = await client.download_media(reply)
        img = Image.open(img_path)
        
        if img.mode == 'RGBA':
            img = img.convert('RGB')
        
        pdf_path = f"converted_{event.sender_id}.pdf"
        img.save(pdf_path, 'PDF', resolution=100.0)
        
        await client.send_file(event.chat_id, pdf_path, caption="📄 **تم التحويل إلى PDF**")
        await event.delete()
        
        os.remove(img_path)
        os.remove(pdf_path)
        
    except ImportError:
        await event.edit("❌ **مكتبة Pillow غير مثبتة**")
    except Exception as e:
        await event.edit(f"❌ **فشل التحويل:** {str(e)[:100]}")


# ========== أمر .معلومات_ملف ==========
@client.on(events.NewMessage(pattern=r'\.معلومات_ملف', outgoing=True))
async def file_info(event):
    reply = await event.get_reply_message()
    
    if not reply or (not reply.document and not reply.photo and not reply.video and not reply.audio):
        await event.edit("❌ **يرجى الرد على ملف**")
        return
    
    await event.edit("📋 **جاري جلب معلومات الملف...**")
    
    try:
        if reply.document:
            f = reply.document
            file_type = "📄 مستند"
            for attr in f.attributes:
                if hasattr(attr, 'file_name'):
                    file_name = attr.file_name
                    break
                elif hasattr(attr, 'title'):
                    file_name = attr.title
                    break
            else:
                file_name = "غير معروف"
        elif reply.photo:
            f = reply.photo
            file_type = "🖼️ صورة"
            file_name = "photo.jpg"
        elif reply.video:
            f = reply.video
            file_type = "🎥 فيديو"
            file_name = "video.mp4"
        elif reply.audio:
            f = reply.audio
            file_type = "🎵 صوت"
            file_name = "audio.mp3"
        
        size = getattr(f, 'size', 0)
        size_mb = size / (1024 * 1024) if size else 0
        file_id = getattr(f, 'id', 'غير معروف')
        mime = getattr(f, 'mime_type', 'غير معروف')
        date = reply.date.strftime('%Y-%m-%d %I:%M %p') if reply.date else 'غير معروف'
        
        text = f"""📋 **معلومات الملف:**

📂 **النوع:** {file_type}
📝 **الاسم:** {file_name}
📏 **الحجم:** {size_mb:.2f} MB
🔢 **الآيدي:** `{file_id}`
📄 **الصيغة:** {mime}
📅 **التاريخ:** {date}"""
        
        await event.edit(text)
        
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .رفع ==========
@client.on(events.NewMessage(pattern=r'\.رفع', outgoing=True))
async def upload_file(event):
    reply = await event.get_reply_message()
    
    if not reply or (not reply.document and not reply.photo and not reply.video):
        await event.edit("❌ **يرجى الرد على ملف أو صورة**")
        return
    
    await event.edit("📤 **جاري رفع الملف...**")
    
    try:
        file_path = await client.download_media(reply)
        file_size = os.path.getsize(file_path)
        
        if file_size > 50 * 1024 * 1024:
            await event.edit("❌ **الملف كبير جداً (الحد 50MB)**")
            os.remove(file_path)
            return
        
        # محاولة رفع إلى transfer.sh
        with open(file_path, 'rb') as f:
            response = requests.put(f"https://transfer.sh/{os.path.basename(file_path)}", data=f)
        
        if response.status_code == 200:
            link = response.text.strip()
            await event.edit(f"✅ **تم رفع الملف:**\n📎 **الرابط:** {link}")
        else:
            await event.edit("❌ **فشل رفع الملف**")
        
        os.remove(file_path)
        
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .بحث_ملف ==========
@client.on(events.NewMessage(pattern=r'\.بحث_ملف\s+([\s\S]+)', outgoing=True))
async def search_file(event):
    query = event.pattern_match.group(1).strip()
    
    await event.edit(f"🔍 **جاري البحث عن:** {query}")
    
    found = []
    count = 0
    
    async for dialog in client.iter_dialogs():
        if count >= 30:
            break
        try:
            async for msg in client.iter_messages(dialog.id, limit=50):
                if msg.document or msg.photo or msg.video:
                    file_name = ""
                    if msg.document:
                        for attr in msg.document.attributes:
                            if hasattr(attr, 'file_name'):
                                file_name = attr.file_name
                                break
                    if query.lower() in file_name.lower():
                        found.append({
                            "name": file_name,
                            "chat": dialog.name,
                            "date": msg.date.strftime('%Y-%m-%d') if msg.date else ""
                        })
            count += 1
        except:
            pass
    
    if found:
        text = f"🔍 **نتائج البحث عن:** {query}\n\n"
        for i, f in enumerate(found[:15], 1):
            text += f"{i}. **{f['name']}**\n   📁 {f['chat']} | 📅 {f['date']}\n"
    else:
        text = f"📭 **لم يتم العثور على ملفات:** {query}"
    
    await event.edit(text)