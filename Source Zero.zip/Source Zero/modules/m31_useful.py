import asyncio
import os
from telethon import events

from main import client

# يمكنك تغيير الدولة حسب منطقتك
WATCH_COUNTRY = "IQ"

moviepath = os.path.join(os.getcwd(), "temp", "moviethumb.jpg")
if not os.path.isdir(os.path.join(os.getcwd(), "temp")):
    os.makedirs(os.path.join(os.getcwd(), "temp"))


# ==================== عرض قائمة الأوامر (.م31) ====================
@client.on(events.NewMessage(pattern=r'\.م31', outgoing=True))
async def show_useful_menu(event):
    menu_text = """⟪───── أوامر عملية ومفيدة ─────⟫

│ `.ترند`
│ ← يعرض أكثر 10 أغاني استماعاً عالمياً (يتغير يومياً)

│ `.فيلم + اسم`
│ ← يبحث عن فيلم ويعطيك معلومات + منصات المشاهدة

│ `.مسلسل + اسم`
│ ← يبحث عن مسلسل ويعطيك معلومات + منصات المشاهدة

│ `.طقس + مدينة`
│ ← يعرض حالة الطقس في أي مدينة (بالعربية)

│ `.صلاة + مدينة`
│ ← يعرض مواقيت الصلاة في أي مدينة

│ `.قرآن + رقم الصفحة`
│ ← يرسل رابط صفحة من القرآن الكريم

│ `.حديث`
│ ← يرسل حديثاً نبوياً عشوائياً (40 حديث)

│ `.ترجمة + نص`
│ ← يترجم أي نص من العربية إلى الإنجليزية

│ `.تذكير + الوقت + النص`
│ ← يضع تذكيراً وينبهك في الوقت المحدد

│ `.مستخدمو تيليجرام`
│ ← يعرض إحصائيات تيليجرام الحية
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== دوال مساعدة (منقولة من ريبثون) ====================

def get_provider(url):
    url = url.replace("https://www.", "")
    url = url.replace("https://", "")
    url = url.replace("http://www.", "")
    url = url.replace("http://", "")
    url = url.split(".")[0]
    return url


def pretty(name):
    if name == "play":
        name = "Google Play Movies"
    return name[0].upper() + name[1:]


def get_stream_data(query, country="IQ"):
    try:
        from justwatch import JustWatch, justwatchapi
        justwatchapi.__dict__["HEADER"] = {
            "User-Agent": "JustWatch client (github.com/dawoudt/JustWatchAPI)"
        }
    except ImportError:
        return None

    just_watch = JustWatch(country=country)
    results = just_watch.search_for_item(query=query)

    if not results.get("items"):
        return None

    movie = results["items"][0]
    stream_data = {
        "title": movie.get("title", "غير معروف"),
        "movie_thumb": (
            "https://images.justwatch.com"
            + movie["poster"].replace("{profile}", "")
            + "s592"
        ) if movie.get("poster") else None,
        "release_year": movie.get("original_release_year", "غير معروف"),
        "type": movie.get("object_type", "غير معروف"),
    }

    try:
        stream_data["release_date"] = movie["cinema_release_date"]
    except KeyError:
        try:
            stream_data["release_date"] = movie["localized_release_date"]
        except KeyError:
            stream_data["release_date"] = None

    available_streams = {}
    for provider in movie.get("offers", []):
        provider_ = get_provider(provider["urls"]["standard_web"])
        available_streams[provider_] = provider["urls"]["standard_web"]

    stream_data["providers"] = available_streams

    scoring = {}
    for scorer in movie.get("scoring", []):
        if scorer["provider_type"] == "tmdb:score":
            scoring["tmdb"] = scorer["value"]
        if scorer["provider_type"] == "imdb:score":
            scoring["imdb"] = scorer["value"]
    stream_data["score"] = scoring

    return stream_data


async def download_thumbnail(url):
    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=15) as response:
                if response.status == 200:
                    with open(moviepath, "wb") as f:
                        f.write(await response.read())
                    return moviepath
    except Exception:
        pass
    return None


# ==================== أمر .فيلم ====================
@client.on(events.NewMessage(pattern=r'\.فيلم\s+([\s\S]+)', outgoing=True))
async def movie_info(event):
    query = event.pattern_match.group(1).strip()
    await event.edit(f"⎙ **جاري البحث عن الفيلم:** {query}...")

    streams = get_stream_data(query, WATCH_COUNTRY)

    if streams is None:
        await event.edit("✘ **لم يتم العثور على الفيلم أو المكتبة غير مثبتة**\n⌔ **لتثبيت المكتبة:** `pip install justwatch`")
        return

    title = streams["title"]
    thumb_link = streams["movie_thumb"]
    release_year = streams["release_year"]
    release_date = streams["release_date"]
    media_type = streams["type"]
    scores = streams["score"]

    imdb_score = scores.get("imdb", None)
    tmdb_score = scores.get("tmdb", None)

    stream_providers = streams["providers"]

    if release_date is None:
        release_date = release_year

    type_ar = {"movie": "فيلم 🎬", "show": "مسلسل 📺"}.get(media_type, media_type)

    output = f"""◈ **{title}**

⦁ **النوع:** {type_ar}
⦁ **تاريخ الإصدار:** {release_date}"""

    if imdb_score:
        output += f"\n⦁ **IMDB:** {imdb_score}⭐"
    if tmdb_score:
        output += f"\n⦁ **TMDB:** {tmdb_score}⭐"

    if stream_providers:
        output += "\n\n⌔ **متاح على:**\n"
        for provider, link in stream_providers.items():
            if "sonyliv" in link:
                link = link.replace(" ", "%20")
            output += f"⦁ [{pretty(provider)}]({link})\n"
    else:
        output += "\n\n✘ **لا توجد منصات متاحة حالياً**"

    output += "\n⌔ **سورس زيرو**"

    thumbnail = await download_thumbnail(thumb_link) if thumb_link else None

    try:
        if thumbnail and os.path.exists(thumbnail):
            await event.client.send_file(
                event.chat_id,
                caption=output,
                file=thumbnail,
                force_document=False,
                allow_cache=False,
                silent=True,
            )
            await event.delete()
        else:
            await event.edit(output)
    except Exception:
        await event.edit(output)


# ==================== أمر .مسلسل ====================
@client.on(events.NewMessage(pattern=r'\.مسلسل\s+([\s\S]+)', outgoing=True))
async def series_info(event):
    query = event.pattern_match.group(1).strip()
    await event.edit(f"⎙ **جاري البحث عن المسلسل:** {query}...")

    streams = get_stream_data(query, WATCH_COUNTRY)

    if streams is None:
        await event.edit("✘ **لم يتم العثور على المسلسل أو المكتبة غير مثبتة**\n⌔ **لتثبيت المكتبة:** `pip install justwatch`")
        return

    title = streams["title"]
    thumb_link = streams["movie_thumb"]
    release_year = streams["release_year"]
    release_date = streams["release_date"]
    media_type = streams["type"]
    scores = streams["score"]

    imdb_score = scores.get("imdb", None)
    tmdb_score = scores.get("tmdb", None)

    stream_providers = streams["providers"]

    if release_date is None:
        release_date = release_year

    type_ar = {"movie": "فيلم 🎬", "show": "مسلسل 📺"}.get(media_type, media_type)

    output = f"""◈ **{title}**

⦁ **النوع:** {type_ar}
⦁ **تاريخ الإصدار:** {release_date}"""

    if imdb_score:
        output += f"\n⦁ **IMDB:** {imdb_score}⭐"
    if tmdb_score:
        output += f"\n⦁ **TMDB:** {tmdb_score}⭐"

    if stream_providers:
        output += "\n\n⌔ **متاح على:**\n"
        for provider, link in stream_providers.items():
            if "sonyliv" in link:
                link = link.replace(" ", "%20")
            output += f"⦁ [{pretty(provider)}]({link})\n"
    else:
        output += "\n\n✘ **لا توجد منصات متاحة حالياً**"

    output += "\n⌔ **سورس زيرو**"

    thumbnail = await download_thumbnail(thumb_link) if thumb_link else None

    try:
        if thumbnail and os.path.exists(thumbnail):
            await event.client.send_file(
                event.chat_id,
                caption=output,
                file=thumbnail,
                force_document=False,
                allow_cache=False,
                silent=True,
            )
            await event.delete()
        else:
            await event.edit(output)
    except Exception:
        await event.edit(output)