import asyncio
from datetime import datetime
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

destroy_settings = {}

# ==================== عرض قائمة الأوامر (.م6) ====================
@client.on(events.NewMessage(pattern=r'\.م6', outgoing=True))
async def show_delete_menu(event):
    menu_text = """⟪───── أوامر المسح ─────⟫

│ `.مسح رسائلي`
│ ← لمسح جميع رسائلك من المحادثة الحالية.

│ `.مسح + العدد`
│ ← لحذف عدد محدد من الرسائل للطرفين.

│ `.مسح الكل`
│ ← لحذف جميع الرسائل من المحادثة.

│ `.تدمير + العدد`
│ ← لحذف الرسائل بعد مدة مؤقتة.

│ `.تدمير_نهائي + الوقت بالدقائق`
│ ← حذف للدردشة بعد مرور الوقت المحدد على اخر رسالة.

│ `.ايقاف التدمير | .ايقاف_التدمير`
│ ← لإيقاف التدمير المؤقت أو النهائي.

│ `.مسح البوتات`
│ ← لحذف جميع البوتات.

│ `.مسح المحذوفين`
│ ← لحذف جميع الحسابات المحذوفة.

│ `.مسح الخاص`
│ ← لحذف جميع المحادثات الخاصة 

╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 1. أمر .مسح رسائلي ====================
@client.on(events.NewMessage(pattern=r'\.مسح رسائلي', outgoing=True))
async def delete_my_messages(event):
    chat_id = event.chat_id
    me = await client.get_me()
    
    await event.edit("🗑 **جاري مسح رسائلك...**")
    
    deleted_count = 0
    try:
        async for msg in client.iter_messages(chat_id, from_user=me.id):
            try:
                await msg.delete()
                deleted_count += 1
                await asyncio.sleep(0.5)
            except:
                pass
    except Exception as e:
        pass
    
    status_msg = await client.send_message(chat_id, f"✅ **تم مسح {deleted_count} رسالة من رسائلك**")
    await asyncio.sleep(3)
    await status_msg.delete()

# ==================== 2. أمر .مسح + العدد ====================
@client.on(events.NewMessage(pattern=r'\.مسح\s+(\d+)', outgoing=True))
async def delete_number_of_messages(event):
    try:
        count = int(event.pattern_match.group(1).strip())
    except:
        await event.edit("❌ **يرجى إدخال رقم صحيح**")
        return
    
    if count <= 0:
        await event.edit("❌ **يجب أن يكون العدد أكبر من صفر**")
        return
    
    if count > 1000:
        await event.edit("❌ **الحد الأقصى 1000 رسالة**")
        return
    
    await event.delete()
    
    chat_id = event.chat_id
    deleted_count = 0
    
    async for msg in client.iter_messages(chat_id, limit=count + 1):
        try:
            await msg.delete()
            deleted_count += 1
            await asyncio.sleep(0.5)
        except:
            pass
    
    status_msg = await client.send_message(chat_id, f"✅ **تم حذف {deleted_count} رسالة**")
    await asyncio.sleep(2)
    await status_msg.delete()

# ==================== 3. أمر .مسح الكل ====================
@client.on(events.NewMessage(pattern=r'\.مسح الكل', outgoing=True))
async def delete_all_messages(event):
    chat_id = event.chat_id
    
    await event.edit("⚠️ **جاري مسح جميع الرسائل...**")
    
    deleted_count = 0
    try:
        async for msg in client.iter_messages(chat_id):
            try:
                await msg.delete()
                deleted_count += 1
                await asyncio.sleep(0.3)
            except:
                pass
    except Exception as e:
        pass
    
    status_msg = await client.send_message(chat_id, f"✅ **تم مسح {deleted_count} رسالة**")
    await asyncio.sleep(3)
    await status_msg.delete()

# ==================== 4. أمر .تدمير + العدد ====================
@client.on(events.NewMessage(pattern=r'\.تدمير\s+(\d+)', outgoing=True))
async def destroy_after_count(event):
    try:
        count = int(event.pattern_match.group(1).strip())
    except:
        await event.edit("❌ **يرجى إدخال رقم صحيح**")
        return
    
    if count <= 0:
        await event.edit("❌ **يجب أن يكون العدد أكبر من صفر**")
        return
    
    chat_id = event.chat_id
    
    if chat_id not in destroy_settings:
        destroy_settings[chat_id] = {}
    
    destroy_settings[chat_id]["temp_destroy"] = count
    destroy_settings[chat_id]["temp_destroy_active"] = True
    destroy_settings[chat_id]["message_count"] = 0
    
    await event.edit(f"⏳ **تم تفعيل التدمير المؤقت**\n*سيتم حذف الرسائل بعد {count} رسائل جديدة*")

@client.on(events.NewMessage(incoming=True))
async def temp_destroy_handler(event):
    """معالج التدمير المؤقت"""
    chat_id = event.chat_id
    
    if chat_id not in destroy_settings:
        return
    
    settings = destroy_settings[chat_id]
    
    if not settings.get("temp_destroy_active", False):
        return
    
    settings["message_count"] = settings.get("message_count", 0) + 1
    
    if settings["message_count"] >= settings.get("temp_destroy", 0):
        await event.respond("🗑 **جاري مسح الرسائل...**")
        
        deleted_count = 0
        async for msg in client.iter_messages(chat_id, limit=settings["temp_destroy"] + 5):
            try:
                await msg.delete()
                deleted_count += 1
                await asyncio.sleep(0.3)
            except:
                pass
        
        settings["message_count"] = 0

# ==================== 5. أمر .تدمير_نهائي ====================
@client.on(events.NewMessage(pattern=r'\.تدمير_نهائي\s+(\d+)', outgoing=True))
async def destroy_final(event):
    try:
        minutes = int(event.pattern_match.group(1).strip())
    except:
        await event.edit("❌ **يرجى إدخال رقم صحيح**")
        return
    
    if minutes <= 0:
        await event.edit("❌ **يجب أن يكون الوقت أكبر من صفر**")
        return
    
    chat_id = event.chat_id
    
    if chat_id not in destroy_settings:
        destroy_settings[chat_id] = {}
    
    destroy_settings[chat_id]["final_destroy"] = minutes
    destroy_settings[chat_id]["final_destroy_active"] = True
    destroy_settings[chat_id]["last_message_time"] = datetime.now()
    
    await event.edit(f"⏰ **تم تفعيل التدمير النهائي**\n*سيتم حذف الدردشة بعد {minutes} دقيقة من آخر رسالة*")
    asyncio.create_task(monitor_final_destroy(chat_id))

async def monitor_final_destroy(chat_id):
    """مراقبة التدمير النهائي"""
    while destroy_settings.get(chat_id, {}).get("final_destroy_active", False):
        await asyncio.sleep(30)
        
        settings = destroy_settings[chat_id]
        last_time = settings.get("last_message_time", datetime.now())
        minutes_limit = settings.get("final_destroy", 10)
        
        elapsed = (datetime.now() - last_time).total_seconds() / 60
        
        if elapsed >= minutes_limit:
            try:
                await client.send_message(chat_id, "⏰ **انتهى الوقت... جاري مسح الدردشة**")
                await asyncio.sleep(2)
                
                async for msg in client.iter_messages(chat_id):
                    try:
                        await msg.delete()
                        await asyncio.sleep(0.3)
                    except:
                        pass
                
                destroy_settings[chat_id]["final_destroy_active"] = False
            except:
                pass

@client.on(events.NewMessage(incoming=True))
async def update_last_message_time(event):
    """تحديث وقت آخر رسالة للتدمير النهائي"""
    chat_id = event.chat_id
    
    if chat_id in destroy_settings and destroy_settings[chat_id].get("final_destroy_active", False):
        destroy_settings[chat_id]["last_message_time"] = datetime.now()

# ==================== 6. أمر .ايقاف التدمير / .ايقاف_التدمير ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف التدمير|\.ايقاف_التدمير', outgoing=True))
async def stop_destroy(event):
    chat_id = event.chat_id
    
    if chat_id in destroy_settings:
        destroy_settings[chat_id]["temp_destroy_active"] = False
        destroy_settings[chat_id]["final_destroy_active"] = False
    
    await event.edit("⏹️ **تم إيقاف جميع أنواع التدمير**")

# ==================== 7. أمر .مسح البوتات ====================
@client.on(events.NewMessage(pattern=r'\.مسح البوتات', outgoing=True))
async def delete_bots(event):
    chat_id = event.chat_id
    
    await event.edit("🤖 **جاري مسح رسائل البوتات...**")
    
    deleted_count = 0
    try:
        async for msg in client.iter_messages(chat_id):
            if msg.sender and msg.sender.bot:
                try:
                    await msg.delete()
                    deleted_count += 1
                    await asyncio.sleep(0.5)
                except:
                    pass
    except Exception as e:
        pass
    
    status_msg = await client.send_message(chat_id, f"✅ **تم مسح {deleted_count} رسالة من البوتات**")
    await asyncio.sleep(3)
    await status_msg.delete()

# ==================== 8. أمر .مسح المحذوفين ====================
@client.on(events.NewMessage(pattern=r'\.مسح المحذوفين', outgoing=True))
async def delete_deleted_accounts_messages(event):
    chat_id = event.chat_id
    
    await event.edit("👻 **جاري مسح رسائل الحسابات المحذوفة...**")
    
    deleted_count = 0
    try:
        async for msg in client.iter_messages(chat_id):
            if msg.sender and hasattr(msg.sender, 'deleted') and msg.sender.deleted:
                try:
                    await msg.delete()
                    deleted_count += 1
                    await asyncio.sleep(0.5)
                except:
                    pass
    except Exception as e:
        pass
    
    status_msg = await client.send_message(chat_id, f"✅ **تم مسح {deleted_count} رسالة من الحسابات المحذوفة**")
    await asyncio.sleep(3)
    await status_msg.delete()

# ==================== 9. أمر .مسح الخاص ====================
@client.on(events.NewMessage(pattern=r'\.مسح الخاص', outgoing=True))
async def delete_private_chats(event):
    await event.edit("💬 **جاري حذف المحادثات الخاصة...**")
    
    deleted_count = 0
    try:
        async for dialog in client.iter_dialogs():
            if dialog.is_user and not dialog.entity.bot:
                try:
                    async for msg in client.iter_messages(dialog.id, from_user=(await client.get_me()).id):
                        try:
                            await msg.delete()
                            await asyncio.sleep(0.3)
                        except:
                            pass
                    deleted_count += 1
                except:
                    pass
    except Exception as e:
        pass
    
    await event.edit(f"✅ **تم مسح محادثات {deleted_count} محادثة خاصة**")