import os
import sys
import asyncio
from datetime import datetime
from telethon import events
from telethon.tl.functions.users import GetFullUserRequest

from main import client

developer_settings = {}
sudo_users = {}
sudo_enabled_cmds = {}
sudo_disabled_cmds = {}
TEMP_DOWNLOAD_PATH = "downloads"
DEVELOPER_ID = 7424434250

DEFAULT_DEVELOPER_TEXT = """♬︰𝙎𝙊𝙐𝙍𝘾𝞝 𝙕𝙀𝙍𝙊 ↯.
━─━─────━─────━─━
♬︰𝗡𝗔𝗠𝗘 ↬ {name}
♬︰𝗨𝗦𝗘𝗥 ↬ {username}
♬︰𝗜𝗗 ↬ {id}
♬︰𝗕𝗜𝗢 ↬ {bio}
━─━─────━─────━─━
♬︰𝗗𝗘𝗩 ↬ @N_jrr"""


# ==================== عرض قائمة الأوامر (.م46) ====================
@client.on(events.NewMessage(pattern=r'\.م57', outgoing=True))
async def show_developer_menu(event):
    menu_text = """⟪───── أوامر المطور ─────⟫

│ `.المطور`
│ ← عرض معلومات المطور كاملة

│ `.تعيين كليشة المطور`
│ ← لتغيير كليشة المطور (بالرد)

│ `.ايدي`
│ ← عرض معلومات سريعة عن حسابك

│ `.اذاعة`
│ ← لإذاعة رسالة لجميع المحادثات

│ `.اذاعة للمجموعات`
│ ← إذاعة للمجموعات فقط

│ `.اذاعة للخاص`
│ ← إذاعة للمحادثات الخاصة فقط

│ `.تنظيف`
│ ← حذف جميع الملفات المؤقتة

│ `.ريستارت`
│ ← إعادة تشغيل السورس

│ `.تحديث`
│ ← تحديث السورس

◈ أوامر المطورين المساعدين:

│ `.رفع مطور`
│ ← رفع شخص كمطور مساعد (بالرد)

│ `.تنزيل مطور`
│ ← إزالة شخص من المطورين (بالرد)

│ `.المطورين`
│ ← عرض قائمة المطورين المساعدين

│ `.حذف المطورين`
│ ← حذف جميع المطورين المساعدين

│ `.تحكم آمن`
│ ← منح صلاحيات الأوامر الآمنة فقط

│ `.تحكم كامل`
│ ← منح صلاحيات جميع الأوامر

│ `.تحكم` + أمر
│ ← منح صلاحية أمر محدد

│ `.ايقاف تحكم آمن`
│ ← سحب صلاحية الأوامر الآمنة

│ `.ايقاف تحكم كامل`
│ ← سحب صلاحية جميع الأوامر

│ `.ايقاف تحكم` + أمر
│ ← سحب صلاحية أمر محدد

│ `.التحكم`
│ ← عرض الأوامر المسموحة للمطورين

│ `.التحكم المعطل`
│ ← عرض الأوامر الممنوعة عن المطورين
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== أوامر المطور الأساسية ====================
@client.on(events.NewMessage(pattern=r'\.المطور$', outgoing=True))
async def show_developer_info(event):
    dev = await client.get_entity(DEVELOPER_ID)
    full_dev = await client(GetFullUserRequest(DEVELOPER_ID))

    name = dev.first_name or ""
    if dev.last_name:
        name += f" {dev.last_name}"
    username = f"@{dev.username}" if dev.username else "بدون"
    user_id = str(dev.id)
    bio = full_dev.full_user.about or "بدون"

    user_dev = event.sender_id
    if user_dev in developer_settings and "dev_text" in developer_settings[user_dev]:
        text = developer_settings[user_dev]["dev_text"].format(name=name, username=username, id=user_id, bio=bio)
    else:
        text = DEFAULT_DEVELOPER_TEXT.format(name=name, username=username, id=user_id, bio=bio)

    photos = await client.get_profile_photos(DEVELOPER_ID, limit=1)
    if photos:
        await client.send_file(event.chat_id, photos[0], caption=text)
        await event.delete()
    else:
        await event.edit(text)


@client.on(events.NewMessage(pattern=r'\.ايدي', outgoing=True))
async def show_id_info(event):
    reply = await event.get_reply_message()
    if reply:
        user = await reply.get_sender()
    else:
        user = await event.get_sender()

    name = user.first_name or ""
    if user.last_name:
        name += f" {user.last_name}"
    username = f"@{user.username}" if user.username else "بدون"
    user_id = user.id

    try:
        full_user = await client(GetFullUserRequest(user.id))
        bio = full_user.full_user.about or "بدون"
    except:
        bio = "بدون"

    text = f"""🆔 **معلومات الحساب**

👤 **الاسم:** {name}
📎 **اليوزر:** {username}
🆔 **الآيدي:** `{user_id}`
📝 **البايو:** {bio}"""

    photos = await client.get_profile_photos(user.id, limit=1)
    if photos:
        await client.send_file(event.chat_id, photos[0], caption=text)
        await event.delete()
    else:
        await event.edit(text)


@client.on(events.NewMessage(pattern=r'\.تعيين كليشة المطور', outgoing=True))
async def set_developer_text(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("✘ **يرجى الرد على رسالة تحتوي على الكليشة الجديدة**")
        return

    user_id = event.sender_id
    developer_settings[user_id] = {}
    developer_settings[user_id]["dev_text"] = reply.text

    await event.edit("✓ **تم تعيين كليشة المطور بنجاح**")


# ==================== أوامر الإذاعة ====================
@client.on(events.NewMessage(pattern=r'\.اذاعة\s+([\s\S]+)', outgoing=True))
async def broadcast(event):
    message_text = event.pattern_match.group(1).strip()
    await event.edit("⎙ **جاري الإذاعة لجميع المحادثات...**")

    count = 0
    async for dialog in client.iter_dialogs():
        try:
            await client.send_message(dialog.id, message_text)
            count += 1
            await asyncio.sleep(0.5)
        except:
            pass

    await event.edit(f"✓ **تمت الإذاعة:** {count} محادثة")


@client.on(events.NewMessage(pattern=r'\.اذاعة للمجموعات\s+([\s\S]+)', outgoing=True))
async def broadcast_groups(event):
    message_text = event.pattern_match.group(1).strip()
    await event.edit("⎙ **جاري الإذاعة للمجموعات...**")

    count = 0
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            try:
                await client.send_message(dialog.id, message_text)
                count += 1
                await asyncio.sleep(0.5)
            except:
                pass

    await event.edit(f"✓ **تمت الإذاعة:** {count} مجموعة")


@client.on(events.NewMessage(pattern=r'\.اذاعة للخاص\s+([\s\S]+)', outgoing=True))
async def broadcast_private(event):
    message_text = event.pattern_match.group(1).strip()
    await event.edit("⎙ **جاري الإذاعة للخاص...**")

    count = 0
    async for dialog in client.iter_dialogs():
        if dialog.is_user and not dialog.entity.bot:
            try:
                await client.send_message(dialog.id, message_text)
                count += 1
                await asyncio.sleep(0.5)
            except:
                pass

    await event.edit(f"✓ **تمت الإذاعة:** {count} محادثة")


# ==================== أوامر الصيانة ====================
@client.on(events.NewMessage(pattern=r'\.تنظيف', outgoing=True))
async def clean_temp_files(event):
    await event.edit("⎙ **جاري تنظيف الملفات المؤقتة...**")
    count = 0
    if os.path.exists(TEMP_DOWNLOAD_PATH):
        for file in os.listdir(TEMP_DOWNLOAD_PATH):
            try:
                os.remove(os.path.join(TEMP_DOWNLOAD_PATH, file))
                count += 1
            except:
                pass
    await event.edit(f"✓ **تم تنظيف {count} ملف**")


@client.on(events.NewMessage(pattern=r'\.ريستارت', outgoing=True))
async def restart_bot(event):
    await event.edit("⎙ **جاري إعادة تشغيل السورس...**")
    os.execl(sys.executable, sys.executable, *sys.argv)


@client.on(events.NewMessage(pattern=r'\.تحديث', outgoing=True))
async def update_bot(event):
    await event.edit("⎙ **جاري تحديث السورس...**")
    try:
        import subprocess
        result = subprocess.run(["git", "pull"], capture_output=True, text=True)
        if "Already up to date" in result.stdout:
            await event.edit("✓ **السورس محدث بالفعل**")
        else:
            await event.edit("✓ **تم تحديث السورس بنجاح**")
            os.execl(sys.executable, sys.executable, *sys.argv)
    except:
        await event.edit("✘ **فشل التحديث**")


# ==================== أوامر المطورين المساعدين (منقولة من ريبثون) ====================

@client.on(events.NewMessage(pattern=r'\.رفع مطور(?:\s|$)([\s\S]*)', outgoing=True))
async def add_sudo_user(event):
    """رفع شخص كمطور مساعد"""
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ **يرجى الرد على رسالة الشخص الذي تريد رفعه**")
        return

    user = await reply.get_sender()
    user_id = user.id

    if user_id == (await client.get_me()).id:
        await event.edit("✘ **لا يمكنك رفع نفسك**")
        return

    if user_id in sudo_users:
        await event.edit("⌔ **هذا المستخدم موجود بالفعل في قائمة المطورين**")
        return

    name = user.first_name or ""
    if user.last_name:
        name += f" {user.last_name}"

    sudo_users[user_id] = {
        "name": name,
        "username": f"@{user.username}" if user.username else "بدون",
        "date": datetime.now().strftime("%Y-%m-%d"),
        "level": "آمن"
    }

    await event.edit(f"✓ **تم رفع** [{name}](tg://user?id={user_id}) **كمطور مساعد**\n⌔ **الصلاحية:** آمن")


@client.on(events.NewMessage(pattern=r'\.تنزيل مطور(?:\s|$)([\s\S]*)', outgoing=True))
async def remove_sudo_user(event):
    """إزالة شخص من المطورين المساعدين"""
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ **يرجى الرد على رسالة الشخص الذي تريد تنزيله**")
        return

    user = await reply.get_sender()
    user_id = user.id

    if user_id not in sudo_users:
        await event.edit("✘ **هذا المستخدم ليس في قائمة المطورين**")
        return

    name = sudo_users[user_id]["name"]
    del sudo_users[user_id]

    await event.edit(f"⌫ **تم تنزيل** [{name}](tg://user?id={user_id}) **من قائمة المطورين**")


@client.on(events.NewMessage(pattern=r'\.المطورين$', outgoing=True))
async def list_sudo_users(event):
    """عرض قائمة المطورين المساعدين"""
    if not sudo_users:
        await event.edit("✘ **لا يوجد مطورين مساعدين حالياً**")
        return

    text = "◈ **قائمة المطورين المساعدين:**\n\n"
    for user_id, data in sudo_users.items():
        text += f"⦁ [{data['name']}](tg://user?id={user_id})\n"
        text += f"  ⌔ **المعرف:** {data['username']}\n"
        text += f"  ⌔ **تاريخ الرفع:** {data['date']}\n"
        text += f"  ⌔ **الصلاحية:** {data['level']}\n\n"

    await event.edit(text)


@client.on(events.NewMessage(pattern=r'\.حذف المطورين$', outgoing=True))
async def clear_sudo_users(event):
    """حذف جميع المطورين المساعدين"""
    count = len(sudo_users)
    sudo_users.clear()
    await event.edit(f"⌫ **تم حذف جميع المطورين المساعدين ({count} مطور)**")


@client.on(events.NewMessage(pattern=r'\.تحكم آمن$', outgoing=True))
async def set_safe_control(event):
    """منح صلاحيات الأوامر الآمنة للمطورين"""
    if not sudo_users:
        await event.edit("✘ **لا يوجد مطورين مساعدين لتعيين الصلاحيات لهم**")
        return

    safe_commands = [
        "ايدي", "المطور", "فحص", "كتم", "الغاء كتم",
        "حظر", "الغاء حظر", "طرد", "تقييد", "الغاء تقييد",
        "منشن", "منشن الكل", "منشن المشرفين", "رسائلي", "رسائله",
        "المشرفين", "الاعضاء", "المحذوفين", "الرابط", "المعلومات",
        "اعدادات", "البوتات", "المقيدين", "مسح المحظورين"
    ]

    for user_id in sudo_users:
        sudo_users[user_id]["level"] = "آمن"

    sudo_enabled_cmds["safe"] = safe_commands
    await event.edit("✓ **تم منح المطورين صلاحيات الأوامر الآمنة فقط**")


@client.on(events.NewMessage(pattern=r'\.تحكم كامل$', outgoing=True))
async def set_full_control(event):
    """منح صلاحيات جميع الأوامر للمطورين"""
    if not sudo_users:
        await event.edit("✘ **لا يوجد مطورين مساعدين لتعيين الصلاحيات لهم**")
        return

    for user_id in sudo_users:
        sudo_users[user_id]["level"] = "كامل"

    if "safe" in sudo_enabled_cmds:
        del sudo_enabled_cmds["safe"]

    await event.edit("✓ **تم منح المطورين صلاحيات جميع الأوامر (تحكم كامل)**")


@client.on(events.NewMessage(pattern=r'\.تحكم\s+(\S+)', outgoing=True))
async def set_command_control(event):
    """منح صلاحية أمر محدد"""
    cmd = event.pattern_match.group(1).strip()

    if not sudo_users:
        await event.edit("✘ **لا يوجد مطورين مساعدين لتعيين الصلاحيات لهم**")
        return

    if "custom" not in sudo_enabled_cmds:
        sudo_enabled_cmds["custom"] = []

    if cmd not in sudo_enabled_cmds["custom"]:
        sudo_enabled_cmds["custom"].append(cmd)
        await event.edit(f"✓ **تم منح صلاحية أمر** `{cmd}` **للمطورين**")
    else:
        await event.edit(f"⌔ **أمر** `{cmd}` **مسموح به بالفعل للمطورين**")


@client.on(events.NewMessage(pattern=r'\.ايقاف تحكم آمن$', outgoing=True))
async def disable_safe_control(event):
    """سحب صلاحية الأوامر الآمنة"""
    if "safe" in sudo_enabled_cmds:
        del sudo_enabled_cmds["safe"]
        await event.edit("✓ **تم سحب صلاحية الأوامر الآمنة من المطورين**")
    else:
        await event.edit("✘ **صلاحية الأوامر الآمنة غير مفعلة أصلاً**")


@client.on(events.NewMessage(pattern=r'\.ايقاف تحكم كامل$', outgoing=True))
async def disable_full_control(event):
    """سحب صلاحية جميع الأوامر"""
    for user_id in sudo_users:
        sudo_users[user_id]["level"] = "آمن"

    await event.edit("✓ **تم سحب التحكم الكامل من المطورين وإعادتهم للتحكم الآمن**")


@client.on(events.NewMessage(pattern=r'\.ايقاف تحكم\s+(\S+)', outgoing=True))
async def disable_command_control(event):
    """سحب صلاحية أمر محدد"""
    cmd = event.pattern_match.group(1).strip()

    if "custom" in sudo_enabled_cmds and cmd in sudo_enabled_cmds["custom"]:
        sudo_enabled_cmds["custom"].remove(cmd)
        await event.edit(f"✓ **تم سحب صلاحية أمر** `{cmd}` **من المطورين**")
    else:
        await event.edit(f"✘ **أمر** `{cmd}` **ليس مسموحاً به للمطورين**")


@client.on(events.NewMessage(pattern=r'\.التحكم$', outgoing=True))
async def show_enabled_commands(event):
    """عرض الأوامر المسموحة للمطورين"""
    text = "◈ **الأوامر المسموحة للمطورين:**\n\n"

    if sudo_enabled_cmds:
        if "safe" in sudo_enabled_cmds:
            text += "⌔ **الأوامر الآمنة:**\n"
            text += "⦁ " + " - ".join(sudo_enabled_cmds["safe"][:20]) + "...\n\n"

        if "custom" in sudo_enabled_cmds:
            text += "⌔ **أوامر مخصصة:**\n"
            text += "⦁ " + " - ".join(sudo_enabled_cmds["custom"]) + "\n\n"
    elif any(data["level"] == "كامل" for data in sudo_users.values()):
        text += "⦁ **جميع الأوامر (تحكم كامل)**\n\n"
    else:
        text += "✘ **لم يتم تعيين أي صلاحيات بعد**\n\n"

    text += "⌔ **المطورين الحاليين:**\n"
    for user_id, data in sudo_users.items():
        text += f"⦁ [{data['name']}](tg://user?id={user_id}) - {data['level']}\n"

    await event.edit(text)


@client.on(events.NewMessage(pattern=r'\.التحكم المعطل$', outgoing=True))
async def show_disabled_commands(event):
    """عرض الأوامر الممنوعة عن المطورين"""
    if any(data["level"] == "كامل" for data in sudo_users.values()):
        await event.edit("✓ **التحكم كامل لجميع المطورين. لا توجد أوامر معطلة.**")
        return

    text = "◈ **الأوامر الممنوعة عن المطورين:**\n\n"
    text += "⦁ **أوامر النظام:** تحديث، ريستارت، تنزيل، رفع\n"
    text += "⦁ **أوامر الفارات:** اضف فار، حذف فار\n"
    text += "⦁ **أوامر الإذاعة:** اذاعة\n"
    text += "⦁ **أوامر الحذف:** حذف رسائلي، مسح\n"
    text += "⦁ **أوامر المطور:** رفع مطور، تنزيل مطور\n"

    await event.edit(text)