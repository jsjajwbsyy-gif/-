from main import client
from telethon import events

# ========== M42: أوامر الحب والرومانسية ==========

@client.on(events.NewMessage(pattern=r'\.م42', outgoing=True))
async def show_m42_menu(event):
    menu_text = """⟪───── أوامر الحب والرومانسية ─────⟫

│ `.حب`
│ ← نسبة الحب بين شخصين

│ `.تطابق`
│ ← مدى التطابق بين شخصين

│ `.حظ حب`
│ ← حظ الحب اليومي

│ `.صفات حب`
│ ← صفات الحب لشخص

│ `.وصف حب`
│ ← وصف طريقة حب الشخص

│ `.شخصية حب`
│ ← نوع شخصية الحب

│ `.توافق ابراج حب`
│ ← توافق الأبراج في الحب

│ `.رسالة حب`
│ ← رسالة حب عشوائية

│ `.اعتراف حب`
│ ← اعتراف حب جريء

│ `.رسالة اعتذار`
│ ← رسالة اعتذار رومانسية

│ `.غضب حب`
│ ← رسالة غضب رومانسية

│ `.قسم حب`
│ ← قسم حب وهمي

│ `.صباح الحب`
│ ← رسالة صباحية رومانسية

│ `.ليلة سعيدة`
│ ← رسالة ليلة سعيدة

│ `.حكمة حب`
│ ← حكمة عن الحب

│ `.حالة حب`
│ ← حالة حب عشوائية

│ `.اغنية حب`
│ ← اقتراح أغنية حب

│ `.ليريك حب`
│ ← كلمات أغنية حب

│ `.زواج حب`
│ ← زواج وهمي (بالرد)

│ `.طلاق حب`
│ ← طلاق وهمي (بالرد)

│ `.ذكرى حب`
│ ← حساب مدة العلاقة

│ `.قبلات حب`
│ ← عداد القبلات

│ `.هدية حب`
│ ← هدية وهمية (بالرد)

│ `.ورد حب`
│ ← باقة ورد (أحمر/أبيض/وردي/أصفر)

│ `.تحدي حب`
│ ← تحدي رومانسي

│ `.تحدي جرأة حب`
│ ← تحدي جرأة

│ `.حرب حب`
│ ← حرب حب بين شخصين

│ `.موعد رومانسي`
│ ← اقتراح موعد رومانسي

│ `.قصة حب`
│ ← قصة حب عشوائية

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== أوامر حسابات الحب ==========

@client.on(events.NewMessage(pattern=r'\.حب\s+(\S+)\s+(\S+)', outgoing=True))
async def love_percentage(event):
    name1 = event.pattern_match.group(1).strip()
    name2 = event.pattern_match.group(2).strip()
    percent = random.randint(40, 100)
    emojis = ["💕", "💖", "💘", "💝", "💗"]
    await event.edit(f"{random.choice(emojis)} **نسبة الحب بين {name1} و {name2}:** {percent}%")


@client.on(events.NewMessage(pattern=r'\.تطابق\s+(\S+)\s+(\S+)', outgoing=True))
async def love_match(event):
    name1 = event.pattern_match.group(1).strip()
    name2 = event.pattern_match.group(2).strip()
    match = random.randint(50, 100)
    await event.edit(f"💘 **مدى التطابق بين {name1} و {name2}:** {match}%")


@client.on(events.NewMessage(pattern=r'\.حظ حب\s+(\S+)', outgoing=True))
async def love_luck(event):
    name = event.pattern_match.group(1).strip()
    luck = random.randint(0, 100)
    if luck >= 80: status = "🌟 رائع! الحب في طريقه إليك"
    elif luck >= 60: status = "😊 جيد! فرصتك في الحب عالية"
    elif luck >= 40: status = "😐 متوسط! انتظر قليلاً"
    else: status = "💔 سيء! ركز على نفسك اليوم"
    await event.edit(f"🔮 **حظ الحب لـ {name}:** {luck}%\n📝 {status}")


@client.on(events.NewMessage(pattern=r'\.صفات حب\s+(\S+)', outgoing=True))
async def love_traits(event):
    name = event.pattern_match.group(1).strip()
    traits = ["وفي 💍", "غامض 🖤", "عاطفي 🌹", "حساس 🥺", "مخلص 💯", "شجاع 🦁", "خجول 😳"]
    selected = random.sample(traits, 3)
    await event.edit(f"💝 **صفات الحب لـ {name}:**\n" + "\n".join(f"• {t}" for t in selected))


@client.on(events.NewMessage(pattern=r'\.وصف حب\s+(\S+)', outgoing=True))
async def love_description(event):
    name = event.pattern_match.group(1).strip()
    styles = [
        "يحب من كل قلبه ❤️", "يخفي حبه جيداً 🤫", "يعبر عن حبه بالأفعال 🎁",
        "يميل للحب الرومانسي 🌹", "يحب بطريقة جنونية 🤪"
    ]
    await event.edit(f"💝 **{name}** {random.choice(styles)}")


@client.on(events.NewMessage(pattern=r'\.شخصية حب\s+(\S+)', outgoing=True))
async def love_personality(event):
    name = event.pattern_match.group(1).strip()
    types = ["العاشق المجنون 🤪", "الحالم 💭", "الواقعي 🧠", "الغيور 👀", "المخلص 💯"]
    await event.edit(f"🎭 **شخصية الحب لـ {name}:** {random.choice(types)}")


@client.on(events.NewMessage(pattern=r'\.توافق ابراج حب\s+(\S+)\s+(\S+)', outgoing=True))
async def love_horoscope(event):
    sign1 = event.pattern_match.group(1).strip()
    sign2 = event.pattern_match.group(2).strip()
    match = random.randint(20, 100)
    await event.edit(f"🧿 **توافق {sign1} و {sign2} في الحب:** {match}%")


# ========== أوامر رسائل الحب ==========

@client.on(events.NewMessage(pattern=r'\.رسالة حب', outgoing=True))
async def love_message(event):
    messages = [
        "💌 في عينيك وطني، وفي قلبك مسكني، ومعك فقط تكتمل سعادتي.",
        "💕 أحببتك دون سبب، وبدون سبب سأظل أحبك للأبد.",
        "🌹 لو كان الحب وردة لكنت أنت حديقتي.",
        "💝 لم أكن أؤمن بالحب حتى التقيت بك.",
    ]
    await event.edit(random.choice(messages))


@client.on(events.NewMessage(pattern=r'\.اعتراف حب', outgoing=True))
async def love_confession(event):
    confessions = [
        "💘 عندي اعتراف... أنا واقع في حبك من أول نظرة!",
        "💕 ما أقدر أخبي بعد... أحبك موت!",
        "😍 اعترفلك بكل صراحة... أنت أجمل شي صار بحياتي!",
    ]
    await event.edit(random.choice(confessions))


@client.on(events.NewMessage(pattern=r'\.رسالة اعتذار', outgoing=True))
async def apology_message(event):
    apologies = [
        "🙏 آسف من كل قلبي، ما كنت أقصد أبداً.",
        "💔 عمري ما فكرت إني بزعلك، سامحني.",
        "🥺 غلطتي كبيرة لكن حبي أكبر، سامحني.",
    ]
    await event.edit(random.choice(apologies))


@client.on(events.NewMessage(pattern=r'\.غضب حب', outgoing=True))
async def love_anger(event):
    angers = [
        "😤 زعلان منك بس ما أقدر أكرهك!",
        "💢 ما بكلمك... إلا إذا بوسني!",
        "🤬 أحبك بس ما أطيقك اليوم!",
    ]
    await event.edit(random.choice(angers))


@client.on(events.NewMessage(pattern=r'\.قسم حب', outgoing=True))
async def love_oath(event):
    oaths = [
        "🤚 أقسم بالحب إني ما رح أخونك أبداً.",
        "💫 والله العظيم إنك أغلى حاجة بحياتي.",
        "💕 أقسملك إني رح فضل جنبك طول العمر.",
    ]
    await event.edit(random.choice(oaths))


@client.on(events.NewMessage(pattern=r'\.صباح الحب', outgoing=True))
async def love_morning(event):
    mornings = [
        "☀️ صباح الخير يا أجمل صباحاتي!",
        "🌅 صباح الحب والورد يا عمري.",
        "💕 صباحك حب وعسل يا قلبي.",
    ]
    await event.edit(random.choice(mornings))


@client.on(events.NewMessage(pattern=r'\.ليلة سعيدة', outgoing=True))
async def love_night(event):
    nights = [
        "🌙 تصبح على خير يا روحي، أحلامك حلوة.",
        "💫 ليلة سعيدة يا نور عيني.",
        "😴 نام وعيوني تحرسك، بحبك.",
    ]
    await event.edit(random.choice(nights))


@client.on(events.NewMessage(pattern=r'\.حكمة حب', outgoing=True))
async def love_wisdom(event):
    wisdoms = [
        "🌹 الحب الحقيقي لا يموت، قد يتعب لكنه لا ينتهي.",
        "💕 أحب بجنون، فعمرك قصير على الحب البارد.",
        "💝 الحب مش نظرة، الحب ألف نظرة ونظرة.",
    ]
    await event.edit(random.choice(wisdoms))


@client.on(events.NewMessage(pattern=r'\.حالة حب', outgoing=True))
async def love_status(event):
    statuses = [
        "❤️ ملكت قلبي وما في حد غيرك.",
        "💔 الحب جميل لكنه مؤلم أحياناً.",
        "💗 في انتظار حب حقيقي.",
        "💘 محظوظ لأني لقيتك.",
    ]
    await event.edit(random.choice(statuses))


# ========== أوامر أغاني الحب ==========

@client.on(events.NewMessage(pattern=r'\.اغنية حب', outgoing=True))
async def love_song(event):
    songs = [
        "🎵 **أقترح:** Perfect - Ed Sheeran",
        "🎵 **أقترح:** All of Me - John Legend",
        "🎵 **أقترح:** Thinking Out Loud - Ed Sheeran",
    ]
    await event.edit(random.choice(songs))


@client.on(events.NewMessage(pattern=r'\.ليريك حب', outgoing=True))
async def love_lyrics(event):
    lyrics = [
        "🎤 'I found a love for me, darling just dive right in...'",
        "🎤 'Cause all of me loves all of you...'",
        "🎤 'When your legs don't work like they used to before...'",
    ]
    await event.edit(random.choice(lyrics))


# ========== أوامر علاقات الحب ==========

@client.on(events.NewMessage(pattern=r'\.زواج حب', outgoing=True))
async def love_marriage(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return
    target = await reply.get_sender()
    user = await event.get_sender()
    await event.edit(f"💍 **تم زواج** {user.first_name} **و** {target.first_name}\n🎉 ألف مبروك! 💒")


@client.on(events.NewMessage(pattern=r'\.طلاق حب', outgoing=True))
async def love_divorce(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return
    target = await reply.get_sender()
    user = await event.get_sender()
    await event.edit(f"💔 **تم طلاق** {user.first_name} **و** {target.first_name}\n😢 للأسف ما نفع النصيب!")


@client.on(events.NewMessage(pattern=r'\.ذكرى حب\s+(\d+)[/\-](\d+)[/\-](\d+)', outgoing=True))
async def love_anniversary(event):
    d = int(event.pattern_match.group(1))
    m = int(event.pattern_match.group(2))
    y = int(event.pattern_match.group(3))
    try:
        from datetime import datetime
        past = datetime(y, m, d)
        now = datetime.now()
        diff = now - past
        days = diff.days
        months = days // 30
        years = days // 365
        await event.edit(f"📅 **مدة العلاقة:**\n{years} سنة | {months} شهر | {days} يوم ❤️")
    except:
        await event.edit("❌ **تاريخ غير صالح**")


@client.on(events.NewMessage(pattern=r'\.قبلات حب', outgoing=True))
async def love_kisses(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return
    target = await reply.get_sender()
    kisses = random.randint(1, 1000)
    await event.edit(f"💋 **عداد القبلات:**\n👤 من: {(await event.get_sender()).first_name}\n👤 إلى: {target.first_name}\n💋 **العدد:** {kisses} قبلة!")


# ========== أوامر هدايا الحب ==========

@client.on(events.NewMessage(pattern=r'\.هدية حب', outgoing=True))
async def love_gift(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return
    target = await reply.get_sender()
    gifts = ["💎 خاتم ألماس", "🌹 99 وردة حمراء", "🧸 دبدوب عملاق", "🍫 علبة شوكولاتة", "💍 سوار ذهب"]
    await event.edit(f"🎁 **هدية من** {(await event.get_sender()).first_name} **إلى** {target.first_name}:\n{random.choice(gifts)}")


@client.on(events.NewMessage(pattern=r'\.ورد حب\s+(\S+)\s+(\S+)', outgoing=True))
async def love_flower(event):
    color = event.pattern_match.group(1).strip()
    name = event.pattern_match.group(2).strip()
    meanings = {"أحمر": "الحب ❤️", "أبيض": "النقاء 🤍", "وردي": "الإعجاب 💗", "أصفر": "الصداقة 💛"}
    meaning = meanings.get(color, "الحب 💕")
    await event.edit(f"🌹 **باقة ورد {color}** من {(await event.get_sender()).first_name} إلى {name}\n💬 {meaning}")


# ========== أوامر تحديات الحب ==========

@client.on(events.NewMessage(pattern=r'\.تحدي حب', outgoing=True))
async def love_challenge(event):
    challenges = [
        "🎯 **تحدي:** قول اسم حبيبك السابق!",
        "🎯 **تحدي:** أرسل رسالة حب للشخص اللي فوقك!",
        "🎯 **تحدي:** احكي عن أول قبلة لك!",
    ]
    await event.edit(random.choice(challenges))


@client.on(events.NewMessage(pattern=r'\.تحدي جرأة حب', outgoing=True))
async def love_dare(event):
    dares = [
        "🔥 **جرأة:** اعترف بحبك لشخص بالغرفة!",
        "🔥 **جرأة:** أرسل صوت وأنت تغني أغنية حب!",
        "🔥 **جرأة:** اتصل بحبيبك/حبيبتك وقول أحبك!",
    ]
    await event.edit(random.choice(dares))


@client.on(events.NewMessage(pattern=r'\.حرب حب\s+(\S+)\s+(\S+)', outgoing=True))
async def love_war(event):
    name1 = event.pattern_match.group(1).strip()
    name2 = event.pattern_match.group(2).strip()
    winner = random.choice([name1, name2])
    await event.edit(f"⚔️ **حرب حب بين {name1} و {name2}**\n🏆 **الفائز:** {winner}!")


@client.on(events.NewMessage(pattern=r'\.موعد رومانسي', outgoing=True))
async def love_date(event):
    places = ["مطعم إيطالي 🍝", "حديقة 🌳", "سينما 🎬", "شاطئ 🏖️", "مقهى ☕"]
    await event.edit(f"💑 **أقترح موعد رومانسي:**\n📍 {random.choice(places)}\n⏰ الساعة {random.randint(6, 10)} مساءً")


# ========== أوامر قصص الحب ==========

@client.on(events.NewMessage(pattern=r'\.قصة حب', outgoing=True))
async def love_story(event):
    stories = [
        "📖 في يوم ممطر، التقت عيناهما... ومنذ تلك اللحظة عرفا أنهما قدر بعض.",
        "📖 جمعتهما الصدفة في مقهى صغير، وتبادلا النظرات حتى أصبحا لا يفترقان.",
        "📖 حب من طرف واحد تحول إلى أعظم قصة حب بعد سنوات من الصبر.",
    ]
    await event.edit(random.choice(stories))