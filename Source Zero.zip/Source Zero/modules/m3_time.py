import asyncio
from datetime import datetime
import pytz
from telethon import events
from telethon.tl.functions.account import UpdateProfileRequest

# استيراد المتغيرات من الملف الرئيسي
from main import client

time_settings = {}

TIME_SHAPES = {
    1: {"0": "𝟎", "1": "𝟏", "2": "𝟐", "3": "𝟑", "4": "𝟒", "5": "𝟓", "6": "𝟔", "7": "𝟕", "8": "𝟖", "9": "𝟗", ":": ":"},
    2: {"0": "𝟶", "1": "𝟷", "2": "𝟸", "3": "𝟹", "4": "𝟺", "5": "𝟻", "6": "𝟼", "7": "𝟽", "8": "𝟾", "9": "𝟿", ":": ":"},
    3: {"0": "𝟢", "1": "𝟣", "2": "𝟤", "3": "𝟥", "4": "𝟦", "5": "𝟧", "6": "𝟨", "7": "𝟩", "8": "𝟪", "9": "𝟫", ":": ":"},
    4: {"0": "𝟬", "1": "𝟭", "2": "𝟮", "3": "𝟯", "4": "𝟰", "5": "𝟱", "6": "𝟲", "7": "𝟳", "8": "𝟴", "9": "𝟵", ":": ":"},
    5: {"0": "𝟶", "1": "𝟷", "2": "𝟸", "3": "𝟹", "4": "𝟺", "5": "𝟻", "6": "𝟼", "7": "𝟽", "8": "𝟾", "9": "𝟿", ":": ":"},
    6: {"0": "۰", "1": "۱", "2": "۲", "3": "۳", "4": "۴", "5": "۵", "6": "۶", "7": "۷", "8": "۸", "9": "۹", ":": ":"},
    7: {"0": "٠", "1": "١", "2": "٢", "3": "٣", "4": "٤", "5": "٥", "6": "٦", "7": "٧", "8": "٨", "9": "٩", ":": ":"},
    8: {"0": "₀", "1": "₁", "2": "₂", "3": "₃", "4": "₄", "5": "₅", "6": "₆", "7": "₇", "8": "₈", "9": "₉", ":": ":"},
    9: {"0": "⓪", "1": "⓵", "2": "⓶", "3": "⓷", "4": "⓸", "5": "⓹", "6": "⓺", "7": "⓻", "8": "⓼", "9": "⓽", ":": ":"},
    10: {"0": "⓪", "1": "①", "2": "②", "3": "③", "4": "④", "5": "⑤", "6": "⑥", "7": "⑦", "8": "⑧", "9": "⑨", ":": ":"},
    11: {"0": "𝟘", "1": "𝟙", "2": "𝟚", "3": "𝟛", "4": "𝟜", "5": "𝟝", "6": "𝟞", "7": "𝟟", "8": "𝟠", "9": "𝟡", ":": ":"},
    12: {"0": "⓿", "1": "❶", "2": "❷", "3": "❸", "4": "❹", "5": "❺", "6": "❻", "7": "❼", "8": "❽", "9": "❾", ":": ":"},
}

TIMEZONES = {
    "السعودية": "Asia/Riyadh", "الرياض": "Asia/Riyadh",
    "مصر": "Africa/Cairo", "القاهرة": "Africa/Cairo",
    "الإمارات": "Asia/Dubai", "دبي": "Asia/Dubai",
    "الكويت": "Asia/Kuwait", "قطر": "Asia/Qatar",
    "البحرين": "Asia/Bahrain", "عمان": "Asia/Muscat",
    "الاردن": "Asia/Amman", "فلسطين": "Asia/Gaza",
    "لبنان": "Asia/Beirut", "سوريا": "Asia/Damascus",
    "اليمن": "Asia/Aden", "العراق": "Asia/Baghdad", "بغداد": "Asia/Baghdad",
    "المغرب": "Africa/Casablanca", "الجزائر": "Africa/Algiers",
    "تونس": "Africa/Tunis", "ليبيا": "Africa/Tripoli",
    "السودان": "Africa/Khartoum", "موريتانيا": "Africa/Nouakchott",
    "بريطانيا": "Europe/London", "لندن": "Europe/London",
    "فرنسا": "Europe/Paris", "باريس": "Europe/Paris",
    "المانيا": "Europe/Berlin", "برلين": "Europe/Berlin",
    "ايطاليا": "Europe/Rome", "روما": "Europe/Rome",
    "اسبانيا": "Europe/Madrid", "مدريد": "Europe/Madrid",
    "تركيا": "Europe/Istanbul", "اسطنبول": "Europe/Istanbul",
    "روسيا": "Europe/Moscow", "موسكو": "Europe/Moscow",
    "امريكا": "America/New_York", "نيويورك": "America/New_York",
    "كندا": "America/Toronto", "تورونتو": "America/Toronto",
    "البرازيل": "America/Sao_Paulo", "ساو باولو": "America/Sao_Paulo",
    "اليابان": "Asia/Tokyo", "طوكيو": "Asia/Tokyo",
    "الصين": "Asia/Shanghai", "بكين": "Asia/Shanghai",
    "الهند": "Asia/Kolkata", "دلهي": "Asia/Kolkata",
    "باكستان": "Asia/Karachi", "كراتشي": "Asia/Karachi",
    "اندونيسيا": "Asia/Jakarta", "جاكرتا": "Asia/Jakarta",
    "ماليزيا": "Asia/Kuala_Lumpur", "كوالالمبور": "Asia/Kuala_Lumpur",
    "استراليا": "Australia/Sydney", "سيدني": "Australia/Sydney",
    "نيوزيلندا": "Pacific/Auckland", "اوكلاند": "Pacific/Auckland",
    "جنوب افريقيا": "Africa/Johannesburg",
    "نيجيريا": "Africa/Lagos",
}

# ========== دالة مساعدة: تحويل الوقت إلى الشكل المطلوب ==========
def format_time_with_shape(time_str, shape_num):
    shape = TIME_SHAPES.get(shape_num, TIME_SHAPES[1])
    result = ""
    for char in time_str:
        if char in shape:
            result += shape[char]
        else:
            result += char
    return result

# ========== دالة تحديث الاسم الثاني بالوقت ==========
async def update_last_name_with_time(user_id):
    try:
        settings = time_settings[user_id]["name_timer"]
        country = settings["country"]
        shape_num = settings.get("shape", 1)
        
        tz = TIMEZONES.get(country, "Asia/Riyadh")
        try:
            tz = pytz.timezone(tz)
        except:
            tz = pytz.timezone("Asia/Riyadh")
        
        now = datetime.now(tz)
        time_str = now.strftime("%I:%M")
        formatted_time = format_time_with_shape(time_str, shape_num)
        await client(UpdateProfileRequest(last_name=formatted_time[:64]))
    except:
        pass
    
    while True:
        try:
            if user_id not in time_settings:
                break
            if "name_timer" not in time_settings[user_id]:
                break
            if not time_settings[user_id]["name_timer"].get("enabled", False):
                break
            
            settings = time_settings[user_id]["name_timer"]
            country = settings["country"]
            shape_num = settings.get("shape", 1)
            
            tz = TIMEZONES.get(country, "Asia/Riyadh")
            try:
                tz = pytz.timezone(tz)
            except:
                tz = pytz.timezone("Asia/Riyadh")
            
            now = datetime.now(tz)
            time_str = now.strftime("%I:%M")
            formatted_time = format_time_with_shape(time_str, shape_num)
            
            await client(UpdateProfileRequest(last_name=formatted_time[:64]))
            
            seconds_to_next_minute = 60 - datetime.now(tz).second
            await asyncio.sleep(seconds_to_next_minute)
            
        except Exception as e:
            await asyncio.sleep(60)

# ========== دالة تحديث البايو بالوقت ==========
async def update_bio_with_time(user_id):
    while True:
        try:
            if user_id not in time_settings:
                break
            if "bio_timer" not in time_settings[user_id]:
                break
            if not time_settings[user_id]["bio_timer"].get("enabled", False):
                break
            
            settings = time_settings[user_id]["bio_timer"]
            country = settings["country"]
            shape_num = settings.get("shape", 1)
            
            tz = TIMEZONES.get(country, "Asia/Riyadh")
            try:
                tz = pytz.timezone(tz)
            except:
                tz = pytz.timezone("Asia/Riyadh")
            
            now = datetime.now(tz)
            time_str = now.strftime("%I:%M")
            date_str = now.strftime("%d/%m/%Y")
            day_name = now.strftime("%A")
            
            days_ar = {
                "Saturday": "السبت", "Sunday": "الأحد", "Monday": "الإثنين",
                "Tuesday": "الثلاثاء", "Wednesday": "الأربعاء", "Thursday": "الخميس", "Friday": "الجمعة"
            }
            day_ar = days_ar.get(day_name, day_name)
            
            formatted_time = format_time_with_shape(time_str, shape_num)
            bio_text = f"⏰ {formatted_time} | 📅 {day_ar} {date_str}"
            
            await client(UpdateProfileRequest(about=bio_text[:70]))
            await asyncio.sleep(60)
            
        except Exception as e:
            await asyncio.sleep(60)

# ========== أمر .اسم_وقتي ==========
@client.on(events.NewMessage(pattern=r'\.اسم_وقتي\s+([\s\S]+)', outgoing=True))
async def name_timer(event):
    country = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in time_settings:
        time_settings[user_id] = {}
    
    me = await client.get_me()
    time_settings[user_id]["original_last_name"] = me.last_name
    time_settings[user_id]["name_timer"] = {
        "enabled": True,
        "country": country,
        "shape": time_settings[user_id].get("shape", 1)
    }
    
    await event.edit(f"**تـم تـحديث الاسـم الى {country} ✓**")
    asyncio.create_task(update_last_name_with_time(user_id))

# ========== أمر .اشكال الوقت ==========
@client.on(events.NewMessage(pattern=r'\.اشكال الوقت', outgoing=True))
async def show_time_shapes(event):
    shapes_text = """⌯ قائمـة أشكـال الوقـت:

1: 𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗𝟎
2: 𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿𝟶
3: 𝟣𝟤𝟥𝟦𝟧𝟨𝟩𝟪𝟫𝟢
4: 𝟭𝟮𝟯𝟰𝟱𝟲𝟳𝟴𝟵𝟬
5: 𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿𝟶
6: ۱۲۳۴۵۶۷۸۹۰
7: ١٢٣٤٥٦٧٨٩٠
8: ₁₂₃₄₅₆₇₈₉₀
9: ⓵⓶⓷⓸⓹⓺⓻⓼⓽⓪
10: ①②③④⑤⑥⑦⑧⑨⓪
11: 𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡𝟘
12: ❶❷❸❹❺❻❼❽❾⓿"""
    await event.edit(shapes_text)

# ========== أمر .ايقاف الاسم ==========
@client.on(events.NewMessage(pattern=r'\.ايقاف الاسم', outgoing=True))
async def stop_name_timer(event):
    user_id = event.sender_id
    
    if user_id in time_settings and "name_timer" in time_settings[user_id]:
        time_settings[user_id]["name_timer"]["enabled"] = False
        original_last_name = time_settings[user_id].get("original_last_name", "")
        await client(UpdateProfileRequest(last_name=original_last_name[:64]))
        await event.edit("**تم إيقاف الساعة ✓**")
    else:
        await event.edit("❌ **الساعة غير مفعلة حالياً**")

# ========== أمر .ايقاف البايو ==========
@client.on(events.NewMessage(pattern=r'\.ايقاف البايو', outgoing=True))
async def stop_bio_timer(event):
    user_id = event.sender_id
    
    if user_id in time_settings and "bio_timer" in time_settings[user_id]:
        time_settings[user_id]["bio_timer"]["enabled"] = False
        await event.edit("**تم إيقاف تحديث البايو**")
    else:
        await event.edit("❌ **عداد البايو غير مفعل حالياً**")

# ========== أمر .الشكل ==========
@client.on(events.NewMessage(pattern=r'\.الشكل\s+(\d+)', outgoing=True))
async def set_shape(event):
    try:
        shape_num = int(event.pattern_match.group(1).strip())
    except:
        await event.edit("❌ **يرجى إدخال رقم صحيح**")
        return
    
    if shape_num not in TIME_SHAPES:
        await event.edit(f"❌ **الشكل غير موجود**\n*الأشكال المتاحة: 1 إلى 12*")
        return
    
    user_id = event.sender_id
    if user_id not in time_settings:
        time_settings[user_id] = {}
    
    time_settings[user_id]["shape"] = shape_num
    
    if "name_timer" in time_settings[user_id]:
        time_settings[user_id]["name_timer"]["shape"] = shape_num
    
    if "bio_timer" in time_settings[user_id]:
        time_settings[user_id]["bio_timer"]["shape"] = shape_num
    
    if time_settings[user_id].get("name_timer", {}).get("enabled", False):
        try:
            settings = time_settings[user_id]["name_timer"]
            country = settings["country"]
            
            tz = TIMEZONES.get(country, "Asia/Riyadh")
            try:
                tz = pytz.timezone(tz)
            except:
                tz = pytz.timezone("Asia/Riyadh")
            
            now = datetime.now(tz)
            time_str = now.strftime("%I:%M")
            formatted_time = format_time_with_shape(time_str, shape_num)
            
            await client(UpdateProfileRequest(last_name=formatted_time[:64]))
        except:
            pass
    
    sample_time = datetime.now().strftime("%I:%M")
    formatted = format_time_with_shape(sample_time, shape_num)
    
    await event.edit(f"**تـم تغيير الشكل إلى رقم {shape_num} ✓**")

# ========== أمر .بايو_وقتي ==========
@client.on(events.NewMessage(pattern=r'\.بايو_وقتي\s+([\s\S]+)', outgoing=True))
async def bio_timer(event):
    country = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in time_settings:
        time_settings[user_id] = {}
    
    time_settings[user_id]["bio_timer"] = {
        "enabled": True,
        "country": country,
        "shape": time_settings[user_id].get("shape", 1)
    }
    
    await event.edit(f"**تم تفعيل تحديث البايو بالوقت ✓**\n📍 *البلد:* {country}")
    asyncio.create_task(update_bio_with_time(user_id))

# ========== أمر .مؤقت ==========
@client.on(events.NewMessage(pattern=r'\.مؤقت', outgoing=True))
async def timer_60(event):
    msg = await event.edit(f"⏳ **بدء المؤقت:** 60 ثانية")
    for i in range(60, 0, -1):
        await asyncio.sleep(1)
        try:
            await msg.edit(f"⏳ **الوقت المتبقي:** {i} ثانية")
        except:
            pass
    await msg.edit("⏰ **انتهى الوقت!**")

# ========== أمر .تنازلي ==========
@client.on(events.NewMessage(pattern=r'\.تنازلي\s+(\d+)', outgoing=True))
async def countdown(event):
    try:
        seconds = int(event.pattern_match.group(1).strip())
    except:
        await event.edit("❌ **يرجى إدخال رقم صحيح**")
        return
    
    if seconds <= 0:
        await event.edit("❌ **يجب أن يكون الرقم أكبر من صفر**")
        return
    
    if seconds > 3600:
        await event.edit("❌ **الحد الأقصى هو 3600 ثانية (ساعة واحدة)**")
        return
    
    msg = await event.edit(f"⏳ **بدء المؤقت:** {seconds} ثانية")
    for i in range(seconds, 0, -1):
        await asyncio.sleep(1)
        try:
            await msg.edit(f"⏳ **الوقت المتبقي:** {i} ثانية")
        except:
            pass
    await msg.edit("⏰ **انتهى الوقت!**")

# ========== أمر .الدول ==========
@client.on(events.NewMessage(pattern=r'\.الدول', outgoing=True))
async def show_countries(event):
    countries_text = """🌍 **الدول المتاحة (اضغط على أي دولة لنسخها):**

🇸🇦 **العربية:**
`السعودية` `مصر` `الإمارات` `الكويت` `قطر` `البحرين` `عمان` `الأردن` `فلسطين` `لبنان` `سوريا` `اليمن` `العراق` `المغرب` `الجزائر` `تونس` `ليبيا` `السودان` `موريتانيا`

🇪🇺 **الأوروبية:**
`بريطانيا` `لندن` `فرنسا` `باريس` `المانيا` `برلين` `ايطاليا` `روما` `اسبانيا` `مدريد` `تركيا` `اسطنبول` `روسيا` `موسكو`

🇺🇸 **الأمريكيتين:**
`امريكا` `نيويورك` `كندا` `تورونتو` `البرازيل` `ساو باولو`

🌏 **آسيا والمحيط:**
`اليابان` `طوكيو` `الصين` `بكين` `الهند` `دلهي` `باكستان` `اندونيسيا` `ماليزيا` `استراليا` `سيدني` `نيوزيلندا`

🇿🇦 **أفريقيا:**
`جنوب افريقيا` `نيجيريا`

📌 **للاستخدام:** `.اسم_وقتي` `اسم_الدولة` أو `.بايو_وقتي` `اسم_الدولة`"""
    
    await event.edit(countries_text)

# ========== أمر .م3 (عرض القائمة) ==========
@client.on(events.NewMessage(pattern=r'\.م3', outgoing=True))
async def show_m3_menu(event):
    menu_text = """⟪───── أوامر الوقتـي ─────⟫

│ `.اسم_وقتي + البلد`
│ ← لتفعيل ساعة في الاسم الثاني

│ `.اشكال الوقت`
│ ← لعرض اشكال أرقام الساعة

│ `.ايقاف الاسم`
│ ← لإيقاف الساعة واستعادة الاسم الثاني

│ `.ايقاف البايو`
│ ← لإيقاف العد في البايو

│ `.الشكل مع رقم`
│ ← لتحديد شكل الساعة، مثال: .الشكل 4

│ `.بايو_وقتي + البلد`
│ ← يعرض الساعة واليوم والشهر والسنة في البايو

│ `.مؤقت`
│ ← يبدأ العد لمدة 60 ثانية

│ `.تنازلي مع الرقم`
│ ← يبدأ العد التنازلي حسب الرقم الذي تحدده

│ `.الدول`
│ ← عرض الدول المتاحة مع إمكانية النسخ بنقرة واحدة
╰─────────────────────────"""
    await event.edit(menu_text)