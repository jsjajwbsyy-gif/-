import random
from datetime import datetime
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

streaks = {"love": {}, "partner": {}, "group": {}}
reaction_settings = {}
last_streak_update = {}

# قوائم الإيموجيات
POSITIVE_EMOJIS = ["❤️", "👍", "😊", "🥰", "😍", "🔥", "💯", "✨", "🌟", "💪"]
NEGATIVE_EMOJIS = ["👎", "😠", "💔", "😢", "😡", "🤬", "💩", "😤", "😒", "🙄"]
RUDE_EMOJIS = ["🖕", "🤮", "👊", "💀", "🤡", "🐷", "🙊", "🍆", "💨", "🫵"]

# ==================== الأمر الرئيسي .م29 ====================
@client.on(events.NewMessage(pattern=r'\.م29', outgoing=True))
async def show_m29_menu(event):
    menu_text = """ ╭───〔  قوائم الأوامر 〕───╮

│ • `.الستريك`
│ ← أوامر نظام الستريك

│ • `.التفاعل`  
│ ← أوامر نظام التفاعل التلقائي

│ • `.المساعدة`  
│ ← معلومات ونصائح عن الستريك

╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 1. أمر .الستريك ====================
@client.on(events.NewMessage(pattern=r'\.الستريك', outgoing=True))
async def show_streak_commands(event):
    menu_text = """╭───〔  أوامر الستريك 〕───╮

│ الستريك اليومي:
│ `.ستريك الحب`
│ ← بدء ستريك حب مع شخص

│ `.ستريك الشريك`  
│ ← بدء ستريك شراكة مع شخص

│ `.ستريك مجموعتي`
│ ← إضافة ستريك للمجموعة

│ العرض والإحصائيات:
│ `.توب الحب`
│ ← أعلى 20 في ستريك الحب

│ `.توب الشريك`
│ ← أعلى 20 في ستريك الشراكة

│ `.توب المجموعات`
│ ← أعلى المجموعات في الستريك

│ `.ستريكي`
│ ← عرض الستريك الخاصة بك

╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 2. أمر .التفاعل ====================
@client.on(events.NewMessage(pattern=r'\.التفاعل', outgoing=True))
async def show_reaction_commands(event):
    menu_text = """╭───〔  أوامر التفاعل 〕───╮

│ التفاعل التلقائي:
│ `.تعيين تفاعل ايجابي الاسم`
│ ← تفاعل عشوائي ايجابي عند ذكر الاسم

│ `.تعيين تفاعل سلبي الاسم`  
│ ← تفاعل عشوائي سلبي عند ذكر الاسم

│ `.تعيين تفاعل وقح الاسم`
│ ← تفاعل عشوائي وقح عند ذكر الاسم

│ `.تفاعلي ايموجي الاسم`
│ ← تفاعل مخصص بإيموجي ثابت

│ الإدارة:
│ `.عرض التفاعل`
│ ← عرض إعدادات التفاعل الحالية

│ `.تعطيل التفاعل`
│ ← إيقاف التفاعل التلقائي

│ `.تفعيل التفاعل`
│ ← إعادة تشغيل التفاعل التلقائي

╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 3. أمر .المساعدة ====================
@client.on(events.NewMessage(pattern=r'\.المساعدة', outgoing=True))
async def show_help_streak(event):
    menu_text = """╭───〔  المساعدة في الستريك 〕───╮

│  معلومات عامة:
│ • كل ستريك مرة واحدة يومياً
│ • يمكن تغيير الشريك بعد التأكيد
│ • يمكن الانتقال بين المجموعات

│  أنواع الستريك:
│ •  ستريك الحب ♡ للعلاقات
│ •  ستريك الشريك 𖤍 للصداقات  
│ •  ستريك المجموعات 👥 للمجتمعات

│  نصائح سريعة:
│ • استخدم .ستريكي لمتابعة تقدمك
│ • تابع .توب للمنافسة مع الآخرين
│ • أضف ستريك يومياً لزيادة العداد

╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== أوامر الستريك ====================

def can_add_streak(user_id, streak_type, target_id):
    """التحقق من إمكانية إضافة ستريك (مرة واحدة يومياً)"""
    today = datetime.now().strftime("%Y-%m-%d")
    key = f"{user_id}_{streak_type}_{target_id}"
    
    if key in last_streak_update and last_streak_update[key] == today:
        return False
    
    last_streak_update[key] = today
    return True

@client.on(events.NewMessage(pattern=r'\.ستريك الحب', outgoing=True))
async def love_streak(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على الشخص الذي تريد بدء ستريك الحب معه**")
        return
    
    user_id = event.sender_id
    target_user = await reply.get_sender()
    target_id = target_user.id
    
    if user_id == target_id:
        await event.edit("❌ **لا يمكنك عمل ستريك حب مع نفسك**")
        return
    
    if not can_add_streak(user_id, "love", target_id):
        await event.edit("❌ **لقد قمت بإضافة ستريك الحب اليوم بالفعل**\n*يمكنك الإضافة مرة واحدة يومياً*")
        return
    
    pair_id = tuple(sorted([user_id, target_id]))
    
    if pair_id not in streaks["love"]:
        streaks["love"][pair_id] = {
            "users": [user_id, target_id],
            "count": 0,
            "started": datetime.now()
        }
    
    streaks["love"][pair_id]["count"] += 1
    
    user_name = (await event.get_sender()).first_name
    target_name = target_user.first_name
    
    await event.edit(
        f"♡ **تم إضافة ستريك الحب!**\n\n"
        f"👤 **{user_name}** ♡ **{target_name}**\n"
        f"🔥 **الستريك:** {streaks['love'][pair_id]['count']} يوم\n\n"
        f"💕 *استمر يومياً لزيادة العداد!*"
    )

@client.on(events.NewMessage(pattern=r'\.ستريك الشريك', outgoing=True))
async def partner_streak(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على الشخص الذي تريد بدء ستريك الشراكة معه**")
        return
    
    user_id = event.sender_id
    target_user = await reply.get_sender()
    target_id = target_user.id
    
    if user_id == target_id:
        await event.edit("❌ **لا يمكنك عمل ستريك شراكة مع نفسك**")
        return
    
    if not can_add_streak(user_id, "partner", target_id):
        await event.edit("❌ **لقد قمت بإضافة ستريك الشراكة اليوم بالفعل**")
        return
    
    pair_id = tuple(sorted([user_id, target_id]))
    
    if pair_id not in streaks["partner"]:
        streaks["partner"][pair_id] = {
            "users": [user_id, target_id],
            "count": 0,
            "started": datetime.now()
        }
    
    streaks["partner"][pair_id]["count"] += 1
    
    user_name = (await event.get_sender()).first_name
    target_name = target_user.first_name
    
    await event.edit(
        f"𖤍 **تم إضافة ستريك الشراكة!**\n\n"
        f"👤 **{user_name}** 𖤍 **{target_name}**\n"
        f"🔥 **الستريك:** {streaks['partner'][pair_id]['count']} يوم"
    )

@client.on(events.NewMessage(pattern=r'\.ستريك مجموعتي', outgoing=True))
async def group_streak(event):
    if not event.is_group:
        await event.edit("❌ **هذا الأمر يعمل فقط في المجموعات**")
        return
    
    chat_id = event.chat_id
    user_id = event.sender_id
    
    if not can_add_streak(user_id, "group", chat_id):
        await event.edit("❌ **لقد قمت بإضافة ستريك لهذه المجموعة اليوم بالفعل**")
        return
    
    chat = await event.get_chat()
    
    if chat_id not in streaks["group"]:
        streaks["group"][chat_id] = {
            "title": chat.title,
            "count": 0,
            "members": {}
        }
    
    if user_id not in streaks["group"][chat_id]["members"]:
        streaks["group"][chat_id]["members"][user_id] = 0
    
    streaks["group"][chat_id]["members"][user_id] += 1
    streaks["group"][chat_id]["count"] += 1
    
    await event.edit(
        f"👥 **تم إضافة ستريك للمجموعة!**\n\n"
        f"📢 **{chat.title}**\n"
        f"🔥 **ستريك المجموعة:** {streaks['group'][chat_id]['count']}\n"
        f"👤 **ستريكك:** {streaks['group'][chat_id]['members'][user_id]}"
    )

@client.on(events.NewMessage(pattern=r'\.توب الحب', outgoing=True))
async def top_love_streaks(event):
    if not streaks["love"]:
        await event.edit("📭 **لا توجد ستريكات حب حالياً**")
        return
    
    sorted_streaks = sorted(
        streaks["love"].items(),
        key=lambda x: x[1]["count"],
        reverse=True
    )[:20]
    
    text = "♡ **أعلى 20 في ستريك الحب:**\n\n"
    
    for i, (pair_id, data) in enumerate(sorted_streaks, 1):
        user1_id, user2_id = pair_id
        count = data["count"]
        
        try:
            user1 = await client.get_entity(user1_id)
            user2 = await client.get_entity(user2_id)
            name1 = user1.first_name
            name2 = user2.first_name
        except:
            name1 = str(user1_id)
            name2 = str(user2_id)
        
        crown = "👑" if i == 1 else "⭐" if i == 2 else "✨" if i == 3 else f"{i}."
        text += f"{crown} **{name1}** ♡ **{name2}** - {count} يوم\n"
    
    await event.edit(text)

@client.on(events.NewMessage(pattern=r'\.توب الشريك', outgoing=True))
async def top_partner_streaks(event):
    if not streaks["partner"]:
        await event.edit("📭 **لا توجد ستريكات شراكة حالياً**")
        return
    
    sorted_streaks = sorted(
        streaks["partner"].items(),
        key=lambda x: x[1]["count"],
        reverse=True
    )[:20]
    
    text = "𖤍 **أعلى 20 في ستريك الشراكة:**\n\n"
    
    for i, (pair_id, data) in enumerate(sorted_streaks, 1):
        user1_id, user2_id = pair_id
        count = data["count"]
        
        try:
            user1 = await client.get_entity(user1_id)
            user2 = await client.get_entity(user2_id)
            name1 = user1.first_name
            name2 = user2.first_name
        except:
            name1 = str(user1_id)
            name2 = str(user2_id)
        
        crown = "👑" if i == 1 else "⭐" if i == 2 else "✨" if i == 3 else f"{i}."
        text += f"{crown} **{name1}** 𖤍 **{name2}** - {count} يوم\n"
    
    await event.edit(text)

@client.on(events.NewMessage(pattern=r'\.توب المجموعات', outgoing=True))
async def top_group_streaks(event):
    if not streaks["group"]:
        await event.edit("📭 **لا توجد ستريكات مجموعات حالياً**")
        return
    
    sorted_groups = sorted(
        streaks["group"].items(),
        key=lambda x: x[1]["count"],
        reverse=True
    )[:20]
    
    text = "👥 **أعلى المجموعات في الستريك:**\n\n"
    
    for i, (chat_id, data) in enumerate(sorted_groups, 1):
        title = data["title"]
        count = data["count"]
        
        crown = "👑" if i == 1 else "⭐" if i == 2 else "✨" if i == 3 else f"{i}."
        text += f"{crown} **{title}** - {count} ستريك\n"
    
    await event.edit(text)

@client.on(events.NewMessage(pattern=r'\.ستريكي', outgoing=True))
async def my_streaks(event):
    user_id = event.sender_id
    user = await event.get_sender()
    user_name = user.first_name
    
    text = f"🔥 **ستريكات {user_name}:**\n\n"
    
    love_streaks = []
    for pair_id, data in streaks["love"].items():
        if user_id in pair_id:
            other_id = pair_id[0] if pair_id[1] == user_id else pair_id[1]
            try:
                other_user = await client.get_entity(other_id)
                other_name = other_user.first_name
            except:
                other_name = str(other_id)
            love_streaks.append((other_name, data["count"]))
    
    if love_streaks:
        text += "♡ **ستريك الحب:**\n"
        for name, count in love_streaks:
            text += f"  • مع **{name}** - {count} يوم\n"
    
    partner_streaks = []
    for pair_id, data in streaks["partner"].items():
        if user_id in pair_id:
            other_id = pair_id[0] if pair_id[1] == user_id else pair_id[1]
            try:
                other_user = await client.get_entity(other_id)
                other_name = other_user.first_name
            except:
                other_name = str(other_id)
            partner_streaks.append((other_name, data["count"]))
    
    if partner_streaks:
        text += "\n𖤍 **ستريك الشراكة:**\n"
        for name, count in partner_streaks:
            text += f"  • مع **{name}** - {count} يوم\n"
    
    group_streaks = []
    for chat_id, data in streaks["group"].items():
        if user_id in data["members"]:
            group_streaks.append((data["title"], data["members"][user_id], data["count"]))
    
    if group_streaks:
        text += "\n👥 **ستريك المجموعات:**\n"
        for title, my_count, total in group_streaks:
            text += f"  • **{title}** - {my_count}/{total}\n"
    
    if not love_streaks and not partner_streaks and not group_streaks:
        text += "📭 *لا توجد ستريكات حالياً*\n\n"
        text += "💡 **ابدأ ستريك:**\n"
        text += "• `.ستريك الحب` مع شخص\n"
        text += "• `.ستريك الشريك` مع صديق\n"
        text += "• `.ستريك مجموعتي` في المجموعة"
    
    await event.edit(text)

# ==================== أوامر التفاعل ====================

@client.on(events.NewMessage(pattern=r'\.تعيين تفاعل ايجابي\s+([\s\S]+)', outgoing=True))
async def set_positive_reaction(event):
    name = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in reaction_settings:
        reaction_settings[user_id] = {}
    
    reaction_settings[user_id][name] = {
        "type": "positive",
        "emojis": POSITIVE_EMOJIS
    }
    
    await event.edit(f"✅ **تم تعيين تفاعل ايجابي لاسم:** {name}")

@client.on(events.NewMessage(pattern=r'\.تعيين تفاعل سلبي\s+([\s\S]+)', outgoing=True))
async def set_negative_reaction(event):
    name = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in reaction_settings:
        reaction_settings[user_id] = {}
    
    reaction_settings[user_id][name] = {
        "type": "negative",
        "emojis": NEGATIVE_EMOJIS
    }
    
    await event.edit(f"✅ **تم تعيين تفاعل سلبي لاسم:** {name}")

@client.on(events.NewMessage(pattern=r'\.تعيين تفاعل وقح\s+([\s\S]+)', outgoing=True))
async def set_rude_reaction(event):
    name = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in reaction_settings:
        reaction_settings[user_id] = {}
    
    reaction_settings[user_id][name] = {
        "type": "rude",
        "emojis": RUDE_EMOJIS
    }
    
    await event.edit(f"✅ **تم تعيين تفاعل وقح لاسم:** {name}")

@client.on(events.NewMessage(pattern=r'\.تفاعلي ايموجي\s+(\S+)\s+(\S+)', outgoing=True))
async def set_custom_emoji_reaction(event):
    name = event.pattern_match.group(1).strip()
    emoji = event.pattern_match.group(2).strip()
    user_id = event.sender_id
    
    if user_id not in reaction_settings:
        reaction_settings[user_id] = {}
    
    reaction_settings[user_id][name] = {
        "type": "custom",
        "emoji": emoji
    }
    
    await event.edit(f"✅ **تم تعيين تفاعل مخصص لاسم:** {name} {emoji}")

@client.on(events.NewMessage(pattern=r'\.عرض التفاعل', outgoing=True))
async def show_reactions(event):
    user_id = event.sender_id
    
    if user_id not in reaction_settings or not reaction_settings[user_id]:
        await event.edit("📭 **لا توجد تفاعلات معينة حالياً**")
        return
    
    text = "⚡ **إعدادات التفاعل الحالية:**\n\n"
    
    for name, settings in reaction_settings[user_id].items():
        if settings["type"] == "custom":
            text += f"• **{name}** → {settings['emoji']} (مخصص)\n"
        elif settings["type"] == "positive":
            text += f"• **{name}** → إيجابي عشوائي 😊\n"
        elif settings["type"] == "negative":
            text += f"• **{name}** → سلبي عشوائي 😠\n"
        elif settings["type"] == "rude":
            text += f"• **{name}** → وقح عشوائي 🖕\n"
    
    await event.edit(text)

@client.on(events.NewMessage(pattern=r'\.تعطيل التفاعل', outgoing=True))
async def disable_reaction(event):
    user_id = event.sender_id
    
    if user_id not in reaction_settings:
        reaction_settings[user_id] = {}
    
    reaction_settings[user_id]["enabled"] = False
    
    await event.edit("🔴 **تم تعطيل التفاعل التلقائي**")

@client.on(events.NewMessage(pattern=r'\.تفعيل التفاعل', outgoing=True))
async def enable_reaction(event):
    user_id = event.sender_id
    
    if user_id not in reaction_settings:
        reaction_settings[user_id] = {}
    
    reaction_settings[user_id]["enabled"] = True
    
    await event.edit("✅ **تم تفعيل التفاعل التلقائي**")

# ==================== معالج التفاعل التلقائي ====================
@client.on(events.NewMessage(incoming=True))
async def auto_reaction_handler(event):
    my_id = (await client.get_me()).id
    sender_id = event.sender_id
    
    if sender_id == my_id:
        return
    
    if my_id not in reaction_settings:
        return
    
    if not reaction_settings[my_id].get("enabled", True):
        return
    
    text = event.text
    if not text:
        return
    
    for name, settings in reaction_settings[my_id].items():
        if name == "enabled":
            continue
        
        if name.lower() in text.lower():
            try:
                if settings["type"] == "custom":
                    await event.react(settings["emoji"])
                else:
                    emoji = random.choice(settings["emojis"])
                    await event.react(emoji)
            except:
                pass