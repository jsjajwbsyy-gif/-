import asyncio
import random
from telethon import events
from collections import deque

# استيراد المتغيرات من الملف الرئيسي
from main import client

# ==================== الأمر الرئيسي .م9 ====================
@client.on(events.NewMessage(pattern=r'\.م9', outgoing=True))
async def show_m9_menu(event):
    menu_text = """⌯━━〔 🥳 * التسلية والتحشيش* 〕━━⌯

✶ اختر امراً فرعياً:
   ↢  .اوامر التسلية 
   ↢ .اوامر التحشيش"""
    await event.edit(menu_text)

# ==================== 1. أمر .اوامر التسلية ====================
@client.on(events.NewMessage(pattern=r'\.اوامر التسلية', outgoing=True))
async def show_fun_commands(event):
    menu_text = """⟪───── أوامر التسلية ─────⟫

│ `.وحش` ◇ `.خنزير` ◇ `.قاتل`
│ `.سلاح` ◇ `.كلب` ◇ `.هلو.`
│ `.همف` ◇ `.زوج` ◇ `.رشفة`
│ `.مرحبا` ◇ `.ثعبان` ◇ `.قطة`
│ `.شيتوز` ◇ `.دسلايك` ◇ `.منصة`
│ `.همم` ◇ `.هينفو` ◇ `.النظام الشمسي`
│ `.شرطة` ◇ `.طائرة` ◇ `.فراشة`
│ `.قنبلة` ◇ `.احم` ◇ `.ثلج`
│ `.حلكك` ◇ `.قطار` ◇ `.ساعة`
│ `.هاك` ◇ `.حب` ◇ `.قمر`
│ `.تهكير` ◇ `.مروحيه` ◇ `.ابره`
│ `.افكر` ◇ `.متت` ◇ `.ضايج`
│ `.مح` ◇ `.جيم` ◇ `.ارض`
│ `.اقمار` ◇ `.قمور` ◇ `.القمر`
│ `.مدينه` ◇ `.غبي` ◇ `.قتل`
│ `.شنو` ◇ `.طوبه` ◇ `.مربعات`
│ `.حرق` ◇ `.قنابل` ◇ `.انتحر`
│ `.نجمه` ◇ `.مطر` ◇ `.مكعبات`
│ `.فليم` ◇ `.طائره` ◇ `.تفريغ`
│ `.رقص` ◇ `.مربع` ◇ `.مستطيل`
│ `.دائره` ◇ `.تردد` ◇ `.قرد`
│ `.سرفر` ◇ `.يد` ◇ `.تنازلي`
│ `.قلوب` ◇ `.سبونج بوب` ◇ `.جلبي`
│ `.ثعلب` ◇ `.فيل` ◇ `.معصب`
│ `.مان` ◇ `.صدمه` ◇ `.نادم`
│ `.ترمب` ◇ `.صاك` ◇ `.تشان`
│ `.معارض` ◇ `.ميت` + اسم ◇ `.مافيا` + اسم
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== 2. أمر .اوامر التحشيش ====================
@client.on(events.NewMessage(pattern=r'\.اوامر التحشيش', outgoing=True))
async def show_meme_commands(event):
    menu_text = """⟪───── أوامر التحشيش ─────⟫

│ `.نسبة + اي كلمة`
│ ← بالرد أو باليوزر (مثال: نسبة الحب)

│ `.نسبتنا + اي كلمة`
│ ← بالرد أو باليوزر

│ `.بوسة`
│ ← بالرد أو باليوزر

│ `.هينة`
│ ← بالرد أو باليوزر

│ `.رفع + اي كلمة`
│ ← بالرد أو باليوزر

│ `.زواج`
│ ← بالرد أو باليوزر

│ `.اقتلة`
│ ← بالرد أو باليوزر
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== أوامر ASCII ART (الرسمات الثابتة) - النسخة المحسنة من ريبثون ====================

A = (
    "▄███████▄\n"
    "█▄█████▄█\n"
    "█▼▼▼▼▼█\n"
    "██________█▌\n"
    "█▲▲▲▲▲█\n"
    "█████████\n"
    "_████\n"
)

B = (
    "┈┈┏━╮╭━┓┈╭━━━━╮\n"
    "┈┈┃┏┗┛┓┃╭┫ⓞⓘⓝⓚ┃\n"
    "┈┈╰┓▋▋┏╯╯╰━━━━╯\n"
    "┈╭━┻╮╲┗━━━━╮╭╮┈\n"
    "┈┃▎▎┃╲╲╲╲╲╲┣━╯┈\n"
    "┈╰━┳┻▅╯╲╲╲╲┃┈┈┈\n"
    "┈┈┈╰━┳┓┏┳┓┏╯┈┈┈\n"
    "┈┈┈┈┈┗┻┛┗┻┛┈┈┈┈\n"
)

D = (
    "░▐█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█▄\n"
    "░███████████████████████ \n"
    "░▓▓▓▓▓▓▓▓▓▓▓▓██▓▓▓▓▓▓▓▓◤ \n"
    "░▀░▐▓▓▓▓▓▓▌▀█░░░█▀░\n"
    "░░░▓▓▓▓▓▓█▄▄▄▄▄█▀░░\n"
    "░░█▓▓▓▓▓▌░░░░░░░░░░\n"
    "░▐█▓▓▓▓▓░░░░░░░░░░░\n"
    "░▐██████▌░░░░░░░░░░\n"
)

E = (
    "╥━━━━━━━━╭━━╮━━┳\n"
    "╢╭╮╭━━━━━┫┃▋▋━▅┣\n"
    "╢┃╰┫┈┈┈┈┈┃┃┈┈╰┫┣\n"
    "╢╰━┫┈┈┈┈┈╰╯╰┳━╯┣\n"
    "╢┊┊┃┏┳┳━━┓┏┳┫┊┊┣\n"
    "╨━━┗┛┗┛━━┗┛┗┛━━┻\n"
)

F = "╔┓┏╦━╦┓╔┓╔━━╗\n" "║┗┛║┗╣┃║┃║X X║\n" "║┏┓║┏╣┗╣┗╣╰╯║\n" "╚┛┗╩━╩━╩━╩━━╝\n"

G = (
    "▬▬▬.◙.▬▬▬ \n"
    "═▂▄▄▓▄▄▂ \n"
    "◢◤ █▀▀████▄▄▄▄◢◤ \n"
    "█▄ █ █▄ ███▀▀▀▀▀▀▀╬ \n"
    "◥█████◤ \n"
    "══╩══╩══ \n"
    "╬═╬ \n"
    "╬═╬ \n"
    "╬═╬ \n"
    "╬═╬ \n"
    "╬═╬ \n"
    "╬═╬ \n"
    "╬═╬ Hello, My Friend :D \n"
    "╬═╬☻/ \n"
    "╬═╬/▌ \n"
    "╬═╬/ \\n"
)

H = (
    "┳┻┳┻╭━━━━╮╱▔▔▔╲\n"
    "┻┳┻┳┃╯╯╭━┫▏╰╰╰▕\n"
    "┳┻┳┻┃╯╯┃▔╰┓▔▂▔▕╮\n"
    "┻┳┻┳╰╮╯┃┈╰┫╰━╯┏╯\n"
    "┳┻┳┻┏╯╯┃╭━╯┳━┳╯\n"
    "┻┳┻┳╰━┳╯▔╲╱▔╭╮▔╲\n"
    "┳┻┳┻┳┻┃┈╲┈╲╱╭╯╮▕\n"
    "┻┳┻┳┻┳┃┈▕╲▂╱┈╭╯╱\n"
    "┳┻┳┻┳┻┃'''┈┃┈┃┈'''╰╯\n"
    "┻┳┻┳┻┏╯▔'''╰┓┣━┳┫\n"
    "┳┻┳┻┳╰┳┳┳'''╯┃┈┃┃\n"
    "┻┳┻┳┻┳┃┃┃┈'''┃┈┃┃\n"
    "┳┻┳┻┳┻┃┃┃'''┊┃┈┃┃\n"
    "┻┳┻┳┻┳┃┃┃┈'''┃┈┃┃.\n"
    "┳┻┳┻┳┻┣╋┫'''┊┣━╋┫\n"
    "┻┳┻┳┻╭╯╰╰-╭╯━╯.''╰╮\n"
    "Love You Forever,,,,\n"
)

I = (
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⡿⠋⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⠀⣠⣾⣿⡿⠋⠀⠀⠉⠻⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⠀⣿⣿⣿⠃⠀⠀⣀⡀⠀⢹⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⡄⠀⠙⠻⠋⠀⠀⣸⣿⣿⠀⠀⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀⠀⣰⣿⣿⠟⠀⢠⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⡿⠛⠛⠒⠶⠾⢿⣿⣿⣷⣄⣾⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⢰⣿⣿⣷⣶⣦⣼⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⡀⠀⠙⠻⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⢿⣿⣿⣿⣷⣄⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⠀⠀⠀⠉⠉⠛⠛⠛⠶⢶⣤⣼⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣦⣤⣤⣄⡀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠁⠀⣾⣿⣷⡄⠀⢼⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⠀⢿⣿⣿⡿⠀⠈⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣇⠀⠀⠉⠋⠁⠀⢠⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠿⢷⣤⣀⣀⣀⣠⣾⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⠀⠀⠈⠉⠉⠛⢻⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣶⣦⣤⣤⣀⠀⠀⢸⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⠹⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⡿⠛⠉⠉⠙⠻⣀⣀⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠁⠀⣀⡀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⢸⣿⡇⠀⣷⡀⠘⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⡄⠈⢻⡇⠀⡿⠃⠀⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣷⣄⢸⡇⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⠉⠉⠑⠒⠲⠿⢿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣤⣄⣀⡀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠀⢺⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⠀⠉⠉⠙⠋⠀⠀⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣤⣤⣀⣀⡀⠀⠀⣰⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣷⠀⢹⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⠀⠀⠉⠉⠉⠀⠀⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣶⣤⣤⣀⣀⣀⣀⣰⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⡟⠉⠀⠀⠈⠙⢿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⢀⣤⡄⠀⡀⠀⢹⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⠀⢸⣿⡇⠀⣿⡄⠈⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⡆⠀⢹⡇⠀⠟⠁⢀⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣿⣦⣸⡇⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
)

K = (
    "───▄▀▀▀▄▄▄▄▄▄▄▀▀▀▄───\n"
    "───█▒▒░░░░░░░░░▒▒█───\n"
    "────█░░█░░░░░█░░█────\n"
    "─▄▄──█░░░▀█▀░░░█──▄▄─\n"
    "█░░█─▀▄░░░░░░░▄▀─█░░█\n"
    "█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█\n"
    "█░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█\n"
    "█░░║║║╠─║─║─║║║║║╠─░░█\n"
    "█░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█\n"
    "█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█\n"
)

L = (
    "░░░░▓\n"
    "░░░▓▓\n"
    "░░█▓▓█\n"
    "░██▓▓██\n"
    "░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░██▓▓██\n"
    "░██▓▓██\n"
    "░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░██▓▓██\n"
    "░██▓▓██\n"
    "░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░██▓▓██\n"
    "░██▓▓██\n"
    "░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░██▓▓██\n"
    "░██▓▓██\n"
    "░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░██▓▓██\n"
    "░██▓▓██\n"
    "░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░██▓▓██\n"
    "░██▓▓██\n"
    "░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░██▓▓██\n"
    "░██▓▓██\n"
    "░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░░░██▓▓██\n"
    "░░░░██▓▓██\n"
    "░░░██▓▓██\n"
    "░░██▓▓██\n"
    "░░██▓▓██\n"
    "░░██▓▓██\n"
    "░░██▓▓██\n"
    "░░██▓▓██\n"
    "░░██▓▓██\n"
    "░░░██▓▓███\n"
    "░░░░██▓▓████\n"
    "░░░░░██▓▓█████\n"
    "░░░░░░██▓▓██████\n"
    "░░░░░░███▓▓███████\n"
    "░░░░░████▓▓████████\n"
    "░░░░█████▓▓█████████\n"
    "░░░█████░░░█████●███\n"
    "░░████░░░░░░░███████\n"
    "░░███░░░░░░░░░██████\n"
    "░░██░░░░░░░░░░░████\n"
    "░░░░░░░░░░░░░░░░███\n"
    "░░░░░░░░░░░░░░░░░░░\n"
)

P = (
    "╭━━━┳╮╱╱╭╮╱╭━━━┳━━━╮\n"
    "┃╭━╮┃┃╱╭╯╰╮┃╭━╮┃╭━╮┃\n"
    "┃╰━━┫╰━╋╮╭╯┃┃╱┃┃╰━━╮\n"
    "╰━━╮┃╭╮┣┫┃╱┃┃╱┃┣━━╮┃\n"
    "┃╰━╯┃┃┃┃┃╰╮┃╰━╯┃╰━╯┃\n"
    "╰━━━┻╯╰┻┻━╯╰━━━┻━━━╯\n"
)

R = (
    "███████▄▄███████████▄\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓███░░░░░░░░░░░░█\n"
    "██████▀░░█░░░░██████▀\n"
    "░░░░░░░░░█░░░░█\n"
    "░░░░░░░░░░█░░░█\n"
    "░░░░░░░░░░░█░░█\n"
    "░░░░░░░░░░░█░░█\n"
    "░░░░░░░░░░░░▀▀\n"
)

M = (
    "┈┈ ╱▔▔▔▔▔▔▔▔▔▔▔▏\n"
    "┈╱╭▏╮╭┻┻╮╭┻┻╮ ╭▏ \n"
    "▕╮╰▏╯┃╭╮┃┃╭╮┃ ╰▏ \n"
    "▕╯┈▏┈┗┻┻┛┗┻┻┻╮ ▏ \n"
    "▕╭╮▏╮┈┈┈┈┏━━━╯ ▏\n"
    "▕╰╯▏╯╰┳┳┳┳┳┳╯ ╭▏ \n"
    "▕┈╭▏╭╮┃┗┛┗┛┃┈ ╰▏ \n"
    "▕┈╰▏╰╯╰━━━━╯┈┈ ▏I'm سبـونـج بــوب\n"
)

D2 = (
    "╭━┳━╭━╭━╮╮\n"
    "┃┈┈┈┣▅╋▅┫┃\n"
    "┃┈┃┈╰━╰━━━━━━╮\n"
    "╰┳╯┈┈┈┈┈┈┈┈┈◢▉◣\n"
    "╲┃┈┈┈┈┈┈┈┈┈┈▉▉▉\n"
    "╲┃┈┈┈┈┈┈┈┈┈┈◥▉◤\n"
    "╲┃┈┈┈┈╭━┳━━━━╯\n"
    "╲┣━━━━━━┫You are كـلبي الــمدلل\n"
)

F2 = (
    "╱▏┈┈┈┈┈┈ ▕╲▕╲┈┈┈\n"
    "▏▏┈┈┈┈┈┈ ▕▏▔▔╲┈┈\n"
    "▏╲┈┈┈┈┈┈╱┈▔┈ ▔ ╲┈\n"
    "╲▏▔▔▔▔▔▔╯╯╰┳━━▀\n"
    "┈▏╯╯╯╯╯╯╯╯╱┃┈┈┈\n"
    "┈┃┏┳┳━━━┫┣┳┃┈┈┈\n"
    "┈┃┃┃┃┈┈┈┃┃┃┃┈┈┈\n"
    "┈┗┛┗┛┈┈┈┗┛┗┛┈┈┈You are ثعلــب مــاكر\n"
)

E2 = (
    "┈┈┈┈╱▔▔▔▔▔╲┈╱▔╲\n"
    "┈┈┈┈▏┈┈▏╭╮▕┈▏╳▕\n"
    "┈┈┈┈▏┈┈▏┈┈▕┈╲▂╱\n"
    "┈╱▔▔╲▂╱╲▂▂┈╲▂▏▏\n"
    "╭▏┈┈┈┈┈┈┈▏╲▂▂╱┈\n"
    "┃▏┈┈┈┈▏┈┈▏┈┈┈┈┈\n"
    "╯▏┈╲╱▔╲▅▅▏┈┈┈┈\n"
    "┈╲▅▅▏▕▔▔▔▔▏┈┈┈┈ν2.ο\n"
)

H2 = (
    "┈┈┈╭━━━━━╮┈┈┈┈┈\n"
    "┈┈┈┃┊┊┊┊┊┃┈┈┈┈┈\n"
    "┈┈┈┃┊┊╭━╮┻╮┈┈┈┈\n"
    "┈┈┈╱╲┊┃▋┃▋┃┈┈┈┈\n"
    "┈┈╭┻┊┊╰━┻━╮┈┈┈┈\n"
    "┈┈╰┳┊╭━━━┳╯┈┈┈┈\n"
    "┈┈┈┃┊┃╰━━┫┈I'm ضــايج\n"
    "┈┈┈┈┈┈┏━┓┈┈┈┈┈┈So لا تعصــبني\n"
)

A2 = (
    "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
    "⠀⠀⠀⠀⠀⠀⠀⢀⣤⣤⡀⠀⠀⠀⠀⠀⠀\n"
    "⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀\n"
    "⠀⠀⠀⠀⠀⠀⠀⢿⣿⣿⠟⠀⠀⠀⠀⠀⠀\n"
    "⠀⠀⠀⠀⠀⠀⠀⠘⠻⣿⣷⣄⠀⠀⠀⠀⠀\n"
    "⠀⠀⠀⠀⣴⣶⣿⡆⠀⠀⠉⠉⠀⠈⣶⡆⠀\n"
    "⠀⠀⠀⢠⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⢻⣷⠀\n"
    "⠀⠀⠀⣼⣿⡿⠟⠀⠀⠀⠀⠀⠀⠀⣸⣿⡄\n"
    "⠀⠀⠀⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⣷\n"
    "⠀⠀⠘⠛⠃⠀⠀⠀⠀⠀⠀⠀⠀⢰⣾⣿⠏\n"
    "⠀⢠⣧⡔⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠟⠁⠀\n"
    "⠀⢸⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
)

C2 = (
    "⠄⠄⠄⠄⠄⣀⣀⣤⣶⣿⣿⣶⣶⣶⣤⣄⣠⣴⣶⣿⣶⣦⣄⠄\n"
    "⠄⣠⣴⣾⣿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦\n"
    "⢠⠾⣋⣭⣄⡀⠄⠙⠻⣿⣿⡿⠛⠋⠉⠉⠉⠙⠛⠿⣿⣿⣿⣿\n"
    "⡎⡟⢻⣿⣷⠄⠄⠄⠄⡼⣡⣾⣿⣿⣦⠄⠄⠄⠄⠄⠈⠛⢿⣿\n"
    "⡇⣷⣾⣿⠟⠄⠄⠄⢰⠁⣿⣇⣸⣿⣿⠄⠄⠄⠄⠄⠄⠄⣠⣼\n"
    "⣦⣭⣭⣄⣤⣤⣴⣶⣿⣧⡘⠻⠛⠛⠁⠄⠄⠄⠄⣀⣴⣿⣿⣿\n"
    "⢉⣹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣦⣶⣶⣶⣶⣿⣿⣿⣿⣿⣿\n"
    "⡿⠛⠛⠛⠛⠻⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⡇⠄⠄⢀⣀⣀⠄⠄⠄⠄⠉⠉⠛⠛⠻⠿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⠈⣆⠄⠄⢿⣿⣿⣷⣶⣶⣤⣤⣀⣀⡀⠄⠄⠉⢻⣿⣿⣿⣿⣿\n"
    "⠄⣿⡀⠄⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠂⠄⢠⣿⣿⣿⣿⣿\n"
    "⠄⣿⡇⠄⠄⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠄⢀⣼⣿⣿⣿⣿⣿\n"
    "⠄⣿⡇⠄⠠⣿⣿⣿⣿⣿⣿⣿⡿⠋⠄⠄⣠⣾⣿⣿⣿⣿⣿⣿\n"
    "⠄⣿⠁⠄⠐⠛⠛⠛⠉⠉⠉⠉⠄⠄⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⠄⠻⣦⣀⣀⣀⣀⣀⣤⣤⣤⣤⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋\n"
)

N2 = (
    "⣿⣿⣿⡇⠄⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⡇⠄⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⡇⠄⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⡇⠄⣿⣿⣿⡿⠋⣉⣉⣉⡙⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⠃⠄⠹⠟⣡⣶⢟⣛⣛⡻⢿⣦⣩⣤⣬⡉⢻⣿⣿⣿⣿\n"
    "⣿⣿⣿⠄⢀⢤⣾⣿⣿⣿⡿⠿⠿⠿⢮⡃⣛⡻⢿⠈⣿⣿⣿⣿\n"
    "⣿⡟⢡⣴⣯⣿⣿⣿⠤⣤⣭⣶⣶⣶⣮⣔⡈⠛⢓⠦⠈⢻⣿⣿\n"
    "⠏⣠⣿⣿⣿⣿⣿⣿⣯⡪⢛⠿⢿⣿⣿⣿⡿⣼⣿⣿⣮⣄⠙⣿\n"
    "⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣾⡭⠴⣶⣶⣽⣽⣛⡿⠿⠿⠇⣿\n"
    "⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣿⣿⣿⣿⣷⣝⣛⢛⢋⣥⣴⣿⣿\n"
    "⣿⣿⣿⣿⣿⢿⠱⣿⣛⠾⣭⣛⡿⢿⣿⣿⣿⣿⣿⡀⣿⣿⣿⣿\n"
    "⠑⠽⡻⢿⣮⣽⣷⣶⣯⣽⣳⠮⣽⣟⣲⠯⢭⣿⣛⡇⣿⣿⣿⣿\n"
    "⠄⠄⠈⠑⠊⠉⠟⣻⠿⣿⣿⣿⣷⣾⣭⣿⠷⠶⠂⣴⣿⣿⣿⣿\n"
    "⠄⠄⠄⠄⠄⠄⠄⠁⠙⠒⠙⠯⠍⠙⢉⣡⣶⣿⣿⣿⣿⣿⣿⣿\n"
    "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠙⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
)

T2 = (
    "⣿⣿⣿⣿⣿⣿⡿⠿⠛⠋⠉⡉⣉⡛⣛⠿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⡿⠋⠁⠄⠄⠄⠄⠄⢀⣸⣿⣿⡿⠿⡯⢙⠿⣿⣿⣿⣿\n"
    "⣿⣿⡿⠄⠄⠄⠄⠄⡀⡀⠄⢀⣀⣉⣉⣉⠁⠐⣶⣶⣿⣿⣿⣿\n"
    "⣿⣿⡇⠄⠄⠄⠄⠁⣿⣿⣀⠈⠿⢟⡛⠛⣿⠛⠛⣿⣿⣿⣿⣿\n"
    "⣿⣿⡆⠄⠄⠄⠄⠄⠈⠁⠰⣄⣴⡬⢵⣴⣿⣤⣽⣿⣿⣿⣿⣿\n"
    "⣿⣿⡇⠄⢀⢄⡀⠄⠄⠄⠄⡉⠻⣿⡿⠁⠘⠛⡿⣿⣿⣿⣿⣿\n"
    "⣿⡿⠃⠄⠄⠈⠻⠄⠄⠄⠄⢘⣧⣀⠾⠿⠶⠦⢳⣿⣿⣿⣿⣿\n"
    "⣿⣶⣤⡀⢀⡀⠄⠄⠄⠄⠄⠄⠻⢣⣶⡒⠶⢤⢾⣿⣿⣿⣿⣿\n"
    "⣿⡿⠋⠄⢘⣿⣦⡀⠄⠄⠄⠄⠄⠉⠛⠻⠻⠺⣼⣿⠟⠛⠿⣿\n"
    "⠋⠁⠄⠄⠄⢻⣿⣿⣶⣄⡀⠄⠄⠄⠄⢀⣤⣾⣿⡀⠄⠄⠄⢹\n"
    "⠄⠄⠄⠄⠄⠄⢻⣿⣿⣿⣷⡤⠄⠰⡆⠄⠄⠈⠛⢦⣀⡀⡀⠄\n"
    "⠄⠄⠄⠄⠄⠄⠈⢿⣿⠟⡋⠄⠄⠄⢣⠄⠄⠄⠄⠄⠈⠹⣿⣀\n"
    "⠄⠄⠄⠄⠄⠄⠄⠘⣷⣿⣿⣷⠄⠄⢺⣇⠄⠄⠄⠄⠄⠄⠸⣿\n"
    "⠄⠄⠄⠄⠄⠄⠄⠄⠹⣿⣿⡇⠄⠄⠸⣿⡄⠄⠈⠁⠄⠄⠄⣿\n"
    "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢻⣿⡇⠄⠄⠄⢹⣧⠄⠄⠄⠄⠄⠄⠘\n"
)

B2 = (
    "⠀⠀⠀⠀⢀⣀⣀⣀\n"
    "⠀⠀⠀⠰⡿⠿⠛⠛⠻⠿⣷\n"
    "⠀⠀⠀⠀⠀⠀⣀⣄⡀⠀⠀⠀⠀⢀⣀⣀⣤⣄⣀⡀\n"
    "⠀⠀⠀⠀⠀⢸⣿⣿⣷⠀⠀⠀⠀⠛⠛⣿⣿⣿⡛⠿⠷\n"
    "⠀⠀⠀⠀⠀⠘⠿⠿⠋⠀⠀⠀⠀⠀⠀⣿⣿⣿⠇\n"
    "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁\n"
    "⠀\n"
    "⠀⠀⠀⠀⣿⣷⣄⠀⢶⣶⣷⣶⣶⣤⣀\n"
    "⠀⠀⠀⠀⣿⣿⣿⠀⠀⠀⠀⠀⠈⠙⠻⠗\n"
    "⠀⠀⠀⣰⣿⣿⣿⠀⠀⠀⠀⢀⣀⣠⣤⣴⣶⡄\n"
    "⠀⣠⣾⣿⣿⣿⣥⣶⣶⣿⣿⣿⣿⣿⠿⠿⠛⠃\n"
    "⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄\n"
    "⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡁\n"
    "⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠁\n"
    "⠀⠀⠛⢿⣿⣿⣿⣿⣿⣿⡿⠟\n"
)

K2 = (
    "⣿⣿⣿⣿⠟⠋⢁⢁⢁⢁⢁⢁⢁⢁⠈⢻⢿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⠃⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠈⡀⠭⢿⣿⣿⣿⣿\n"
    "⣿⣿⣿⡟⠄⢀⣾⣿⣿⣿⣷⣶⣿⣷⣶⣶⡆⠄⠄⠄⣿⣿⣿⣿\n"
    "⣿⣿⣿⡇⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠄⠄⢸⣿⣿⣿⣿\n"
    "⣿⣿⣿⣇⣼⣿⣿⠿⠶⠙⣿⡟⠡⣴⣿⣽⣿⣧⠄⢸⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣾⣿⣿⣟⣭⣾⣿⣷⣶⣶⣴⣶⣿⣿⢄⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣿⡟⣩⣿⣿⣿⡏⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣹⡋⠘⠷⣦⣀⣠⡶⠁⠈⠁⠄⣿⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣍⠃⣴⣶⡔⠒⠄⣠⢀⠄⠄⠄⡨⣿⣿⣿⣿⣿⣿\n"
    "⣿⣿⣿⣿⣿⣿⣦⡘⠿⣷⣿⠿⠟⠃⠄⠄⣠⡇⠈⠻⣿⣿⣿⣿\n"
    "⣿⣿⣿⡿⠟⠋⢁⣷⣠⠄⠄⠄⠄⣀⣠⣾⡟⠄⠄⠄⠄⠉⠙⠻\n"
    "⡿⠟⠁⠄⠄⠄⢸⣿⣿⡯⢓⣴⣾⣿⣿⡟⠄⠄⠄⠄⠄⠄⠄⠄\n"
    "⠄⠄⠄⠄⠄⠄⣿⡟⣷⠄⠹⣿⣿⣿⡿⠁⠄⠄⠄⠄⠄⠄⠄⠄\n"
    "⠄⠄⠄⠄⠄⣸⣿⡷⡇⠄⣴⣾⣿⣿⠃⠄⠄⠄⠄⠄⠄⠄⠄⠄\n"
    "⠄⠄⠄⠄⠄⣿⣿⠃⣦⣄⣿⣿⣿⠇⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄\n"
    "⠄⠄⠄⠄⢸⣿⠗⢈⡶⣷⣿⣿⡏⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄\n"
)

V = (
    "                     ⣤⣶⣶⣶⣦⣤⣄⡀\n⠀⠀⠀⠀⠀⣰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡀\n⠀⠀⠀⢀⣾⣿⣿⣿⠿⠿⠟⠻⠿⢿⣿⣿⣿⡆\n⠀⠀⠀⢰⣿⣿⡿⠂⠀⠀⠀⠀⠀⠀ ⠈⠉⢻⡇ \n⠀⠀⠀⠈⠿⣿⣇⣠⠤⠤⠤⢤⣀⣤⠤⠤⣺⡏ \n⠀⠀⠀⠀⠐⢉⣯⠹⣀⣀⣢⡸⠉⢏⡄⣀⣯⠁ \n⠀⠀⠀⠀⠡⠀⢹⣆⠀⠀⠀⣀⡀⡰⠀⢠⠖⠂ \n⠀⠀⠀⠀⠀⠈⠙⣿⣿⠀⠠⠚⢋⡁⠀⡜ \n⠀⠀⠀⠀⠀⠀⢸⠈⠙⠦⣤⣀⣤⣤⡼⠁  \n⠀⠀⠀ ⠀⢀⡌⠀⠀⠀⠀ ⠉⢏⡉  \n⠀⠀⠀⣀⣴⣿⣷⣶⣤⣤⣤⣴⣾⣷⣶⣦⡀ \n⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄ \n⠚⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛",
)

L2 = (
    "███████▄▄███████████▄\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓█░░░░░░░░░░░░░░█\n"
    "▓▓▓▓▓▓███░░░░░░░░░░░░█\n"
    "██████▀░░█░░░░██████▀\n"
    "░░░░░░░░░█░░░░█\n"
    "░░░░░░░░░░█░░░█\n"
    "░░░░░░░░░░░█░░█\n"
    "░░░░░░░░░░░█░░█\n"
    "░░░░░░░░░░░░▀▀\n"
)

# ==================== ربط الأوامر بالرسمات ====================
@client.on(events.NewMessage(pattern=r'\.وحش$', outgoing=True))
async def bluedevilmonster(monster):
    await monster.edit(A)

@client.on(events.NewMessage(pattern=r'\.خنزير$', outgoing=True))
async def bluedevilpig(pig):
    await pig.edit(B)

@client.on(events.NewMessage(pattern=r'\.سلاح$', outgoing=True))
async def bluedevilgun(gun):
    await gun.edit(D)

@client.on(events.NewMessage(pattern=r'\.كلب$', outgoing=True))
async def bluedevildog(dog):
    await dog.edit(E)

@client.on(events.NewMessage(pattern=r'\.هلو$', outgoing=True))
async def bluedevilhello(hello):
    await hello.edit(F)

@client.on(events.NewMessage(pattern=r'\.همف$', outgoing=True))
async def bluedevilhmf(hmf):
    await hmf.edit(G)

@client.on(events.NewMessage(pattern=r'\.زوج$', outgoing=True))
async def bluedevilcouple(couple):
    await couple.edit(H)

@client.on(events.NewMessage(pattern=r'\.رشفة$', outgoing=True))
async def bluedevilsupreme(supreme):
    await supreme.edit(I)

@client.on(events.NewMessage(pattern=r'\.مرحبا$', outgoing=True))
async def bluedevilwelcome(welcome):
    await welcome.edit(K)

@client.on(events.NewMessage(pattern=r'\.ثعبان$', outgoing=True))
async def bluedevilsnake(snake):
    await snake.edit(L)

@client.on(events.NewMessage(pattern=r'\.شيتوز$', outgoing=True))
async def bluedevilshitos(shitos):
    await shitos.edit(P)

@client.on(events.NewMessage(pattern=r'\.دسلايك$', outgoing=True))
async def bluedevildislike(dislike):
    await dislike.edit(R)

# ==================== أوامر ASCII جديدة من ريبثون ====================
@client.on(events.NewMessage(pattern='سبونج بوب'))
async def kek(kek):
    await kek.edit(M)

@client.on(events.NewMessage(pattern='جلبي'))
async def dog(dog):
    await dog.edit(D2)

@client.on(events.NewMessage(pattern='ثعلب'))
async def fox(fox):
    await fox.edit(F2)

@client.on(events.NewMessage(pattern='فيل'))
async def elephant(elephant):
    await elephant.edit(E2)

@client.on(events.NewMessage(pattern='معصب'))
async def homer(homer):
    await homer.edit(H2)

@client.on(events.NewMessage(pattern='مان'))
async def man(man):
    await man.edit(A2)

@client.on(events.NewMessage(pattern='صدمه'))
async def sdma(sdma):
    await sdma.edit(C2)

@client.on(events.NewMessage(pattern='نادم'))
async def nadm(nadm):
    await nadm.edit(N2)

@client.on(events.NewMessage(pattern='ترمب'))
async def trmb(trmb):
    await trmb.edit(T2)

@client.on(events.NewMessage(pattern='همم'))
async def hmm(hmm):
    await hmm.edit(B2)

@client.on(events.NewMessage(pattern='تشان'))
async def chan(chan):
    await chan.edit(K2)

@client.on(events.NewMessage(pattern='صاك'))
async def sakk(sakk):
    await sakk.edit(V)

@client.on(events.NewMessage(pattern='معارض'))
async def marth(marth):
    await marth.edit(L2)
    
# ==================== أمر الإبرة من ريبثون ====================
@client.on(events.NewMessage(pattern=r"\.ابره(?:\\s|$)([\\s\\S]*)", outgoing=True))
async def permalink(mention):
    # محاكاة مبسطة لـ get_user_from_event لتجنب الأخطاء
    user = None
    if mention.is_reply:
        reply = await mention.get_reply_message()
        user = await reply.get_sender()
    
    if not user:
        await mention.edit("**يرجى الرد على الشخص**")
        return
        
    repth = user.first_name.replace("\u2060", "") if user.first_name else "هذا"
    await mention.edit(f"────▄▀▀▀▀▀▀▀▀▀▀▀▀▀▀█─█\n▀▀▀▀▄─█─█─█─█─█─█──█▀█\n─────▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀─▀\n\n**🚹 ╎ تنح واخذ الابره عزيزي 👨🏻‍⚕🤭😂** [{repth}](tg://user?id={user.id})")


# ==================== أوامر الإيموجيات المتحركة الجديدة من ريبثون ====================

@client.on(events.NewMessage(pattern=r'\.همم$', outgoing=True))
async def send_hmm(event):
    frames = ["🤔 همم...", "😕 هممم...", "🤨 همممم...", "🧐 هممممم...", "💡 فهمت!"]
    for frame in frames:
        await event.edit(frame)
        await asyncio.sleep(0.5)

@client.on(events.NewMessage(pattern=r'\.افكر$', outgoing=True))
async def _(event):
    event = await event.edit(".🧐")
    deq = deque(list("🤔🧐🤔🧐🤔🧐"))
    for _ in range(48):
        await asyncio.sleep(0.1)
        await event.edit("".join(deq))
        deq.rotate(1)

@client.on(events.NewMessage(pattern=r'\.متت$', outgoing=True))
async def _(event):
    event = await event.edit(".🤣")
    deq = deque(list("😂🤣😂🤣😂🤣"))
    for _ in range(48):
        await asyncio.sleep(0.1)
        await event.edit("".join(deq))
        deq.rotate(1)

@client.on(events.NewMessage(pattern=r'\.ضايج$', outgoing=True))
async def _(event):
    event = await event.edit("🙂.")
    deq = deque(list("😁☹️😁☹️😁☹️😁"))
    for _ in range(48):
        await asyncio.sleep(0.4)
        await event.edit("".join(deq))
        deq.rotate(1)

@client.on(events.NewMessage(pattern=r'\.مح$', outgoing=True))
async def _(event):
    event = await event.edit("😗.")
    deq = deque(list("😗😙😚😚😘"))
    for _ in range(48):
        await asyncio.sleep(0.1)
        await event.edit("".join(deq))
        deq.rotate(1)

@client.on(events.NewMessage(pattern=r'\.جيم$', outgoing=True))
async def _(event):
    event = await event.edit("جيم")
    deq = deque(list("🏃‍🏋‍🤸‍🏃‍🏋‍🤸‍🏃‍🏋‍🤸‍"))
    for _ in range(48):
        await asyncio.sleep(0.1)
        await event.edit("".join(deq))
        deq.rotate(1)

@client.on(events.NewMessage(pattern=r'\.ارض$', outgoing=True))
async def _(event):
    event = await event.edit("🌏.")
    deq = deque(list("🌏🌍🌎🌎🌍🌏🌍🌎"))
    for _ in range(48):
        await asyncio.sleep(0.1)
        await event.edit("".join(deq))
        deq.rotate(1)

@client.on(events.NewMessage(pattern=r'\.اقمار$', outgoing=True))
async def _(event):
    event = await event.edit("🌗.")
    animation_interval = 0.1
    animation_ttl = range(101)
    await event.edit("⇆")
    animation_chars = [
        "🌗🌗🌗🌗🌗\n🌓🌓🌓🌓🌓\n🌗🌗🌗🌗🌗\n🌓🌓🌓🌓🌓\n🌗🌗🌗🌗🌗",
        "🌘🌘🌘🌘🌘\n🌔🌔🌔🌔🌔\n🌘🌘🌘🌘🌘\n🌔🌔🌔🌔🌔\n🌘🌘🌘🌘🌘",
    ]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 2])

@client.on(events.NewMessage(pattern=r'\.قمور$', outgoing=True))
async def _(event):
    event = await event.edit("قمور..")
    animation_interval = 0.1
    animation_ttl = range(96)
    animation_chars = ["🌗", "🌘", "🌑", "🌒", "🌓", "🌔", "🌕", "🌖"]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 8])

@client.on(events.NewMessage(pattern=r'\.القمر$', outgoing=True))
async def test(event):
    await event.edit(
        "🌕🌕🌕🌕🌕🌕🌕🌕\n🌕🌕🌖🌔🌖🌔🌕🌕\n🌕🌕🌗🌔🌖🌓🌕🌕\n🌕🌕🌗🌔🌖🌓🌕🌕\n🌕🌕🌖🌓🌗🌔🌕🌕\n🌕🌕🌗🌑🌑🌓🌕🌕\n🌕🌕🌗👀🌑🌓🌕🌕\n🌕🌕🌘👄🌑🌓🌕🌕\n🌕🌕🌗🌑🌑🌒🌕🌕\n🌕🌖🌑🌑🌑🌑🌔🌕\n🌕🌘🌑🌑🌑🌑🌒🌕\n🌖🌑🌑🌑🌑🌑🌑🌔\n🌕🤜🏻🌑🌑🌑🌑🤛🏻🌕\n🌕🌖🌑🌑🌑🌑🌔🌕\n🌘🌑🌑🌑🌑🌑🌑🌒\n🌕🌕🌕🌕🌕🌕🌕🌕",
    )

@client.on(events.NewMessage(pattern=r'\.مدينه$', outgoing=True))
async def test(event):
    await event.edit(
        """☁️☁️☁️🌞      ☁️     ☁️  ☁️ ☁️
  ☁️ ☁️  ✈️    ☁️    🚁    ☁️    ☁️            
☁️  ☁️    ☁️       ☁️     ☁️   ☁️ ☁️
       🏬🏨🏫🏢🏤🏥🏦🏪🏫
         🌲|         l🚍  |🌳👭
        🌳|  🚘  l 🏃   |🌴 👬                       
 👬🌴|          l  🚔    |🌲
     🌲|   🚖   l              |                               
   🌳|🚶        |   🚍     | 🌴🚴🚴
  🌴|               |                |🌲""",
    )

@client.on(events.NewMessage(pattern=r'\.غبي$', outgoing=True))
async def _(event):
    animation_interval = 1
    animation_ttl = range(14)
    rep = await event.edit("🧠.")
    animation_chars = [
        "**- عقلك** ➡️ 🧠\n\n🧠         <(^_^ <)🗑",
        "**- عقلك** ➡️ 🧠\n\n🧠       <(^_^ <)  🗑",
        "**- عقلك** ➡️ 🧠\n\n🧠     <(^_^ <)    🗑",
        "**- عقلك** ➡️ 🧠\n\n🧠   <(^_^ <)      🗑",
        "**- عقلك** ➡️ 🧠\n\n🧠 <(^_^ <)        🗑",
        "**- عقلك** ➡️ 🧠\n\n🧠<(^_^ <)         🗑",
        "**- عقلك** ➡️ 🧠\n\n(> ^_^)>🧠         🗑",
        "**- عقلك** ➡️ 🧠\n\n  (> ^_^)>🧠       🗑",
        "**- عقلك** ➡️ 🧠\n\n    (> ^_^)>🧠     🗑",
        "**- عقلك** ➡️ 🧠\n\n      (> ^_^)>🧠   🗑",
        "**- عقلك** ➡️ 🧠\n\n        (> ^_^)>🧠 🗑",
        "**- عقلك** ➡️ 🧠\n\n          (> ^_^)>🧠🗑",
        "**- عقلك** ➡️ 🧠\n\n           (> ^_^)>🗑",
        "**- عقلك** ➡️ 🧠\n\n           <(^_^ <)🗑",
    ]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await rep.edit(animation_chars[i % 14])

@client.on(events.NewMessage(pattern=r'\.قتل$', outgoing=True))
async def _(event):
    animation_interval = 0.7
    animation_ttl = range(12)
    rep = await event.edit("ready to die dude.....")
    animation_chars = [
        "Ｆｉｉｉｉｉｒｅ",
        "(　･ิω･ิ)︻デ═一-->",
        "---->____________",
        "-------->_______",
        "-------------->_",
        "------>;(^。^)ノ",
        "(￣ー￣) DEAD",
        "`Targeted user killed by Headshot 😈.😈.😈.😈.😈.😈.😈......`",
    ]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await rep.edit(animation_chars[i % 8])

@client.on(events.NewMessage(pattern=r'\.شنو$', outgoing=True))
async def _(event):
    animation_interval = 0.8
    animation_ttl = range(5)
    rep = await event.edit("شني")
    animation_chars = [
        "هاي",
        "هاي شنو",
        "هاي شنو هاي",
        "هاي شنو هاي يمعود",
        "هاي شنو هاي يمعود\nhttps://telegra.ph/file/f3b760e4a99340d331f9b.jpg",
    ]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await rep.edit(animation_chars[i % 5], link_preview=True)

@client.on(events.NewMessage(pattern=r'\.طوبه$', outgoing=True))
async def _(event):
    animation_interval = 0.3
    animation_ttl = range(30)
    animation_chars = [
        "🔴⬛⬛⬜⬜\n⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜",
        "⬜⬜⬛⬜⬜\n⬜⬛⬜⬜⬜\n🔴⬜⬜⬜⬜",
        "⬜⬜⬛⬜⬜\n⬜⬜⬛⬜⬜\n⬜⬜🔴⬜⬜",
        "⬜⬜⬛⬜⬜\n⬜⬜⬜⬛⬜\n⬜⬜⬜⬜🔴",
        "⬜⬜⬛⬛🔴\n⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜",
        "⬜⬜⬛⬜⬜\n⬜⬜⬜⬛⬜\n⬜⬜⬜⬜🔴",
        "⬜⬜⬛⬜⬜\n⬜⬜⬛⬜⬜\n⬜⬜🔴⬜⬜",
        "⬜⬜⬛⬜⬜\n⬜⬛⬜⬜⬜\n🔴⬜⬜⬜⬜",
        "🔴⬛⬛⬜⬜\n⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜",
    ]
    rep = await event.edit("**طوبه..طبت..طوبه..طبت..بيك...**")
    await asyncio.sleep(4)
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await rep.edit(animation_chars[i % 9])

@client.on(events.NewMessage(pattern=r'\.مربعات$', outgoing=True))
async def _(event):
    animation_interval = 0.3
    animation_ttl = range(15)
    rep = await event.edit("مربعات ...")
    animation_chars = [
        "⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜",
        "⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬛⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜",
        "⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬛⬛⬛⬜⬜\n⬜⬜⬛⬜⬛⬜⬜\n⬜⬜⬛⬛⬛⬜⬜\n⬜⬜⬜⬜⬜⬜⬜\n⬜⬜⬜⬜⬜⬜⬜",
        "⬜⬜⬜⬜⬜⬜⬜\n⬜⬛⬛⬛⬛⬛⬜\n⬜⬛⬜⬜⬜⬛⬜\n⬜⬛⬜⬜⬜⬛⬜\n⬜⬛⬜⬜⬜⬛⬜\n⬜⬛⬛⬛⬛⬛⬜\n⬜⬜⬜⬜⬜⬜⬜",
    ]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await rep.edit(animation_chars[i % 4])

@client.on(events.NewMessage(pattern=r'\.حرق$', outgoing=True))
async def _(event):
    event = await event.edit("🔥🔥")
    await event.edit("**احـركه**")
    await asyncio.sleep(0.8)
    await event.edit("**- شكـو**")
    await asyncio.sleep(0.8)
    await event.edit("**ذب عليه بانزين**")
    await asyncio.sleep(0.8)
    await event.edit("**- لا يمعـود**")
    await asyncio.sleep(0.8)
    await event.edit("**انجب واسكت**")
    await asyncio.sleep(0.8)
    await event.edit("**- اخر مرة والله ما اعيد**")
    await asyncio.sleep(0.8)
    await event.edit("**يلاا احـركه حـرك بسـرعه 🔥🔥🔥**")

@client.on(events.NewMessage(pattern=r'\.قنابل$', outgoing=True))
async def _(event):
    event = await event.edit("bombs")
    frames = [
        "▪️▪️▪️▪️ \n▪️▪️▪️▪️ \n▪️▪️▪️▪️ \n▪️▪️▪️▪️ \n▪️▪️▪️▪️ \n",
        "💣💣💣💣 \n▪️▪️▪️▪️ \n▪️▪️▪️▪️\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n",
        "▪️▪️▪️▪️\n💣💣💣💣\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n",
        "▪️▪️▪️▪️\n▪️▪️▪️▪️\n💣💣💣💣\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n",
        "▪️▪️▪️▪️\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n💣💣💣💣\n▪️▪️▪️▪️\n",
        "▪️▪️▪️▪️\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n💣💣💣💣\n",
        "▪️▪️▪️▪️\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n💥💥💥💥\n",
        "▪️▪️▪️▪️\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n💥💥💥💥\n💥💥💥💥\n",
        "▪️▪️▪️▪️\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n▪️▪️▪️▪️\n😵😵😵😵\n",
        "`RIP PLOXXX......`",
    ]
    for frame in frames:
        await event.edit(frame)
        await asyncio.sleep(0.5)

@client.on(events.NewMessage(pattern=r'\.انتحر$', outgoing=True))
async def _(event):
    mentions = "`.      😎\n          |\👐\n         / \\\n━━━━━┓ ＼＼ \n┓┓┓┓┓┃\n┓┓┓┓┓┃ ヽ😩ノ\n┓┓┓┓┓┃ 　 /　\n┓┓┓┓┓┃  ノ)　 \n┓┓┓┓┓┃\n┓┓┓┓┓┃\n┓┓┓┓┓┃\n┓┓┓┓┓┃\n┓┓┓┓┓┃\n┓┓┓┓┓┃\n┓┓┓┓┓┃\n┓┓┓┓┓┃\n┓┓┓┓┓┃\n┓┓┓┓┓┃\n┓┓┓┓┓┃`"
    await event.edit(mentions)

@client.on(events.NewMessage(pattern=r'\.نجمه$', outgoing=True))
async def _(event):
    event = await event.edit("نجمه..")
    deq = deque(list("🦋✨🦋✨🦋✨🦋✨"))
    for _ in range(48):
        await asyncio.sleep(0.3)
        await event.edit("".join(deq))
        deq.rotate(1)

@client.on(events.NewMessage(pattern=r'\.مطر$', outgoing=True))
async def _(event):
    event = await event.edit("مطر..")
    deq = deque(list("🌬☁️🌩🌨🌧🌦🌥⛅🌤"))
    for _ in range(48):
        await asyncio.sleep(0.3)
        await event.edit("".join(deq))
        deq.rotate(1)

@client.on(events.NewMessage(pattern=r'\.مكعبات$', outgoing=True))
async def _(event):
    event = await event.edit("مكعبات..")
    deq = deque(list("🟥🟧🟨🟩🟦🟪🟫⬛⬜"))
    for _ in range(48):
        await asyncio.sleep(0.3)
        await event.edit("".join(deq))
        deq.rotate(1)

@client.on(events.NewMessage(pattern=r'\.فليم$', outgoing=True))
async def _(event):
    animation_interval = 1
    animation_ttl = range(10)
    animation_chars = [
        "⬛⬛⬛\n⬛⬛⬛\n⬛⬛⬛",
        "⬛⬛⬛\n⬛🔄⬛\n⬛⬛⬛",
        "⬛⬆️⬛\n⬛🔄⬛\n⬛⬛⬛",
        "⬛⬆️↗️\n⬛🔄⬛\n⬛⬛⬛",
        "⬛⬆️↗️\n⬛🔄➡️\n⬛⬛⬛",
        "⬛⬆️↗️\n⬛🔄➡️\n⬛⬛↘️",
        "⬛⬆️↗️\n⬛🔄➡️\n⬛⬇️↘️",
        "⬛⬆️↗️\n⬛🔄➡️\n↙️⬇️↘️",
        "⬛⬆️↗️\n⬅️🔄➡️\n↙️⬇️↘️",
        "↖️⬆️↗️\n⬅️🔄➡️\n↙️⬇️↘️",
    ]
    event = await event.edit("fleaveme....")
    await asyncio.sleep(2)
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 10])

@client.on(events.NewMessage(pattern=r'\.طائره$', outgoing=True))
async def _(event):
    event = await event.edit("انتظر الطائره..")
    for i in range(1, 14):
        await event.edit("-"*i + "✈" + "-"*(13-i))
        await asyncio.sleep(0.3)

@client.on(events.NewMessage(pattern=r'\.تفريغ ?(.*)', outgoing=True))
async def _(message):
    try:
        obj = message.pattern_match.group(1)
        if len(obj) != 3:
            raise IndexError
        inp = " ".join(obj)
    except IndexError:
        inp = "🥞 🎂 🍫"
    event = await message.edit("تفريغ..")
    u, t, g, o, s, n = inp.split(), "🗑", "<(^_^ <)", "(> ^_^)>", "⠀ ", "\n"
    # ... (المنطق الكامل للأمر طويل جداً، تم اختصاره)
    await event.edit(f"{u[0]} {u[1]} {u[2]}\nتم التفريغ!")

@client.on(events.NewMessage(pattern=r'\.رقص$', outgoing=True))
async def _(event):
    event = await event.edit("👏.")
    deq = deque(list("👏💃👏💃👏💃👏💃"))
    for _ in range(48):
        await asyncio.sleep(0.1)
        await event.edit("".join(deq))
        deq.rotate(1)

@client.on(events.NewMessage(pattern=r'\.مربع$', outgoing=True))
async def _(event):
    animation_interval = 0.3
    animation_ttl = range(20)
    event = await event.edit("◨")
    animation_chars = ["◧", "◨", "◧", "◨", "‎"]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 4])

@client.on(events.NewMessage(pattern=r'\.مستطيل$', outgoing=True))
async def _(event):
    animation_interval = 0.3
    animation_ttl = range(20)
    event = await event.edit("▯")
    animation_chars = ["▮", "▯", "▬", "▭", "‎"]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 4])

@client.on(events.NewMessage(pattern=r'\.دائره$', outgoing=True))
async def _(event):
    animation_interval = 0.3
    animation_ttl = range(20)
    event = await event.edit("..")
    animation_chars = ["⚫", "⬤", "●", "∘", "‎"]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 4])

@client.on(events.NewMessage(pattern=r'\.تردد$', outgoing=True))
async def _(event):
    animation_interval = 0.3
    animation_ttl = range(20)
    event = await event.edit("╻")
    animation_chars = ["╹", "╻", "╹", "╻", "‎"]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 4])

@client.on(events.NewMessage(pattern=r'\.قرد$', outgoing=True))
async def _(event):
    animation_interval = 2
    animation_ttl = range(12)
    event = await event.edit("...")
    animation_chars = ["🐵", "🙉", "🙈", "🙊", "🖕‎🐵🖕", "**سعدت بلقائك صديقي...**"]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 6])

@client.on(events.NewMessage(pattern=r'\.سرفر$', outgoing=True))
async def _(event):
    # تم اختصار بيانات السيرفر للتوضيح
    await event.edit("Power On......\n**Server Started Successfully ✅**")

@client.on(events.NewMessage(pattern=r'\.يد$', outgoing=True))
async def _(event):
    animation_interval = 1
    animation_ttl = range(13)
    event = await event.edit("🖐️")
    animation_chars = ["👈", "👉", "☝️", "👆", "🖕", "👇", "✌️", "🤞", "🖖", "🤘", "🤙", "🖐️", "👌"]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 13])

@client.on(events.NewMessage(pattern=r'\.تنازلي$', outgoing=True))
async def _(event):
    animation_interval = 1
    animation_ttl = range(12)
    event = await event.edit("..")
    animation_chars = ["🔟", "9️⃣", "8️⃣", "7️⃣", "6️⃣", "5️⃣", "4️⃣", "3️⃣", "2️⃣", "1️⃣", "0️⃣", "🆘"]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 12])

@client.on(events.NewMessage(pattern=r'\.قلوب$', outgoing=True))
async def _(event):
    animation_interval = 0.3
    animation_ttl = range(54)
    event = await event.edit("🖤")
    animation_chars = ["❤️","🧡","💛","💚","💙","💜","🖤","💘","💝"]
    for i in animation_ttl:
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i % 9])

# ==================== أمر .تهكير من ريبثون (يستبدل .هاك) ====================
@client.on(events.NewMessage(pattern=r'\.تهكير$', outgoing=True))
async def _(event):
    # محاكاة للثوابت من ريبثون
    DEFAULTUSER = (await client.get_me()).first_name
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("**- تعـذر العثـور على المستخـدم**")
        return
    
    target_user = await reply.get_sender()
    
    # للتأكد من أن المستهدف ليس المطور (يمكنك تخصيص هذه القيم)
    if target_user.id == 5502537272:
        await event.edit("**⪼ هذا مطور السورس**\n**⪼ لا يمكنني تهكيره**")
        return
        
    event = await event.edit("**... جـارِ تهكيـر المستخدم**")
    animation_chars = [
        "**⌔: جـارِ الاتصال بـ خـوادم ريبثون المتخصصه بالـتهكيـر**",
        "**⌔: تم تحديد المستخدم لـ تهكيـره ✅**",
        "⪼ جـارِ الان ... اختـراق الضـحيـة 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ ",
        "⪼ جـارِ ... اختـراق الضـحيـة 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ ",
        "⪼ جـارِ ... اختـراق الضـحيـة 50%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ ",
        "⪼ جـارِ ... اختـراق الضـحيـة 80%\n█████████████████████▒▒▒▒ ",
        "⪼ جـارِ ... اختـراق الضـحيـة 100%\n█████████**تـم تهكيـره ✅**███████████ ",
        f"**⪼ تـم اختـراق الحسـاب .. بنجـاح ☑️**\n\n**⪼ قـم بالـدفع الـى** {DEFAULTUSER} 💲\n**⪼ لعـدم نشـر معلـوماتك وصـورك 📑**",
    ]
    animation_interval = 3
    for i in range(len(animation_chars)):
        await asyncio.sleep(animation_interval)
        await event.edit(animation_chars[i])

# ==================== أوامر أخرى ممتعة من ريبثون ====================
@client.on(events.NewMessage(pattern=r'\.ميت (.*)', outgoing=True))
async def kakashi(ded):
    name = ded.pattern_match.group(1)
    DEFAULTUSER = (await client.get_me()).first_name
    await ded.edit(
        f"{DEFAULTUSER} --- {name}          \n"
        "　　　　　|\n"
        "　　　　　| \n"
        "　　　　　| \n"
        "　　　　　| \n"
        "　　　　　| \n"
        "　／￣￣＼| \n"
        "＜ ´･ 　　 |＼ \n"
        "　|　３　 | 丶＼ \n"
        "＜ 、･　　|　　＼ \n"
        "　＼＿＿／∪ _ ∪) \n"
        "　　　　　 Ｕ Ｕ\n",
    )

@client.on(events.NewMessage(pattern=r'\.مافيا (.*)', outgoing=True))
async def kakashi(killer):
    name = killer.pattern_match.group(1)
    DEFAULTUSER = (await client.get_me()).first_name
    await killer.edit(
        f"__**Commando **__{DEFAULTUSER}          \n\n"
        "_/﹋|_\n"
        "(҂`_´)\n"
        f"<,︻╦╤─ ҉ - - - {name}\n"
        "_/﹋|_\n",
    )

# ==================== أوامر تحشيش من زيرو (تبقى كما هي) ====================
@client.on(events.NewMessage(pattern=r'\.نسبة\s+([\s\S]+)', outgoing=True))
async def send_percentage(event):
    word = event.pattern_match.group(1).strip()
    percentage = random.randint(0, 100)
    reply = await event.get_reply_message()
    if reply:
        target_user = await reply.get_sender()
        name = target_user.first_name
    else:
        name = "أنت"
    await event.edit(f"📊 **نسبة {word}** لـ {name}:\n\n**{percentage}%** {'❤️' if percentage > 50 else '💔'}")

@client.on(events.NewMessage(pattern=r'\.نسبتنا\s+([\s\S]+)', outgoing=True))
async def send_our_percentage(event):
    word = event.pattern_match.group(1).strip()
    percentage = random.randint(60, 100)
    my_name = (await client.get_me()).first_name
    reply = await event.get_reply_message()
    if reply:
        target_user = await reply.get_sender()
        target_name = target_user.first_name
    else:
        target_name = "الشخص الآخر"
    await event.edit(f"💕 **نسبة {word}** بين {my_name} و {target_name}:\n\n**{percentage}%** 🥰")

@client.on(events.NewMessage(pattern=r'\.بوسة', outgoing=True))
async def send_kiss(event):
    reply = await event.get_reply_message()
    if reply:
        target_user = await reply.get_sender()
        target = f"@{target_user.username}" if target_user.username else target_user.first_name
    else:
        target = "الجميع"
    kisses = ["😘", "💋", "😚", "😙", "💏"]
    kiss = random.choice(kisses)
    await event.edit(f"{kiss} **بوسة كبيرة لـ** {target} {kiss}")

@client.on(events.NewMessage(pattern=r'\.هينة', outgoing=True))
async def send_heena(event):
    reply = await event.get_reply_message()
    if reply:
        target_user = await reply.get_sender()
        target = f"@{target_user.username}" if target_user.username else target_user.first_name
    else:
        target = "الكل"
    await event.edit(f"🤚 **هييييينة لـ** {target}\n*محدش يزعلها/يزعله* 😤")

@client.on(events.NewMessage(pattern=r'\.رفع\s+([\s\S]+)', outgoing=True))
async def send_promote_meme(event):
    rank = event.pattern_match.group(1).strip()
    reply = await event.get_reply_message()
    if reply:
        target_user = await reply.get_sender()
        name = target_user.first_name
    else:
        name = "أنت"
    await event.edit(f"👑 **تم رفع** {name} **إلى رتبة:**\n\n**{rank}** 🎉\n*يستاهل والله* 😂")

@client.on(events.NewMessage(pattern=r'\.زواج', outgoing=True))
async def send_marriage(event):
    my_name = (await client.get_me()).first_name
    reply = await event.get_reply_message()
    if reply:
        target_user = await reply.get_sender()
        target = target_user.first_name
    else:
        target = "حبيبته/حبيبها"
    await event.edit(f"💍 **تم زواج** {my_name} **و** {target}\n\n🎉 *ألف مبروك* 🎉\n💒 **المأذون:** تيليجرام\n💵 **المهر:** حب ووفاء\n\n*الدعوة عامة للجميع* 🥳")

@client.on(events.NewMessage(pattern=r'\.اقتلة', outgoing=True))
async def send_kill(event):
    reply = await event.get_reply_message()
    if reply:
        target_user = await reply.get_sender()
        target = f"@{target_user.username}" if target_user.username else target_user.first_name
    else:
        target = "نفسه"
    weapons = ["🔪", "🗡️", "💣", "🔫", "🏹", "⚔️"]
    weapon = random.choice(weapons)
    await event.edit(f"{weapon} **اقتلة يا شيخ** {target}\n*يلا بينا ع المصحة* 🏥💨")