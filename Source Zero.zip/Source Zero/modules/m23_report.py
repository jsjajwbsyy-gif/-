import asyncio
from datetime import datetime
from telethon import events
from telethon.tl.functions.messages import ReportRequest
from telethon.tl.types import InputReportReasonSpam, InputReportReasonViolence, InputReportReasonPornography, InputReportReasonCopyright, InputReportReasonOther

# استيراد المتغيرات من الملف الرئيسي
from main import client

report_status = {}

# ==================== عرض قائمة الأوامر (.م23) ====================
@client.on(events.NewMessage(pattern=r'\.م23', outgoing=True))
async def show_report_menu(event):
    menu_text = """⟪───── الإبلاغ الداخلي ─────⟫

│ `.شد`
│ ← للإبلاغ مع تعليق على رسالة
│ ← مثال: رد على رسالة مع:  
│    1 رابط الرسالة  
│    2 نوع الإبلاغ  
│    3 التعليق الاختياري  
│    ثم أرسل .شد

│ `.ايقاف الشد`
│ ← لإيقاف عملية الإبلاغ الجارية

│ `.حالة_الشد`
│ ← لعرض حالة الإبلاغ الحالية

│ `.نوع_الشد`
│ ← لعرض أنواع الإبلاغ المتاحة

 اوامر الشد النوع2 :
 ─ ──────
│ `.ابلاغ مع عدد`
│ ← مثال: رد على رسالة مع:  
│    1 رابط الرسالة  
│    2 رقم الإبلاغ  
│    3 التعليق الاجباري  

│ `.ايقاف الداخلي`
│ ← لإيقاف عملية الإبلاغ الداخلي

│ `.حالة الداخلي`
│ ← لعرض حالة الإبلاغ الداخلي الحالية

│ `.نوع الداخلي`
│ ← لعرض أنواع الإبلاغ الداخلي المتاحة
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 1. أمر .نوع_الشد ====================
@client.on(events.NewMessage(pattern=r'\.نوع_الشد', outgoing=True))
async def show_report_types(event):
    text = "📋 **أنواع الإبلاغ المتاحة:**\n\n"
    
    for num, data in REPORT_TYPES.items():
        text += f"{num}. {data['name']}\n"
    
    text += "\n📌 **الاستخدام:** رد على رسالة تحتوي:\n"
    text += "1️⃣ رابط الرسالة أو القناة\n"
    text += "2️⃣ رقم نوع الإبلاغ\n"
    text += "3️⃣ تعليق (اختياري)\n"
    text += "ثم أرسل `.شد`"
    
    await event.edit(text)

# ==================== 2. أمر .شد ====================
@client.on(events.NewMessage(pattern=r'\.شد', outgoing=True))
async def start_report(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على رسالة تحتوي معلومات الإبلاغ**\n\n📝 **التنسيق:**\n1. رابط الهدف\n2. رقم نوع الإبلاغ\n3. التعليق (اختياري)")
        return
    
    lines = reply.text.strip().split("\n")
    
    if len(lines) < 2:
        await event.edit("❌ **تنسيق غير صحيح**\n\n📝 **المطلوب:**\n1. رابط الهدف\n2. رقم نوع الإبلاغ\n3. التعليق (اختياري)")
        return
    
    target_link = lines[0].strip()
    report_type_num = lines[1].strip()
    comment = lines[2].strip() if len(lines) > 2 else ""
    
    if report_type_num not in REPORT_TYPES:
        await event.edit(f"❌ **نوع الإبلاغ غير صحيح**\n\n*استخدم* `.نوع_الشد` *لعرض الأنواع المتاحة*")
        return
    
    user_id = event.sender_id
    
    if user_id not in report_status:
        report_status[user_id] = {}
    
    report_status[user_id]["active"] = True
    report_status[user_id]["type"] = "normal"
    report_status[user_id]["target"] = target_link
    report_status[user_id]["report_type"] = REPORT_TYPES[report_type_num]["reason"]
    report_status[user_id]["comment"] = comment
    report_status[user_id]["count"] = 0
    report_status[user_id]["start_time"] = datetime.now()
    
    await event.edit(
        f"📢 **بدء الإبلاغ**\n\n"
        f"🎯 **الهدف:** {target_link[:50]}...\n"
        f"⚠️ **النوع:** {REPORT_TYPES[report_type_num]['name']}\n"
        f"📝 **التعليق:** {comment if comment else 'بدون'}\n\n"
        f"⏳ **جاري الإبلاغ...**"
    )
    
    asyncio.create_task(process_reports(user_id, event.chat_id, target_link, REPORT_TYPES[report_type_num]["reason"], comment))

async def process_reports(user_id, chat_id, target, reason, comment):
    count = 0
    
    if user_id in active_sessions:
        for session_num, session_data in active_sessions[user_id].items():
            if not report_status.get(user_id, {}).get("active", False):
                break
            
            try:
                session_client = session_data["client"]
                
                if "t.me/" in target or "telegram.me/" in target:
                    username = target.split("/")[-1]
                    try:
                        entity = await session_client.get_entity(username)
                        
                        # تحديد سبب الإبلاغ
                        if reason == "spam":
                            report_reason = InputReportReasonSpam()
                        elif reason == "violence":
                            report_reason = InputReportReasonViolence()
                        elif reason == "pornography":
                            report_reason = InputReportReasonPornography()
                        elif reason == "copyright":
                            report_reason = InputReportReasonCopyright()
                        else:
                            report_reason = InputReportReasonOther()
                        
                        await session_client(ReportRequest(
                            peer=entity,
                            id=[0],
                            reason=report_reason,
                            message=comment if comment else reason
                        ))
                    except:
                        pass
                
                count += 1
                report_status[user_id]["count"] = count
                
                await asyncio.sleep(2)
                
            except Exception as e:
                await asyncio.sleep(1)
    
    if user_id in report_status:
        report_status[user_id]["active"] = False
        report_status[user_id]["end_time"] = datetime.now()
    
    await client.send_message(
        chat_id,
        f"✅ **انتهى الإبلاغ**\n\n📊 **تم الإبلاغ:** {count} مرة\n🎯 **الهدف:** {target[:50]}..."
    )

# ==================== 3. أمر .ايقاف الشد ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف الشد', outgoing=True))
async def stop_report(event):
    user_id = event.sender_id
    
    if user_id in report_status and report_status[user_id].get("active", False):
        report_status[user_id]["active"] = False
        
        count = report_status[user_id].get("count", 0)
        target = report_status[user_id].get("target", "غير معروف")
        
        await event.edit(
            f"🛑 **تم إيقاف الإبلاغ**\n\n"
            f"📊 **تم الإبلاغ:** {count} مرة\n"
            f"🎯 **الهدف:** {target[:50]}..."
        )
    else:
        await event.edit("❌ **لا توجد عملية إبلاغ جارية**")

# ==================== 4. أمر .حالة_الشد ====================
@client.on(events.NewMessage(pattern=r'\.حالة_الشد', outgoing=True))
async def report_status_cmd(event):
    user_id = event.sender_id
    
    if user_id not in report_status or not report_status[user_id].get("active", False):
        await event.edit("📭 **لا توجد عملية إبلاغ جارية**")
        return
    
    status = report_status[user_id]
    
    target = status.get("target", "غير معروف")
    report_type = status.get("report_type", "spam")
    comment = status.get("comment", "بدون")
    count = status.get("count", 0)
    start_time = status.get("start_time", datetime.now())
    
    elapsed = datetime.now() - start_time
    minutes = elapsed.seconds // 60
    seconds = elapsed.seconds % 60
    
    status_text = f"""📢 **حالة الإبلاغ الحالية:**

🎯 **الهدف:** {target[:50]}...
⚠️ **النوع:** {report_type}
📝 **التعليق:** {comment[:50]}...
📊 **تم الإبلاغ:** {count} مرة
⏱️ **الوقت المنقضي:** {minutes:02d}:{seconds:02d}

📌 **لإيقاف الإبلاغ:** `.ايقاف الشد`"""
    
    await event.edit(status_text)

# ==================== 5. أمر .نوع الداخلي ====================
@client.on(events.NewMessage(pattern=r'\.نوع الداخلي', outgoing=True))
async def show_internal_report_types(event):
    text = "📋 **أنواع الإبلاغ الداخلي المتاحة:**\n\n"
    
    for num, name in INTERNAL_REPORT_TYPES.items():
        text += f"{num}. {name}\n"
    
    text += "\n📌 **الاستخدام:** رد على رسالة تحتوي:\n"
    text += "1️⃣ رابط الهدف\n"
    text += "2️⃣ رقم نوع الإبلاغ\n"
    text += "3️⃣ التعليق (إجباري)\n"
    text += "ثم أرسل `.ابلاغ مع عدد`"
    
    await event.edit(text)

# ==================== 6. أمر .ابلاغ مع عدد ====================
@client.on(events.NewMessage(pattern=r'\.ابلاغ مع عدد', outgoing=True))
async def start_internal_report(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على رسالة تحتوي معلومات الإبلاغ**")
        return
    
    lines = reply.text.strip().split("\n")
    
    if len(lines) < 3:
        await event.edit("❌ **تنسيق غير صحيح**\n\n📝 **المطلوب:**\n1. رابط الهدف\n2. رقم نوع الإبلاغ\n3. التعليق (إجباري)")
        return
    
    target_link = lines[0].strip()
    report_type_num = lines[1].strip()
    comment = lines[2].strip()
    
    if report_type_num not in INTERNAL_REPORT_TYPES:
        await event.edit(f"❌ **نوع الإبلاغ غير صحيح**\n\n*استخدم* `.نوع الداخلي` *لعرض الأنواع المتاحة*")
        return
    
    user_id = event.sender_id
    
    if user_id not in report_status:
        report_status[user_id] = {}
    
    report_status[user_id]["internal_active"] = True
    report_status[user_id]["internal_target"] = target_link
    report_status[user_id]["internal_type"] = INTERNAL_REPORT_TYPES[report_type_num]
    report_status[user_id]["internal_comment"] = comment
    report_status[user_id]["internal_count"] = 0
    report_status[user_id]["internal_start_time"] = datetime.now()
    
    await event.edit(
        f"🔴 **بدء الإبلاغ الداخلي**\n\n"
        f"🎯 **الهدف:** {target_link[:50]}...\n"
        f"📋 **النوع:** {INTERNAL_REPORT_TYPES[report_type_num]}\n"
        f"📝 **التعليق:** {comment[:50]}...\n\n"
        f"⏳ **جاري الإبلاغ...**"
    )
    
    asyncio.create_task(process_internal_reports(user_id, event.chat_id, target_link, comment))

async def process_internal_reports(user_id, chat_id, target, comment):
    count = 0
    
    if user_id in active_sessions:
        for session_num, session_data in active_sessions[user_id].items():
            if not report_status.get(user_id, {}).get("internal_active", False):
                break
            
            try:
                session_client = session_data["client"]
                
                await session_client.send_message(
                    "SpamBot",
                    f"/report {target}\n{comment}"
                )
                
                count += 1
                report_status[user_id]["internal_count"] = count
                
                await asyncio.sleep(3)
                
            except Exception as e:
                await asyncio.sleep(1)
    
    if user_id in report_status:
        report_status[user_id]["internal_active"] = False
        report_status[user_id]["internal_end_time"] = datetime.now()
    
    await client.send_message(
        chat_id,
        f"✅ **انتهى الإبلاغ الداخلي**\n\n📊 **تم الإبلاغ:** {count} مرة\n🎯 **الهدف:** {target[:50]}..."
    )

# ==================== 7. أمر .ايقاف الداخلي ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف الداخلي', outgoing=True))
async def stop_internal_report(event):
    user_id = event.sender_id
    
    if user_id in report_status and report_status[user_id].get("internal_active", False):
        report_status[user_id]["internal_active"] = False
        
        count = report_status[user_id].get("internal_count", 0)
        target = report_status[user_id].get("internal_target", "غير معروف")
        
        await event.edit(
            f"🛑 **تم إيقاف الإبلاغ الداخلي**\n\n"
            f"📊 **تم الإبلاغ:** {count} مرة\n"
            f"🎯 **الهدف:** {target[:50]}..."
        )
    else:
        await event.edit("❌ **لا توجد عملية إبلاغ داخلي جارية**")

# ==================== 8. أمر .حالة الداخلي ====================
@client.on(events.NewMessage(pattern=r'\.حالة الداخلي', outgoing=True))
async def internal_report_status_cmd(event):
    user_id = event.sender_id
    
    if user_id not in report_status or not report_status[user_id].get("internal_active", False):
        await event.edit("📭 **لا توجد عملية إبلاغ داخلي جارية**")
        return
    
    status = report_status[user_id]
    
    target = status.get("internal_target", "غير معروف")
    report_type = status.get("internal_type", "غير معروف")
    comment = status.get("internal_comment", "بدون")
    count = status.get("internal_count", 0)
    start_time = status.get("internal_start_time", datetime.now())
    
    elapsed = datetime.now() - start_time
    minutes = elapsed.seconds // 60
    seconds = elapsed.seconds % 60
    
    status_text = f"""🔴 **حالة الإبلاغ الداخلي الحالية:**

🎯 **الهدف:** {target[:50]}...
📋 **النوع:** {report_type}
📝 **التعليق:** {comment[:50]}...
📊 **تم الإبلاغ:** {count} مرة
⏱️ **الوقت المنقضي:** {minutes:02d}:{seconds:02d}

📌 **لإيقاف الإبلاغ:** `.ايقاف الداخلي`"""
    
    await event.edit(status_text)