import asyncio
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

tts_settings = {}
download_settings = {}

DEFAULT_TTS_BOT = "@ttsbot"
DEFAULT_DOWNLOAD_BOT = "@utubebot"

# ==================== عرض قائمة الأوامر (.م15) ====================
@client.on(events.NewMessage(pattern=r'\.م15', outgoing=True))
async def show_tts_download_menu(event):
    menu_text = """⟪───── أوامر النطق والتحميل ─────⟫

│ `.انطق`
│ ← ضع الكلام الذي تريده ان ينطقه .

│ `.تبديل النطق`
│ ← لتغيير بوت النطق الافتراضي

│ `.حمل`
│ ← ضع الرابط، لتحميل من جميع مواقع التواصل .

│ `.تبديل التحميل`
│ ← لتغيير بوت التحميل الافتراضي

│ `.عرض البوتات`
│ ← لعرض البوتات الحالية للنطق والتحميل
╰─────────────────────────"""
    
    await event.edit(menu_text)

# ==================== 1. أمر .انطق ====================
@client.on(events.NewMessage(pattern=r'\.انطق\s+([\s\S]+)', outgoing=True))
async def text_to_speech(event):
    text = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    chat_id = event.chat_id
    
    tts_bot = DEFAULT_TTS_BOT
    if user_id in tts_settings:
        tts_bot = tts_settings[user_id].get("bot", DEFAULT_TTS_BOT)
    
    await event.edit(f"🔊 **جاري نطق:** {text[:50]}...")
    
    try:
        async with client.conversation(tts_bot) as conv:
            await conv.send_message(text)
            response = await conv.get_response()
            
            if response.voice:
                await client.send_file(chat_id, response.voice)
                await event.delete()
            elif response.audio:
                await client.send_file(chat_id, response.audio)
                await event.delete()
            elif response.text:
                await event.edit(f"❌ **رد البوت:** {response.text[:100]}")
            else:
                await event.edit("❌ **البوت لم يرسل ملفاً صوتياً**")
                
    except Exception as e:
        await event.edit(f"❌ **فشل النطق:**\n*تأكد من أن البوت {tts_bot} يعمل*")

# ==================== 2. أمر .تبديل النطق ====================
@client.on(events.NewMessage(pattern=r'\.تبديل النطق\s+(@\w+)', outgoing=True))
async def switch_tts_bot(event):
    bot_username = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in tts_settings:
        tts_settings[user_id] = {}
    
    tts_settings[user_id]["bot"] = bot_username
    
    await event.edit(f"✅ **تم تغيير بوت النطق إلى:** {bot_username}")

# ==================== 3. أمر .حمل (معدل لانتظار الفيديو) ====================
@client.on(events.NewMessage(pattern=r'\.حمل\s+(\S+)', outgoing=True))
async def download_media(event):
    url = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    chat_id = event.chat_id
    
    download_bot = DEFAULT_DOWNLOAD_BOT
    if user_id in download_settings:
        download_bot = download_settings[user_id].get("bot", DEFAULT_DOWNLOAD_BOT)
    
    await event.edit(f"📥 **جاري التحميل...**")
    
    try:
        async with client.conversation(download_bot, timeout=180) as conv:
            await conv.send_message(url)
            
            # ننتظر حتى نستلم ملف فيديو أو صوت أو مستند
            while True:
                response = await conv.get_response(timeout=60)
                
                # فحص جميع أنواع الملفات الممكنة
                if response.video:
                    await client.send_file(chat_id, response.video)
                    await event.delete()
                    break
                elif response.audio:
                    await client.send_file(chat_id, response.audio)
                    await event.delete()
                    break
                elif response.document:
                    await client.send_file(chat_id, response.document)
                    await event.delete()
                    break
                elif response.photo:
                    await client.send_file(chat_id, response.photo)
                    await event.delete()
                    break
                elif response.voice:
                    await client.send_file(chat_id, response.voice)
                    await event.delete()
                    break
                
                # إذا كان الرد نصاً (مثل "يرجى الانتظار")، نتجاهل ونكمل
                continue
                
    except asyncio.TimeoutError:
        await event.edit(f"❌ **انتهت مهلة الانتظار**\n*لم يتم استلام الملف من البوت*")
    except Exception as e:
        error_msg = str(e)
        if "Cannot find any entity" in error_msg:
            await event.edit(f"❌ **البوت {download_bot} غير موجود**\n*تأكد من أنك بدأت محادثة مع البوت أولاً*")
        else:
            await event.edit(f"❌ **خطأ:** {error_msg[:100]}")

# ==================== 4. أمر .تبديل التحميل ====================
@client.on(events.NewMessage(pattern=r'\.تبديل التحميل\s+(@\w+)', outgoing=True))
async def switch_download_bot_cmd(event):
    bot_username = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in download_settings:
        download_settings[user_id] = {}
    
    download_settings[user_id]["bot"] = bot_username
    
    await event.edit(f"✅ **تم تغيير بوت التحميل إلى:** {bot_username}")

# ==================== 5. أمر .عرض البوتات ====================
@client.on(events.NewMessage(pattern=r'\.عرض البوتات', outgoing=True))
async def show_current_bots(event):
    user_id = event.sender_id
    
    tts_bot = DEFAULT_TTS_BOT
    if user_id in tts_settings:
        tts_bot = tts_settings[user_id].get("bot", DEFAULT_TTS_BOT)
    
    download_bot = DEFAULT_DOWNLOAD_BOT
    if user_id in download_settings:
        download_bot = download_settings[user_id].get("bot", DEFAULT_DOWNLOAD_BOT)
    
    text = f"""📋 **البوتات الحالية:**

🔊 **بوت النطق:** {tts_bot}
📥 **بوت التحميل:** {download_bot}

📌 **لتغيير البوت:**
• `.تبديل النطق @البوت`
• `.تبديل التحميل @البوت`"""
    
    await event.edit(text)