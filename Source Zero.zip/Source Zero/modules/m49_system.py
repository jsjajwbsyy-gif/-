import os
import sys
import io
import asyncio
import platform
import psutil
from datetime import datetime
from asyncio import create_subprocess_exec as asyncrunapp
from asyncio.subprocess import PIPE as asyncPIPE
from telethon import events

from main import client

TMP_DOWNLOAD_DIRECTORY = "./temp"
if not os.path.isdir(TMP_DOWNLOAD_DIRECTORY):
    os.makedirs(TMP_DOWNLOAD_DIRECTORY)


# ==================== عرض قائمة الأوامر (.م49) ====================
@client.on(events.NewMessage(pattern=r'\.م49', outgoing=True))
async def show_system_menu(event):
    menu_text = """⟪───── أوامر النظام والصيانة ─────⟫

│ `.مكاتب` + اسم المكتبة
│ ← البحث عن مكتبة بايثون في pip
│ ← مثال: .مكاتب requests

│ `.الاضافات`
│ ← عرض جميع ملفات السورس المنصبة

│ `.فاراتي`
│ ← عرض جميع متغيرات البيئة (env)

│ `.السرعه`
│ ← قياس سرعة الإنترنت في السيرفر

│ `.النظام`
│ ← عرض معلومات النظام كاملة

╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== أمر .مكاتب ====================
@client.on(events.NewMessage(pattern=r'\.مكاتب (.+)', outgoing=True))
async def pip_search(event):
    pipmodule = event.pattern_match.group(1).strip()
    
    await event.edit(f"⎙ **جاري البحث عن** `{pipmodule}` ...")
    
    try:
        pipc = await asyncrunapp(
            "pip3", "search", pipmodule,
            stdout=asyncPIPE, stderr=asyncPIPE,
        )
        stdout, stderr = await pipc.communicate()
        pipout = str(stdout.decode().strip()) + str(stderr.decode().strip())
        
        if pipout:
            if len(pipout) > 4096:
                await event.edit("⌔ **النتيجة كبيرة جداً، جاري الإرسال كملف...**")
                with open("pips.txt", "w+") as file:
                    file.write(pipout)
                await event.client.send_file(
                    event.chat_id,
                    "pips.txt",
                    reply_to=event.message.id,
                    caption=f"⌔ **نتائج البحث عن:** `{pipmodule}`"
                )
                os.remove("pips.txt")
                await event.delete()
                return
            
            await event.edit(
                f"⌔ **نتائج البحث عن:** `{pipmodule}`\n\n"
                f"`{pipout}`"
            )
        else:
            await event.edit(f"✘ **لم يتم العثور على نتائج لـ** `{pipmodule}`")
    
    except Exception as e:
        await event.edit(f"✘ **فشل البحث:** {str(e)}")


# ==================== أمر .الاضافات ====================
@client.on(events.NewMessage(pattern=r'\.الاضافات$', outgoing=True))
async def list_plugins(event):
    await event.edit("⎙ **جاري جلب قائمة الملفات...**")
    
    try:
        if os.path.isdir("modules"):
            files = os.listdir("modules")
            py_files = [f for f in files if f.endswith(".py")]
            
            if py_files:
                text = f"⌔ **ملفات السورس المنصبة ({len(py_files)}):**\n\n"
                for i, file in enumerate(sorted(py_files), 1):
                    text += f"⦁ {i}. `{file}`\n"
            else:
                text = "✘ **لم يتم العثور على أي ملفات**"
        else:
            text = "✘ **مجلد modules غير موجود**"
        
        await event.edit(text)
    
    except Exception as e:
        await event.edit(f"✘ **خطأ:** {str(e)}")


# ==================== أمر .فاراتي ====================
@client.on(events.NewMessage(pattern=r'\.فاراتي$', outgoing=True))
async def show_env_vars(event):
    await event.edit("⎙ **جاري جلب متغيرات البيئة...**")
    
    try:
        process = await asyncio.create_subprocess_shell(
            "env", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        o = stdout.decode()
        
        if o:
            if len(o) > 4096:
                with io.BytesIO(str.encode(o)) as out_file:
                    out_file.name = "env.txt"
                    await event.client.send_file(
                        event.chat_id,
                        out_file,
                        force_document=True,
                        allow_cache=False,
                        caption="⌔ **متغيرات البيئة (env)**",
                        reply_to=event.message.id,
                    )
                    await event.delete()
            else:
                await event.edit(f"⌔ **متغيرات البيئة:**\n\n`{o}`")
        else:
            await event.edit("✘ **لم يتم العثور على متغيرات**")
    
    except Exception as e:
        await event.edit(f"✘ **خطأ:** {str(e)}")


# ==================== أمر .السرعه ====================
@client.on(events.NewMessage(pattern=r'\.السرعه$', outgoing=True))
async def speed_test(event):
    await event.edit("⎙ **جاري قياس سرعة الإنترنت...**")
    
    try:
        process = await asyncio.create_subprocess_shell(
            "speedtest-cli", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        o = stdout.decode()
        
        if o:
            if len(o) > 4096:
                with io.BytesIO(str.encode(o)) as out_file:
                    out_file.name = "speed.txt"
                    await event.client.send_file(
                        event.chat_id,
                        out_file,
                        force_document=True,
                        allow_cache=False,
                        caption="⌔ **نتيجة قياس السرعة**",
                        reply_to=event.message.id,
                    )
                    await event.delete()
            else:
                await event.edit(f"⌔ **نتيجة قياس السرعة:**\n\n`{o}`")
        else:
            await event.edit("✘ **فشل قياس السرعة. تأكد من تثبيت speedtest-cli**")
    
    except Exception as e:
        await event.edit(f"✘ **خطأ:** {str(e)}\n⌔ **تأكد من تثبيت:** `pip install speedtest-cli`")


# ==================== أمر .النظام ====================
@client.on(events.NewMessage(pattern=r'\.النظام$', outgoing=True))
async def system_info(event):
    await event.edit("⎙ **جاري جلب معلومات النظام...**")
    
    try:
        uname = platform.uname()
        boot_time = datetime.fromtimestamp(psutil.boot_time())
        cpu_freq = psutil.cpu_freq()
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        
        info_text = f"""◈ **معلومات النظام**

⌔ **النظام:** {uname.system} {uname.release}
⌔ **اسم الجهاز:** {uname.node}
⌔ **المعالج:** {uname.processor}
⌔ **المعمارية:** {uname.machine}

⌔ **المعالج:**
⦁ **السرعة:** {cpu_freq.current:.2f} MHz
⦁ **الاستخدام:** {cpu_percent}%

⌔ **الذاكرة:**
⦁ **الإجمالي:** {memory.total / (1024**3):.2f} GB
⦁ **المستخدم:** {memory.used / (1024**3):.2f} GB
⦁ **المتاح:** {memory.available / (1024**3):.2f} GB
⦁ **النسبة:** {memory.percent}%

⌔ **القرص:**
⦁ **الإجمالي:** {disk.total / (1024**3):.2f} GB
⦁ **المستخدم:** {disk.used / (1024**3):.2f} GB
⦁ **المتاح:** {disk.free / (1024**3):.2f} GB
⦁ **النسبة:** {disk.percent}%

⌔ **وقت التشغيل:** {boot_time.strftime('%Y-%m-%d %H:%M:%S')}"""
        
        await event.edit(info_text)
    
    except Exception as e:
        await event.edit(f"✘ **خطأ:** {str(e)}")