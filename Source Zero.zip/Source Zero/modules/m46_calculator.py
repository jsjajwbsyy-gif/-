import io
import sys
import random
import traceback
from datetime import datetime, date
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

# قائمة تحويلات الوحدات المدعومة
units = {
    "كم": 1000, "متر": 1, "سم": 0.01, "ملم": 0.001,
    "كغم": 1000, "غرام": 1, "ملغم": 0.001,
}


# ==================== عرض قائمة الأوامر (.م46) ====================
@client.on(events.NewMessage(pattern=r'\.م46', outgoing=True))
async def show_calc_menu(event):
    menu_text = """⟪───── أوامر الحاسبة ─────⟫

│ `.حاسبه + المعادلة`
│ ← حل المعادلات الرياضية
│ ← مثال: .حاسبه 2+5*3

│ `.حل_معادلة a b c`
│ ← حل معادلة من الدرجة الثانية
│ ← مثال: .حل_معادلة 1 -5 6

│ `.جذر + الرقم`
│ ← حساب الجذر التربيعي
│ ← مثال: .جذر 144

│ `.نسبة_مئوية + جزء من كل`
│ ← حساب النسبة المئوية
│ ← مثال: .نسبة_مئوية 20 من 80

│ `.متوسط + الأرقام`
│ ← حساب المتوسط الحسابي
│ ← مثال: .متوسط 10 20 30 40

│ `.تحويل + من إلى القيمة`
│ ← تحويل الوحدات والحرارة
│ ← مثال: .تحويل كم متر 5
│ ← مثال: .تحويل س ف 100

│ `.عشوائي + أصغر أكبر`
│ ← توليد رقم عشوائي
│ ← مثال: .عشوائي 1 100

│ `.السن + يوم-شهر-سنة`
│ ← حساب العمر من تاريخ الميلاد
│ ← مثال: .السن 15-8-2004
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== 1. أمر .حاسبه ====================
@client.on(events.NewMessage(pattern=r'\.حاسبه ([\s\S]+)', outgoing=True))
async def calculator(event):
    "لحل المعادلات الرياضية"
    cmd = event.pattern_match.group(1)
    event = await event.edit("⎙ **جاري الحل…**")

    old_stderr = sys.stderr
    old_stdout = sys.stdout
    redirected_output = sys.stdout = io.StringIO()
    redirected_error = sys.stderr = io.StringIO()
    stdout, stderr, exc = None, None, None
    san = f"print({cmd})"

    try:
        await aexec(san, event)
    except Exception:
        exc = traceback.format_exc()

    stdout = redirected_output.getvalue()
    stderr = redirected_error.getvalue()
    sys.stdout = old_stdout
    sys.stderr = old_stderr

    evaluation = ""
    if exc:
        evaluation = exc
    elif stderr:
        evaluation = stderr
    elif stdout:
        evaluation = stdout
    else:
        evaluation = "✘ **اسف لا يمكنني حلها**"

    final_output = f"⌔ **المعـادلـة ⇜** `{cmd}`\n\n✓ **الحـل ⇜** `{evaluation}`"
    await event.edit(final_output)


async def aexec(code, event):
    exec("async def __aexec(event): " + "".join(f"\n {l}" for l in code.split("\n")))
    return await locals()["__aexec"](event)


# ==================== 2. أمر .حل_معادلة ====================
@client.on(events.NewMessage(pattern=r'\.حل_معادلة (\S+) (\S+) (\S+)', outgoing=True))
async def solve_quadratic(event):
    "لحل معادلة من الدرجة الثانية: ax² + bx + c = 0"
    try:
        a = float(event.pattern_match.group(1))
        b = float(event.pattern_match.group(2))
        c = float(event.pattern_match.group(3))
    except ValueError:
        await event.edit("✘ **يرجى إدخال أرقام صحيحة فقط**")
        return

    event = await event.edit("⎙ **جاري حل المعادلة…**")

    discriminant = (b ** 2) - (4 * a * c)

    if discriminant > 0:
        x1 = (-b + (discriminant ** 0.5)) / (2 * a)
        x2 = (-b - (discriminant ** 0.5)) / (2 * a)
        result = f"✓ **x₁ =** `{x1:.2f}`\n✓ **x₂ =** `{x2:.2f}`"
    elif discriminant == 0:
        x = -b / (2 * a)
        result = f"✓ **x =** `{x:.2f}`"
    else:
        result = "✘ **لا يوجد حل حقيقي (المميز سالب)**"

    final_output = f"⌔ **المعادلة:** `{a}x² + {b}x + {c} = 0`\n\n{result}"
    await event.edit(final_output)


# ==================== 3. أمر .جذر ====================
@client.on(events.NewMessage(pattern=r'\.جذر (\S+)', outgoing=True))
async def square_root(event):
    "لحساب الجذر التربيعي"
    try:
        num = float(event.pattern_match.group(1))
    except ValueError:
        await event.edit("✘ **يرجى إدخال رقم صحيح**")
        return

    event = await event.edit("⎙ **جاري حساب الجذر…**")

    if num >= 0:
        sqrt_num = num ** 0.5
        result = f"✓ **الجذر التربيعي لـ {num} =** `{sqrt_num:.2f}`"
    else:
        result = "✘ **لا يمكن حساب جذر لعدد سالب**"

    final_output = f"⌔ **العملية:** √{num}\n\n{result}"
    await event.edit(final_output)


# ==================== 4. أمر .نسبة_مئوية ====================
@client.on(events.NewMessage(pattern=r'\.نسبة_مئوية (\S+) من (\S+)', outgoing=True))
async def percentage(event):
    "لحساب النسبة المئوية"
    try:
        part = float(event.pattern_match.group(1))
        total = float(event.pattern_match.group(2))
    except ValueError:
        await event.edit("✘ **يرجى إدخال أرقام صحيحة فقط**")
        return

    event = await event.edit("⎙ **جاري الحساب…**")

    if total == 0:
        await event.edit("✘ **لا يمكن القسمة على صفر**")
        return

    percent = (part / total) * 100
    final_output = f"⌔ **العملية:** {part} من {total}\n\n✓ **النسبة:** `{percent:.2f}%`"
    await event.edit(final_output)


# ==================== 5. أمر .متوسط ====================
@client.on(events.NewMessage(pattern=r'\.متوسط (.+)', outgoing=True))
async def average(event):
    "لحساب المتوسط الحسابي"
    numbers_str = event.pattern_match.group(1).split()

    try:
        numbers = [float(num) for num in numbers_str]
    except ValueError:
        await event.edit("✘ **يرجى إدخال أرقام صحيحة فقط**")
        return

    if not numbers:
        await event.edit("✘ **يرجى إدخال رقم واحد على الأقل**")
        return

    event = await event.edit("⎙ **جاري الحساب…**")

    avg = sum(numbers) / len(numbers)
    final_output = f"⌔ **الأرقام:** {', '.join(numbers_str)}\n\n✓ **المتوسط:** `{avg:.2f}`"
    await event.edit(final_output)


# ==================== 6. أمر .تحويل ====================
@client.on(events.NewMessage(pattern=r'\.تحويل (\S+) (\S+) (\S+)', outgoing=True))
async def convert_units(event):
    "لتحويل الوحدات"
    from_unit = event.pattern_match.group(1)
    to_unit = event.pattern_match.group(2)

    try:
        value = float(event.pattern_match.group(3))
    except ValueError:
        await event.edit("✘ **يرجى إدخال رقم صحيح**")
        return

    event = await event.edit("⎙ **جاري التحويل…**")

    # تحويل درجات الحرارة
    if from_unit == "س" and to_unit == "ف":
        result = (value * 9/5) + 32
        final_output = f"⌔ **التحويل:** {value}°C → °F\n\n✓ **الناتج:** `{result:.2f}°F`"
    elif from_unit == "ف" and to_unit == "س":
        result = (value - 32) * 5/9
        final_output = f"⌔ **التحويل:** {value}°F → °C\n\n✓ **الناتج:** `{result:.2f}°C`"

    # تحويل المسافات والاوزان
    elif from_unit in units and to_unit in units:
        base_value = value * units[from_unit]
        result = base_value / units[to_unit]
        final_output = f"⌔ **التحويل:** {value} {from_unit} → {to_unit}\n\n✓ **الناتج:** `{result:.2f} {to_unit}`"

    else:
        final_output = "✘ **الوحدات المدعومة:** كم, متر, سم, ملم, كغم, غرام, ملغم, س, ف"

    await event.edit(final_output)


# ==================== 7. أمر .عشوائي ====================
@client.on(events.NewMessage(pattern=r'\.عشوائي (\S+) (\S+)', outgoing=True))
async def random_number(event):
    "لتوليد رقم عشوائي"
    try:
        min_num = int(event.pattern_match.group(1))
        max_num = int(event.pattern_match.group(2))
    except ValueError:
        await event.edit("✘ **يرجى إدخال أرقام صحيحة فقط**")
        return

    if min_num > max_num:
        min_num, max_num = max_num, min_num

    result = random.randint(min_num, max_num)
    final_output = f"⌔ **النطاق:** {min_num} ← → {max_num}\n\n✓ **الرقم العشوائي:** `{result}`"
    await event.edit(final_output)


# ==================== 8. أمر .السن ====================
@client.on(events.NewMessage(pattern=r'\.السن (\d{1,2})-(\d{1,2})-(\d{4})', outgoing=True))
async def calculate_age(event):
    "لحساب العمر من تاريخ الميلاد"
    try:
        day = int(event.pattern_match.group(1))
        month = int(event.pattern_match.group(2))
        year = int(event.pattern_match.group(3))
        birth_date = date(year, month, day)
    except (ValueError, OverflowError):
        await event.edit("✘ **تاريخ غير صالح**")
        return

    today = date.today()

    if birth_date > today:
        await event.edit("✘ **تاريخ الميلاد في المستقبل!**")
        return

    age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
    final_output = f"⌔ **تاريخ الميلاد:** {day}-{month}-{year}\n\n✓ **العمر:** `{age}` سنة"
    await event.edit(final_output)