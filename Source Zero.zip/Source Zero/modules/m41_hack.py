from main import client
from telethon import events

# ========== M41: أوامر الاختراق الوهمي ==========

@client.on(events.NewMessage(pattern=r'\.م41', outgoing=True))
async def show_m41_menu(event):
    menu_text = """⟪───── أوامر الاختراق الوهمي ─────⟫

│ `.اختراق`
│ ← اختراق حساب تيليجرام وهمي (بالرد)

│ `.اختراق_وايفاي`
│ ← اختراق شبكة واي فاي وهمية

│ `.اختراق_كاميرا`
│ ← اختراق كاميرا وهمي (بالرد)

│ `.اختراق_فيروس`
│ ← تلويث جهاز وهمي

│ `.اختراق_باسورد`
│ ← كسر كلمة مرور وهمية (بالرد)

│ `.اختراق_موقع`
│ ← اختراق موقع وهمي

│ `.اختراق_تتبع`
│ ← تتبع موقع وهمي (بالرد)

│ `.اختراق_بنك`
│ ← اختراق بنك وهمي

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== أمر .اختراق ==========
@client.on(events.NewMessage(pattern=r'\.اختراق', outgoing=True))
async def hack_telegram(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص المراد اختراقه**")
        return
    
    target = await reply.get_sender()
    target_name = target.first_name
    
    steps = [
        "🔍 **جاري جمع المعلومات...**",
        "🔗 **تم العثور على ثغرة في الجلسة...**",
        "📡 **جاري اعتراض البيانات...**",
        "🔓 **تم كسر التشفير...**",
        "📱 **تم الوصول إلى الجهاز...**",
        "💰 **جاري سرقة العملات...**",
        "📸 **تم نسخ الصور...**",
        "💬 **تم سرقة المحادثات...**",
    ]
    
    for step in steps:
        await event.edit(step)
        await asyncio.sleep(0.8)
    
    await event.edit(f"""🎭 **تم الاختراق بنجاح!**

👤 **الهدف:** {target_name}
📱 **الجهاز:** iPhone 15 Pro Max
🔑 **كلمة المرور:** ********
💰 **الرصيد:** 0.00 دولار
📸 **الصور:** 420 صورة
💬 **المحادثات:** 1337 محادثة""")


# ========== أمر .اختراق_وايفاي ==========
@client.on(events.NewMessage(pattern=r'\.اختراق_وايفاي', outgoing=True))
async def hack_wifi(event):
    networks = ["STARLINK-5G", "NASA-SECURE", "CIA-HEADQUARTERS", "AREA-51", "PENTAGON-GUEST"]
    selected = random.choice(networks)
    
    steps = [
        f"📡 **جاري البحث عن شبكات واي فاي...**",
        f"🔍 **تم العثور على {random.randint(5, 20)} شبكة**",
        f"🎯 **استهداف:** {selected}",
        f"🔐 **جاري كسر كلمة المرور...**",
        f"🔑 **تم تخمين الباسورد:** {random.choice(['admin123', 'password', '12345678', 'qwerty'])}",
        f"✅ **تم الاتصال بالشبكة!**",
    ]
    
    for step in steps:
        await event.edit(step)
        await asyncio.sleep(0.7)
    
    await event.edit(f"""📡 **تم اختراق الواي فاي!**

🌐 **الشبكة:** {selected}
🔑 **الباسورد:** ********
⚡ **السرعة:** {random.randint(100, 1000)} Mbps""")


# ========== أمر .اختراق_كاميرا ==========
@client.on(events.NewMessage(pattern=r'\.اختراق_كاميرا', outgoing=True))
async def hack_camera(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص المراد اختراق كاميراه**")
        return
    
    target = await reply.get_sender()
    
    steps = [
        "📸 **جاري الوصول إلى الكاميرا...**",
        "🔓 **تم تجاوز الحماية...**",
        "📡 **جاري البث المباشر...**",
        "👁️ **تم تفعيل الكاميرا الأمامية...**",
        "📷 **تم التقاط صورة...**",
    ]
    
    for step in steps:
        await event.edit(step)
        await asyncio.sleep(0.8)
    
    await event.edit(f"""📸 **تم اختراق الكاميرا!**

👤 **الهدف:** {target.first_name}
📷 **الكاميرا:** أمامية
🖼️ **تم التقاط الصورة بنجاح**
😴 **المستخدم نائم حالياً** 🛌""")


# ========== أمر .اختراق_فيروس ==========
@client.on(events.NewMessage(pattern=r'\.اختراق_فيروس', outgoing=True))
async def hack_virus(event):
    virus_name = random.choice(["WannaCry 3.0", "ILOVEYOU V2", "Stuxnet-X", "Zeus-Trojan", "Pegasus-Pro"])
    
    steps = [
        "🦠 **جاري رفع الفيروس...**",
        "📤 **تم الإرسال...**",
        "💻 **جاري التثبيت على الجهاز...**",
        "⚠️ **تم تعطيل مضاد الفيروسات...**",
        "🔒 **جاري تشفير الملفات...**",
        "📁 **تم تشفير 1337 ملف**",
        "💰 **طلب فدية:** 3 بيتكوين",
    ]
    
    for step in steps:
        await event.edit(step)
        await asyncio.sleep(0.7)
    
    await event.edit(f"""🦠 **تم إرسال الفيروس!**

💻 **الفيروس:** {virus_name}
📁 **الملفات المشفرة:** 1337
💰 **الفدية المطلوبة:** 3 BTC""")


# ========== أمر .اختراق_باسورد ==========
@client.on(events.NewMessage(pattern=r'\.اختراق_باسورد', outgoing=True))
async def hack_password(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص المراد كسر كلمة مروره**")
        return
    
    target = await reply.get_sender()
    passwords = ["admin123", "password", "12345678", "qwerty", "iloveyou", "hunter2"]
    
    steps = [
        "🔐 **جاري تحليل الحساب...**",
        "📊 **تم جمع البيانات...**",
        "🔢 **جاري تجربة 1000 كلمة مرور...**",
        "🔢 **جاري تجربة 10000 كلمة مرور...**",
        "🔢 **جاري تجربة 100000 كلمة مرور...**",
        "✅ **تم العثور على كلمة المرور!**",
    ]
    
    for step in steps:
        await event.edit(step)
        await asyncio.sleep(0.6)
    
    await event.edit(f"""🔓 **تم كسر كلمة المرور!**

👤 **الهدف:** {target.first_name}
🔑 **كلمة المرور:** {random.choice(passwords)}
📧 **الإيميل:** ***@gmail.com""")


# ========== أمر .اختراق_موقع ==========
@client.on(events.NewMessage(pattern=r'\.اختراق_موقع\s+(\S+)', outgoing=True))
async def hack_website(event):
    url = event.pattern_match.group(1).strip()
    
    steps = [
        f"🌐 **جاري فحص:** {url}",
        "🔍 **تم العثور على ثغرة SQL Injection...**",
        "💉 **جاري حقن قاعدة البيانات...**",
        "📊 **تم استخراج 10,000 مستخدم...**",
        "🔑 **تم الحصول على صلاحيات الأدمن...**",
        "🏴 **تم رفع علم القراصنة...**",
    ]
    
    for step in steps:
        await event.edit(step)
        await asyncio.sleep(0.7)
    
    await event.edit(f"""💀 **تم اختراق الموقع!**

🌐 **الموقع:** {url}
🔓 **الثغرة:** SQL Injection
👥 **المستخدمون:** 10,000
🛡️ **الحالة:** تم الرفع""")


# ========== أمر .اختراق_تتبع ==========
@client.on(events.NewMessage(pattern=r'\.اختراق_تتبع', outgoing=True))
async def hack_track(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص المراد تتبعه**")
        return
    
    target = await reply.get_sender()
    cities = ["بغداد 🇮🇶", "دبي 🇦🇪", "القاهرة 🇪🇬", "لندن 🇬🇧", "نيويورك 🇺🇸"]
    
    steps = [
        "📡 **جاري تتبع الموقع...**",
        "🛰️ **تم الاتصال بالقمر الصناعي...**",
        "📍 **جاري تحديد الإحداثيات...**",
        "🗺️ **تم العثور على الموقع!**",
    ]
    
    for step in steps:
        await event.edit(step)
        await asyncio.sleep(0.8)
    
    await event.edit(f"""📍 **تم تتبع الموقع!**

👤 **الهدف:** {target.first_name}
🗺️ **المدينة:** {random.choice(cities)}
📍 **الإحداثيات:** {random.uniform(30, 40):.4f}, {random.uniform(40, 50):.4f}
📱 **الجهاز:** iPhone 15 Pro Max""")


# ========== أمر .اختراق_بنك ==========
@client.on(events.NewMessage(pattern=r'\.اختراق_بنك', outgoing=True))
async def hack_bank(event):
    banks = ["البنك المركزي", "بنك الراجحي", "البنك الأهلي", "HSBC", "Chase Bank"]
    
    steps = [
        "🏦 **جاري استهداف البنك...**",
        "🔓 **تم تجاوز جدار الحماية...**",
        "💳 **جاري سحب بيانات البطاقات...**",
        "💰 **جاري تحويل الأموال...**",
        "💸 **تم تحويل 1,000,000 دولار...**",
    ]
    
    for step in steps:
        await event.edit(step)
        await asyncio.sleep(0.8)
    
    await event.edit(f"""🏦 **تم اختراق البنك!**

🏛️ **البنك:** {random.choice(banks)}
💳 **البطاقات المسروقة:** 500
💰 **المبلغ المحول:** 1,000,000 دولار
🛑 **تم تجميد الحساب من FBI**""")