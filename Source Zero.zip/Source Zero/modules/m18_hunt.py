import asyncio
import random
from datetime import datetime
from telethon import events
from telethon.tl.functions.account import UpdateUsernameRequest
from telethon.tl.functions.channels import CreateChannelRequest, UpdateUsernameRequest as ChannelUpdateUsername

# استيراد المتغيرات من الملف الرئيسي
from main import client

hunt_settings = {}
hunted_usernames = {}
hunt_status = {}

# خرائط الأنماط
PATTERN_MAP = {
    '1': 'abcdefghijklmnopqrstuvwxyz',
    '2': '0123456789',
    '3': 'abcdefghijklmnopqrstuvwxyz0123456789',
    '4': 'abcdefghijklmnopqrstuvwxyz0123456789',
    '5': 'abcdefghijklmnopqrstuvwxyz',
    '6': '0123456789',
}


# ==================== عرض قائمة الأوامر (.م18) ====================
@client.on(events.NewMessage(pattern=r'\.م18', outgoing=True))
async def show_hunt_menu(event):
    menu_text = """⟪───── أوامر الصيد ─────⟫

│ `.صيد + النمط`
│ ← لبدء صيد اليوزرات حسب النمط
│ ← مثال: .صيد 12211 → s99ss

│ `.صيد_مستمر + النمط`
│ ← لبدء صيد متواصل على نفس النمط

│ `.صيد_قناة + النمط`
│ ← صيد متواصل مع حفظ النتائج في قناة تلقائية

│ الأنماط المدعومة:
│ 1 ← حرف عشوائي من a إلى z
│ 2 ← رقم عشوائي من 0 إلى 9
│ 3 ← حرف أو رقم عشوائي
│ 4 ← حرف أو رقم عشوائي
│ 5 ← حرف عشوائي مختلف
│ 6 ← رقم عشوائي مختلف

│ `.ايقاف الصيد`
│ ← لإيقاف عملية الصيد الجارية

│ `.حالة الصيد`
│ ← لعرض حالة الصيد (النمط، النتائج، الوقت...)

│ `.المصادين`
│ ← لعرض اليوزرات التي تم صيدها

│ `.مسح المصادين`
│ ← لمسح قائمة اليوزرات المصادة

│ `.ضع_يوزر + الرقم`
│ ← لوضع يوزر من القائمة يدوياً

│ `.تأكيد_يوزر + الرقم`
│ ← لتأكيد وضع اليوزر المحدد

ملاحظة:  
↢ يمكنك استخدام [كلمة] أو [_] ضمن النمط  
↪ مثال: .صيد _123_ → _a9b_
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== دالة مساعدة: توليد يوزر من النمط ====================
def generate_username_from_pattern(pattern, used_chars=None):
    result = ""
    pattern_chars = list(pattern)
    
    if used_chars is None:
        used_chars = {}
    
    for char in pattern_chars:
        if char == '_':
            pool = PATTERN_MAP['3']
            result += random.choice(pool)
        elif char.isdigit() and char in PATTERN_MAP:
            pattern_type = char
            
            if pattern_type not in used_chars:
                used_chars[pattern_type] = []
            
            pool = PATTERN_MAP[pattern_type]
            
            if pattern_type in ['5', '6']:
                available = [c for c in pool if c not in used_chars[pattern_type]]
                if not available:
                    available = pool
                chosen = random.choice(available)
                used_chars[pattern_type].append(chosen)
            else:
                chosen = random.choice(pool)
            
            result += chosen
        else:
            result += char
    
    return result


# ==================== دالة مساعدة: إنشاء قناة تلقائية ====================
async def create_hunt_channel(event):
    try:
        result = await client(CreateChannelRequest(
            title="⎉ صيد اليوزرات ⎉",
            about=f"قناة لحفظ اليوزرات المصادة - {datetime.now().strftime('%Y-%m-%d')}",
            megagroup=False
        ))
        channel_id = result.chats[0].id
        return channel_id
    except Exception as e:
        await event.edit(f"✘ **خطأ في إنشاء القناة:** {str(e)}")
        return None


# ==================== 1. أمر .صيد ====================
@client.on(events.NewMessage(pattern=r'\.صيد\s+(\S+)', outgoing=True))
async def hunt_usernames(event):
    pattern = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in hunt_settings:
        hunt_settings[user_id] = {}
    
    hunt_settings[user_id]["active"] = True
    hunt_settings[user_id]["continuous"] = False
    hunt_settings[user_id]["use_channel"] = False
    hunt_settings[user_id]["pattern"] = pattern
    hunt_settings[user_id]["found_count"] = 0
    hunt_settings[user_id]["checked_count"] = 0
    hunt_settings[user_id]["start_time"] = datetime.now()
    
    if user_id not in hunted_usernames:
        hunted_usernames[user_id] = []
    
    await event.edit(f"♞ **بدء الصيد بالنمط:** `{pattern}`\n⎙ **جاري البحث...**")
    asyncio.create_task(start_hunting(event, user_id, pattern, continuous=False, use_channel=False))


# ==================== 2. أمر .صيد_مستمر ====================
@client.on(events.NewMessage(pattern=r'\.صيد_مستمر\s+(\S+)', outgoing=True))
async def hunt_continuous(event):
    pattern = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in hunt_settings:
        hunt_settings[user_id] = {}
    
    hunt_settings[user_id]["active"] = True
    hunt_settings[user_id]["continuous"] = True
    hunt_settings[user_id]["use_channel"] = False
    hunt_settings[user_id]["pattern"] = pattern
    hunt_settings[user_id]["found_count"] = 0
    hunt_settings[user_id]["checked_count"] = 0
    hunt_settings[user_id]["start_time"] = datetime.now()
    
    if user_id not in hunted_usernames:
        hunted_usernames[user_id] = []
    
    await event.edit(f"♞ **بدء الصيد المستمر بالنمط:** `{pattern}`\n⌔ **سيستمر حتى يتم إيقافه...**")
    asyncio.create_task(start_hunting(event, user_id, pattern, continuous=True, use_channel=False))


# ==================== 3. أمر .صيد_قناة ====================
@client.on(events.NewMessage(pattern=r'\.صيد_قناة\s+(\S+)', outgoing=True))
async def hunt_channel(event):
    pattern = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    channel_id = await create_hunt_channel(event)
    if channel_id is None:
        return
    
    if user_id not in hunt_settings:
        hunt_settings[user_id] = {}
    
    hunt_settings[user_id]["active"] = True
    hunt_settings[user_id]["continuous"] = True
    hunt_settings[user_id]["use_channel"] = True
    hunt_settings[user_id]["channel_id"] = channel_id
    hunt_settings[user_id]["pattern"] = pattern
    hunt_settings[user_id]["found_count"] = 0
    hunt_settings[user_id]["checked_count"] = 0
    hunt_settings[user_id]["start_time"] = datetime.now()
    
    if user_id not in hunted_usernames:
        hunted_usernames[user_id] = []
    
    await event.edit(f"♞ **بدء الصيد مع القناة بالنمط:** `{pattern}`\n⌔ **القناة:** تم إنشاؤها بنجاح\n⎙ **جاري البحث...**")
    asyncio.create_task(start_hunting(event, user_id, pattern, continuous=True, use_channel=True))


# ==================== دالة الصيد الرئيسية ====================
async def start_hunting(event, user_id, pattern, continuous=False, use_channel=False):
    checked = 0
    found = 0
    status_msg = None
    chat_id = event.chat_id
    channel_id = hunt_settings[user_id].get("channel_id", None) if use_channel else None
    pattern_type = "نمط " + pattern
    
    while True:
        if user_id not in hunt_settings:
            break
        
        if not hunt_settings[user_id].get("active", False):
            break
        
        if not continuous and found > 0:
            hunt_settings[user_id]["active"] = False
            break
        
        used_chars = {}
        username = generate_username_from_pattern(pattern, used_chars)
        checked += 1
        hunt_settings[user_id]["checked_count"] = checked
        
        try:
            await client.get_entity(username)
        except Exception as e:
            if "username not occupied" in str(e).lower() or "not found" in str(e).lower():
                found += 1
                hunt_settings[user_id]["found_count"] = found
                
                if username not in hunted_usernames[user_id]:
                    hunted_usernames[user_id].append(username)
                
                # رسالة الصيد بالتنسيق الجديد
                found_msg = f"""♞ **تم العثور على يوزر متاح!**

⌔ **المعلومات:**
⦁ **اليوزر:** @{username}
⦁ **النمط:** `{pattern}`
⦁ **النوع:** {pattern_type}
⦁ **المحاولات:** {checked}
⦁ **المصاد:** {found}
◈ **بواسطة:** الصيد التلقائي"""

                await client.send_message(chat_id, found_msg)
                
                # حفظ في القناة إذا كانت مفعلة
                if use_channel and channel_id:
                    try:
                        await client(ChannelUpdateUsername(channel=channel_id, username=username))
                        await client.send_message(channel_id, found_msg)
                    except Exception:
                        pass
                
                if not continuous:
                    break
        
        if checked % 50 == 0:
            status_text = f"⎙ **جاري الصيد...**\n⦁ **النمط:** `{pattern}`\n⦁ **تم الفحص:** {checked}\n⦁ **تم العثور:** {found}"
            if use_channel:
                status_text += f"\n⦁ **القناة:** ✓ مفعلة"
            
            if status_msg:
                try:
                    await status_msg.edit(status_text)
                except:
                    pass
            else:
                status_msg = await client.send_message(chat_id, status_text)
        
        await asyncio.sleep(random.uniform(0.5, 1.5))
    
    if user_id in hunt_settings:
        hunt_settings[user_id]["active"] = False
        hunt_settings[user_id]["end_time"] = datetime.now()
    
    end_msg = f"""✓ **انتهى الصيد!**

⌔ **الإحصائيات:**
⦿ **النمط:** `{pattern}`
⦿ **تم الفحص:** {checked}
⦿ **تم العثور:** {found}
⦿ **الوقت:** {datetime.now().strftime('%I:%M %p')}"""

    if use_channel and channel_id:
        end_msg += f"\n⦿ **القناة:** تم الحفظ فيها"
    
    await client.send_message(chat_id, end_msg)


# ==================== 4. أمر .ايقاف الصيد ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف الصيد', outgoing=True))
async def stop_hunting(event):
    user_id = event.sender_id
    
    if user_id in hunt_settings:
        hunt_settings[user_id]["active"] = False
        await event.edit("✘ **تم إيقاف الصيد**")
    else:
        await event.edit("✘ **لا توجد عملية صيد جارية**")


# ==================== 5. أمر .حالة الصيد ====================
@client.on(events.NewMessage(pattern=r'\.حالة الصيد', outgoing=True))
async def hunt_status_cmd(event):
    user_id = event.sender_id
    
    if user_id not in hunt_settings or not hunt_settings[user_id].get("active", False):
        await event.edit("✘ **لا توجد عملية صيد جارية**")
        return
    
    settings = hunt_settings[user_id]
    pattern = settings.get("pattern", "غير محدد")
    continuous = "✓ نعم" if settings.get("continuous", False) else "✘ لا"
    use_channel = "✓ نعم" if settings.get("use_channel", False) else "✘ لا"
    checked = settings.get("checked_count", 0)
    found = settings.get("found_count", 0)
    start_time = settings.get("start_time", datetime.now())
    
    elapsed = datetime.now() - start_time
    minutes = elapsed.seconds // 60
    seconds = elapsed.seconds % 60
    
    status_text = f"""◈ **حالة الصيد الحالية:**

⌔ **النمط:** `{pattern}`
⦁ **مستمر:** {continuous}
⦁ **قناة:** {use_channel}
⦁ **تم الفحص:** {checked}
⦁ **تم العثور:** {found}
⦁ **الوقت المنقضي:** {minutes:02d}:{seconds:02d}

⦁ **لإيقاف الصيد:** `.ايقاف الصيد`"""
    
    await event.edit(status_text)


# ==================== 6. أمر .المصادين ====================
@client.on(events.NewMessage(pattern=r'\.المصادين', outgoing=True))
async def show_hunted_usernames(event):
    user_id = event.sender_id
    
    if user_id not in hunted_usernames or not hunted_usernames[user_id]:
        await event.edit("✘ **لا توجد يوزرات مصادة حالياً**")
        return
    
    usernames = hunted_usernames[user_id]
    text = f"⌔ **اليوزرات المصادة ({len(usernames)}):**\n\n"
    
    for i, username in enumerate(usernames[:50], 1):
        text += f"⦁ {i}. @{username}\n"
    
    if len(usernames) > 50:
        text += f"\n⦁ ... و {len(usernames) - 50} يوزر آخر"
    
    text += f"\n\n⦁ **لوضع يوزر:** `.ضع_يوزر + الرقم`\n⦁ **لمسح القائمة:** `.مسح المصادين`"
    
    await event.edit(text)


# ==================== 7. أمر .مسح المصادين ====================
@client.on(events.NewMessage(pattern=r'\.مسح المصادين', outgoing=True))
async def clear_hunted_usernames(event):
    user_id = event.sender_id
    
    if user_id in hunted_usernames:
        count = len(hunted_usernames[user_id])
        hunted_usernames[user_id] = []
        await event.edit(f"⌫ **تم مسح {count} يوزر من القائمة**")
    else:
        await event.edit("✘ **القائمة فارغة بالفعل**")


# ==================== 8. أمر .ضع_يوزر ====================
@client.on(events.NewMessage(pattern=r'\.ضع_يوزر\s+(\d+)', outgoing=True))
async def set_username_manually(event):
    index = int(event.pattern_match.group(1).strip()) - 1
    user_id = event.sender_id
    
    if user_id not in hunted_usernames or not hunted_usernames[user_id]:
        await event.edit("✘ **لا توجد يوزرات مصادة**")
        return
    
    if index < 0 or index >= len(hunted_usernames[user_id]):
        await event.edit(f"✘ **الرقم غير موجود**\n⌔ *القائمة تحتوي على {len(hunted_usernames[user_id])} يوزر*")
        return
    
    username = hunted_usernames[user_id][index]
    
    await event.edit(f"⚠ **هل أنت متأكد من تغيير اليوزر إلى** `@{username}`؟\n\n✓ **للتأكيد:** `.تأكيد_يوزر {index + 1}`\n✘ **للإلغاء:** `.الغاء`")
    
    if user_id not in hunt_status:
        hunt_status[user_id] = {}
    hunt_status[user_id]["pending_username"] = username
    hunt_status[user_id]["pending_index"] = index


# ==================== 9. أمر .تأكيد_يوزر ====================
@client.on(events.NewMessage(pattern=r'\.تأكيد_يوزر\s+(\d+)', outgoing=True))
async def confirm_set_username(event):
    user_id = event.sender_id
    
    if user_id not in hunt_status or "pending_username" not in hunt_status[user_id]:
        await event.edit("✘ **لا يوجد يوزر معلق للتأكيد**")
        return
    
    username = hunt_status[user_id]["pending_username"]
    index = hunt_status[user_id]["pending_index"]
    
    try:
        await client(UpdateUsernameRequest(username))
        
        if user_id in hunted_usernames and index < len(hunted_usernames[user_id]):
            hunted_usernames[user_id].pop(index)
        
        del hunt_status[user_id]["pending_username"]
        del hunt_status[user_id]["pending_index"]
        
        await event.edit(f"✓ **تم تغيير اليوزر بنجاح إلى:** `@{username}`")
        
    except Exception as e:
        error_msg = str(e)
        if "USERNAME_OCCUPIED" in error_msg or "already taken" in error_msg.lower():
            if user_id in hunted_usernames and index < len(hunted_usernames[user_id]):
                hunted_usernames[user_id].pop(index)
            
            del hunt_status[user_id]["pending_username"]
            del hunt_status[user_id]["pending_index"]
            
            await event.edit(f"✘ **اليوزر** `@{username}` **تم حجزه للأسف**\n⌫ *تم حذفه من القائمة*")
        else:
            await event.edit(f"✘ **فشل تغيير اليوزر:** {error_msg}")