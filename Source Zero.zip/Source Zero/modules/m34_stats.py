from main import client
from telethon import events

# ========== M34: أوامر الإحصائيات والتحليلات ==========

@client.on(events.NewMessage(pattern=r'\.م34', outgoing=True))
async def show_m34_menu(event):
    menu_text = """⟪───── أوامر الإحصائيات والتحليلات ─────⟫

│ `.الأكثر تفاعلاً`
│ ← أكثر 10 أشخاص تفاعلاً معك

│ `.عدد الكل`
│ ← إحصائيات حسابك كاملة

│ `.عدد الخاص`
│ ← عدد الرسائل غير المقروءة

│ `.مستوى`
│ ← معرفة إذا كان حسابك مقيد أو محظور

│ `.وقت التقييد`
│ ← معرفة متى ينتهي تقييدك

│ `.حالة السيرفر`
│ ← سرعة استجابة السيرفر

│ `.اسماء`
│ ← عرض أسماء جميع المجموعات

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== أمر .الأكثر تفاعلاً ==========
@client.on(events.NewMessage(pattern=r'\.الأكثر تفاعلاً', outgoing=True))
async def most_interactive(event):
    await event.edit("📊 **جاري التحليل...**")
    
    stats = {}
    count = 0
    async for dialog in client.iter_dialogs():
        if count >= 30:
            break
        if dialog.is_user and not dialog.entity.bot:
            try:
                messages = await client.get_messages(dialog.id, limit=50)
                sent = len([m for m in messages if m.out])
                if sent > 0:
                    stats[dialog.name] = sent
                    count += 1
            except:
                pass
    
    sorted_stats = sorted(stats.items(), key=lambda x: x[1], reverse=True)[:10]
    
    if sorted_stats:
        text = "👥 **أكثر 10 أشخاص تفاعلاً معك:**\n\n"
        for i, (name, count) in enumerate(sorted_stats, 1):
            text += f"{i}. **{name}** - {count} رسالة\n"
    else:
        text = "📭 **لا توجد بيانات كافية**"
    
    await event.edit(text)


# ========== أمر .عدد الكل ==========
@client.on(events.NewMessage(pattern=r'\.عدد الكل', outgoing=True))
async def all_stats(event):
    await event.edit("📊 **جاري جلب الإحصائيات...**")
    
    groups = 0
    channels = 0
    users = 0
    bots = 0
    
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            groups += 1
        elif dialog.is_channel:
            channels += 1
        elif dialog.is_user:
            if dialog.entity.bot:
                bots += 1
            else:
                users += 1
    
    me = await client.get_me()
    
    text = f"""📊 **إحصائيات حسابك:**

👥 **المجموعات:** {groups}
📢 **القنوات:** {channels}
💬 **المستخدمين:** {users}
🤖 **البوتات:** {bots}
📊 **الإجمالي:** {groups + channels + users + bots}

📝 **معلومات الحساب:**
📎 **اليوزر:** @{me.username or 'بدون'}
🆔 **الآيدي:** `{me.id}`"""
    
    await event.edit(text)


# ========== أمر .عدد الخاص ==========
@client.on(events.NewMessage(pattern=r'\.عدد الخاص', outgoing=True))
async def unread_count(event):
    await event.edit("📊 **جاري جلب عدد الرسائل غير المقروءة...**")
    
    unread = 0
    async for dialog in client.iter_dialogs():
        if dialog.is_user and not dialog.entity.bot:
            if hasattr(dialog, 'unread_count') and dialog.unread_count > 0:
                unread += dialog.unread_count
    
    await event.edit(f"📊 **عدد الرسائل غير المقروءة في الخاص:** {unread}")


# ========== أمر .مستوى ==========
@client.on(events.NewMessage(pattern=r'\.مستوى', outgoing=True))
async def account_status(event):
    me = await client.get_me()
    
    status_text = "📊 **حالة حسابك:**\n\n"
    
    if hasattr(me, 'restricted') and me.restricted:
        status_text += "⚠️ **حسابك مقيد**\n"
        if hasattr(me, 'restriction_reason'):
            status_text += f"📝 **السبب:** {me.restriction_reason}\n"
    else:
        status_text += "✅ **حسابك غير مقيد**\n"
    
    status_text += f"💎 **مميز:** {'✅ نعم' if hasattr(me, 'premium') and me.premium else '❌ لا'}"
    
    await event.edit(status_text)


# ========== أمر .وقت التقييد ==========
@client.on(events.NewMessage(pattern=r'\.وقت التقييد', outgoing=True))
async def restriction_time(event):
    await event.edit("📊 **لا توجد معلومات عن مدة التقييد حالياً**\n✅ **حسابك حر**")


# ========== أمر .حالة السيرفر ==========
@client.on(events.NewMessage(pattern=r'\.حالة السيرفر', outgoing=True))
async def server_status(event):
    import time
    from datetime import datetime
    
    start = time.time()
    await event.edit("🔄 **جاري فحص السيرفر...**")
    end = time.time()
    ping = round((end - start) * 1000)
    
    await event.edit(f"""🖥️ **حالة السيرفر:**

⚡ **سرعة الاستجابة:** {ping}ms
✅ **السيرفر يعمل**
📅 **الوقت:** {datetime.now().strftime('%I:%M:%S %p')}""")


# ========== أمر .اسماء ==========
@client.on(events.NewMessage(pattern=r'\.اسماء', outgoing=True))
async def list_groups(event):
    await event.edit("📋 **جاري جلب أسماء المجموعات...**")
    
    text = "📋 **المجموعات:**\n\n"
    count = 0
    
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            count += 1
            text += f"{count}. {dialog.name}\n"
    
    text += f"\n📊 **العدد:** {count}"
    
    await event.edit(text)