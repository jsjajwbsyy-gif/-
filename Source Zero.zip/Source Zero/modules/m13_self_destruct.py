import os
from asyncio import sleep
from datetime import datetime
from telethon import events

from main import client

self_destruct_enabled = True


# ==================== عرض قائمة الأوامر (.م13) ====================
@client.on(events.NewMessage(pattern=r'\.م13', outgoing=True))
async def show_self_menu(event):
    menu_text = """⟪───── أوامر الذاتية والإعلانات ─────⟫

│ `.تفعيل الذاتية`
│ ← تفعيل الحفظ التلقائي للصور الذاتية المؤقتة

│ `.تعطيل الذاتية`
│ ← تعطيل الحفظ التلقائي للصور الذاتية

│ `.ذاتية`
│ ← حفظ صورة ذاتية يدوياً (بالرد على الصورة)

│ `.مقيد`
│ ← حفظ محتوى من قنوات مقيدة (بالرد)

│ `.اعلان` + وقت + نص
│ ← إرسال إعلان مؤقت يتحذف تلقائياً
│ ← مثال: .اعلان 5 هذا إعلان مؤقت

│ `.حالة الذاتية`
│ ← معرفة حالة الذاتية (مفعل/معطل)
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== 1. أمر تفعيل الذاتية ====================
@client.on(events.NewMessage(pattern=r'\.تفعيل الذاتية$', outgoing=True))
async def enable_self_destruct(event):
    global self_destruct_enabled
    if self_destruct_enabled:
        await event.edit("⌔ **حفظ الذاتية التلقائي مفعل مسبقاً**")
    else:
        self_destruct_enabled = True
        await event.edit("✓ **تم تفعيل حفظ الذاتية التلقائي بنجاح**")


# ==================== 2. أمر تعطيل الذاتية ====================
@client.on(events.NewMessage(pattern=r'\.تعطيل الذاتية$', outgoing=True))
async def disable_self_destruct(event):
    global self_destruct_enabled
    if not self_destruct_enabled:
        await event.edit("⌔ **حفظ الذاتية التلقائي معطل مسبقاً**")
    else:
        self_destruct_enabled = False
        await event.edit("✘ **تم تعطيل حفظ الذاتية التلقائي بنجاح**")


# ==================== 3. أمر الذاتية اليدوي ====================
@client.on(events.NewMessage(pattern=r'\.ذاتية$', outgoing=True))
async def manual_self_destruct(event):
    if not event.is_reply:
        await event.edit("✘ **يرجى الرد على صورة أو فيديو ذاتي التدمير**")
        return
    
    reply = await event.get_reply_message()
    
    if not (reply.photo or reply.video):
        await event.edit("✘ **يرجى الرد على صورة أو فيديو فقط**")
        return
    
    await event.edit("⎙ **جاري حفظ الذاتية...**")
    
    try:
        me = await client.get_me()
        pic = await reply.download_media()
        await client.send_file(me.id, pic, caption=f"⌔ **تم حفظ الذاتية يدوياً**\n⌔ **الوقت:** {datetime.now().strftime('%I:%M %p')}")
        await event.edit("✓ **تم حفظ الذاتية في المحفوظات بنجاح**")
    except Exception as e:
        await event.edit(f"✘ **فشل الحفظ:** {str(e)}")


# ==================== 4. أمر .مقيد (حفظ من قنوات مقيدة) ====================
@client.on(events.NewMessage(pattern=r'\.مقيد$', outgoing=True))
async def save_restricted_content(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ **يرجى الرد على رسالة من قناة مقيدة**")
        return
    
    await event.edit("⎙ **جاري حفظ المحتوى...**")
    
    try:
        me = await client.get_me()
        
        if reply.photo:
            await client.send_file(me.id, reply.photo, caption=f"⌔ **تم الحفظ من قناة مقيدة**")
            await event.edit("✓ **تم حفظ الصورة في المحفوظات**")
        
        elif reply.video:
            await client.send_file(me.id, reply.video, caption=f"⌔ **تم الحفظ من قناة مقيدة**")
            await event.edit("✓ **تم حفظ الفيديو في المحفوظات**")
        
        elif reply.document:
            await client.send_file(me.id, reply.document, caption=f"⌔ **تم الحفظ من قناة مقيدة**")
            await event.edit("✓ **تم حفظ الملف في المحفوظات**")
        
        else:
            await event.edit("✘ **الرسالة لا تحتوي على صورة أو فيديو أو ملف**")
            
    except Exception as e:
        await event.edit(f"✘ **فشل الحفظ:** {str(e)}")


# ==================== 5. أمر .اعلان (إعلان مؤقت) ====================
@client.on(events.NewMessage(pattern=r'\.اعلان\s+(\d+)\s+([\s\S]+)', outgoing=True))
async def temporary_ad(event):
    try:
        ttl = int(event.pattern_match.group(1))
        message = event.pattern_match.group(2).strip()
    except:
        await event.edit("✘ **يرجى إدخال الوقت والرسالة بشكل صحيح**\n⌔ **مثال:** `.اعلان 5 هذا إعلان مؤقت`")
        return
    
    wait_time = ttl * 60
    
    await event.delete()
    
    ad_text = f"{message}\n\n⌔ **هذا الإعلان سيتم حذفه تلقائياً بعد {ttl} دقائق**"
    smsg = await client.send_message(event.chat_id, ad_text)
    
    await sleep(wait_time)
    try:
        await smsg.delete()
    except:
        pass


# ==================== 6. أمر .حالة الذاتية ====================
@client.on(events.NewMessage(pattern=r'\.حالة الذاتية$', outgoing=True))
async def self_destruct_status(event):
    if self_destruct_enabled:
        await event.edit("✓ **حفظ الذاتية التلقائي مفعل حالياً**")
    else:
        await event.edit("✘ **حفظ الذاتية التلقائي معطل حالياً**")


# ==================== الحفظ التلقائي للذاتية (منقولة من ريبثون) ====================
@client.on(events.NewMessage(incoming=True))
async def auto_save_self_destruct(event):
    global self_destruct_enabled
    
    if not event.is_private:
        return
    
    if not self_destruct_enabled:
        return
    
    my_id = (await client.get_me()).id
    sender_id = event.sender_id
    
    if sender_id == my_id:
        return
    
    try:
        sender = await event.get_sender()
    except:
        return
    
    if not (event.photo or event.video):
        return
    
    # التحقق مما إذا كانت الوسائط ذاتية التدمير
    is_self_destruct = False
    if hasattr(event.media, 'ttl_seconds') and event.media.ttl_seconds:
        is_self_destruct = True
    
    if not is_self_destruct:
        return
    
    try:
        pic = await event.download_media()
        sender_name = sender.first_name or ""
        if sender.last_name:
            sender_name += f" {sender.last_name}"
        
        caption = f"""⌔ **تم حفظ الذاتية تلقائياً**

⦁ **المرسل:** {sender_name}
⦁ **اليوزر:** @{sender.username if sender.username else 'بدون'}
⦁ **الوقت:** {datetime.now().strftime('%I:%M %p')}"""
        
        await client.send_file(my_id, pic, caption=caption)
        
    except Exception:
        pass