import os
import re
import urllib
import asyncio
import PIL
import requests
from bs4 import BeautifulSoup
from PIL import Image, ImageDraw, ImageFont
from telethon import events

from main import client

# ==================== عرض قائمة الأوامر (.م53) ====================
@client.on(events.NewMessage(pattern=r'\.م52', outgoing=True))
async def show_logo_menu(event):
    menu_text = """⟪───── أوامر صنع اللوجوهات ─────⟫

│ `.لوجو` + نص
│ ← صنع لوجو على شكل صورة

│ `.لوجو_ملصق` + نص
│ ← صنع لوجو على شكل ملصق شفاف

◈ أوامر تخصيص اللوجو:

│ `.خلفية_لوجو` + اسم/لون
│ ← تغيير خلفية اللوجو

│ `.خلفية_لوجو_مخصص` + رابط
│ ← تعيين خلفية مخصصة (رابط أو بالرد)

│ `.خط_لوجو` + اسم الخط
│ ← تغيير نوع خط اللوجو

│ `.لون_لوجو` + اسم اللون
│ ← تغيير لون النص

│ `.حجم_لوجو` + رقم
│ ← تغيير حجم الخط (1-1000)

│ `.موقع_لوجو` + رقمين
│ ← تغيير موقع النص (عرض ارتفاع)
│ ← مثال: .موقع_لوجو 2 2

│ `.ظل_لوجو` + رقم
│ ← تغيير سمك الظل

│ `.لون_ظل_لوجو` + لون
│ ← تغيير لون الظل

◈ إدارة الإعدادات:

│ `.عرض_اعداد_لوجو`
│ ← عرض جميع الإعدادات الحالية

│ `.حذف_اعداد_لوجو`
│ ← إعادة جميع الإعدادات للوضع الافتراضي
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== دوال مساعدة ====================

def get_logo_setting(key, default):
    try:
        with open("logo_settings.txt", "r") as f:
            for line in f:
                if line.startswith(key + "="):
                    return line.split("=", 1)[1].strip()
    except:
        pass
    return default


def save_logo_setting(key, value):
    settings = {}
    try:
        with open("logo_settings.txt", "r") as f:
            for line in f:
                if "=" in line:
                    k, v = line.split("=", 1)
                    settings[k.strip()] = v.strip()
    except:
        pass
    settings[key] = str(value)
    with open("logo_settings.txt", "w") as f:
        for k, v in settings.items():
            f.write(f"{k}={v}\n")


def delete_logo_setting(key):
    settings = {}
    try:
        with open("logo_settings.txt", "r") as f:
            for line in f:
                if "=" in line:
                    k, v = line.split("=", 1)
                    settings[k.strip()] = v.strip()
    except:
        pass
    if key in settings:
        del settings[key]
    with open("logo_settings.txt", "w") as f:
        for k, v in settings.items():
            f.write(f"{k}={v}\n")


# ==================== أمر .لوجو ====================
@client.on(events.NewMessage(pattern=r'\.لوجو\s+([\s\S]+)', outgoing=True))
async def make_logo(event):
    text = event.pattern_match.group(1).strip()
    cmd = "logo"
    await create_logo(event, text, cmd)


# ==================== أمر .لوجو_ملصق ====================
@client.on(events.NewMessage(pattern=r'\.لوجو_ملصق\s+([\s\S]+)', outgoing=True))
async def make_logo_sticker(event):
    text = event.pattern_match.group(1).strip()
    cmd = "sticker"
    await create_logo(event, text, cmd)


# ==================== دالة صنع اللوجو ====================
async def create_logo(event, text, cmd):
    await event.edit("⎙ **جاري صنع اللوجو...**")

    font_size = int(get_logo_setting("LOGO_FONT_SIZE", "220"))
    font_width = float(get_logo_setting("LOGO_FONT_WIDTH", "2"))
    font_height = float(get_logo_setting("LOGO_FONT_HEIGHT", "2"))
    font_color = get_logo_setting("LOGO_FONT_COLOR", "red")
    stroke_width = int(get_logo_setting("LOGO_FONT_STROKE_WIDTH", "0"))
    stroke_color = get_logo_setting("LOGO_FONT_STROKE_COLOR", None)
    background = get_logo_setting("LOGO_BACKGROUND", "https://raw.githubusercontent.com/Jisan09/Files/main/backgroud/black.jpg")
    font_url = get_logo_setting("LOGO_FONT", "https://github.com/Jisan09/Files/blob/main/fonts/Streamster.ttf?raw=true")

    if not os.path.isdir("./temp"):
        os.mkdir("./temp")

    if not os.path.exists("temp/bg_img.jpg"):
        try:
            urllib.request.urlretrieve(background, "temp/bg_img.jpg")
        except:
            await event.edit("✘ **فشل تحميل الخلفية**")
            return

    img = Image.open("./temp/bg_img.jpg")
    draw = ImageDraw.Draw(img)

    if not os.path.exists("temp/logo.ttf"):
        try:
            urllib.request.urlretrieve(font_url, "temp/logo.ttf")
        except:
            await event.edit("✘ **فشل تحميل الخط**")
            return

    font = ImageFont.truetype("temp/logo.ttf", font_size)
    image_width, image_height = img.size
    w, h = draw.textsize(text, font=font)
    h += int(h * 0.21)

    try:
        draw.text(
            ((image_width - w) / font_width, (image_height - h) / font_height),
            text,
            font=font,
            fill=font_color,
            stroke_width=stroke_width,
            stroke_fill=stroke_color if stroke_width > 0 else None,
        )
    except:
        draw.text(
            ((image_width - w) / font_width, (image_height - h) / font_height),
            text,
            font=font,
            fill=font_color,
            stroke_width=0,
        )

    file_name = "logo_output.png"
    img.save(file_name, "png")

    if cmd == "logo":
        await event.client.send_file(event.chat_id, file_name, reply_to=event.message.id)
    elif cmd == "sticker":
        await event.client.send_file(event.chat_id, file_name, force_document=True, reply_to=event.message.id)

    await event.delete()
    if os.path.exists(file_name):
        os.remove(file_name)


# ==================== أمر .خلفية_لوجو ====================
@client.on(events.NewMessage(pattern=r'\.خلفية_لوجو\s+([\s\S]+)', outgoing=True))
async def set_logo_bg(event):
    input_str = event.pattern_match.group(1).strip()

    try:
        source = requests.get("https://github.com/Jisan09/Files/tree/main/backgroud")
        soup = BeautifulSoup(source.text, features="html.parser")
        links = soup.find_all("a", class_="js-navigation-open Link--primary")
        bg_names = [os.path.splitext(each.text)[0] for each in links]

        if input_str in bg_names:
            string = f"https://raw.githubusercontent.com/Jisan09/Files/main/backgroud/{input_str}.jpg"
            save_logo_setting("LOGO_BACKGROUND", string)
            if os.path.exists("./temp/bg_img.jpg"):
                os.remove("./temp/bg_img.jpg")
            await event.edit(f"✓ **تم تغيير خلفية اللوجو إلى:** `{input_str}`")
        else:
            bg_list = "⌔ **الخلفيات المتاحة:**\n\n"
            for i, name in enumerate(bg_names, 1):
                bg_list += f"⦁ {i}. `{name}`\n"
            await event.edit(bg_list)
    except:
        save_logo_setting("LOGO_BACKGROUND", input_str)
        await event.edit(f"✓ **تم تعيين الخلفية إلى:** `{input_str}`")


# ==================== أمر .خلفية_لوجو_مخصص ====================
@client.on(events.NewMessage(pattern=r'\.خلفية_لوجو_مخصص(?:\s+([\s\S]+))?', outgoing=True))
async def set_logo_custom_bg(event):
    input_str = event.pattern_match.group(1)
    reply = await event.get_reply_message()

    if reply and reply.media:
        await reply.download_media("./temp/bg_img.jpg")
        save_logo_setting("LOGO_BACKGROUND", "./temp/bg_img.jpg")
        await event.edit("✓ **تم تعيين الصورة كخلفية للوجو**")
    elif input_str and input_str.startswith("https://"):
        save_logo_setting("LOGO_BACKGROUND", input_str)
        if os.path.exists("./temp/bg_img.jpg"):
            os.remove("./temp/bg_img.jpg")
        await event.edit(f"✓ **تم تعيين رابط الخلفية إلى:** `{input_str}`")
    else:
        await event.edit("✘ **يرجى الرد على صورة أو وضع رابط صورة**")


# ==================== أمر .خط_لوجو ====================
@client.on(events.NewMessage(pattern=r'\.خط_لوجو\s+([\s\S]+)', outgoing=True))
async def set_logo_font(event):
    input_str = event.pattern_match.group(1).strip()

    try:
        source = requests.get("https://github.com/Jisan09/Files/tree/main/fonts")
        soup = BeautifulSoup(source.text, features="html.parser")
        links = soup.find_all("a", class_="js-navigation-open Link--primary")
        font_names = [os.path.splitext(each.text)[0] for each in links]

        if input_str in font_names:
            if " " in input_str:
                input_str = input_str.replace(" ", "%20")
            string = f"https://github.com/Jisan09/Files/blob/main/fonts/{input_str}.ttf?raw=true"
            save_logo_setting("LOGO_FONT", string)
            if os.path.exists("temp/logo.ttf"):
                os.remove("temp/logo.ttf")
            await event.edit(f"✓ **تم تغيير خط اللوجو إلى:** `{input_str}`")
        else:
            font_list = "⌔ **الخطوط المتاحة:**\n\n"
            for i, name in enumerate(font_names, 1):
                font_list += f"⦁ {i}. `{name}`\n"
            await event.edit(font_list)
    except:
        save_logo_setting("LOGO_FONT", input_str)
        await event.edit(f"✓ **تم تعيين الخط إلى:** `{input_str}`")


# ==================== أمر .لون_لوجو ====================
@client.on(events.NewMessage(pattern=r'\.لون_لوجو\s+([\s\S]+)', outgoing=True))
async def set_logo_font_color(event):
    input_str = event.pattern_match.group(1).strip()

    try:
        color_names = list(PIL.ImageColor.colormap.keys())
        if input_str in color_names:
            save_logo_setting("LOGO_FONT_COLOR", input_str)
            await event.edit(f"✓ **تم تغيير لون اللوجو إلى:** `{input_str}`")
        else:
            await event.edit(f"✘ **اللون غير صالح:** `{input_str}`\n⌔ **مثال:** `red`, `blue`, `white`, `black`")
    except:
        save_logo_setting("LOGO_FONT_COLOR", input_str)
        await event.edit(f"✓ **تم تعيين اللون إلى:** `{input_str}`")


# ==================== أمر .حجم_لوجو ====================
@client.on(events.NewMessage(pattern=r'\.حجم_لوجو\s+(\d+)', outgoing=True))
async def set_logo_font_size(event):
    size = int(event.pattern_match.group(1).strip())

    if 1 <= size <= 1000:
        save_logo_setting("LOGO_FONT_SIZE", str(size))
        await event.edit(f"✓ **تم تغيير حجم الخط إلى:** `{size}`")
    else:
        await event.edit("✘ **الحجم يجب أن يكون بين 1 و 1000**")


# ==================== أمر .موقع_لوجو ====================
@client.on(events.NewMessage(pattern=r'\.موقع_لوجو\s+(\d+)\s+(\d+)', outgoing=True))
async def set_logo_position(event):
    width = float(event.pattern_match.group(1).strip())
    height = float(event.pattern_match.group(2).strip())

    if 1 <= width <= 100 and 1 <= height <= 100:
        save_logo_setting("LOGO_FONT_WIDTH", str(width))
        save_logo_setting("LOGO_FONT_HEIGHT", str(height))
        await event.edit(f"✓ **تم تغيير موقع النص:** العرض `{width}` - الارتفاع `{height}`")
    else:
        await event.edit("✘ **القيم يجب أن تكون بين 1 و 100**")


# ==================== أمر .ظل_لوجو ====================
@client.on(events.NewMessage(pattern=r'\.ظل_لوجو\s+(\d+)', outgoing=True))
async def set_logo_stroke_width(event):
    width = int(event.pattern_match.group(1).strip())

    if 0 <= width <= 100:
        save_logo_setting("LOGO_FONT_STROKE_WIDTH", str(width))
        await event.edit(f"✓ **تم تغيير سمك الظل إلى:** `{width}`")
    else:
        await event.edit("✘ **القيمة يجب أن تكون بين 0 و 100**")


# ==================== أمر .لون_ظل_لوجو ====================
@client.on(events.NewMessage(pattern=r'\.لون_ظل_لوجو\s+([\s\S]+)', outgoing=True))
async def set_logo_stroke_color(event):
    input_str = event.pattern_match.group(1).strip()

    try:
        color_names = list(PIL.ImageColor.colormap.keys())
        if input_str in color_names:
            save_logo_setting("LOGO_FONT_STROKE_COLOR", input_str)
            await event.edit(f"✓ **تم تغيير لون الظل إلى:** `{input_str}`")
        else:
            await event.edit(f"✘ **اللون غير صالح:** `{input_str}`\n⌔ **مثال:** `red`, `blue`, `white`, `black`")
    except:
        save_logo_setting("LOGO_FONT_STROKE_COLOR", input_str)
        await event.edit(f"✓ **تم تعيين لون الظل إلى:** `{input_str}`")


# ==================== أمر .عرض_اعداد_لوجو ====================
@client.on(events.NewMessage(pattern=r'\.عرض_اعداد_لوجو', outgoing=True))
async def show_logo_settings(event):
    settings = {}
    try:
        with open("logo_settings.txt", "r") as f:
            for line in f:
                if "=" in line:
                    k, v = line.split("=", 1)
                    settings[k.strip()] = v.strip()
    except:
        pass

    if settings:
        text = "◈ **إعدادات اللوجو الحالية:**\n\n"
        for k, v in settings.items():
            text += f"⦁ **{k}:** `{v[:50]}...`\n" if len(str(v)) > 50 else f"⦁ **{k}:** `{v}`\n"
        await event.edit(text)
    else:
        await event.edit("✘ **لا توجد إعدادات مخصصة. جميع القيم افتراضية.**")


# ==================== أمر .حذف_اعداد_لوجو ====================
@client.on(events.NewMessage(pattern=r'\.حذف_اعداد_لوجو', outgoing=True))
async def reset_logo_settings(event):
    if os.path.exists("logo_settings.txt"):
        os.remove("logo_settings.txt")
    if os.path.exists("./temp/bg_img.jpg"):
        os.remove("./temp/bg_img.jpg")
    if os.path.exists("./temp/logo.ttf"):
        os.remove("./temp/logo.ttf")
    await event.edit("⌫ **تم حذف جميع إعدادات اللوجو والعودة للقيم الافتراضية**")