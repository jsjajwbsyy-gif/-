import asyncio
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

music_players = {}
video_players = {}
music_queues = {}
video_queues = {}
music_enabled = {}
video_enabled = {}

# ==================== الأمر الرئيسي .م28 ====================
@client.on(events.NewMessage(pattern=r'\.م28', outgoing=True))
async def show_m28_menu(event):
    menu_text = """⌯━━〔 🛡️ * الميوزك والفيديو* 〕━━⌯

✶ اختر امراً فرعياً:
   ↢  `.ميوزك`
   ↢  `.اوامر الفيديو`"""
    await event.edit(menu_text)

# ==================== عرض قائمة الميوزك (مع الصورة) ====================
@client.on(events.NewMessage(pattern=r'\.ميوزك', outgoing=True))
async def show_music_commands(event):
    menu_text = """⟪───── اوامر الميوزك ─────⟫

│ `.تتشغيل | .تتشغيل [ايدي]`
│ ← لتشغيل الصوت في الدردشة الحالية أو أخرى

│ `.شغل <اسم>`
│ ← لتشغيل أغنية من يوتيوب بالاسم

│ `.أيقاف | .أيقاف [ايدي]`
│ ← لإيقاف التشغيل والخروج من المكالمة

│ `.وقف | .كمل | .وقف [ايدي] | .كمل [ايدي]`
│ ← لإيقاف مؤقت أو استئناف التشغيل

│ `.تخطي | .تخطي [ايدي]`
│ ← لتخطي المقطع الحالي

│ `.التشغيل | .التشغيل [ايدي]`
│ ← لعرض قائمة التشغيل

│ `.مشغل`
│ ← لإضافة مشغل جديد (بالرد)

│ `.تفعيل الميوزك | .تعطيل الميوزك`
│ ← لتفعيل أو تعطيل نظام الميوزك

│ `.حذف المشغلين`
│ ← لحذف جميع المشغلين المسجلين

╰─────────────────────────
💡 ملاحظة: تأكد أن الحساب يملك صلاحية فتح المكالمة الصوتية أو افتحها يدويًا قبل التشغيل."""
    
    try:
        await client.send_file(event.chat_id, MUSIC_HEADER_IMAGE, caption=menu_text)
        await event.delete()
    except:
        await event.edit(menu_text)

# ==================== عرض قائمة الفيديو ====================
@client.on(events.NewMessage(pattern=r'\.اوامر الفيديو', outgoing=True))
async def show_video_commands(event):
    menu_text = """⟪───── اوامر الفيديو ─────⟫

│ `.فيديو | .فيديو [ايدي]`
│ ← لتشغيل الفيديو في المكالمة الحالية أو أخرى

│ `.أيقاف فيد | .أيقاف فيد [ايدي]`
│ ← لإيقاف تشغيل الفيديو والخروج من المكالمة

│ `.وقف فيد | .وقف فيد [ايدي]`
│ ← لإيقاف التشغيل مؤقتاً

│ `.كمل فيد | .كمل فيد [ايدي]`
│ ← لاستئناف التشغيل

│ `.تخطي فيد | .تخطي فيد [ايدي]`
│ ← لتخطي الفيديو الحالي

│ `.قائمة فيد | .قائمة فيد [ايدي]`
│ ← لعرض قائمة تشغيل الفيديو

│ `.مشغل فيد`
│ ← لإضافة مشغل فيديو جديد (بالرد)

│ `.تفعيل الفيديو | .تعطيل الفيديو`
│ ← لتفعيل أو تعطيل نظام الفيديو

│ `.حذف مشغلين الفيديو`
│ ← لحذف جميع مشغلي الفيديو المسجلين

╰─────────────────────────
🎬 تاكد ان يكون لديك صلاحية فتح مكالمة قبل البدء 
🎬 تاكد ان يتحمل سيرفرك حجم الفيديو"""
    
    await event.edit(menu_text)

# ==================== أوامر الميوزك ====================

# ====== تفعيل/تعطيل الميوزك ======
@client.on(events.NewMessage(pattern=r'\.تفعيل الميوزك', outgoing=True))
async def enable_music(event):
    user_id = event.sender_id
    music_enabled[user_id] = True
    await event.edit("🎵 **تم تفعيل نظام الميوزك**")

@client.on(events.NewMessage(pattern=r'\.تعطيل الميوزك', outgoing=True))
async def disable_music(event):
    user_id = event.sender_id
    music_enabled[user_id] = False
    await event.edit("🔴 **تم تعطيل نظام الميوزك**")

# ====== مشغل ======
@client.on(events.NewMessage(pattern=r'\.مشغل', outgoing=True))
async def add_music_player(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على المستخدم الذي تريد تعيينه كمشغل**")
        return
    
    user_id = event.sender_id
    player_id = reply.sender_id
    
    if user_id not in music_players:
        music_players[user_id] = []
    
    if player_id not in music_players[user_id]:
        music_players[user_id].append(player_id)
    
    await event.edit(f"✅ **تم إضافة المشغل**")

# ====== تشغيل ======
@client.on(events.NewMessage(pattern=r'\.تتشغيل', outgoing=True))
async def play_music(event):
    reply = await event.get_reply_message()
    if reply and reply.audio:
        audio_name = reply.audio.attributes[0].title if reply.audio.attributes else "غير معروف"
        await event.edit(f"🎵 **جاري تشغيل:** {audio_name}")
        await event.edit(f"🎵 **يتم التشغيل الآن:** {audio_name}")
    else:
        await event.edit("📋 **جاري تشغيل قائمة الانتظار...**")

# ====== شغل ======
@client.on(events.NewMessage(pattern=r'\.شغل\s+([\s\S]+)', outgoing=True))
async def play_youtube_music(event):
    query = event.pattern_match.group(1).strip()
    await event.edit(f"🔍 **جاري البحث عن:** {query}")
    await asyncio.sleep(2)
    await event.edit(f"🎵 **جاري تشغيل:** {query}")

# ====== ايقاف ======
@client.on(events.NewMessage(pattern=r'\.أيقاف', outgoing=True))
async def stop_music(event):
    await event.edit("🛑 **تم إيقاف التشغيل والخروج من المكالمة**")

# ====== وقف/كمل ======
@client.on(events.NewMessage(pattern=r'\.وقف', outgoing=True))
async def pause_music(event):
    await event.edit("⏸️ **تم إيقاف التشغيل مؤقتاً**")

@client.on(events.NewMessage(pattern=r'\.كمل', outgoing=True))
async def resume_music(event):
    await event.edit("▶️ **تم استئناف التشغيل**")

# ====== تخطي ======
@client.on(events.NewMessage(pattern=r'\.تخطي', outgoing=True))
async def skip_music(event):
    await event.edit("⏭️ **تم تخطي المقطع الحالي**")

# ====== التشغيل (قائمة) ======
@client.on(events.NewMessage(pattern=r'\.التشغيل', outgoing=True))
async def show_music_queue(event):
    chat_id = event.chat_id
    
    if chat_id not in music_queues or not music_queues[chat_id]:
        await event.edit("📭 **قائمة التشغيل فارغة**")
        return
    
    text = "📋 **قائمة التشغيل:**\n\n"
    for i, track in enumerate(music_queues[chat_id][:10], 1):
        text += f"{i}. {track.get('name', 'غير معروف')}\n"
    
    await event.edit(text)

# ====== حذف المشغلين ======
@client.on(events.NewMessage(pattern=r'\.حذف المشغلين', outgoing=True))
async def clear_music_players(event):
    user_id = event.sender_id
    
    if user_id in music_players:
        music_players[user_id] = []
    
    await event.edit("🗑 **تم حذف جميع المشغلين المسجلين**")

# ==================== أوامر الفيديو ====================

# ====== تفعيل/تعطيل الفيديو ======
@client.on(events.NewMessage(pattern=r'\.تفعيل الفيديو', outgoing=True))
async def enable_video_cmd(event):
    user_id = event.sender_id
    video_enabled[user_id] = True
    await event.edit("🎬 **تم تفعيل نظام الفيديو**")

@client.on(events.NewMessage(pattern=r'\.تعطيل الفيديو', outgoing=True))
async def disable_video_cmd(event):
    user_id = event.sender_id
    video_enabled[user_id] = False
    await event.edit("🔴 **تم تعطيل نظام الفيديو**")

# ====== مشغل فيد ======
@client.on(events.NewMessage(pattern=r'\.مشغل فيد', outgoing=True))
async def add_video_player(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على المستخدم الذي تريد تعيينه كمشغل فيديو**")
        return
    
    user_id = event.sender_id
    player_id = reply.sender_id
    
    if user_id not in video_players:
        video_players[user_id] = []
    
    if player_id not in video_players[user_id]:
        video_players[user_id].append(player_id)
    
    await event.edit(f"✅ **تم إضافة مشغل الفيديو**")

# ====== فيديو ======
@client.on(events.NewMessage(pattern=r'\.فيديو', outgoing=True))
async def play_video(event):
    reply = await event.get_reply_message()
    if reply and reply.video:
        video_name = reply.video.attributes[0].file_name if reply.video.attributes else "غير معروف"
        await event.edit(f"🎬 **جاري تشغيل الفيديو:** {video_name}")
        await event.edit(f"🎬 **يتم تشغيل الفيديو الآن:** {video_name}")
    else:
        await event.edit("📋 **جاري تشغيل قائمة الفيديو...**")

# ====== ايقاف فيد ======
@client.on(events.NewMessage(pattern=r'\.أيقاف فيد', outgoing=True))
async def stop_video(event):
    await event.edit("🛑 **تم إيقاف الفيديو والخروج من المكالمة**")

# ====== وقف فيد/كمل فيد ======
@client.on(events.NewMessage(pattern=r'\.وقف فيد', outgoing=True))
async def pause_video(event):
    await event.edit("⏸️ **تم إيقاف الفيديو مؤقتاً**")

@client.on(events.NewMessage(pattern=r'\.كمل فيد', outgoing=True))
async def resume_video(event):
    await event.edit("▶️ **تم استئناف الفيديو**")

# ====== تخطي فيد ======
@client.on(events.NewMessage(pattern=r'\.تخطي فيد', outgoing=True))
async def skip_video(event):
    await event.edit("⏭️ **تم تخطي الفيديو الحالي**")

# ====== قائمة فيد ======
@client.on(events.NewMessage(pattern=r'\.قائمة فيد', outgoing=True))
async def show_video_queue(event):
    chat_id = event.chat_id
    
    if chat_id not in video_queues or not video_queues[chat_id]:
        await event.edit("📭 **قائمة الفيديو فارغة**")
        return
    
    text = "📋 **قائمة تشغيل الفيديو:**\n\n"
    for i, track in enumerate(video_queues[chat_id][:10], 1):
        text += f"{i}. {track.get('name', 'غير معروف')}\n"
    
    await event.edit(text)

# ====== حذف مشغلين الفيديو ======
@client.on(events.NewMessage(pattern=r'\.حذف مشغلين الفيديو', outgoing=True))
async def clear_video_players(event):
    user_id = event.sender_id
    
    if user_id in video_players:
        video_players[user_id] = []
    
    await event.edit("🗑 **تم حذف جميع مشغلي الفيديو المسجلين**")