import asyncio
from datetime import datetime
from telethon import events
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.errors.rpcerrorlist import YouBlockedUserError
from telethon.tl.functions.contacts import UnblockRequest as unblock
from telethon.tl.functions.channels import GetParticipantRequest

# استيراد المتغيرات من الملف الرئيسي
from main import client

# قائمة المحادثات التي يتم تفليشها حالياً
spam_chats = []
flush_status = {}

# ==================== عرض قائمة الأوامر (.م22) ====================
@client.on(events.NewMessage(pattern=r'\.م22', outgoing=True))
async def show_flush_menu(event):
    menu_text = """⟪───── أوامر التفليش ─────⟫

│ `.فلش`
│ ← يبدأ عملية تفليش الأعضاء (إزالتهم من المجموعة)
│ ← مثال: .فلش

│ `.تفليش بالبوت`
│ ← يستخدم صلاحيات البوت للتفليش

│ `.ايقاف التفليش`
│ ← لإيقاف أي عملية تفليش جارية

│ `.حالة التفليش`
│ ← عرض حالة التفليش الجاري

ملاحظة:  
↢ تحتاج لصلاحية "الإشراف + الحظر" لاستخدام .فلش  
↢ أما .تفليش بالبوت فتحتاج فقط رتبة في بوت المجموعة

 اوامر الاضافة والحالة :
 ─ ──────
│ `.ضيف + الرابط`
│ ← لإضافة رابط داخل مجموعتك

│ `.حالتي`
│ ← لمعرفة حالة حسابك (محدود أو لا)

│ `.بوتي`
│ ← لمعرفة معرف البوت المساعد الخاص بك

ملاحظة: الأوامر تعمل فقط مع الأعضاء الظاهريين
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== 1. أمر .فلش ====================
@client.on(events.NewMessage(pattern=r'\.فلش', outgoing=True))
async def flush_members(event):
    chat_id = event.chat_id
    user_id = event.sender_id
    
    if not event.is_group:
        await event.edit("✘ **هذا الأمر يعمل فقط في المجموعات**")
        return
    
    try:
        participant = await client.get_permissions(chat_id, user_id)
        if not participant.is_admin or not participant.ban_users:
            await event.edit("✘ **تحتاج صلاحية الحظر لاستخدام هذا الأمر**")
            return
    except:
        await event.edit("✘ **تحتاج صلاحية الإشراف لاستخدام هذا الأمر**")
        return
    
    await event.edit("♞ **بدء عملية تفليش الأعضاء...**\n\n⎙ *قد تستغرق العملية بعض الوقت*")
    
    flush_status[chat_id] = {
        "active": True,
        "type": "manual",
        "count": 0,
        "start_time": datetime.now()
    }
    
    asyncio.create_task(flush_members_manual(chat_id, event))

async def flush_members_manual(chat_id, event):
    count = 0
    failed = 0
    
    try:
        async for user in client.iter_participants(chat_id):
            if not flush_status.get(chat_id, {}).get("active", False):
                break
            
            if user.bot:
                continue
            
            try:
                participant = await client.get_permissions(chat_id, user.id)
                if participant.is_admin or participant.is_creator:
                    continue
            except:
                pass
            
            try:
                await client.kick_participant(chat_id, user.id)
                count += 1
                flush_status[chat_id]["count"] = count
                
                if count % 5 == 0:
                    try:
                        await event.edit(f"⎙ **جاري التفليش...**\n\n✓ **تم:** {count}\n✘ **فشل:** {failed}")
                    except:
                        pass
                
                await asyncio.sleep(0.5)
                
            except Exception as e:
                failed += 1
                await asyncio.sleep(0.3)
        
        final_text = f"""✓ **تم التفليش بنجاح**

⌔ **الإحصائيات:**
⦿ **تم التفليش:** {count} عضو
⦿ **فشل:** {failed}
⦿ **الوقت:** {datetime.now().strftime('%I:%M %p')}"""
        
        await event.edit(final_text)
        
    except Exception as e:
        await event.edit(f"✘ **توقف التفليش:** {str(e)}")
    
    finally:
        if chat_id in flush_status:
            flush_status[chat_id]["active"] = False


# ==================== 2. أمر .تفليش بالبوت ====================
@client.on(events.NewMessage(pattern=r'\.تفليش بالبوت', outgoing=True))
async def flush_with_bot(event):
    chat_id = event.chat_id
    me = await client.get_me()
    
    if not event.is_group:
        await event.edit("✘ **هذا الأمر يعمل فقط في المجموعات**")
        return
    
    try:
        bot_participant = await client.get_permissions(chat_id, me.id)
        if not bot_participant.is_admin or not bot_participant.ban_users:
            await event.edit("✘ **البوت لا يملك صلاحية الحظر في هذه المجموعة**")
            return
    except:
        await event.edit("✘ **البوت ليس مشرفاً في هذه المجموعة**")
        return
    
    await event.edit("♞ **بدء التفليش باستخدام صلاحيات البوت...**\n\n⎙ *قد تستغرق العملية بعض الوقت*")
    
    flush_status[chat_id] = {
        "active": True,
        "type": "bot",
        "count": 0,
        "start_time": datetime.now()
    }
    
    asyncio.create_task(flush_members_with_bot(chat_id, event))

async def flush_members_with_bot(chat_id, event):
    count = 0
    failed = 0
    
    try:
        async for user in client.iter_participants(chat_id):
            if not flush_status.get(chat_id, {}).get("active", False):
                break
            
            if user.bot:
                continue
            
            try:
                participant = await client.get_permissions(chat_id, user.id)
                if participant.is_admin or participant.is_creator:
                    continue
            except:
                pass
            
            try:
                await client.kick_participant(chat_id, user.id)
                count += 1
                flush_status[chat_id]["count"] = count
                
                if count % 10 == 0:
                    try:
                        await event.edit(f"⎙ **جاري التفليش بالبوت...**\n\n✓ **تم:** {count}\n✘ **فشل:** {failed}")
                    except:
                        pass
                
                await asyncio.sleep(0.3)
                
            except Exception as e:
                failed += 1
                await asyncio.sleep(0.2)
        
        final_text = f"""✓ **تم التفليش بالبوت بنجاح**

⌔ **الإحصائيات:**
⦿ **تم التفليش:** {count} عضو
⦿ **فشل:** {failed}
⦿ **الوقت:** {datetime.now().strftime('%I:%M %p')}"""
        
        await event.edit(final_text)
        
    except Exception as e:
        await event.edit(f"✘ **توقف التفليش:** {str(e)}")
    
    finally:
        if chat_id in flush_status:
            flush_status[chat_id]["active"] = False


# ==================== 3. أمر .ايقاف التفليش ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف التفليش', outgoing=True))
async def stop_flush(event):
    chat_id = event.chat_id
    
    if chat_id in flush_status and flush_status[chat_id].get("active", False):
        flush_status[chat_id]["active"] = False
        
        count = flush_status[chat_id].get("count", 0)
        flush_type = flush_status[chat_id].get("type", "manual")
        
        await event.edit(
            f"✘ **تم إيقاف التفليش**\n\n"
            f"⌔ **تم تفليش:** {count} عضو\n"
            f"◈ **النوع:** {'يدوي' if flush_type == 'manual' else 'بالبوت'}"
        )
    else:
        await event.edit("✘ **لا توجد عملية تفليش جارية**")


# ==================== 4. أمر .ضيف ====================
@client.on(events.NewMessage(pattern=r'\.ضيف\s+(\S+)', outgoing=True))
async def add_members_from_link(event):
    link = event.pattern_match.group(1).strip()
    chat_id = event.chat_id
    
    if not event.is_group:
        await event.edit("✘ **هذا الأمر يعمل فقط في المجموعات**")
        return
    
    await event.edit("⎙ **جاري إضافة الأعضاء الظاهريين...**")
    
    try:
        if "t.me/" in link:
            if "joinchat" in link:
                invite_hash = link.split("/")[-1]
            elif "+" in link:
                invite_hash = link.split("+")[-1]
            else:
                invite_hash = link.split("/")[-1]
        else:
            invite_hash = link
        
        try:
            await client(ImportChatInviteRequest(invite_hash))
            await event.edit(f"✓ **تم الانضمام إلى المجموعة بنجاح**")
        except Exception as e:
            if "USER_ALREADY_PARTICIPANT" in str(e):
                await event.edit("⌔ **أنت بالفعل عضو في هذه المجموعة**")
            else:
                await event.edit(f"✘ **فشل الانضمام:** {str(e)}")
                
    except Exception as e:
        await event.edit(f"✘ **خطأ في الرابط:** {str(e)}")


# ==================== 5. أمر .حالة التفليش ====================
@client.on(events.NewMessage(pattern=r'\.حالة التفليش', outgoing=True))
async def flush_status_cmd(event):
    chat_id = event.chat_id
    
    if chat_id not in flush_status or not flush_status[chat_id].get("active", False):
        await event.edit("✘ **لا توجد عملية تفليش جارية**")
        return
    
    status = flush_status[chat_id]
    
    count = status.get("count", 0)
    flush_type = "يدوي" if status.get("type") == "manual" else "بالبوت"
    start_time = status.get("start_time", datetime.now())
    
    elapsed = datetime.now() - start_time
    minutes = elapsed.seconds // 60
    seconds = elapsed.seconds % 60
    
    status_text = f"""◈ **حالة التفليش الحالية:**

⌔ **النوع:** {flush_type}
✓ **تم التفليش:** {count} عضو
⏱️ **الوقت المنقضي:** {minutes:02d}:{seconds:02d}

⦁ **لإيقاف التفليش:** `.ايقاف التفليش`"""
    
    await event.edit(status_text)


# ==================== 6. أمر .الظاهريين ====================
@client.on(events.NewMessage(pattern=r'\.الظاهريين', outgoing=True))
async def list_virtual_members(event):
    if not virtual_members:
        await event.edit("✘ **لا يوجد أعضاء ظاهريين متاحين حالياً**\n\n⦁ **لإضافة عضو ظاهري:** `.اضف ظاهري + @اليوزر`")
        return
    
    text = f"⌔ **الأعضاء الظاهريين المتاحين ({len(virtual_members)}):**\n\n"
    
    for i, member in enumerate(virtual_members[:20], 1):
        text += f"⦁ {i}. {member}\n"
    
    if len(virtual_members) > 20:
        text += f"\n⦁ ... و {len(virtual_members) - 20} عضو آخر"
    
    await event.edit(text)


# ==================== 7. أمر .اضف ظاهري ====================
@client.on(events.NewMessage(pattern=r'\.اضف ظاهري\s+(@\w+)', outgoing=True))
async def add_virtual_member(event):
    username = event.pattern_match.group(1).strip()
    
    if username in virtual_members:
        await event.edit(f"✘ **العضو {username} موجود بالفعل في القائمة**")
        return
    
    virtual_members.append(username)
    await event.edit(f"✓ **تم إضافة العضو الظاهري:** {username}")


# ==================== 8. أمر .حذف ظاهري ====================
@client.on(events.NewMessage(pattern=r'\.حذف ظاهري\s+(@\w+)', outgoing=True))
async def remove_virtual_member(event):
    username = event.pattern_match.group(1).strip()
    
    if username in virtual_members:
        virtual_members.remove(username)
        await event.edit(f"✓ **تم حذف العضو الظاهري:** {username}")
    else:
        await event.edit(f"✘ **العضو {username} غير موجود في القائمة**")


# ==================== 9. أمر .حالتي (مضاف من ريبثون) ====================
@client.on(events.NewMessage(pattern=r'\.حالتي ?(.*)', outgoing=True))
async def check_my_status(event):
    await event.edit("⎙ **جـارِ التحقـق من حالة حسابك، انتظـر قليـلاً . . .**")
    async with client.conversation("@SpamBot") as conv:
        try:
            dontTag = conv.wait_event(events.NewMessage(incoming=True, from_users=178220800))
            await conv.send_message("/start")
            dontTag = await dontTag
            await client.send_read_acknowledge(conv.chat_id)
        except YouBlockedUserError:
            await client(unblock("SpamBot"))
            dontTag = conv.wait_event(events.NewMessage(incoming=True, from_users=178220800))
            await conv.send_message("/start")
            dontTag = await dontTag
            await client.send_read_acknowledge(conv.chat_id)
        await event.edit(f"⌔ **حالة حسابـك حاليـاً هـي :**\n\n~ {dontTag.message.message}")


# ==================== 10. أمر .بوتي (مضاف من ريبثون) ====================
@client.on(events.NewMessage(pattern=r'\.بوتي$', outgoing=True))
async def show_my_bot(event):
    # تحتاج إلى تعيين معرف البوت المساعد في ملف الإعدادات
    try:
        from main import TG_BOT_USERNAME
        await event.edit(f"⌔ **البـوت المسـاعد الخـاص بك هـو** \n {TG_BOT_USERNAME}")
    except ImportError:
        await event.edit("✘ **لم يتم تعيين بوت مساعد. الرجاء إضافة `TG_BOT_USERNAME` في ملف الإعدادات.**")