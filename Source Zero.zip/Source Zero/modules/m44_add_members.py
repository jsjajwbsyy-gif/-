import asyncio
from telethon import events
from telethon.errors import (
    ChannelInvalidError,
    ChannelPrivateError,
    ChannelPublicGroupNaError,
)
from telethon.tl import functions
from telethon.tl.functions.channels import GetFullChannelRequest
from telethon.tl.functions.messages import GetFullChatRequest

from main import client

# ========== دوال مساعدة ==========

def make_mention(user):
    """يرجع منشن مع يوزر او اسم + رابط"""
    if user.username:
        return f"@{user.username}"
    else:
        return inline_mention(user)


def inline_mention(user):
    """يرجع اسم + رابط للعضو"""
    full_name = user_full_name(user) or "بدون اسم"
    return f"[{full_name}](tg://user?id={user.id})"


def user_full_name(user):
    """يرجع الاسم الكامل للعضو"""
    names = [user.first_name, user.last_name]
    names = [i for i in list(names) if i]
    full_name = " ".join(names)
    return full_name


async def get_chatinfo(event):
    """جلب معلومات المجموعة مع معالجة جميع الاخطاء"""
    chat = event.pattern_match.group(1)
    chat_info = None

    if chat:
        try:
            chat = int(chat)
        except ValueError:
            pass

    if not chat:
        if event.reply_to_msg_id:
            replied_msg = await event.get_reply_message()
            if replied_msg.fwd_from and replied_msg.fwd_from.channel_id is not None:
                chat = replied_msg.fwd_from.channel_id
        else:
            chat = event.chat_id

    try:
        chat_info = await event.client(GetFullChatRequest(chat))
    except:
        try:
            chat_info = await event.client(GetFullChannelRequest(chat))
        except ChannelInvalidError:
            await event.edit("**╮ عـذراً ..﮼ لم يتم العثور على المجموعة او القناة 𓅫╰**")
            return None
        except ChannelPrivateError:
            await event.edit(
                "**╮ لا يمكنني استخدام الامر على المجموعات او القنوات الخاصة ...𓅫╰**"
            )
            return None
        except ChannelPublicGroupNaError:
            await event.edit("**╮ عـذراً ..﮼ لم يتم العثور على المجموعة او القناة 𓅫╰**")
            return None
        except (TypeError, ValueError):
            await event.edit("**╮ رابط المجموعـه غير صحيح ..𓅫╰**")
            return None

    return chat_info


# ========== أمر .ضيف ==========
@client.on(events.NewMessage(pattern=r'\.ضيف\s*(.*)', outgoing=True))
async def add_all_members(event):
    """
    \n**الوصف:** اضافة جميع اعضاء مجموعة الى مجموعتك
    \n**الاستخدام:** `.ضيف` او `.ضيف <ايدي المجموعة>` او بالرد على رسالة محولة
    \n**المتطلبات:** صلاحية اضافة اعضاء في المجموعة الحالية
    """
    # جلب معلومات المجموعة المصدر
    REPTHON = await get_chatinfo(event)
    if not REPTHON:
        return

    # جلب معلومات المحادثة الحالية
    chat = await event.get_chat()

    # التحقق ان الامر لم يرسل في الخاص
    if event.is_private:
        await event.edit("**╮ لا استطـيع اضافـة الاعضـاء هـنا 𓅫╰**")
        return

    s = 0  # عداد المضافين بنجاح
    f = 0  # عداد الاخطاء
    error = "لا يوجد"

    await event.edit(
        "**╮ حـالة الإضافـه :**\n\n**╮ جـاري جـمع معـلومات الاعضـاء ...⏳**"
    )

    # المرور على جميع اعضاء المجموعة المصدر
    async for user in event.client.iter_participants(REPTHON.full_chat.id):
        try:
            # ايقاف الاضافة اذا واجهنا حظر مؤقت
            if error.startswith("Too"):
                await event.edit(
                    f"**╮ حـالة الأضـافة انتـهت مـع الأخـطاء**\n"
                    f"**- (ربـما هـنالك ضغـط عـلى الأمࢪ حاول مجددا لاحقـا 🧸)**\n"
                    f"**الـخطأ :** \n`{error}`\n\n"
                    f"• تم اضافـة `{s}`\n"
                    f"• خـطأ بأضافـة `{f}`"
                )
                return

            # محاولة اضافة العضو
            await event.client(
                functions.channels.InviteToChannelRequest(
                    channel=chat,
                    users=[user.id]
                )
            )
            s += 1

            # تحديث الرسالة كل 5 اعضاء
            if s % 5 == 0:
                await event.edit(
                    f"**╮ جـاري الإضـافـه...⧑**\n\n"
                    f"• تـم اضافـة `{s}`\n"
                    f"• خـطأ بإضافـة `{f}`\n\n"
                    f"**× آخـر خـطأ:** `{error}`"
                )

        except Exception as e:
            error = str(e)
            f += 1

    # رسالة النهاية
    await event.edit(
        f"**╮ تـمت الإضافـه بنجـاح ✅**\n\n"
        f"• تـم اضـافة `{s}`\n"
        f"• خـطأ بإضافـة `{f}`"
    )


# ========== أمر .م44 ==========
@client.on(events.NewMessage(pattern=r'\.م44', outgoing=True))
async def show_m44_menu(event):
    menu_text = """⟪───── اوامـر ادارة الاعضـاء ─────⟫

│ `.ضيف`
│ ← لاضافة جميع اعضاء مجموعة الى مجموعتك الحالية

│ `.ضيف` + ايدي المجموعة
│ ← لاضافة اعضاء مجموعة محددة بالرقم

│ `.ضيف` (بالرد على رسالة محولة)
│ ← لاضافة اعضاء المجموعة المحولة منها الرسالة

│ `.صنع`
│ ← (قريباً)

╰─────────────────────────"""
    await event.edit(menu_text)