import asyncio
import google.generativeai as genai
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

ai_settings = {}
user_api_keys = {}

# المتغيرات الجديدة لنظام البوت
DEFAULT_AI_BOT = "@gpt4bot"
bot_ai_settings = {}

# النماذج المتاحة
AVAILABLE_MODELS = [
    "gemini-3-flash-preview",
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    "gemini-2.5-pro-preview-05-06",
]

DEFAULT_MODEL = "gemini-3-flash-preview"

# المفاتيح الاحتياطية
BACKUP_API_KEYS = [
    "AIzaSyC54GREVohBro7RIBAwh3HrIqHySH_wIbM",
    "AIzaSyDtppUt_ns3rxBO9cwJdG7kGa-umC7iuQ8",
    "AIzaSyB0wzGdwT233ppyq984emOvcSZkRFWvzCc",
    "AIzaSyCPK79Os0_tgZ0bE6o9g3YcLky_Pro7u90",
    "AIzaSyDB6DqIsSFuTUIRg2tp26uc5W4wYpXa_Ak",
    "AIzaSyDKVNUjQtOS_ZmwfKcfp9OgF5UW_HMvCE4",
    "AIzaSyCrs2vLIWZy_kbcH4FZzW2zrP7LTU7T7IQ",
    "AIzaSyD4ZVto7JZVT7GP6Ftylgn49XV60bJb9Zc",
    "AIzaSyBeUWYfU7HBUVy-5Vf1YPhu28utW2xw-RE",
    "AIzaSyCmV7AG0Ma7X5hqHIDtth36zcv2w1VNMVU",
    "AIzaSyDLYHKGbcOQD1lvwb_jcgVEWcgQDNSOkT0",
    "AIzaSyAklL7Si70rmTm7AQtqGJtm6eM3GlFUQio",
]

# ==================== عرض قائمة الأوامر (.م2) ====================
@client.on(events.NewMessage(pattern=r'\.م2', outgoing=True))
async def show_m2_menu(event):
    menu_text = """⟪───── أوامر الذكاء الاصطناعي ─────⟫

│ `.مفتاح + API Key`
│ ← لتعيين مفتاح API الخاص بك

│ `.تشغيل الذكاء` | `.تعطيل الذكاء`
│ ← لتفعيل أو تعطيل الردود التلقائية عبر Gemini

│ `.تشغيل البوت` | `.تعطيل البوت`
│ ← لتفعيل أو تعطيل الردود التلقائية عبر بوت الذكاء

│ `.تبديل بوت الذكاء + @اليوزر`
│ ← لتغيير بوت الذكاء الاصطناعي

│ `.ايقاف هنا` | `.تشغيل هنا`
│ ← لتعطيل أو إعادة تشغيل الذكاء في هذه المحادثة

│ `.اسالني مع الاسم` | `.تعطيل اسالني`
│ ← لتفعيل أو تعطيل ميزة اسالني

│ `.تبديل النموذج`
│ ← لتبديل النموذج المستخدم

│ `.تدريب الذكاء`
│ ← بالرد على تعليمات، الذكاء ينفذ طلباتك

│ `.عرض النماذج`
│ ← يعرض لك النماذج المتاحة

╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== أمر .مفتاح ====================
@client.on(events.NewMessage(pattern=r'\.مفتاح\s+([\s\S]+)', outgoing=True))
async def set_api_key(event):
    api_key = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if genai is None:
        await event.edit("❌ **مكتبة الذكاء الاصطناعي غير مثبتة**")
        return
    
    try:
        genai.configure(api_key=api_key)
        user_api_keys[user_id] = api_key
        
        await event.delete()
        confirm = await client.send_message(
            event.chat_id,
            "✅ **تم حفظ مفتاح API بنجاح**\n🤖 *جاهز للاستخدام*\n🔒 *تم حذف الرسالة لحماية بياناتك*"
        )
        await asyncio.sleep(5)
        await confirm.delete()
    except Exception as e:
        await event.edit(f"❌ **المفتاح غير صالح:** {str(e)}")


# ==================== أمر .تشغيل الذكاء (Gemini) ====================
@client.on(events.NewMessage(pattern=r'\.تشغيل الذكاء', outgoing=True))
async def enable_ai(event):
    chat_id = event.chat_id
    if chat_id not in ai_settings:
        ai_settings[chat_id] = {}
    ai_settings[chat_id]["enabled"] = True
    ai_settings[chat_id]["mode"] = "gemini"
    await event.edit("🤖 **تم تفعيل الردود التلقائية عبر Gemini**")


# ==================== أمر .تشغيل البوت (بوت تيليجرام) ====================
@client.on(events.NewMessage(pattern=r'\.تشغيل البوت', outgoing=True))
async def enable_bot_ai(event):
    chat_id = event.chat_id
    if chat_id not in ai_settings:
        ai_settings[chat_id] = {}
    ai_settings[chat_id]["enabled"] = True
    ai_settings[chat_id]["mode"] = "bot"
    await event.edit("🤖 **تم تفعيل الردود التلقائية عبر بوت الذكاء الاصطناعي**")


# ==================== أمر .تعطيل الذكاء ====================
@client.on(events.NewMessage(pattern=r'\.تعطيل الذكاء', outgoing=True))
async def disable_ai(event):
    chat_id = event.chat_id
    if chat_id not in ai_settings:
        ai_settings[chat_id] = {}
    ai_settings[chat_id]["enabled"] = False
    await event.edit("🔴 **تم تعطيل الردود التلقائية**")


# ==================== أمر .تبديل بوت الذكاء ====================
@client.on(events.NewMessage(pattern=r'\.تبديل بوت الذكاء\s+(@\w+)', outgoing=True))
async def switch_ai_bot(event):
    bot_username = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in bot_ai_settings:
        bot_ai_settings[user_id] = {}
    
    bot_ai_settings[user_id]["bot"] = bot_username
    
    await event.edit(f"✅ **تم تغيير بوت الذكاء إلى:** {bot_username}")


# ==================== أمر .ايقاف هنا ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف هنا', outgoing=True))
async def stop_here(event):
    chat_id = event.chat_id
    if chat_id not in ai_settings:
        ai_settings[chat_id] = {}
    ai_settings[chat_id]["chat_enabled"] = False
    await event.edit("⏸️ **تم إيقاف الذكاء في هذه المحادثة**")


# ==================== أمر .تشغيل هنا ====================
@client.on(events.NewMessage(pattern=r'\.تشغيل هنا', outgoing=True))
async def start_here(event):
    chat_id = event.chat_id
    if chat_id not in ai_settings:
        ai_settings[chat_id] = {}
    ai_settings[chat_id]["chat_enabled"] = True
    await event.edit("▶️ **تم تشغيل الذكاء في هذه المحادثة**")


# ==================== أمر .اسالني ====================
@client.on(events.NewMessage(pattern=r'\.اسالني\s+(\w+)', outgoing=True))
async def ask_me_enable(event):
    name = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in ai_settings:
        ai_settings[user_id] = {}
    ai_settings[user_id]["ask_me_name"] = name
    ai_settings[user_id]["ask_me_enabled"] = True
    
    await event.edit(f"✅ **تم تفعيل ميزة اسالني**\n👤 *الاسم:* {name}")


# ==================== أمر .تعطيل اسالني ====================
@client.on(events.NewMessage(pattern=r'\.تعطيل اسالني', outgoing=True))
async def ask_me_disable(event):
    user_id = event.sender_id
    
    if user_id not in ai_settings:
        ai_settings[user_id] = {}
    ai_settings[user_id]["ask_me_enabled"] = False
    
    await event.edit("🔴 **تم تعطيل ميزة اسالني**")


# ==================== أمر .تبديل النموذج ====================
@client.on(events.NewMessage(pattern=r'\.تبديل النموذج(?:\s+(\S+))?', outgoing=True))
async def switch_model(event):
    chat_id = event.chat_id
    model_name = event.pattern_match.group(1)
    
    if not model_name:
        current = ai_settings.get(chat_id, {}).get("model", DEFAULT_MODEL)
        models_list = "\n".join([f"• `{m}`" for m in AVAILABLE_MODELS])
        await event.edit(f"📋 **النموذج الحالي:** `{current}`\n\n**النماذج المتاحة:**\n{models_list}\n\n📌 *استخدم:* `.تبديل النموذج gemini-2.5-flash`")
        return
    
    model_name = model_name.strip()
    
    if model_name not in AVAILABLE_MODELS:
        await event.edit(f"❌ **النموذج غير متوفر**\nالنماذج المتاحة: {', '.join(AVAILABLE_MODELS)}")
        return
    
    if chat_id not in ai_settings:
        ai_settings[chat_id] = {}
    ai_settings[chat_id]["model"] = model_name
    
    await event.edit(f"🔄 **تم تبديل النموذج إلى:** `{model_name}`")


# ==================== أمر .تدريب الذكاء ====================
@client.on(events.NewMessage(pattern=r'\.تدريب الذكاء', outgoing=True))
async def train_ai(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على التعليمات التي تريد تدريب الذكاء عليها**")
        return
    
    instructions = reply.text
    chat_id = event.chat_id
    
    if chat_id not in ai_settings:
        ai_settings[chat_id] = {}
    
    if "training_context" not in ai_settings[chat_id]:
        ai_settings[chat_id]["training_context"] = []
    
    ai_settings[chat_id]["training_context"].append(instructions)
    
    await event.edit(f"🧠 **تم تدريب الذكاء على التعليمات التالية:**\n\n📝 *{instructions[:100]}...*")


# ==================== أمر .عرض النماذج ====================
@client.on(events.NewMessage(pattern=r'\.عرض النماذج', outgoing=True))
async def show_models(event):
    chat_id = event.chat_id
    current = ai_settings.get(chat_id, {}).get("model", DEFAULT_MODEL)
    
    models_text = "\n".join([
        f"• `{model}` {'✅ *الحالي*' if model == current else ''}"
        for model in AVAILABLE_MODELS
    ])
    
    await event.edit(f"🤖 **النماذج المتاحة:**\n\n{models_text}\n\n📌 **النموذج الحالي:** `{current}`")


# ==================== دالة الرد عبر بوت تيليجرام ====================
async def get_bot_reply(user_id, prompt):
    """الحصول على رد من بوت الذكاء الاصطناعي"""
    ai_bot = bot_ai_settings.get(user_id, {}).get("bot", DEFAULT_AI_BOT)
    
    try:
        async with client.conversation(ai_bot, timeout=60) as conv:
            await conv.send_message(prompt)
            response = await conv.get_response()
            
            if response.text:
                # تنظيف الرد من رسائل الانتظار
                if "wait" in response.text.lower() or "another" in response.text.lower():
                    await asyncio.sleep(8)
                    response = await conv.get_response()
                return response.text
            
            return None
    except Exception as e:
        return None


# ==================== الرد التلقائي على الرسائل (نظام مدمج) ====================
@client.on(events.NewMessage(outgoing=False, incoming=True))
async def ai_auto_reply(event):
    if not event.is_private:
        return
    
    my_id = (await client.get_me()).id
    
    if my_id not in ai_settings:
        ai_settings[my_id] = {}
    
    if not ai_settings[my_id].get("enabled", False):
        return
    
    if not ai_settings[my_id].get("chat_enabled", True):
        return
    
    mode = ai_settings[my_id].get("mode", "gemini")
    
    # ========== وضع البوت (GPT Telegram Bot) ==========
    if mode == "bot":
        prompt = event.text
        reply_text = await get_bot_reply(my_id, prompt)
        
        if reply_text:
            await event.reply(reply_text)
        else:
            await event.reply("⚠️ **تعذر الحصول على رد من بوت الذكاء**\n📌 جرب لاحقاً أو استخدم `.تشغيل الذكاء` لوضع Gemini")
        return
    
    # ========== وضع Gemini API ==========
    # تجميع جميع المفاتيح المتاحة
    api_keys = []
    main_key = user_api_keys.get(my_id)
    if main_key:
        api_keys.append(main_key)
    api_keys.extend([k for k in BACKUP_API_KEYS if k])
    
    if not api_keys:
        # إذا لم توجد مفاتيح، نجرب البوت تلقائياً
        prompt = event.text
        reply_text = await get_bot_reply(my_id, prompt)
        if reply_text:
            await event.reply(reply_text)
        else:
            await event.reply("⚠️ **يرجى تعيين مفتاح API أولاً**\nاستخدم: `.مفتاح xxxxx`\n\nأو استخدم: `.تشغيل البوت` للذكاء المجاني")
        return
    
    if genai is None:
        # إذا لم توجد مكتبة Gemini، نجرب البوت تلقائياً
        prompt = event.text
        reply_text = await get_bot_reply(my_id, prompt)
        if reply_text:
            await event.reply(reply_text)
        else:
            await event.reply("❌ **مكتبة الذكاء الاصطناعي غير مثبتة**")
        return
    
    ask_me_enabled = ai_settings[my_id].get("ask_me_enabled", False)
    ask_me_name = ai_settings[my_id].get("ask_me_name", "")
    
    try:
        sender = await event.get_sender()
        user_first_name = sender.first_name or "صديقي"
    except:
        user_first_name = "صديقي"
    
    system_prompt = """أنت مساعد ذكي باسم Zero، تتحدث بلهجة عراقية راقية ومهذبة. شخصيتك: محترم، ذكي، منطقي، ذو شخصية قوية، خفيف الدم بدون مبالغة.

قواعدك الأساسية:
1. أجب على السؤال بشكل كامل ومنطقي، دون حصر نفسك بعدد جمل.
2. لا تبدأ مواضيع جانبية أبداً. أجب فقط على السؤال المطروح.
3. الترحيب يكون مرة واحدة فقط في بداية المحادثة، ثم تتوقف تماماً.
4. المزاح مسموح فقط إذا كان السؤال خفيفاً، ويكون بكلمة أو كلمتين فقط.
5. لا تستخدم عبارات مبالغ فيها.
6. الكلمات العراقية المسموحة: "شلونك"، "زين"، "ماكو"، "هسه"، "تدلل"، "واجبنا"، "خوش"، "عاشت ايدك".
7. لا تثرثر. لا تعلق على كلام المستخدم بدون داعٍ.
8. إذا قال المستخدم "شكراً"، رد فقط بـ "تدلل" أو "واجبنا".
9. إذا قال "هاي" أو "مرحباً"، رد بـ "هلا" فقط.
10. كن واثقاً، إجاباتك دقيقة ومنطقية.

تذكر: أنت Zero، مساعد عراقي مهذب وقوي الشخصية، سريع البديهة، خفيف الظل."""
    
    prompt = event.text
    
    if ask_me_enabled and ask_me_name:
        context = f"""ملاحظة مهمة: اسمك هو {ask_me_name}. المستخدم الذي يكلمك اسمه الحقيقي هو {user_first_name}. 
عندما تريد مناداته، استخدم اسمه الحقيقي ({user_first_name}). {ask_me_name} هو اسمك أنت فقط."""
    else:
        context = f"المستخدم الذي يكلمك اسمه {user_first_name}."
    
    training = ai_settings[my_id].get("training_context", [])
    if training:
        training_text = "\n\n---\n\n".join(training)
        full_prompt = f"{system_prompt}\n\n---\n\nالتعليمات الإضافية:\n{training_text}\n\n---\n\n{context}\n\nالسؤال: {prompt}"
    else:
        full_prompt = f"{system_prompt}\n\n---\n\n{context}\n\nالسؤال: {prompt}"
    
    model_name = ai_settings[my_id].get("model", DEFAULT_MODEL)
    
    # تجربة جميع المفاتيح بصمت
    for api_key in api_keys:
        try:
            genai.configure(api_key=api_key)
            model = genai.GenerativeModel(model_name)
            
            response = model.generate_content(full_prompt)
            reply_text = response.text
            
            await event.reply(reply_text)
            return
            
        except Exception as e:
            error_msg = str(e)
            
            # إذا كان الخطأ متعلق بالحصة، ننتقل للمفتاح التالي بصمت
            if "quota" in error_msg.lower() or "exceeded" in error_msg.lower():
                continue
            elif "not found" in error_msg.lower():
                continue
            elif "invalid" in error_msg.lower() or "expired" in error_msg.lower():
                continue
            else:
                # خطأ آخر - نجرب البوت تلقائياً
                prompt = event.text
                reply_text = await get_bot_reply(my_id, prompt)
                if reply_text:
                    await event.reply(reply_text)
                return
    
    # كل المفاتيح فشلت - نجرب البوت تلقائياً
    prompt = event.text
    reply_text = await get_bot_reply(my_id, prompt)
    if reply_text:
        await event.reply(reply_text)