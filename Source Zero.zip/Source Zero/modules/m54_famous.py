import os
import random
from telethon import events
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.types import MessageEntityMentionName

from main import client

# ايدي المطور (للحماية)
DEVELOPER_ID = 7424434250

# قائمة صور المشاهير الذكور
FAMOUS_MALE = [
    "https://telegra.ph/file/50caf0efa9a2453985364.jpg",
    "https://telegra.ph/file/dda7dd09f7d697fe92ff6.jpg",
    "https://telegra.ph/file/007f130ef1028d15c3596.jpg",
    "https://telegra.ph/file/593c7e83d4eb25f7b0e55.jpg",
    "https://telegra.ph/file/48f567da3417c581446dc.jpg",
    "https://telegra.ph/file/165c9405bddc89cf818be.jpg",
    "https://telegra.ph/file/7217fc9ebe7c92b1e42c3.jpg",
    "https://telegra.ph/file/de70edbf7e01440c6e7bd.jpg",
    "https://telegra.ph/file/63e1b87537e92c05da46d.jpg",
    "https://telegra.ph/file/d58d68c118d862437f66a.jpg",
    "https://telegra.ph/file/28c209102abe082b97e99.jpg",
    "https://telegra.ph/file/53f4c117abcfc24934337.jpg",
    "https://telegra.ph/file/739a13b944c62412e908b.jpg",
    "https://telegra.ph/file/291a667b5bc7e7f15895d.jpg",
    "https://telegra.ph/file/e83874718d4eb829fc0e7.jpg",
    "https://telegra.ph/file/f2683a9c2f6aec9f16850.jpg",
    "https://telegra.ph/file/8775bf7b8edde56243897.jpg",
    "https://telegra.ph/file/b544499b6853568ce475f.jpg",
]

# قائمة أسماء المشاهير الذكور
FAMOUS_MALE_NAMES = [
    "إنجين أكيوريك", "كيفانش تاتليتوغ", "شاتاي أولسوي", "إنجين ألتان دوزياتان",
    "بوراك أوزجيفت", "أراس بولوت إيناملي", "كريستيانو رونالدو", "سيركان شاي أوغلو",
    "كرم بورسين", "توم كروز", "شاهيد كابور", "ليونيل ميسي",
    "محمد حماقي", "شاروخان", "سيف نبيل", "ليوناردو دي كابريو",
    "محمد رمضان", "سعد المجرد",
]

# قائمة صور المشاهير الإناث
FAMOUS_FEMALE = [
    "https://telegra.ph/file/1f79aad6235f08ea76166.jpg",
    "https://telegra.ph/file/e04b22171d7bb524e7f44.jpg",
    "https://telegra.ph/file/4502e1268a73117d9abac.jpg",
    "https://telegra.ph/file/5221a638913c64749760b.jpg",
    "https://telegra.ph/file/9c070eb80b621cbe0333c.jpg",
    "https://telegra.ph/file/6f34aa7f98fb6cfec3b57.jpg",
    "https://telegra.ph/file/9f0de560d7e7fc2752437.jpg",
    "https://telegra.ph/file/434d739dd887df9a40ae1.jpg",
    "https://telegra.ph/file/ac11888f2eca8529387de.jpg",
    "https://telegra.ph/file/4d999ac0dddd3964979a4.jpg",
    "https://telegra.ph/file/07d59b7a9a9b37c46d64f.jpg",
    "https://telegra.ph/file/788aab2a68a5a6f19f8c1.jpg",
    "https://telegra.ph/file/6c18a61f0f3d9e5b51576.jpg",
    "https://telegra.ph/file/974240259ba3d35a0507d.jpg",
    "https://telegra.ph/file/a5d73c57e8eea74937093.jpg",
    "https://telegra.ph/file/e6fd5618dc186ae286e9c.jpg",
    "https://telegra.ph/file/d40c3f57c3b1c2fceaef0.jpg",
    "https://telegra.ph/file/650f99255eb90e8f95061.jpg",
]

# قائمة أسماء المشاهير الإناث
FAMOUS_FEMALE_NAMES = [
    "بيرين سات", "إسراء الأصيل", "رحمة رياض", "توبا بويوكوستن",
    "هازال كايا", "هاندا ارتشل", "هيفاء وهبي", "نانسي عجرم",
    "شيرين عبد الوهاب", "أحلام", "حلا ترك", "نجوى كرم",
    "هاندا ارتشل", "آيشه افيخاي", "burcu ozberk", "شيماء سيف",
    "نيهان اتاغول", "ميليسا باموك",
]

# بصمة الزاحف
ZAHFF_VOICE = "https://t.me/fasngon/287"


# ==================== عرض قائمة الأوامر (.م55) ====================
@client.on(events.NewMessage(pattern=r'\.م54', outgoing=True))
async def show_famous_menu(event):
    menu_text = """⟪───── أوامر المشاهير ─────⟫

│ `.مشهور` بالرد على شخص
│ ← يعرض صورة مشهور عشوائي ويقول أنه تزوج الشخص

│ `.مشهوره` بالرد على شخص
│ ← يعرض صورة مشهورة عشوائية وتقول أنها تزوجت الشخص

│ `.زاحف` بالرد على شخص
│ ← يرسل بصمة "اطلع زاحف" للشخص

⌔ **ملاحظة:** الأوامر للتحشيش والتسلية فقط
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== دالة مساعدة: جلب المستخدم ====================
async def get_user_from_event(event):
    if event.reply_to_msg_id:
        previous_message = await event.get_reply_message()
        user_object = await event.client.get_entity(previous_message.sender_id)
    else:
        user = event.pattern_match.group(1)
        if user.isnumeric():
            user = int(user)
        if not user:
            self_user = await event.client.get_me()
            user = self_user.id
        if event.message.entities:
            probable_user_mention_entity = event.message.entities[0]
            if isinstance(probable_user_mention_entity, MessageEntityMentionName):
                user_id = probable_user_mention_entity.user_id
                user_obj = await event.client.get_entity(user_id)
                return user_obj
        if isinstance(user, int) or user.startswith("@"):
            user_obj = await event.client.get_entity(user)
            return user_obj
        try:
            user_object = await event.client.get_entity(user)
        except (TypeError, ValueError) as err:
            await event.edit(str(err))
            return None
    return user_object


# ==================== أمر .مشهور ====================
@client.on(events.NewMessage(pattern=r'\.مشهور(?: |$)(.*)', outgoing=True))
async def famous_male(event):
    zed = await event.edit("⎙ **جاري اختيار مشهور...**")
    
    replied_user = await get_user_from_event(event)
    
    if not replied_user:
        await event.edit("✘ **لم استطع العثور على الشخص**")
        return
    
    if replied_user.id == DEVELOPER_ID:
        await event.edit("✘ **هذا الشخص لا يمكن استخدام الأمر عليه**")
        return
    
    first_name = replied_user.first_name or ""
    
    x = random.randrange(0, len(FAMOUS_MALE))
    image = FAMOUS_MALE[x]
    name = FAMOUS_MALE_NAMES[x]
    
    caption = f"""◈ **مبـروك الزواج!** 💞🤵💞

⌔ **العريس:** {name}
⌔ **العروسة:** [{first_name}](tg://user?id={replied_user.id})

✾ **مبـروك زواجك مـن {name} 🥺💘**

⌔ **سورس زيرو**"""
    
    message_id_to_reply = event.message.reply_to_msg_id
    
    try:
        await event.client.send_file(
            event.chat_id,
            image,
            caption=caption,
            link_preview=False,
            force_document=False,
            reply_to=message_id_to_reply,
            parse_mode="html",
        )
        await zed.delete()
    except TypeError:
        await zed.edit(caption, parse_mode="html")


# ==================== أمر .مشهوره ====================
@client.on(events.NewMessage(pattern=r'\.مشهوره(?: |$)(.*)', outgoing=True))
async def famous_female(event):
    zed = await event.edit("⎙ **جاري اختيار مشهورة...**")
    
    replied_user = await get_user_from_event(event)
    
    if not replied_user:
        await event.edit("✘ **لم استطع العثور على الشخص**")
        return
    
    if replied_user.id == DEVELOPER_ID:
        await event.edit("✘ **هذا الشخص لا يمكن استخدام الأمر عليه**")
        return
    
    first_name = replied_user.first_name or ""
    
    x = random.randrange(0, len(FAMOUS_FEMALE))
    image = FAMOUS_FEMALE[x]
    name = FAMOUS_FEMALE_NAMES[x]
    
    caption = f"""◈ **مبـروك الزواج!** 💞🤵💞

⌔ **العروسة:** {name}
⌔ **العريس:** [{first_name}](tg://user?id={replied_user.id})

✾ **مبـروك زواجك مـن {name} 🥺💘**

⌔ **سورس زيرو**"""
    
    message_id_to_reply = event.message.reply_to_msg_id
    
    try:
        await event.client.send_file(
            event.chat_id,
            image,
            caption=caption,
            link_preview=False,
            force_document=False,
            reply_to=message_id_to_reply,
            parse_mode="html",
        )
        await zed.delete()
    except TypeError:
        await zed.edit(caption, parse_mode="html")


# ==================== أمر .زاحف ====================
@client.on(events.NewMessage(pattern=r'\.زاحف(?: |$)(.*)', outgoing=True))
async def zahif(event):
    zed = await event.edit("⎙ **جاري...**")
    
    replied_user = await get_user_from_event(event)
    
    if not replied_user:
        await event.edit("✘ **لم استطع العثور على الشخص**")
        return
    
    first_name = replied_user.first_name or ""
    
    caption = f"""◈ **اطـلـع زاحـف 😹🤫**

⌔ [{first_name}](tg://user?id={replied_user.id})

⌔ **سورس زيرو**"""
    
    message_id_to_reply = event.message.reply_to_msg_id
    
    try:
        await event.client.send_file(
            event.chat_id,
            ZAHFF_VOICE,
            caption=caption,
            link_preview=False,
            force_document=False,
            reply_to=message_id_to_reply,
            parse_mode="html",
        )
        await zed.delete()
    except TypeError:
        await zed.edit(caption, parse_mode="html")