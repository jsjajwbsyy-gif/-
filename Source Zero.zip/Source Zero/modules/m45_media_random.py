import asyncio
import random
from telethon import events
from telethon.tl.types import (
    InputMessagesFilterVideo,
    InputMessagesFilterVoice,
    InputMessagesFilterPhotos,
)

from main import client


# ========== أمر .حالات ==========
@client.on(events.NewMessage(pattern=r'\.حالات$', outgoing=True))
async def whatsapp_status(event):
    await event.edit("**جـارِ تحميـل حـالات واتـس ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@RSHDO5", filter=InputMessagesFilterVideo
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="حـالات واتـس قصيـرة",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .ستوري انمي ==========
@client.on(events.NewMessage(pattern=r'\.ستوري انمي$', outgoing=True))
async def anime_story(event):
    await event.edit("**جـارِ تحميـل الستـوري ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@AA_Zll", filter=InputMessagesFilterVideo
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="ستـوريات آنمـي قصيـرة",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .رقيه ==========
@client.on(events.NewMessage(pattern=r'\.رقيه$', outgoing=True))
async def roqya(event):
    await event.edit("**جـارِ تحميـل الرقيـه ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@Rqy_1", filter=InputMessagesFilterVoice
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="مقاطـع رقيـه شرعيـة",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .رمادي ==========
@client.on(events.NewMessage(pattern=r'\.رمادي$', outgoing=True))
async def gray_boy(event):
    await event.edit("**جـارِ تحميـل الافتـار ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@shababbbbR", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="افتـارات شبـاب رمـاديه",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .رماديه ==========
@client.on(events.NewMessage(pattern=r'\.رماديه$', outgoing=True))
async def gray_girl(event):
    await event.edit("**جـارِ تحميـل الافتـار ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@banatttR", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="افتـارات بنـات رمـاديه",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .بيست ==========
@client.on(events.NewMessage(pattern=r'\.بيست$', outgoing=True))
async def best(event):
    await event.edit("**جـارِ تحميـل الافتـار ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@Tatkkkkkim", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="افتـارات بيست تطقيـم بنـات",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .حب ==========
@client.on(events.NewMessage(pattern=r'\.حب$', outgoing=True))
async def love(event):
    await event.edit("**جـارِ تحميـل الافتـار ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@tatkkkkkimh", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="افتـارات حـب تمبلـر",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .رياكشن ==========
@client.on(events.NewMessage(pattern=r'\.رياكشن$', outgoing=True))
async def reaction_vid(event):
    await event.edit("**جـارِ تحميـل الرياكشـن ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@reagshn", filter=InputMessagesFilterVideo
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="رياكشـن تحشيـش",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .ادت ==========
@client.on(events.NewMessage(pattern=r'\.ادت$', outgoing=True))
async def edit_vid(event):
    await event.edit("**جـارِ تحميـل مقطـع ادت ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@snje1", filter=InputMessagesFilterVideo
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="مقاطـع ايـدت منوعـه",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .غنيلي ==========
@client.on(events.NewMessage(pattern=r'\.غنيلي$', outgoing=True))
async def sing(event):
    await event.edit("**جـارِ تحميـل الاغنيـه ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@TEAMSUL", filter=InputMessagesFilterVoice
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="تم اختياࢪ الاغنيـه لك",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .شعر ==========
@client.on(events.NewMessage(pattern=r'\.شعر$', outgoing=True))
async def poetry(event):
    await event.edit("**جـارِ تحميـل الشعـر ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@L1BBBL", filter=InputMessagesFilterVoice
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="تم اختيـار مقطـع الشعـر هـذا لك",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .ميمز ==========
@client.on(events.NewMessage(pattern=r'\.ميمز$', outgoing=True))
async def memes(event):
    await event.edit("**جـارِ تحميـل الميمـز ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@MemzWaTaN", filter=InputMessagesFilterVoice
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="تم اختيـار مقطـع الميمـز هـذا لك",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .ري اكشن ==========
@client.on(events.NewMessage(pattern=r'\.ري اكشن$', outgoing=True))
async def reaction_img(event):
    await event.edit("**جـارِ تحميـل الرياكشـن ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@gafffg", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="رياكشـن تحشيـش",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .معلومه ==========
@client.on(events.NewMessage(pattern=r'\.معلومه$', outgoing=True))
async def info(event):
    await event.edit("**جـارِ تحميـل صـورة ومعلومـة ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@A_l3l", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="صـورة ومعلومـة",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .تويت ==========
@client.on(events.NewMessage(pattern=r'\.تويت$', outgoing=True))
async def tweet(event):
    await event.edit("**كـت تـويت بالصـور ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@twit_selva", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="كـت تـويت بالصـور",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .خيرني ==========
@client.on(events.NewMessage(pattern=r'\.خيرني$', outgoing=True))
async def kheyerni(event):
    await event.edit("**لـو خيـروك بالصـور ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@SourceSaidi", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="لـو خيـروك",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .ولد انمي ==========
@client.on(events.NewMessage(pattern=r'\.ولد انمي$', outgoing=True))
async def anime_boy(event):
    await event.edit("**جـارِ تحميـل الافتـار ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@dnndxn", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="افتـارات آنمي شبـاب",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .بنت انمي ==========
@client.on(events.NewMessage(pattern=r'\.بنت انمي$', outgoing=True))
async def anime_girl(event):
    await event.edit("**جـارِ تحميـل الافتـار ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@shhdhn", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="افتـارات آنمي بنـات",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .بنات ==========
@client.on(events.NewMessage(pattern=r'\.بنات$', outgoing=True))
async def girls(event):
    await event.edit("**جـارِ تحميـل الافتـار ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@banaaaat1", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="افتـارات بنـات تمبلـر",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .كرة ==========
@client.on(events.NewMessage(pattern=r'\.كرة$', outgoing=True))
async def football(event):
    await event.edit("**جـارِ تحميـل الافتـار ...**")
    try:
        reps = [
            msg
            async for msg in event.client.iter_messages(
                "@xy_89y", filter=InputMessagesFilterPhotos
            )
        ]
        await event.client.send_file(
            event.chat_id,
            file=random.choice(reps),
            caption="افتـارات كـرة قـدم",
        )
        await event.delete()
    except Exception:
        await event.edit("**عـذراً .. لـم استطـع ايجـاد المطلـوب**")


# ========== أمر .م45 (عرض القائمة) ==========
@client.on(events.NewMessage(pattern=r'\.م45', outgoing=True))
async def show_m45_menu(event):
    menu_text = """⟪───── اوامــر الوسائط العشوائية ─────⟫

│ `.حالات`  ←  فيديوهات واتساب قصيرة

│ `.ستوري انمي`  ←  ستوريات انمي قصيرة

│ `.رقيه`  ←  مقاطع رقية شرعية

│ `.رمادي`  ←  افتارات شباب رمادية

│ `.رماديه`  ←  افتارات بنات رمادية

│ `.بيست`  ←  افتارات بيست تطقيم بنات

│ `.حب`  ←  افتارات حب تمبلر

│ `.رياكشن`  ←  فيديوهات رياكشن تحشيش

│ `.ادت`  ←  مقاطع ايدت منوعة

│ `.غنيلي`  ←  مقاطع اغاني

│ `.شعر`  ←  مقاطع شعر

│ `.ميمز`  ←  مقاطع ميمز

│ `.ري اكشن`  ←  صور رياكشن تحشيش

│ `.معلومه`  ←  صورة ومعلومة

│ `.تويت`  ←  كت تويت بالصور

│ `.خيرني`  ←  لو خيروك بالصور

│ `.ولد انمي`  ←  افتارات انمي شباب

│ `.بنت انمي`  ←  افتارات انمي بنات

│ `.بنات`  ←  افتارات بنات تمبلر

│ `.كرة`  ←  افتارات كرة قدم

╰─────────────────────────"""
    await event.edit(menu_text)