from main import client
from telethon import events

# ========== M32: أوامر البوتات ==========

@client.on(events.NewMessage(pattern=r'\.م32', outgoing=True))
async def show_m32_menu(event):
    menu_text = """⟪───── أوامر البوتات ─────⟫

│ `.انشاء بوت`
│ ← بالرد على اسم البوت، ينشئ بوت جديد

│ `.حذف بوت`
│ ← بالرد على يوزر البوت، يحذفه نهائياً

│ `.بوتاتي`
│ ← يعرض جميع البوتات التي تملكها

│ `.تغيير اسم بوت`
│ ← بالرد على يوزر البوت + الاسم الجديد

│ `.تغيير بايو بوت`
│ ← بالرد على يوزر البوت + البايو الجديد

│ `.رفع صورة بوت`
│ ← بالرد على صورة + يوزر البوت

│ `.توكن`
│ ← بالرد على يوزر البوت، يعرض توكينه

│ `.تحكم بوت`
│ ← بالرد على يوزر البوت، يفتح لوحة تحكم

│ `.معلومات بوت`
│ ← بالرد على يوزر البوت، يعرض معلوماته

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== أمر .انشاء بوت (بالرد على الاسم) ==========
@client.on(events.NewMessage(pattern=r'\.انشاء بوت', outgoing=True))
async def create_bot(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على اسم البوت المطلوب**")
        return
    
    bot_name = reply.text.strip()
    bot_username = f"{bot_name}Bot"
    
    await event.edit(f"🤖 **جاري إنشاء البوت:** {bot_name}...")
    
    try:
        async with client.conversation("@BotFather") as conv:
            await conv.send_message("/newbot")
            response = await conv.get_response()
            await conv.send_message(bot_name)
            await asyncio.sleep(1)
            await conv.send_message(bot_username)
            
            response = await conv.get_response()
            
            if "Done!" in response.text or "تم" in response.text:
                import re
                token_match = re.search(r'(\d+:[A-Za-z0-9_-]+)', response.text)
                if token_match:
                    token = token_match.group(1)
                    await event.edit(f"""✅ **تم إنشاء البوت بنجاح!**

🤖 **الاسم:** {bot_name}
📎 **اليوزر:** @{bot_username}
🔑 **التوكين:** `{token}`

⚠️ **احفظ التوكين!**""")
                else:
                    await event.edit(f"✅ **تم إنشاء البوت:** @{bot_username}")
            else:
                await event.edit(f"❌ **فشل:**\n{response.text[:200]}")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .حذف بوت (بالرد على اليوزر) ==========
@client.on(events.NewMessage(pattern=r'\.حذف بوت', outgoing=True))
async def delete_bot(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على يوزر البوت**")
        return
    
    bot_username = reply.text.strip()
    
    await event.edit(f"🗑 **جاري حذف:** {bot_username}...")
    
    try:
        async with client.conversation("@BotFather") as conv:
            await conv.send_message("/mybots")
            await asyncio.sleep(1)
            await conv.send_message(bot_username)
            await asyncio.sleep(1)
            await conv.send_message("/deletebot")
            await asyncio.sleep(1)
            response = await conv.get_response()
            
            if "confirm" in response.text.lower():
                await conv.send_message("Yes, I am sure")
                await event.edit(f"✅ **تم حذف البوت:** {bot_username}")
            else:
                await event.edit(f"❌ **فشل حذف البوت**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .بوتاتي ==========
@client.on(events.NewMessage(pattern=r'\.بوتاتي', outgoing=True))
async def my_bots(event):
    await event.edit("🤖 **جاري جلب البوتات...**")
    
    try:
        async with client.conversation("@BotFather") as conv:
            await conv.send_message("/mybots")
            response = await conv.get_response()
            
            if response.text:
                # استخراج اليوزرات من النص
                import re
                usernames = re.findall(r'@(\w+)', response.text)
                
                text = "🤖 **البوتات التي تملكها:**\n\n"
                for i, username in enumerate(usernames, 1):
                    text += f"{i}. `@{username}`\n"
                
                text += f"\n📊 **العدد:** {len(usernames)}\n📌 **اضغط على أي يوزر لنسخه**"
                await event.edit(text)
            else:
                await event.edit("📭 **لا توجد بوتات**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .توكن (بالرد على اليوزر) ==========
@client.on(events.NewMessage(pattern=r'\.توكن', outgoing=True))
async def get_bot_token(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على يوزر البوت**")
        return
    
    bot_username = reply.text.strip()
    
    await event.edit(f"🔑 **جاري جلب توكين:** {bot_username}...")
    
    try:
        async with client.conversation("@BotFather") as conv:
            await conv.send_message("/mybots")
            await asyncio.sleep(1)
            await conv.send_message(bot_username)
            await asyncio.sleep(1)
            await conv.send_message("/token")
            
            response = await conv.get_response()
            
            import re
            token_match = re.search(r'(\d+:[A-Za-z0-9_-]+)', response.text)
            if token_match:
                token = token_match.group(1)
                await event.edit(f"🔑 **توكين البوت:** `{token}`\n\n⚠️ **لا تشاركه مع أحد!**")
            else:
                await event.edit(f"❌ **لم يتم العثور على التوكين**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .تحكم بوت (بالرد على اليوزر) ==========
@client.on(events.NewMessage(pattern=r'\.تحكم بوت', outgoing=True))
async def control_bot(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على يوزر البوت**")
        return
    
    bot_username = reply.text.strip()
    
    text = f"""🎮 **لوحة تحكم البوت:** {bot_username}

│ `.تغيير اسم بوت` - تغيير الاسم
│ `.تغيير بايو بوت` - تغيير البايو
│ `.رفع صورة بوت` - تغيير الصورة
│ `.توكن` - عرض التوكين
│ `.حذف بوت` - حذف البوت

📌 **طريقة الاستخدام:** رد على يوزر البوت + الأمر"""
    
    await event.edit(text)


# ========== أمر .تغيير اسم بوت (بالرد على يوزر + اسم في نفس الرسالة) ==========
@client.on(events.NewMessage(pattern=r'\.تغيير اسم بوت\s+([\s\S]+)', outgoing=True))
async def change_bot_name(event):
    new_name = event.pattern_match.group(1).strip()
    reply = await event.get_reply_message()
    
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على يوزر البوت**\n📝 مثال: رد على @البوت ثم اكتب .تغيير اسم بوت الاسم_الجديد")
        return
    
    bot_username = reply.text.strip()
    
    await event.edit(f"✏️ **جاري تغيير اسم:** {bot_username} → {new_name}...")
    
    try:
        async with client.conversation("@BotFather") as conv:
            await conv.send_message("/mybots")
            await asyncio.sleep(1)
            await conv.send_message(bot_username)
            await asyncio.sleep(1)
            await conv.send_message("/setname")
            await asyncio.sleep(1)
            await conv.send_message(new_name)
            
            response = await conv.get_response()
            
            if "Success" in response.text or "تم" in response.text:
                await event.edit(f"✅ **تم تغيير الاسم إلى:** {new_name}")
            else:
                await event.edit(f"❌ **فشل تغيير الاسم**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .تغيير بايو بوت (بالرد على يوزر + بايو في نفس الرسالة) ==========
@client.on(events.NewMessage(pattern=r'\.تغيير بايو بوت\s+([\s\S]+)', outgoing=True))
async def change_bot_bio(event):
    new_bio = event.pattern_match.group(1).strip()
    reply = await event.get_reply_message()
    
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على يوزر البوت**")
        return
    
    bot_username = reply.text.strip()
    
    await event.edit(f"📝 **جاري تغيير بايو:** {bot_username}...")
    
    try:
        async with client.conversation("@BotFather") as conv:
            await conv.send_message("/mybots")
            await asyncio.sleep(1)
            await conv.send_message(bot_username)
            await asyncio.sleep(1)
            await conv.send_message("/setabouttext")
            await asyncio.sleep(1)
            await conv.send_message(new_bio)
            
            response = await conv.get_response()
            
            if "Success" in response.text or "تم" in response.text:
                await event.edit(f"✅ **تم تغيير البايو**")
            else:
                await event.edit(f"❌ **فشل تغيير البايو**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .رفع صورة بوت (بالرد على صورة تحتوي على يوزر البوت) ==========
@client.on(events.NewMessage(pattern=r'\.رفع صورة بوت', outgoing=True))
async def set_bot_photo(event):
    reply = await event.get_reply_message()
    
    if not reply:
        await event.edit("❌ **يرجى الرد على صورة مع يوزر البوت في التعليق**")
        return
    
    bot_username = reply.text.strip() if reply.text else ""
    
    if not bot_username:
        await event.edit("❌ **اكتب يوزر البوت في تعليق الصورة**")
        return
    
    await event.edit("🖼️ **جاري رفع صورة البوت...**")
    
    try:
        async with client.conversation("@BotFather") as conv:
            await conv.send_message("/mybots")
            await asyncio.sleep(1)
            await conv.send_message(bot_username)
            await asyncio.sleep(1)
            await conv.send_message("/setuserpic")
            await asyncio.sleep(1)
            await client.forward_messages("@BotFather", reply)
            
            response = await conv.get_response()
            
            if "Success" in response.text or "تم" in response.text:
                await event.edit(f"✅ **تم رفع صورة البوت**")
            else:
                await event.edit(f"❌ **فشل رفع الصورة**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .معلومات بوت (بالرد على اليوزر) ==========
@client.on(events.NewMessage(pattern=r'\.معلومات بوت', outgoing=True))
async def bot_info(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على يوزر البوت**")
        return
    
    bot_username = reply.text.strip()
    
    try:
        bot = await client.get_entity(bot_username)
        
        name = bot.first_name or ""
        if bot.last_name:
            name += f" {bot.last_name}"
        
        username = f"@{bot.username}" if bot.username else "بدون"
        bot_id = bot.id
        
        text = f"""🤖 **معلومات البوت:**

👤 **الاسم:** {name}
📎 **اليوزر:** {username}
🆔 **الآيدي:** `{bot_id}`"""
        
        photos = await client.get_profile_photos(bot.id, limit=1)
        if photos:
            await client.send_file(event.chat_id, photos[0], caption=text)
            await event.delete()
        else:
            await event.edit(text)
            
    except Exception as e:
        await event.edit(f"❌ **البوت غير موجود:** {bot_username}")