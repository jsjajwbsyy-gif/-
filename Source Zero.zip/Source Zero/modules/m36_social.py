from main import client
from telethon import events

# ========== M36: أوامر اجتماعية وتفاعلية ==========

@client.on(events.NewMessage(pattern=r'\.م36', outgoing=True))
async def show_m36_menu(event):
    menu_text = """⟪───── أوامر اجتماعية وتفاعلية ─────⟫

│ `.هدية`
│ ← إرسال عملات وهمية لشخص (بالرد)

│ `.شكر`
│ ← إرسال رسالة شكر جميلة (بالرد)

│ `.وداع`
│ ← رسالة وداع عند مغادرة عضو

│ `.اقترح`
│ ← اقتراح فيلم/مسلسل/أغنية عشوائية

│ `.مقارنة`
│ ← مقارنة بين شيئين

│ `.حظك`
│ ← نسبة حظك اليوم

│ `.شخصيتك`
│ ← تحليل شخصيتك من اسمك

│ `.أسمك`
│ ← معرفة معنى اسمك

│ `.برجك`
│ ← برجك اليوم وتوقعاتك

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== أمر .هدية ==========
@client.on(events.NewMessage(pattern=r'\.هدية', outgoing=True))
async def send_gift(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return
    
    target = await reply.get_sender()
    coins = random.randint(100, 10000)
    
    text = f"""🎁 **هدية خاصة!**

👤 **من:** {(await client.get_me()).first_name}
👤 **إلى:** {target.first_name}
💰 **القيمة:** {coins} عملة وهمية

🎉 **مبروك!**"""
    
    await event.edit(text)


# ========== أمر .شكر ==========
@client.on(events.NewMessage(pattern=r'\.شكر', outgoing=True))
async def send_thanks(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return
    
    target = await reply.get_sender()
    
    thanks = [
        f"🌸 **شكراً جزيلاً** {target.first_name} على كل شيء!",
        f"💐 **كل الشكر والتقدير** لك {target.first_name}!",
        f"⭐ **أنت الأفضل** {target.first_name}، شكراً من القلب!",
        f"🙏 **جزاك الله خيراً** {target.first_name}!",
        f"💖 **شكراً من الأعماق** {target.first_name}!"
    ]
    
    await event.edit(random.choice(thanks))


# ========== أمر .وداع ==========
@client.on(events.NewMessage(pattern=r'\.وداع', outgoing=True))
async def send_goodbye(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return
    
    target = await reply.get_sender()
    
    goodbyes = [
        f"👋 **وداعاً** {target.first_name}، نتمنى لك التوفيق!",
        f"🥺 **سنفتقدك** {target.first_name}، عد إلينا قريباً!",
        f"💔 **لا تقل وداعاً** {target.first_name}، بل قل إلى اللقاء!",
        f"🌈 **في أمان الله** {target.first_name}!"
    ]
    
    await event.edit(random.choice(goodbyes))


# ========== أمر .اقترح ==========
@client.on(events.NewMessage(pattern=r'\.اقترح', outgoing=True))
async def suggest(event):
    movies = ["🎬 **فيلم:** The Shawshank Redemption", "🎬 **فيلم:** Inception", "🎬 **فيلم:** Interstellar"]
    series = ["📺 **مسلسل:** Breaking Bad", "📺 **مسلسل:** Game of Thrones", "📺 **مسلسل:** Stranger Things"]
    songs = ["🎵 **أغنية:** Bohemian Rhapsody - Queen", "🎵 **أغنية:** Hotel California - Eagles", "🎵 **أغنية:** Imagine - John Lennon"]
    
    category = random.choice(["movie", "series", "song"])
    
    if category == "movie":
        await event.edit(random.choice(movies))
    elif category == "series":
        await event.edit(random.choice(series))
    else:
        await event.edit(random.choice(songs))


# ========== أمر .مقارنة ==========
@client.on(events.NewMessage(pattern=r'\.مقارنة\s+([\s\S]+)\s+و\s+([\s\S]+)', outgoing=True))
async def compare(event):
    item1 = event.pattern_match.group(1).strip()
    item2 = event.pattern_match.group(2).strip()
    
    score1 = random.randint(1, 100)
    score2 = 100 - score1 if score1 > 50 else random.randint(1, 100)
    
    if score1 > score2:
        winner = item1
    elif score2 > score1:
        winner = item2
    else:
        winner = "تعادل!"
    
    text = f"""⚖️ **مقارنة:**

🔹 **{item1}:** {score1}%
🔸 **{item2}:** {score2}%

🏆 **الفائز:** {winner}"""
    
    await event.edit(text)


# ========== أمر .حظك ==========
@client.on(events.NewMessage(pattern=r'\.حظك', outgoing=True))
async def luck_today(event):
    me = await client.get_me()
    luck = random.randint(0, 100)
    
    if luck >= 80:
        status = "🌟 ممتاز! يوم رائع بانتظارك"
    elif luck >= 60:
        status = "😊 جيد! يوم إيجابي"
    elif luck >= 40:
        status = "😐 متوسط! يوم عادي"
    elif luck >= 20:
        status = "😕 سيء! خذ حذرك"
    else:
        status = "💀 سيء جداً! ابق في المنزل"
    
    text = f"""🍀 **حظك اليوم {me.first_name}:**

📊 **النسبة:** {luck}%
📝 **التوقعات:** {status}"""
    
    await event.edit(text)


# ========== أمر .شخصيتك ==========
@client.on(events.NewMessage(pattern=r'\.شخصيتك\s+(\w+)', outgoing=True))
async def personality(event):
    name = event.pattern_match.group(1).strip()
    
    types = ["قائد بالفطرة 🦁", "مبدع خيالي 🎨", "اجتماعي محبوب 🤝", "مفكر عميق 🤔", "مغامر جريء 🏃"]
    personality_type = random.choice(types)
    
    text = f"""🔮 **تحليل شخصية:** {name}

👤 **النوع:** {personality_type}
💪 **القوة:** {random.randint(60, 100)}%
🧠 **الذكاء:** {random.randint(60, 100)}%
❤️ **القلب:** {random.randint(60, 100)}%"""
    
    await event.edit(text)


# ========== أمر .أسمك ==========
@client.on(events.NewMessage(pattern=r'\.أسمك\s+(\w+)', outgoing=True))
async def name_meaning(event):
    name = event.pattern_match.group(1).strip()
    
    meanings = {
        "محمد": "المحمود، الذي يحمده الناس",
        "أحمد": "كثير الحمد، الأكثر حمداً",
        "علي": "العالي، الرفيع",
        "عمر": "الحياة، العمر المديد",
        "نور": "الضوء، الإشراق",
    }
    
    meaning = meanings.get(name, f"اسم جميل ومعناه مميز ✨")
    
    await event.edit(f"""📖 **معنى اسم:** {name}

💬 **المعنى:** {meaning}""")


# ========== أمر .برجك ==========
@client.on(events.NewMessage(pattern=r'\.برجك\s+(\w+)', outgoing=True))
async def horoscope(event):
    sign = event.pattern_match.group(1).strip()
    
    predictions = [
        "اليوم يوم رائع للحب والعلاقات 💕",
        "ستحصل على أخبار سارة قريباً 📩",
        "خذ حذرك من شخص قريب منك ⚠️",
        "يوم مناسب لاتخاذ القرارات المهمة 🎯",
        "الراحة ضرورية اليوم، لا تجهد نفسك 🛌",
    ]
    
    text = f"""🌟 **برجك اليوم:** {sign}

📝 **التوقعات:**
{random.choice(predictions)}

🍀 **حظك:** {random.randint(30, 100)}%
💕 **الحب:** {random.randint(30, 100)}%
💰 **المال:** {random.randint(30, 100)}%"""
    
    await event.edit(text)