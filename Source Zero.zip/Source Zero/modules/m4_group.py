import asyncio
from telethon import events
from telethon.tl.functions.channels import EditAdminRequest, InviteToChannelRequest
from telethon.tl.functions.messages import CreateChatRequest, ExportChatInviteRequest, EditChatAboutRequest, DeleteChatUserRequest
from telethon.tl.types import ChatAdminRights, ChannelParticipantsAdmins

from main import client

group_settings = {}
custom_replies = {}
group_restrictions = {}
gbanned_users = {}

# ==================== الأمر الرئيسي .م4 ====================
@client.on(events.NewMessage(pattern=r'\.م4', outgoing=True))
async def show_m4_menu(event):
    menu_text = """» اختر احد الامرين:

│ `.اوامر المجموعة`

│ `.حماية المجموعة`

╰────────────"""
    await event.edit(menu_text)

# ==================== 1. أمر .اوامر المجموعة ====================
@client.on(events.NewMessage(pattern=r'\.اوامر المجموعة', outgoing=True))
async def show_group_commands(event):
    menu_text = """⟪───── أوامر المجموعات ─────⟫

│ تقييد - طرد - حظر - كتم (بالرد على العضو)
│ `.الغاء` ← لإلغاء التقييد / الكتم / الحظر
│ `.المقيدين` ← لعرض المقيدين
│ `.مسح المقيدين` ← لمسح المقيدين

│ `.منشن`
│ ← لعرض أوامر المنشن الذكي

│ `.كشف المحذوفين` ← لعرض عدد الحسابات المحذوفة
│ `.اطرد المحذوفين` ← لطرد جميع الحسابات المحذوفة

│ `.مغادرة المجموعات | .مغادرة القنوات`
│ ← لمغادرة المجموعات أو القنوات

│ `.رد_مجموعة` ← لتشغيل الردود في المجموعة
│ `.ايقاف_رد_مجموعة` ← لإيقاف الردود
│ `.تعيين_رد` ← لتعيين رد مخصص للمجموعة

│ `.كروباتي` ← لعرض مجموعاتك
│ `.قنواتي` ← لعرض قنواتك

│ `.رفع مشرف [بالرد]` ← لترقية المستخدم لمشرف محدود الصلاحيات
│ `.رفع مشرف اساسي [بالرد]` ← لترقية المستخدم لمشرف كامل الصلاحيات

│ `.انشاء مجموعات [العدد] ← لصنع مجموعات `وإرسال روابطها

│ `.اوامر الترحيب` ← لعرض اوامر الترحيب

│ `.حظر عام` ← حظر الشخص من كل مجموعاتك
│ `.الغاء حظر عام` ← الغاء الحظر العام
│ `.طرد عام` ← طرد الشخص من كل مجموعاتك
│ `.المحظورين عام` ← عرض قائمة المحظورين عام
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 2. أمر .حماية المجموعة ====================
@client.on(events.NewMessage(pattern=r'\.حماية المجموعة', outgoing=True))
async def show_protection_commands(event):
    menu_text = """⟪───── حماية المجموعة ─────⟫

│ `.فعل الصور / .عطل الصور`
│ ← يمنع أي صور جديدة في المجموعة

│ `.فعل المتحركة / .عطل المتحركة`
│ ← يمنع أي متحركات جديدة

│ `.فعل الملصقات / .عطل الملصقات`
│ ← يمنع أي ملصقات جديدة

│ `.فعل التحويل / .عطل التحويل`
│ ← يمنع أي رسائل محولة جديدة

│ `.فعل الفيديوهات / .عطل الفيديوهات`
│ ← يمنع أي فيديوهات جديدة

│ `.فعل الروابط / .عطل الروابط`
│ ← يمنع أي روابط جديدة

│ `.فعل البصمات / .عطل البصمات`
│ ← يمنع أي رسائل صوتية جديدة

│ `.فعل الدردشة / .عطل الدردشة`
│ ← يمنع جميع الرسائل الجديدة
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== أوامر التقييد والطرد والحظر ====================
@client.on(events.NewMessage(pattern=r'\.تقييد', outgoing=True))
async def restrict_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة العضو الذي تريد تقييده**")
        return
    
    user_id = reply.sender_id
    chat_id = event.chat_id
    
    try:
        await client.edit_permissions(chat_id, user_id, send_messages=False)
        await event.edit("✅ **تم تقييد العضو**")
    except Exception as e:
        await event.edit(f"❌ **فشل التقييد:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.طرد', outgoing=True))
async def kick_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة العضو الذي تريد طرده**")
        return
    
    user_id = reply.sender_id
    chat_id = event.chat_id
    
    try:
        await client.kick_participant(chat_id, user_id)
        await event.edit("✅ **تم طرد العضو**")
    except Exception as e:
        await event.edit(f"❌ **فشل الطرد:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.حظر', outgoing=True))
async def ban_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة العضو الذي تريد حظره**")
        return
    
    user_id = reply.sender_id
    chat_id = event.chat_id
    
    try:
        await client.edit_permissions(chat_id, user_id, view_messages=False)
        await event.edit("🚫 **تم حظر العضو**")
    except Exception as e:
        await event.edit(f"❌ **فشل الحظر:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.كتم', outgoing=True))
async def mute_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة العضو الذي تريد كتمه**")
        return
    
    user_id = reply.sender_id
    chat_id = event.chat_id
    
    try:
        await client.edit_permissions(chat_id, user_id, send_messages=False)
        await event.edit("🔇 **تم كتم العضو**")
    except Exception as e:
        await event.edit(f"❌ **فشل الكتم:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.الغاء', outgoing=True))
async def unrestrict_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة العضو الذي تريد إلغاء التقييد عنه**")
        return
    
    user_id = reply.sender_id
    chat_id = event.chat_id
    
    try:
        await client.edit_permissions(
            chat_id, user_id,
            send_messages=True, send_media=True,
            send_stickers=True, send_gifs=True,
            send_games=True, send_inline=True,
            send_polls=True
        )
        await event.edit("✅ **تم إلغاء التقييد/الحظر عن العضو**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.المقيدين', outgoing=True))
async def list_restricted(event):
    chat_id = event.chat_id
    restricted_list = []
    
    try:
        async for user in client.iter_participants(chat_id):
            try:
                perms = await client.get_permissions(chat_id, user.id)
                if not perms.send_messages:
                    name = user.first_name or ""
                    username = f"@{user.username}" if user.username else "بدون"
                    restricted_list.append(f"• {name} ({username})")
            except:
                pass
        
        if restricted_list:
            text = "📋 **قائمة المقيدين:**\n\n" + "\n".join(restricted_list[:50])
        else:
            text = "✅ **لا يوجد أعضاء مقيدين**"
        
        await event.edit(text)
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.مسح المقيدين', outgoing=True))
async def clear_restricted(event):
    chat_id = event.chat_id
    count = 0
    
    try:
        async for user in client.iter_participants(chat_id):
            try:
                perms = await client.get_permissions(chat_id, user.id)
                if not perms.send_messages:
                    await client.edit_permissions(
                        chat_id, user.id,
                        send_messages=True, send_media=True,
                        send_stickers=True, send_gifs=True,
                        send_games=True, send_inline=True,
                        send_polls=True
                    )
                    count += 1
            except:
                pass
        
        await event.edit(f"✅ **تم إلغاء تقييد {count} عضو**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

# ==================== أوامر الحظر العام ====================
@client.on(events.NewMessage(pattern=r'\.حظر عام', outgoing=True))
async def gban_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة العضو**")
        return
    
    user = await reply.get_sender()
    user_id = user.id
    name = user.first_name or ""
    
    if user_id == (await client.get_me()).id:
        await event.edit("❌ **لا يمكنك حظر نفسك**")
        return
    
    if user_id in gbanned_users:
        await event.edit(f"⚠️ **{name} محظور عام بالفعل**")
        return
    
    gbanned_users[user_id] = name
    
    await event.edit("🔄 **جاري الحظر العام...**")
    
    count = 0
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            try:
                await client.edit_permissions(dialog.id, user_id, view_messages=False)
                count += 1
                await asyncio.sleep(0.5)
            except:
                pass
    
    await event.edit(f"✅ **تم حظر {name} عام من {count} مجموعة**")


@client.on(events.NewMessage(pattern=r'\.الغاء حظر عام', outgoing=True))
async def ungban_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة العضو**")
        return
    
    user = await reply.get_sender()
    user_id = user.id
    name = user.first_name or ""
    
    if user_id not in gbanned_users:
        await event.edit(f"⚠️ **{name} ليس محظوراً عام**")
        return
    
    del gbanned_users[user_id]
    
    await event.edit("🔄 **جاري الغاء الحظر العام...**")
    
    count = 0
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            try:
                await client.edit_permissions(
                    dialog.id, user_id,
                    send_messages=True, send_media=True,
                    send_stickers=True, send_gifs=True,
                    send_games=True, send_inline=True,
                    send_polls=True
                )
                count += 1
                await asyncio.sleep(0.5)
            except:
                pass
    
    await event.edit(f"✅ **تم الغاء حظر {name} عام من {count} مجموعة**")


@client.on(events.NewMessage(pattern=r'\.طرد عام', outgoing=True))
async def gkick_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة العضو**")
        return
    
    user = await reply.get_sender()
    user_id = user.id
    name = user.first_name or ""
    
    if user_id == (await client.get_me()).id:
        await event.edit("❌ **لا يمكنك طرد نفسك**")
        return
    
    await event.edit("🔄 **جاري الطرد العام...**")
    
    count = 0
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            try:
                await client.kick_participant(dialog.id, user_id)
                count += 1
                await asyncio.sleep(0.5)
            except:
                pass
    
    await event.edit(f"✅ **تم طرد {name} عام من {count} مجموعة**")


@client.on(events.NewMessage(pattern=r'\.المحظورين عام', outgoing=True))
async def list_gbanned(event):
    if not gbanned_users:
        await event.edit("✅ **لا يوجد محظورين عام**")
        return
    
    text = "🚫 **قائمة المحظورين عام:**\n\n"
    for user_id, name in gbanned_users.items():
        text += f"• [{name}](tg://user?id={user_id}) - `{user_id}`\n"
    
    await event.edit(text)


# ==================== أوامر المنشن ====================
@client.on(events.NewMessage(pattern=r'\.منشن', outgoing=True))
async def mention_commands(event):
    menu_text = """⟪───── أوامر المنشن الذكي ─────⟫

│ `.منشن الكل`
│ ← ينادي جميع الأعضاء

│ `.منشن المشرفين`
│ ← ينادي المشرفين فقط

│ `.منشن اونلاين`
│ ← ينادي الأعضاء المتصلين فقط

│ `.منشن بالتفاعل`
│ ← ينادي الأعضاء حسب تفاعلهم
╰─────────────────────────"""
    await event.edit(menu_text)

@client.on(events.NewMessage(pattern=r'\.منشن الكل', outgoing=True))
async def mention_all(event):
    chat_id = event.chat_id
    mentions = []
    
    try:
        async for user in client.iter_participants(chat_id):
            if not user.bot:
                name = user.first_name or ""
                mentions.append(f"[{name}](tg://user?id={user.id})")
                if len(mentions) >= 10:
                    text = "📢 **منشن الكل:**\n" + " • ".join(mentions)
                    await client.send_message(chat_id, text)
                    mentions = []
                    await asyncio.sleep(1)
        
        if mentions:
            text = "📢 **منشن الكل:**\n" + " • ".join(mentions)
            await client.send_message(chat_id, text)
        
        await event.delete()
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.منشن المشرفين', outgoing=True))
async def mention_admins(event):
    chat_id = event.chat_id
    mentions = []
    
    try:
        async for user in client.iter_participants(chat_id, filter=ChannelParticipantsAdmins):
            if not user.bot:
                name = user.first_name or ""
                mentions.append(f"[{name}](tg://user?id={user.id})")
        
        if mentions:
            text = "👑 **منشن المشرفين:**\n" + " • ".join(mentions)
            await client.send_message(chat_id, text)
        else:
            await event.edit("❌ **لا يوجد مشرفين**")
        
        await event.delete()
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.منشن اونلاين', outgoing=True))
async def mention_online(event):
    chat_id = event.chat_id
    mentions = []
    
    try:
        async for user in client.iter_participants(chat_id):
            if not user.bot and hasattr(user.status, 'was_online'):
                name = user.first_name or ""
                mentions.append(f"[{name}](tg://user?id={user.id})")
                if len(mentions) >= 20:
                    break
        
        if mentions:
            text = "🟢 **الأعضاء المتصلون:**\n" + " • ".join(mentions)
            await client.send_message(chat_id, text)
        else:
            await event.edit("❌ **لا يوجد أعضاء متصلون حالياً**")
        
        await event.delete()
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.منشن بالتفاعل', outgoing=True))
async def mention_by_activity(event):
    chat_id = event.chat_id
    mentions = []
    
    try:
        participants = []
        async for user in client.iter_participants(chat_id):
            if not user.bot:
                participants.append(user)
        
        participants.sort(key=lambda x: getattr(x.participant, 'date', 0) if hasattr(x, 'participant') else 0, reverse=True)
        
        for user in participants[:20]:
            name = user.first_name or ""
            mentions.append(f"[{name}](tg://user?id={user.id})")
        
        if mentions:
            text = "📊 **الأعضاء الأكثر تفاعلاً:**\n" + " • ".join(mentions)
            await client.send_message(chat_id, text)
        else:
            await event.edit("❌ **لا يوجد أعضاء**")
        
        await event.delete()
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

# ==================== كشف وطرد المحذوفين ====================
@client.on(events.NewMessage(pattern=r'\.كشف المحذوفين', outgoing=True))
async def detect_deleted(event):
    chat_id = event.chat_id
    deleted_count = 0
    
    await event.edit("🔍 **جاري فحص الأعضاء...**")
    
    try:
        async for user in client.iter_participants(chat_id):
            if user.deleted:
                deleted_count += 1
        
        await event.edit(f"👻 **عدد الحسابات المحذوفة:** {deleted_count}")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.اطرد المحذوفين', outgoing=True))
async def kick_deleted(event):
    chat_id = event.chat_id
    kicked_count = 0
    
    await event.edit("🚮 **جاري طرد الحسابات المحذوفة...**")
    
    try:
        async for user in client.iter_participants(chat_id):
            if user.deleted:
                try:
                    await client.kick_participant(chat_id, user.id)
                    kicked_count += 1
                except:
                    pass
        
        await event.edit(f"✅ **تم طرد {kicked_count} حساب محذوف**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

# ==================== مغادرة المجموعات والقنوات ====================
@client.on(events.NewMessage(pattern=r'\.مغادرة المجموعات', outgoing=True))
async def leave_groups(event):
    await event.edit("🚪 **جاري مغادرة المجموعات...**")
    
    count = 0
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            try:
                await client.delete_dialog(dialog.id)
                count += 1
            except:
                pass
    
    await event.edit(f"✅ **تمت مغادرة {count} مجموعة**")

@client.on(events.NewMessage(pattern=r'\.مغادرة القنوات', outgoing=True))
async def leave_channels(event):
    await event.edit("🚪 **جاري مغادرة القنوات...**")
    
    count = 0
    async for dialog in client.iter_dialogs():
        if dialog.is_channel and not dialog.is_group:
            try:
                await client.delete_dialog(dialog.id)
                count += 1
            except:
                pass
    
    await event.edit(f"✅ **تمت مغادرة {count} قناة**")

# ==================== الردود المخصصة ====================
@client.on(events.NewMessage(pattern=r'\.رد_مجموعة', outgoing=True))
async def enable_group_reply(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["replies_enabled"] = True
    await event.edit("✅ **تم تفعيل الردود المخصصة في المجموعة**")

@client.on(events.NewMessage(pattern=r'\.ايقاف_رد_مجموعة', outgoing=True))
async def disable_group_reply(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["replies_enabled"] = False
    await event.edit("🔴 **تم تعطيل الردود المخصصة في المجموعة**")

@client.on(events.NewMessage(pattern=r'\.تعيين_رد\s+(\S+)\s+([\s\S]+)', outgoing=True))
async def set_custom_reply(event):
    keyword = event.pattern_match.group(1).strip()
    reply_text = event.pattern_match.group(2).strip()
    chat_id = event.chat_id
    
    if chat_id not in custom_replies:
        custom_replies[chat_id] = {}
    
    custom_replies[chat_id][keyword] = reply_text
    await event.edit(f"✅ **تم تعيين رد:** `{keyword}` → `{reply_text[:50]}...`")

# ==================== عرض المجموعات والقنوات ====================
@client.on(events.NewMessage(pattern=r'\.كروباتي', outgoing=True))
async def my_groups(event):
    groups = []
    
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            groups.append(f"• {dialog.name}")
    
    if groups:
        text = "📋 **مجموعاتك:**\n\n" + "\n".join(groups[:50])
    else:
        text = "📭 **لا توجد مجموعات**"
    
    await event.edit(text)

@client.on(events.NewMessage(pattern=r'\.قنواتي', outgoing=True))
async def my_channels(event):
    channels = []
    
    async for dialog in client.iter_dialogs():
        if dialog.is_channel and not dialog.is_group:
            channels.append(f"• {dialog.name}")
    
    if channels:
        text = "📋 **قنواتك:**\n\n" + "\n".join(channels[:50])
    else:
        text = "📭 **لا توجد قنوات**"
    
    await event.edit(text)

# ==================== رفع المشرفين ====================
@client.on(events.NewMessage(pattern=r'\.رفع مشرف', outgoing=True))
async def promote_admin(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة العضو**")
        return
    
    user_id = reply.sender_id
    chat_id = event.chat_id
    
    rights = ChatAdminRights(
        change_info=False, delete_messages=True,
        invite_users=True, ban_users=False,
        pin_messages=True, add_admins=False
    )
    
    try:
        await client(EditAdminRequest(chat_id, user_id, rights, "مشرف"))
        await event.edit("✅ **تم رفع العضو مشرفاً محدود الصلاحيات**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

@client.on(events.NewMessage(pattern=r'\.رفع مشرف اساسي', outgoing=True))
async def promote_full_admin(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة العضو**")
        return
    
    user_id = reply.sender_id
    chat_id = event.chat_id
    
    rights = ChatAdminRights(
        change_info=True, delete_messages=True,
        invite_users=True, ban_users=True,
        pin_messages=True, add_admins=True
    )
    
    try:
        await client(EditAdminRequest(chat_id, user_id, rights, "مشرف اساسي"))
        await event.edit("✅ **تم رفع العضو مشرفاً كامل الصلاحيات**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)}")

# ==================== إنشاء مجموعات ====================
@client.on(events.NewMessage(pattern=r'\.انشاء مجموعات\s+(\d+)', outgoing=True))
async def create_groups(event):
    try:
        count = int(event.pattern_match.group(1).strip())
    except:
        await event.edit("❌ **يرجى إدخال رقم صحيح**")
        return

    if count > 10:
        await event.edit("❌ **الحد الأقصى 10 مجموعات**")
        return

    await event.edit("🔄 **جاري إنشاء المجموعات...**")

    links = []
    created_chats = []
    me = await client.get_me()

    for i in range(count):
        await event.edit(f"🔄 **جاري إنشاء المجموعة {i+1} من {count}...**")
        try:
            result = await client(CreateChatRequest(
                users=[],
                title="𝐒𝐨𝐮𝐫𝐜𝐞 𝐙𝐞𝐫𝐨"
            ))

            chat_id = result.chats[0].id
            created_chats.append(chat_id)

            # تعيين البايو
            try:
                await client(EditChatAboutRequest(
                    peer=chat_id,
                    about="⌯ هـذه المجموعة تم انشاؤها بواسـطة سورس زيرو"
                ))
            except:
                pass

            # إنشاء الرابط
            try:
                invite = await client(ExportChatInviteRequest(peer=chat_id))
                if hasattr(invite, 'link'):
                    link = invite.link
                else:
                    link = f"https://t.me/joinchat/{invite.invite_hash}"
                links.append(f"{i+1}. {link}")
            except:
                links.append(f"{i+1}. لم يتم إنشاء الرابط")

            await asyncio.sleep(3)

        except Exception as e:
            links.append(f"{i+1}. فشل - {str(e)[:30]}")

    # عرض كل الروابط في رسالة واحدة
    if links:
        text = "✅ **تـم انـشاء المجمـوعات التالـية :**\n\n" + "\n".join(links)
        await event.edit(text)

    if not created_chats:
        await event.edit("❌ **فشل انشاء جميع المجموعات**")
        return

    # إرسال الأرقام من 1 إلى 10 في كل مجموعة
    await event.edit("🔢 **جاري نشر الأرقام...**")
    for chat_id in created_chats:
        try:
            for num in range(1, 11):
                await client.send_message(chat_id, str(num))
                await asyncio.sleep(0.3)
        except:
            pass

    # مغادرة جميع المجموعات
    await event.edit("🚪 **جاري مغادرة المجموعات...**")
    left_count = 0
    for chat_id in created_chats:
        try:
            await client(DeleteChatUserRequest(chat_id=chat_id, user_id=me.id))
            left_count += 1
            await asyncio.sleep(1.5)
        except:
            pass

    # النتيجة النهائية
    await event.edit(
        f"✅ **تـم انـشاء {len(created_chats)} مجموعـة بنـجاح**\n\n"
        f"📌 **الروابط محفوظة في الأعلى**\n"
        f"🔢 **تـم نشر الارقـام**\n"
        f"🚪 **تـم مغادرة {left_count} مجموعة**"
    )

# ==================== أوامر الترحيب ====================
@client.on(events.NewMessage(pattern=r'\.اوامر الترحيب', outgoing=True))
async def welcome_commands(event):
    menu_text = """⟪───── أوامر الترحيب ─────⟫

│ `.تفعيل الترحيب`
│ ← لتفعيل رسالة ترحيب في المجموعة

│ `.تعطيل الترحيب`
│ ← لتعطيل رسالة الترحيب

│ `.تعيين الترحيب [النص]`
│ ← لتعيين نص ترحيب مخصص

│ `.ترحيب1` | `.ترحيب2` | `.ترحيب3`
│ ← قوالب ترحيب جاهزة
╰─────────────────────────"""
    await event.edit(menu_text)

@client.on(events.NewMessage(pattern=r'\.تفعيل الترحيب', outgoing=True))
async def enable_welcome(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["welcome_enabled"] = True
    await event.edit("✅ **تم تفعيل رسالة الترحيب في المجموعة**")

@client.on(events.NewMessage(pattern=r'\.تعطيل الترحيب', outgoing=True))
async def disable_welcome(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["welcome_enabled"] = False
    await event.edit("🔴 **تم تعطيل رسالة الترحيب**")

@client.on(events.NewMessage(pattern=r'\.تعيين الترحيب\s+([\s\S]+)', outgoing=True))
async def set_welcome_text(event):
    welcome_text = event.pattern_match.group(1).strip()
    chat_id = event.chat_id
    
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["welcome_text"] = welcome_text
    
    await event.edit(f"✅ **تم تعيين رسالة الترحيب:**\n\n{welcome_text[:200]}...")

@client.on(events.NewMessage(pattern=r'\.ترحيب1', outgoing=True))
async def welcome1(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["welcome_text"] = "👋 **أهلاً وسهلاً بك في المجموعة!**\nنتمنى لك وقتاً ممتعاً 🌹"
    await event.edit("✅ **تم تعيين قالب الترحيب 1**")

@client.on(events.NewMessage(pattern=r'\.ترحيب2', outgoing=True))
async def welcome2(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["welcome_text"] = "🌟 **مرحباً بالعضو الجديد!**\nنورت المجموعة ✨"
    await event.edit("✅ **تم تعيين قالب الترحيب 2**")

@client.on(events.NewMessage(pattern=r'\.ترحيب3', outgoing=True))
async def welcome3(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["welcome_text"] = "💫 **يا هلا والله!**\nانضم إلينا عضو جديد، فأهلاً وسهلاً 🎉"
    await event.edit("✅ **تم تعيين قالب الترحيب 3**")

@client.on(events.ChatAction)
async def welcome_handler(event):
    if event.user_joined or event.user_added:
        chat_id = event.chat_id
        user = await event.get_user()
        
        if chat_id in group_settings and group_settings[chat_id].get("welcome_enabled", False):
            welcome_text = group_settings[chat_id].get("welcome_text", "👋 **أهلاً وسهلاً بك في المجموعة!**")
            name = user.first_name or "عضو جديد"
            message = welcome_text.replace("{name}", name).replace("{mention}", f"[{name}](tg://user?id={user.id})")
            await client.send_message(chat_id, message)

# ==================== أوامر الحماية ====================
def init_group_settings(chat_id):
    if chat_id not in group_restrictions:
        group_restrictions[chat_id] = {
            "photos": False, "gifs": False, "stickers": False,
            "forwarded": False, "videos": False, "links": False,
            "voice": False, "chat": False
        }

@client.on(events.NewMessage(pattern=r'\.فعل الصور', outgoing=True))
async def enable_photos(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["photos"] = True
    await event.edit("🖼️ **تم تفعيل منع الصور**")

@client.on(events.NewMessage(pattern=r'\.عطل الصور', outgoing=True))
async def disable_photos(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["photos"] = False
    await event.edit("🖼️ **تم تعطيل منع الصور**")

@client.on(events.NewMessage(pattern=r'\.فعل المتحركة', outgoing=True))
async def enable_gifs(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["gifs"] = True
    await event.edit("🎬 **تم تفعيل منع المتحركة**")

@client.on(events.NewMessage(pattern=r'\.عطل المتحركة', outgoing=True))
async def disable_gifs(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["gifs"] = False
    await event.edit("🎬 **تم تعطيل منع المتحركة**")

@client.on(events.NewMessage(pattern=r'\.فعل الملصقات', outgoing=True))
async def enable_stickers(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["stickers"] = True
    await event.edit("🎯 **تم تفعيل منع الملصقات**")

@client.on(events.NewMessage(pattern=r'\.عطل الملصقات', outgoing=True))
async def disable_stickers(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["stickers"] = False
    await event.edit("🎯 **تم تعطيل منع الملصقات**")

@client.on(events.NewMessage(pattern=r'\.فعل التحويل', outgoing=True))
async def enable_forwarded(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["forwarded"] = True
    await event.edit("↪️ **تم تفعيل منع التحويل**")

@client.on(events.NewMessage(pattern=r'\.عطل التحويل', outgoing=True))
async def disable_forwarded(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["forwarded"] = False
    await event.edit("↪️ **تم تعطيل منع التحويل**")

@client.on(events.NewMessage(pattern=r'\.فعل الفيديوهات', outgoing=True))
async def enable_videos(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["videos"] = True
    await event.edit("🎥 **تم تفعيل منع الفيديوهات**")

@client.on(events.NewMessage(pattern=r'\.عطل الفيديوهات', outgoing=True))
async def disable_videos(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["videos"] = False
    await event.edit("🎥 **تم تعطيل منع الفيديوهات**")

@client.on(events.NewMessage(pattern=r'\.فعل الروابط', outgoing=True))
async def enable_links(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["links"] = True
    await event.edit("🔗 **تم تفعيل منع الروابط**")

@client.on(events.NewMessage(pattern=r'\.عطل الروابط', outgoing=True))
async def disable_links(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["links"] = False
    await event.edit("🔗 **تم تعطيل منع الروابط**")

@client.on(events.NewMessage(pattern=r'\.فعل البصمات', outgoing=True))
async def enable_voice(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["voice"] = True
    await event.edit("🎙️ **تم تفعيل منع البصمات**")

@client.on(events.NewMessage(pattern=r'\.عطل البصمات', outgoing=True))
async def disable_voice(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["voice"] = False
    await event.edit("🎙️ **تم تعطيل منع البصمات**")

@client.on(events.NewMessage(pattern=r'\.فعل الدردشة', outgoing=True))
async def enable_chat_lock(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["chat"] = True
    await event.edit("🔒 **تم قفل الدردشة**")

@client.on(events.NewMessage(pattern=r'\.عطل الدردشة', outgoing=True))
async def disable_chat_lock(event):
    chat_id = event.chat_id
    init_group_settings(chat_id)
    group_restrictions[chat_id]["chat"] = False
    await event.edit("🔓 **تم فتح الدردشة**")

# ==================== مراقبة الرسائل للحماية ====================
@client.on(events.NewMessage(incoming=True))
async def protection_handler(event):
    if not event.is_group:
        return
    
    chat_id = event.chat_id
    if chat_id not in group_restrictions:
        return
    
    settings = group_restrictions[chat_id]
    
    if settings.get("chat", False):
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("photos", False) and event.photo:
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("gifs", False) and (event.gif or event.video):
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("stickers", False) and event.sticker:
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("forwarded", False) and event.forward:
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("videos", False) and event.video:
        try:
            await event.delete()
        except:
            pass
        return
    
    if settings.get("links", False) and event.text:
        if "http://" in event.text or "https://" in event.text or "t.me/" in event.text:
            try:
                await event.delete()
            except:
                pass
            return
    
    if settings.get("voice", False) and event.voice:
        try:
            await event.delete()
        except:
            pass
        return