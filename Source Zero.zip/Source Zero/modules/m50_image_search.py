import os
import shutil
import asyncio
from telethon import events
from telethon.errors.rpcerrorlist import MediaEmptyError

from main import client

TMP_DOWNLOAD_DIRECTORY = "./temp"
if not os.path.isdir(TMP_DOWNLOAD_DIRECTORY):
    os.makedirs(TMP_DOWNLOAD_DIRECTORY)


# ==================== عرض قائمة الأوامر (.م50) ====================
@client.on(events.NewMessage(pattern=r'\.م50', outgoing=True))
async def show_image_search_menu(event):
    menu_text = """⟪───── أوامر البحث عن الصور ─────⟫

│ `.صور` + كلمة البحث
│ ← تنزيل 3 صور افتراضياً من جوجل
│ ← مثال: .صور قطط

│ `.صور` + عدد + كلمة البحث
│ ← تنزيل عدد محدد من الصور (1-10)
│ ← مثال: .صور 7 ورود

│ `.صور` بالرد على كلمة
│ ← البحث عن الصور بالرد على رسالة

ملاحظة:
↢ الصور تُحمل من Google Images
↢ الحد الأقصى للتحميل 10 صور
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== أمر .صور ====================
@client.on(events.NewMessage(pattern=r'\.صور(?: |$)(\d*)? ?([\s\S]*)', outgoing=True))
async def img_sampler(event):
    """للبحث عن الصور من جوجل"""
    
    # تحديد الاستعلام
    if event.is_reply and not event.pattern_match.group(2):
        reply = await event.get_reply_message()
        query = str(reply.message)
    else:
        query = str(event.pattern_match.group(2))
    
    if not query:
        await event.edit("✘ **يرجى كتابة كلمة البحث أو الرد على رسالة**")
        return
    
    # تحديد عدد الصور
    if event.pattern_match.group(1) != "":
        lim = int(event.pattern_match.group(1))
        if lim > 10:
            lim = 10
        if lim <= 0:
            lim = 1
    else:
        lim = 3
    
    await event.edit(f"⎙ **جاري البحث عن {lim} صور...**")
    
    try:
        from google_images_download import google_images_download
        response = google_images_download.googleimagesdownload()
        
        arguments = {
            "keywords": query.replace(",", " "),
            "limit": lim,
            "format": "jpg",
            "no_directory": "no_directory",
            "output_directory": TMP_DOWNLOAD_DIRECTORY,
        }
        
        paths = response.download(arguments)
        lst = paths[0][query.replace(",", " ")]
        
        if lst:
            try:
                await event.client.send_file(event.chat_id, lst, reply_to=event.message.id)
            except MediaEmptyError:
                for i in lst:
                    try:
                        await event.client.send_file(event.chat_id, i, reply_to=event.message.id)
                    except MediaEmptyError:
                        pass
            
            # حذف الملفات المؤقتة
            if lst and os.path.exists(os.path.dirname(os.path.abspath(lst[0]))):
                shutil.rmtree(os.path.dirname(os.path.abspath(lst[0])))
            
            await event.delete()
        else:
            await event.edit("✘ **لم يتم العثور على صور**")
    
    except ImportError:
        await event.edit("✘ **المكتبة غير مثبتة**\n⌔ **قم بتثبيت:** `pip install google_images_download`")
    
    except Exception as e:
        await event.edit(f"✘ **خطأ:** {str(e)}")


# ==================== أمر تثبيت المكتبة ====================
@client.on(events.NewMessage(pattern=r'\.تثبيت بحث الصور', outgoing=True))
async def install_image_search(event):
    """تثبيت مكتبة البحث عن الصور"""
    await event.edit("⎙ **جاري تثبيت مكتبة البحث عن الصور...**")
    
    try:
        process = await asyncio.create_subprocess_shell(
            "pip install google_images_download",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        
        if process.returncode == 0:
            await event.edit("✓ **تم تثبيت المكتبة بنجاح**\n⌔ **يمكنك الآن استخدام** `.صور`")
        else:
            await event.edit(f"✘ **فشل التثبيت:** {stderr.decode()}")
    
    except Exception as e:
        await event.edit(f"✘ **خطأ:** {str(e)}")