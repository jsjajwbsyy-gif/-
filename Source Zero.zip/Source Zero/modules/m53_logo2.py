import os
import random
import string
from telethon import events
from telethon.tl.types import InputMessagesFilterDocument, InputMessagesFilterPhotos
from PIL import Image, ImageDraw, ImageFont, ImageOps

from main import client

PICS_STR = []

try:
    import arabic_reshaper
except ModuleNotFoundError:
    os.system("pip3 install arabic_reshaper")
    import arabic_reshaper

# القنوات الافتراضية
FONT_CHANNEL_EN = "@T_Taiz"
FONT_CHANNEL_AR = "@S_SSQ"
PICS_CHANNEL = "@Z_44_Z"


def get_setting(key, default):
    try:
        with open("logo_channels.txt", "r") as f:
            for line in f:
                if line.startswith(key + "="):
                    return line.split("=", 1)[1].strip()
    except:
        pass
    return default


def save_setting(key, value):
    settings = {}
    try:
        with open("logo_channels.txt", "r") as f:
            for line in f:
                if "=" in line:
                    k, v = line.split("=", 1)
                    settings[k.strip()] = v.strip()
    except:
        pass
    settings[key] = str(value)
    with open("logo_channels.txt", "w") as f:
        for k, v in settings.items():
            f.write(f"{k}={v}\n")


# ==================== عرض قائمة الأوامر (.م54) ====================
@client.on(events.NewMessage(pattern=r'\.م53', outgoing=True))
async def show_logo2_menu(event):
    menu_text = """⟪───── أوامر اللوجوهات السريعة ─────⟫

│ `.لوكو` + نص إنجليزي
│ ← صنع لوجو إنجليزي على صورة عشوائية
│ ← مثال: .لوكو Repthon

│ `.لوقو` + نص عربي
│ ← صنع لوجو عربي على صورة عشوائية
│ ← مثال: .لوقو ريبثون

│ `.لوكو` / `.لوقو` بالرد على صورة
│ ← صنع لوجو على صورة محددة

◈ أوامر إدارة القنوات:

│ `.قناة_الخط_انجليزي` + @يوزر
│ ← تغيير قناة الخطوط الإنجليزية

│ `.قناة_الخط_عربي` + @يوزر
│ ← تغيير قناة الخطوط العربية

│ `.قناة_الصور` + @يوزر
│ ← تغيير قناة صور الخلفيات

│ `.عرض_القنوات`
│ ← عرض القنوات الحالية

│ `.حذف_القنوات`
│ ← إعادة القنوات للافتراضية
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== دوال مساعدة منقولة ====================

def convert_toimage(image, filename=None):
    filename = filename or os.path.join("./temp/", "temp.jpg")
    img = Image.open(image)
    if img.mode != "RGB":
        img = img.convert("RGB")
    img.save(filename, "jpeg")
    os.remove(image)
    return filename


def convert_tosticker(response, filename=None):
    filename = filename or os.path.join("./temp/", "temp.webp")
    image = Image.open(response)
    if image.mode != "RGB":
        image.convert("RGB")
    image.save(filename, "webp")
    os.remove(response)
    return filename


async def invert_colors(imagefile, endname):
    image = Image.open(imagefile)
    inverted_image = ImageOps.invert(image)
    inverted_image.save(endname)


async def flip_image(imagefile, endname):
    image = Image.open(imagefile)
    inverted_image = ImageOps.flip(image)
    inverted_image.save(endname)


async def grayscale(imagefile, endname):
    image = Image.open(imagefile)
    inverted_image = ImageOps.grayscale(image)
    inverted_image.save(endname)


async def mirror_file(imagefile, endname):
    image = Image.open(imagefile)
    inverted_image = ImageOps.mirror(image)
    inverted_image.save(endname)


async def solarize(imagefile, endname):
    image = Image.open(imagefile)
    inverted_image = ImageOps.solarize(image, threshold=128)
    inverted_image.save(endname)


async def add_frame(imagefile, endname, x, color):
    image = Image.open(imagefile)
    inverted_image = ImageOps.expand(image, border=x, fill=color)
    inverted_image.save(endname)


async def crop(imagefile, endname, x):
    image = Image.open(imagefile)
    inverted_image = ImageOps.crop(image, border=x)
    inverted_image.save(endname)


async def get_font_file(channel_id):
    font_file_message_s = await client.get_messages(
        entity=channel_id,
        filter=InputMessagesFilterDocument,
        limit=None,
    )
    font_file_message = random.choice(font_file_message_s)
    return await client.download_media(font_file_message)


def has_arabic(text):
    return any(char.isalpha() and char not in string.ascii_letters for char in text)


async def create_logo_image(event, text, is_arabic):
    me = await client.get_me()
    my_mention = f"[{me.first_name}](tg://user?id={me.id})"

    font_channel = get_setting("FONT_CHANNEL_AR", FONT_CHANNEL_AR) if is_arabic else get_setting("FONT_CHANNEL_EN", FONT_CHANNEL_EN)
    pics_channel = get_setting("PICS_CHANNEL", PICS_CHANNEL)

    try:
        rep_font = await get_font_file(font_channel)
    except Exception:
        await event.edit(f"✘ **فشل جلب الخط من {font_channel}**\n⌔ تأكد من توفر القناة أو غيرها")
        return None, None

    if event.reply_to_msg_id:
        rply = await event.get_reply_message()
        logo_ = await rply.download_media()
    else:
        try:
            PICS_STR.clear()
            async for i in client.iter_messages(pics_channel, filter=InputMessagesFilterPhotos):
                PICS_STR.append(i)
            if not PICS_STR:
                await event.edit(f"✘ **لا توجد صور في {pics_channel}**\n⌔ تأكد من توفر القناة أو غيرها بـ `.قناة_الصور`")
                return None, None
            pic = random.choice(PICS_STR)
            logo_ = await pic.download_media()
        except Exception:
            await event.edit(f"✘ **فشل جلب الصور من {pics_channel}**\n⌔ تأكد من توفر القناة أو غيرها بـ `.قناة_الصور`")
            return None, None

    if len(text) <= 8:
        font_size_ = 150
        strik = 10
    elif len(text) >= 9:
        font_size_ = 50
        strik = 5
    else:
        font_size_ = 130
        strik = 20

    img = Image.open(logo_)
    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype(rep_font, font_size_)
    image_width, image_height = img.size
    w, h = draw.textsize(text, font=font)
    h += int(h * 0.21)

    draw.text(
        ((image_width - w) / 2, (image_height - h) / 2),
        text,
        font=font,
        fill=(255, 255, 255),
    )
    w_ = (image_width - w) / 2
    h_ = (image_height - h) / 2
    draw.text(
        (w_, h_), text, font=font, fill="white", stroke_width=strik, stroke_fill="black"
    )

    file_name = "logo_output.png"
    img.save(file_name, "png")
    return file_name, my_mention


# ==================== أمر .قناة_الخط_انجليزي ====================
@client.on(events.NewMessage(pattern=r'\.قناة_الخط_انجليزي\s+(@\w+)', outgoing=True))
async def set_font_channel_en(event):
    channel = event.pattern_match.group(1).strip()
    save_setting("FONT_CHANNEL_EN", channel)
    await event.edit(f"✓ **تم تغيير قناة الخطوط الإنجليزية إلى:** {channel}")


# ==================== أمر .قناة_الخط_عربي ====================
@client.on(events.NewMessage(pattern=r'\.قناة_الخط_عربي\s+(@\w+)', outgoing=True))
async def set_font_channel_ar(event):
    channel = event.pattern_match.group(1).strip()
    save_setting("FONT_CHANNEL_AR", channel)
    await event.edit(f"✓ **تم تغيير قناة الخطوط العربية إلى:** {channel}")


# ==================== أمر .قناة_الصور ====================
@client.on(events.NewMessage(pattern=r'\.قناة_الصور\s+(@\w+)', outgoing=True))
async def set_pics_channel(event):
    channel = event.pattern_match.group(1).strip()
    save_setting("PICS_CHANNEL", channel)
    await event.edit(f"✓ **تم تغيير قناة صور الخلفيات إلى:** {channel}")


# ==================== أمر .عرض_القنوات ====================
@client.on(events.NewMessage(pattern=r'\.عرض_القنوات', outgoing=True))
async def show_channels(event):
    font_en = get_setting("FONT_CHANNEL_EN", FONT_CHANNEL_EN)
    font_ar = get_setting("FONT_CHANNEL_AR", FONT_CHANNEL_AR)
    pics_ch = get_setting("PICS_CHANNEL", PICS_CHANNEL)
    
    text = f"""◈ **القنوات الحالية للوجوهات:**

⦁ **الخطوط الإنجليزية:** {font_en}
⦁ **الخطوط العربية:** {font_ar}
⦁ **صور الخلفيات:** {pics_ch}

⌔ **للتغيير:**
`.قناة_الخط_انجليزي` + @يوزر
`.قناة_الخط_عربي` + @يوزر
`.قناة_الصور` + @يوزر"""
    await event.edit(text)


# ==================== أمر .حذف_القنوات ====================
@client.on(events.NewMessage(pattern=r'\.حذف_القنوات', outgoing=True))
async def reset_channels(event):
    if os.path.exists("logo_channels.txt"):
        os.remove("logo_channels.txt")
    await event.edit("⌫ **تم إعادة القنوات للوضع الافتراضي**")


# ==================== أمر .لوكو (إنجليزي) ====================
@client.on(events.NewMessage(pattern=r'\.لوكو ?(.*)', outgoing=True))
async def make_logo_english(event):
    await event.edit("⎙ **جـارِ صنـع لـوجـو انجليزي...**")
    
    text = event.pattern_match.group(1)
    if not text:
        await event.edit("✘ **يرجى كتابة نص مع الأمر**\n⌔ **مثال:** `.لوكو Repthon`")
        return
    
    if has_arabic(text):
        await event.edit("✘ **هذا النص يحتوي على حروف عربية**\n⌔ **استخدم:** `.لوقو` **للنص العربي**")
        return
    
    file_name, my_mention = await create_logo_image(event, text, False)
    if not file_name:
        return
    
    await client.send_file(
        event.chat_id,
        file_name,
        caption=f"✓ **تم صنـع لـوجـو انجليزي بنجاح**\n⌔ **حقـوق:** {my_mention}\n⌔ **سورس زيرو**",
        reply_to=event.message.id,
    )
    await event.delete()
    
    try:
        os.remove(file_name)
    except:
        pass


# ==================== أمر .لوقو (عربي) ====================
@client.on(events.NewMessage(pattern=r'\.لوقو ?(.*)', outgoing=True))
async def make_logo_arabic(event):
    await event.edit("⎙ **جـارِ صنـع لـوجـو عربي...**")
    
    text = event.pattern_match.group(1)
    if not text:
        await event.edit("✘ **يرجى كتابة نص مع الأمر**\n⌔ **مثال:** `.لوقو ريبثون`")
        return
    
    if not has_arabic(text):
        await event.edit("✘ **هذا النص لا يحتوي على حروف عربية**\n⌔ **استخدم:** `.لوكو` **للنص الإنجليزي**")
        return
    
    file_name, my_mention = await create_logo_image(event, text, True)
    if not file_name:
        return
    
    await client.send_file(
        event.chat_id,
        file_name,
        caption=f"✓ **تم صنـع لـوجـو عربي بنجاح**\n⌔ **حقـوق:** {my_mention}\n⌔ **سورس زيرو**",
        reply_to=event.message.id,
    )
    await event.delete()
    
    try:
        os.remove(file_name)
    except:
        pass