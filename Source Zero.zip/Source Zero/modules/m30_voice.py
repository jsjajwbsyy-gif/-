import os
import asyncio
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

voice_settings = {}

DEFAULT_VOICE_BOT = "@VoiceBot"

# ==================== عرض قائمة الأوامر (.م31) ====================
@client.on(events.NewMessage(pattern=r'\.م30', outgoing=True))
async def show_voice_menu(event):
    menu_text = """⟪───── أوامر البصمات ─────⟫

│ `.بصمة + نص`
│ ← يحول النص إلى رسالة صوتية

│ `.بصمة بالرد`
│ ← بالرد على نص، يحوله إلى بصمة

│ `.دمج بصمة`
│ ← بالرد على بصمتين، يجمعهما معاً

│ `.عكس بصمة`
│ ← بالرد على بصمة، يعكسها

│ `.بطء بصمة`
│ ← بالرد على بصمة، يبطئ سرعتها

│ `.سرعة بصمة`
│ ← بالرد على بصمة، يسرعها

│ `.رفع بصمة`
│ ← بالرد على بصمة، يرفعها ويعطيك رابطاً

│ `.تنزيل بصمة`
│ ← بالرد على بصمة، ينزلها كملف MP3

│ `.بصمة مضحكة`
│ ← بالرد على بصمة، يحولها لصوت مضحك

│ `.بصمة شبح`
│ ← بالرد على بصمة، ترسل كرسالة ذاتية التدمير

│ `.تبديل البصمة`
│ ← لتغيير بوت تحويل النص إلى صوت

╰─────────────────────────"""
    await event.edit(menu_text)

# ========== أمر .بصمة + نص ==========
@client.on(events.NewMessage(pattern=r'\.بصمة\s+([\s\S]+)', outgoing=True))
async def text_to_voice(event):
    text = event.pattern_match.group(1).strip()
    chat_id = event.chat_id
    user_id = event.sender_id
    
    voice_bot = voice_settings.get(user_id, {}).get("bot", DEFAULT_VOICE_BOT)
    
    await event.edit(f"🎙️ **جاري تحويل النص إلى بصمة...**")
    
    try:
        async with client.conversation(voice_bot, timeout=60) as conv:
            await conv.send_message(text)
            
            while True:
                response = await conv.get_response(timeout=30)
                
                if response.voice:
                    await client.send_file(chat_id, response.voice)
                    await event.delete()
                    break
                elif response.audio:
                    await client.send_file(chat_id, response.audio)
                    await event.delete()
                    break
                elif response.text:
                    if "error" in response.text.lower() or "خطأ" in response.text:
                        await event.edit(f"❌ **خطأ:** {response.text[:100]}")
                        break
                continue
                
    except Exception as e:
        await event.edit(f"❌ **فشل التحويل:** {str(e)[:100]}")

# ========== أمر .بصمة بالرد ==========
@client.on(events.NewMessage(pattern=r'\.بصمة بالرد', outgoing=True))
async def reply_to_voice(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على رسالة نصية**")
        return
    
    text = reply.text.strip()
    chat_id = event.chat_id
    user_id = event.sender_id
    
    voice_bot = voice_settings.get(user_id, {}).get("bot", DEFAULT_VOICE_BOT)
    
    await event.edit(f"🎙️ **جاري تحويل النص إلى بصمة...**")
    
    try:
        async with client.conversation(voice_bot, timeout=60) as conv:
            await conv.send_message(text)
            
            while True:
                response = await conv.get_response(timeout=30)
                
                if response.voice:
                    await client.send_file(chat_id, response.voice)
                    await event.delete()
                    break
                elif response.audio:
                    await client.send_file(chat_id, response.audio)
                    await event.delete()
                    break
                elif response.text:
                    if "error" in response.text.lower() or "خطأ" in response.text:
                        await event.edit(f"❌ **خطأ:** {response.text[:100]}")
                        break
                continue
                
    except Exception as e:
        await event.edit(f"❌ **فشل التحويل:** {str(e)[:100]}")

# ========== أمر .دمج بصمة ==========
@client.on(events.NewMessage(pattern=r'\.دمج بصمة', outgoing=True))
async def merge_voices(event):
    await event.edit("🔄 **هذه الميزة تحتاج إلى مكتبة pydub**\n📌 قم بتثبيتها: `pip install pydub`")

# ========== أمر .عكس بصمة ==========
@client.on(events.NewMessage(pattern=r'\.عكس بصمة', outgoing=True))
async def reverse_voice(event):
    reply = await event.get_reply_message()
    if not reply or not reply.voice:
        await event.edit("❌ **يرجى الرد على بصمة صوتية**")
        return
    
    await event.edit("🔄 **جاري عكس البصمة...**")
    
    try:
        voice_path = await client.download_media(reply.voice)
        
        try:
            from pydub import AudioSegment
            audio = AudioSegment.from_file(voice_path)
            reversed_audio = audio.reverse()
            output_path = "reversed_voice.mp3"
            reversed_audio.export(output_path, format="mp3")
            
            await client.send_file(event.chat_id, output_path, voice_note=True)
            await event.delete()
            
            os.remove(voice_path)
            os.remove(output_path)
        except ImportError:
            await event.edit("❌ **مكتبة pydub غير مثبتة**\n📌 قم بتثبيتها: `pip install pydub`")
            
    except Exception as e:
        await event.edit(f"❌ **فشل العكس:** {str(e)[:100]}")

# ========== أمر .بطء بصمة ==========
@client.on(events.NewMessage(pattern=r'\.بطء بصمة', outgoing=True))
async def slow_voice(event):
    reply = await event.get_reply_message()
    if not reply or not reply.voice:
        await event.edit("❌ **يرجى الرد على بصمة صوتية**")
        return
    
    await event.edit("🐢 **جاري إبطاء البصمة...**")
    
    try:
        voice_path = await client.download_media(reply.voice)
        
        try:
            from pydub import AudioSegment
            audio = AudioSegment.from_file(voice_path)
            slowed = audio._spawn(audio.raw_data, overrides={"frame_rate": int(audio.frame_rate * 0.7)})
            output_path = "slow_voice.mp3"
            slowed.export(output_path, format="mp3")
            
            await client.send_file(event.chat_id, output_path, voice_note=True)
            await event.delete()
            
            os.remove(voice_path)
            os.remove(output_path)
        except ImportError:
            await event.edit("❌ **مكتبة pydub غير مثبتة**\n📌 قم بتثبيتها: `pip install pydub`")
            
    except Exception as e:
        await event.edit(f"❌ **فشل الإبطاء:** {str(e)[:100]}")

# ========== أمر .سرعة بصمة ==========
@client.on(events.NewMessage(pattern=r'\.سرعة بصمة', outgoing=True))
async def fast_voice(event):
    reply = await event.get_reply_message()
    if not reply or not reply.voice:
        await event.edit("❌ **يرجى الرد على بصمة صوتية**")
        return
    
    await event.edit("🐇 **جاري تسريع البصمة...**")
    
    try:
        voice_path = await client.download_media(reply.voice)
        
        try:
            from pydub import AudioSegment
            audio = AudioSegment.from_file(voice_path)
            sped = audio._spawn(audio.raw_data, overrides={"frame_rate": int(audio.frame_rate * 1.5)})
            output_path = "fast_voice.mp3"
            sped.export(output_path, format="mp3")
            
            await client.send_file(event.chat_id, output_path, voice_note=True)
            await event.delete()
            
            os.remove(voice_path)
            os.remove(output_path)
        except ImportError:
            await event.edit("❌ **مكتبة pydub غير مثبتة**\n📌 قم بتثبيتها: `pip install pydub`")
            
    except Exception as e:
        await event.edit(f"❌ **فشل التسريع:** {str(e)[:100]}")

# ========== أمر .رفع بصمة ==========
@client.on(events.NewMessage(pattern=r'\.رفع بصمة', outgoing=True))
async def upload_voice(event):
    reply = await event.get_reply_message()
    if not reply or not reply.voice:
        await event.edit("❌ **يرجى الرد على بصمة صوتية**")
        return
    
    await event.edit("📤 **جاري رفع البصمة...**")
    
    try:
        voice_path = await client.download_media(reply.voice)
        
        try:
            import requests
            files = {'file': open(voice_path, 'rb')}
            response = requests.post('https://transfer.sh/', files=files)
            
            if response.status_code == 200:
                link = response.text.strip()
                await event.edit(f"**تم رفع البصمة:**\n\n{link} ✓")
            else:
                await event.edit("❌ **فشل الرفع**")
                
            os.remove(voice_path)
        except:
            await event.edit(f"📎 **رابط البصمة:**\n\nيمكنك إرسالها لأي شخص")
            
    except Exception as e:
        await event.edit(f"❌ **فشل الرفع:** {str(e)[:100]}")

# ========== أمر .تنزيل بصمة ==========
@client.on(events.NewMessage(pattern=r'\.تنزيل بصمة', outgoing=True))
async def download_voice(event):
    reply = await event.get_reply_message()
    if not reply or not reply.voice:
        await event.edit("❌ **يرجى الرد على بصمة صوتية**")
        return
    
    await event.edit("📥 **جاري تنزيل البصمة...**")
    
    try:
        voice_path = await client.download_media(reply.voice)
        await client.send_file(event.chat_id, voice_path, caption="تم تنزيل البصمة ✓")
        await event.delete()
        os.remove(voice_path)
        
    except Exception as e:
        await event.edit(f"❌ **فشل التنزيل:** {str(e)[:100]}")

# ========== أمر .بصمة مضحكة ==========
@client.on(events.NewMessage(pattern=r'\.بصمة مضحكة', outgoing=True))
async def funny_voice(event):
    reply = await event.get_reply_message()
    if not reply or not reply.voice:
        await event.edit("❌ **يرجى الرد على بصمة صوتية**")
        return
    
    await event.edit("🤡 **جاري تحويل البصمة...**")
    
    try:
        voice_path = await client.download_media(reply.voice)
        
        try:
            from pydub import AudioSegment
            audio = AudioSegment.from_file(voice_path)
            chipmunk = audio._spawn(audio.raw_data, overrides={"frame_rate": int(audio.frame_rate * 2.0)})
            output_path = "funny_voice.mp3"
            chipmunk.export(output_path, format="mp3")
            
            await client.send_file(event.chat_id, output_path, voice_note=True)
            await event.delete()
            
            os.remove(voice_path)
            os.remove(output_path)
        except ImportError:
            await event.edit("❌ **مكتبة pydub غير مثبتة**\n📌 قم بتثبيتها: `pip install pydub`")
            
    except Exception as e:
        await event.edit(f"❌ **فشل التحويل:** {str(e)[:100]}")

# ========== أمر .بصمة شبح ==========
@client.on(events.NewMessage(pattern=r'\.بصمة شبح', outgoing=True))
async def ghost_voice(event):
    reply = await event.get_reply_message()
    if not reply or not reply.voice:
        await event.edit("❌ **يرجى الرد على بصمة صوتية**")
        return
    
    await event.edit("👻 **جاري إرسال بصمة شبح...**")
    
    try:
        voice_path = await client.download_media(reply.voice)
        
        await client.send_file(
            event.chat_id,
            voice_path,
            voice_note=True,
            ttl=86400  # تختفي بعد يوم
        )
        await event.delete()
        
        os.remove(voice_path)
        
    except Exception as e:
        await event.edit(f"❌ **فشل الإرسال:** {str(e)[:100]}")

# ========== أمر .تبديل البصمة ==========
@client.on(events.NewMessage(pattern=r'\.تبديل البصمة\s+(@\w+)', outgoing=True))
async def switch_voice_bot(event):
    bot_username = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    if user_id not in voice_settings:
        voice_settings[user_id] = {}
    
    voice_settings[user_id]["bot"] = bot_username
    
    await event.edit(f"**تم تغيير بوت البصمات إلى:** {bot_username} ✓")