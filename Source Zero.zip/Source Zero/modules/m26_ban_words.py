from datetime import datetime, timedelta
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

banned_words = {}

# ==================== عرض قائمة الأوامر (.م26) ====================
@client.on(events.NewMessage(pattern=r'\.م26', outgoing=True))
async def show_ban_words_menu(event):
    menu_text = """⟪───── أوامر المنع ─────⟫

│ `.منع`
│ ← لمنع كلمة أو جملة في المجموعة (الحذف فقط)
│ ← مثال: رد على كلمة ثم أرسل .منع

│ `.منع بالتقييد`
│ ← لمنع كلمة مع تقييد المستخدم لمدة يوم
│ ← مثال: رد على كلمة ثم أرسل .منع بالتقييد

│ `.منع بالطرد`
│ ← لمنع كلمة مع طرد المستخدم
│ ← مثال: رد على كلمة ثم أرسل .منع بالطرد

│ `.منع بالحظر`
│ ← لمنع كلمة مع حظر المستخدم
│ ← مثال: رد على كلمة ثم أرسل .منع بالحظر

│ `.الغاء المنع`
│ ← لإلغاء منع كلمة
│ ← مثال: رد على كلمة ثم أرسل .الغاء المنع

│ `.قائمة المنع`
│ ← عرض قائمة الكلمات الممنوعة

│ `.مسح قائمة المنع`
│ ← حذف جميع الكلمات الممنوعة

│ `.منع كلمة + الكلمة`
│ ← لمنع كلمة بدون رد (حذف فقط)

│ `.الغاء منع كلمة + الكلمة`
│ ← لإلغاء منع كلمة بدون رد
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== دالة مساعدة: تهيئة قائمة المنع ====================
def init_banned_words(chat_id):
    if chat_id not in banned_words:
        banned_words[chat_id] = {}

# ==================== 1. أمر .منع (حذف فقط) ====================
@client.on(events.NewMessage(pattern=r'\.منع$', outgoing=True))
async def ban_word_delete(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على الكلمة التي تريد منعها**")
        return
    
    word = reply.text.strip()
    chat_id = event.chat_id
    
    init_banned_words(chat_id)
    
    if word in banned_words[chat_id]:
        await event.edit(f"❌ **الكلمة منعت بالفعل:** `{word}`")
        return
    
    banned_words[chat_id][word] = {
        "action": "delete",
        "added_by": event.sender_id,
        "added_at": datetime.now()
    }
    
    await event.edit(f"✅ **تم منع الكلمة (حذف فقط):** `{word}`")

# ==================== 2. أمر .منع بالتقييد ====================
@client.on(events.NewMessage(pattern=r'\.منع بالتقييد', outgoing=True))
async def ban_word_restrict(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على الكلمة التي تريد منعها**")
        return
    
    word = reply.text.strip()
    chat_id = event.chat_id
    
    init_banned_words(chat_id)
    
    if word in banned_words[chat_id]:
        await event.edit(f"❌ **الكلمة منعت بالفعل:** `{word}`")
        return
    
    banned_words[chat_id][word] = {
        "action": "restrict",
        "added_by": event.sender_id,
        "added_at": datetime.now()
    }
    
    await event.edit(f"✅ **تم منع الكلمة مع تقييد المستخدم لمدة يوم:** `{word}`")

# ==================== 3. أمر .منع بالطرد ====================
@client.on(events.NewMessage(pattern=r'\.منع بالطرد', outgoing=True))
async def ban_word_kick(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على الكلمة التي تريد منعها**")
        return
    
    word = reply.text.strip()
    chat_id = event.chat_id
    
    init_banned_words(chat_id)
    
    if word in banned_words[chat_id]:
        await event.edit(f"❌ **الكلمة منعت بالفعل:** `{word}`")
        return
    
    banned_words[chat_id][word] = {
        "action": "kick",
        "added_by": event.sender_id,
        "added_at": datetime.now()
    }
    
    await event.edit(f"✅ **تم منع الكلمة مع طرد المستخدم:** `{word}`")

# ==================== 4. أمر .منع بالحظر ====================
@client.on(events.NewMessage(pattern=r'\.منع بالحظر', outgoing=True))
async def ban_word_ban(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على الكلمة التي تريد منعها**")
        return
    
    word = reply.text.strip()
    chat_id = event.chat_id
    
    init_banned_words(chat_id)
    
    if word in banned_words[chat_id]:
        await event.edit(f"❌ **الكلمة منعت بالفعل:** `{word}`")
        return
    
    banned_words[chat_id][word] = {
        "action": "ban",
        "added_by": event.sender_id,
        "added_at": datetime.now()
    }
    
    await event.edit(f"🚫 **تم منع الكلمة مع حظر المستخدم:** `{word}`")

# ==================== 5. أمر .الغاء المنع ====================
@client.on(events.NewMessage(pattern=r'\.الغاء المنع', outgoing=True))
async def unban_word(event):
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على الكلمة التي تريد إلغاء منعها**")
        return
    
    word = reply.text.strip()
    chat_id = event.chat_id
    
    init_banned_words(chat_id)
    
    if word not in banned_words[chat_id]:
        await event.edit(f"❌ **الكلمة ليست ممنوعة:** `{word}`")
        return
    
    del banned_words[chat_id][word]
    
    await event.edit(f"✅ **تم إلغاء منع الكلمة:** `{word}`")

# ==================== 6. أمر .قائمة المنع ====================
@client.on(events.NewMessage(pattern=r'\.قائمة المنع', outgoing=True))
async def list_banned_words(event):
    chat_id = event.chat_id
    init_banned_words(chat_id)
    
    if not banned_words[chat_id]:
        await event.edit("📭 **لا توجد كلمات ممنوعة في هذه المجموعة**")
        return
    
    text = "🚫 **قائمة الكلمات الممنوعة:**\n\n"
    
    action_names = {
        "delete": "🗑 حذف",
        "restrict": "🔒 تقييد يوم",
        "kick": "👢 طرد",
        "ban": "🚫 حظر"
    }
    
    for i, (word, data) in enumerate(banned_words[chat_id].items(), 1):
        action = action_names.get(data["action"], data["action"])
        text += f"{i}. `{word}` - {action}\n"
    
    text += f"\n📊 **إجمالي الكلمات الممنوعة:** {len(banned_words[chat_id])}"
    
    await event.edit(text)

# ==================== 7. أمر .مسح قائمة المنع ====================
@client.on(events.NewMessage(pattern=r'\.مسح قائمة المنع', outgoing=True))
async def clear_banned_words(event):
    chat_id = event.chat_id
    init_banned_words(chat_id)
    
    count = len(banned_words[chat_id])
    banned_words[chat_id] = {}
    
    await event.edit(f"🗑 **تم مسح جميع الكلمات الممنوعة ({count} كلمة)**")

# ==================== 8. أمر .منع كلمة (بدون رد) ====================
@client.on(events.NewMessage(pattern=r'\.منع كلمة\s+([\s\S]+)', outgoing=True))
async def ban_word_direct(event):
    word = event.pattern_match.group(1).strip()
    chat_id = event.chat_id
    
    init_banned_words(chat_id)
    
    if word in banned_words[chat_id]:
        await event.edit(f"❌ **الكلمة منعت بالفعل:** `{word}`")
        return
    
    banned_words[chat_id][word] = {
        "action": "delete",
        "added_by": event.sender_id,
        "added_at": datetime.now()
    }
    
    await event.edit(f"✅ **تم منع الكلمة (حذف فقط):** `{word}`")

# ==================== 9. أمر .الغاء منع كلمة (بدون رد) ====================
@client.on(events.NewMessage(pattern=r'\.الغاء منع كلمة\s+([\s\S]+)', outgoing=True))
async def unban_word_direct(event):
    word = event.pattern_match.group(1).strip()
    chat_id = event.chat_id
    
    init_banned_words(chat_id)
    
    if word not in banned_words[chat_id]:
        await event.edit(f"❌ **الكلمة ليست ممنوعة:** `{word}`")
        return
    
    del banned_words[chat_id][word]
    
    await event.edit(f"✅ **تم إلغاء منع الكلمة:** `{word}`")

# ==================== معالج الرسائل (للكشف عن الكلمات الممنوعة) ====================
@client.on(events.NewMessage(incoming=True))
async def check_banned_words(event):
    if not event.is_group:
        return
    
    chat_id = event.chat_id
    user_id = event.sender_id
    
    if chat_id not in banned_words or not banned_words[chat_id]:
        return
    
    if not event.text:
        return
    
    text_lower = event.text.lower()
    
    for word, data in banned_words[chat_id].items():
        if word.lower() in text_lower:
            action = data["action"]
            
            try:
                await event.delete()
            except:
                pass
            
            try:
                if action == "delete":
                    pass
                    
                elif action == "restrict":
                    until_date = datetime.now() + timedelta(days=1)
                    await client.edit_permissions(
                        chat_id, user_id,
                        send_messages=False,
                        until_date=until_date
                    )
                    
                elif action == "kick":
                    await client.kick_participant(chat_id, user_id)
                    
                elif action == "ban":
                    await client.edit_permissions(chat_id, user_id, view_messages=False)
                    
            except Exception as e:
                pass
            
            try:
                user = await event.get_sender()
                user_mention = f"[{user.first_name}](tg://user?id={user_id})"
                action_msg = {
                    "delete": "🗑 تم حذف رسالة",
                    "restrict": "🔒 تم تقييد",
                    "kick": "👢 تم طرد",
                    "ban": "🚫 تم حظر"
                }.get(action, "")
                
                await client.send_message(
                    chat_id,
                    f"⚠️ {action_msg} {user_mention}\n"
                    f"📝 **السبب:** استخدام كلمة ممنوعة"
                )
            except:
                pass
            
            break