# ==================== م11: أوامر النشر التلقائي ====================

import re
import random
import asyncio
from telethon import events
from main import client

# ========== المتغيرات العامة ==========
publish_settings = {}
setup_state = {}


# ==================== دالة استخراج الإيديات من أي نص ====================
def extract_ids_from_text(text):
    """تستخرج جميع الإيديات من أي نص (مع كلام أو بدونه)"""
    if not text:
        return []
    
    ids = re.findall(r'-?\d+', text)
    
    valid_ids = []
    for id_str in ids:
        try:
            id_num = int(id_str)
            if id_num < -100:
                valid_ids.append(id_num)
        except:
            pass
    
    return valid_ids


# ==================== دالة التحقق من المجموعات ====================
async def verify_groups(user_id, group_ids):
    """تتحقق من أن السورس عضو في جميع المجموعات وتعيد المجموعات الصالحة والمتجاهلة"""
    valid = []
    ignored = {}
    
    for gid in group_ids:
        try:
            entity = await client.get_entity(gid)
            try:
                await client.get_permissions(gid, user_id)
                valid.append(gid)
            except:
                title = entity.title if hasattr(entity, 'title') else str(gid)
                ignored[gid] = title
        except:
            ignored[gid] = str(gid)
    
    return valid, ignored


# ==================== عرض قائمة الأوامر (.م11) ====================
@client.on(events.NewMessage(pattern=r'\.م11', outgoing=True))
async def show_publish_menu(event):
    menu_text = """⟪───── أوامر النشر التلقائي ─────⟫

│ `.مخصص <كلمة>`
│ ← للبحث عن المجموعات
│ ← مثال: .مخصص سوبر

│ `.تخصيص`
│ ← للرد على نتائج البحث وحفظ المجموعات

│ `.انشرها <ثوانٍ>` | `.نشر <ثوانٍ>` | `.انشر <ثوانٍ>` (≥5)
│ ← للرد على رسالة ونشرها في المجموعات
│ ← مثال: .انشرها 10

│ `.خاص` | `.اذاعة للخاص` | `.اذاعة`
│ ← للرد على رسالة والنشر في الخاص (مع وقت او بدون)

│ `.بلش <ثوانٍ>` | `.كرر <ثوانٍ>` | `.كررها <ثوانٍ>` (≥5)
│ ← للرد على رسالة وتكرارها

│ `.تفعيل النشر`
│ ← لاستخدام طريقة اخرى للنشر واتبع التعليمات

│ `.اضف_مجموعة`
│ ← لإضافة مجموعات جديدة أثناء النشر بدون إيقافه

│ `.المجموعات`
│ ← لعرض جميع المجموعات المحفوظة (يمكن نسخها)

│ `.المجموعات_المتجاهلة`
│ ← لعرض المجموعات التي تم تجاهلها لعدم الدخول فيها

│ `.مسح_المجموعات`
│ ← لمسح جميع المجموعات المحفوظة (اختياري)

│ `.مسح_المتجاهلة`
│ ← لمسح قائمة المجموعات المتجاهلة

│ `.ايقاف النشر`
│ ← لإيقاف كل عمليات النشر المستمر

│ `.الغاء`
│ ← لإلغاء عملية إعداد النشر الحالية فقط
╰─────────────────────────"""
    
    await event.edit(menu_text)


# ==================== دالة حفظ بيانات الرسالة ====================
async def save_message_data(msg):
    msg_data = {"type": "text", "content": None, "caption": None}
    
    if msg.text:
        msg_data["type"] = "text"
        msg_data["content"] = msg.text
    elif msg.photo:
        msg_data["type"] = "photo"
        msg_data["content"] = msg.photo.id
        msg_data["caption"] = msg.text or ""
    elif msg.video:
        msg_data["type"] = "video"
        msg_data["content"] = msg.video.id
        msg_data["caption"] = msg.text or ""
    elif msg.audio:
        msg_data["type"] = "audio"
        msg_data["content"] = msg.audio.id
        msg_data["caption"] = msg.text or ""
    elif msg.voice:
        msg_data["type"] = "voice"
        msg_data["content"] = msg.voice.id
    elif msg.sticker:
        msg_data["type"] = "sticker"
        msg_data["content"] = msg.sticker.id
    elif msg.gif:
        msg_data["type"] = "gif"
        msg_data["content"] = msg.gif.id
        msg_data["caption"] = msg.text or ""
    elif msg.document:
        msg_data["type"] = "document"
        msg_data["content"] = msg.document.id
        msg_data["caption"] = msg.text or ""
    
    return msg_data


# ==================== دالة إرسال الرسالة المحفوظة ====================
async def send_saved_message(chat_id, msg_data, counter=None):
    try:
        caption = msg_data.get("caption", "")
        if counter is not None:
            caption = f"({counter}) {caption}" if caption else f"({counter})"
        
        if msg_data["type"] == "text":
            content = msg_data["content"]
            if counter is not None:
                content = f"({counter}) {content}"
            await client.send_message(chat_id, content)
        elif msg_data["type"] == "photo":
            await client.send_file(chat_id, msg_data["content"], caption=caption)
        elif msg_data["type"] == "video":
            await client.send_file(chat_id, msg_data["content"], caption=caption)
        elif msg_data["type"] == "audio":
            await client.send_file(chat_id, msg_data["content"], caption=caption)
        elif msg_data["type"] == "voice":
            await client.send_file(chat_id, msg_data["content"])
        elif msg_data["type"] == "sticker":
            await client.send_file(chat_id, msg_data["content"])
        elif msg_data["type"] == "gif":
            await client.send_file(chat_id, msg_data["content"], caption=caption)
        elif msg_data["type"] == "document":
            await client.send_file(chat_id, msg_data["content"], caption=caption)
        
        return True
    except Exception:
        return False


# ==================== أوامر البحث والتخصيص ====================
@client.on(events.NewMessage(pattern=r'\.مخصص\s+(\S+)', outgoing=True))
async def search_groups(event):
    keyword = event.pattern_match.group(1).strip().lower()
    user_id = event.sender_id
    
    await event.edit(f"⎙ **جاري البحث عن مجموعات تحتوي على:** `{keyword}` ...")
    
    found_groups = []
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            if keyword in dialog.name.lower():
                found_groups.append({"id": dialog.id, "title": dialog.name})
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    publish_settings[user_id]["search_results"] = found_groups
    
    if found_groups:
        text = f"✓ **تم العثور على {len(found_groups)} مجموعة:**\n\n"
        for i, group in enumerate(found_groups[:20], 1):
            text += f"⦁ {group['title']}\n"
        text += "\n⌔ **استخدم** `.تخصيص` **للرد على هذه الرسالة وحفظ المجموعات**"
    else:
        text = f"✘ **لم يتم العثور على مجموعات تحتوي على:** `{keyword}`"
    
    await event.edit(text)


@client.on(events.NewMessage(pattern=r'\.تخصيص', outgoing=True))
async def save_search_results(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ **يرجى الرد على رسالة نتائج البحث**")
        return
    
    user_id = event.sender_id
    
    if user_id not in publish_settings or "search_results" not in publish_settings[user_id]:
        await event.edit("✘ **لا توجد نتائج بحث محفوظة**\n*استخدم* `.مخصص` *أولاً*")
        return
    
    found_groups = publish_settings[user_id]["search_results"]
    group_ids = [g["id"] for g in found_groups]
    
    # التحقق من المجموعات
    valid, ignored = await verify_groups(user_id, group_ids)
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    
    if "saved_groups" not in publish_settings[user_id]:
        publish_settings[user_id]["saved_groups"] = []
    
    if "ignored_groups" not in publish_settings[user_id]:
        publish_settings[user_id]["ignored_groups"] = {}
    
    # حفظ الصالحة
    for gid in valid:
        if gid not in publish_settings[user_id]["saved_groups"]:
            publish_settings[user_id]["saved_groups"].append(gid)
    
    # حفظ المتجاهلة
    for gid, title in ignored.items():
        if gid not in publish_settings[user_id]["ignored_groups"]:
            publish_settings[user_id]["ignored_groups"][gid] = title
    
    result = f"✓ **تم حفظ {len(valid)} مجموعة**"
    if ignored:
        result += f"\n\n✘ **تم تجاهل {len(ignored)} مجموعة (غير منضم إليها):**\n"
        for gid, title in ignored.items():
            result += f"⦁ {title}\n"
    
    await event.edit(result)


# ==================== أوامر النشر السريع ====================
@client.on(events.NewMessage(pattern=r'\.(انشرها|نشر|انشر)\s+(\d+)', outgoing=True))
async def quick_publish(event):
    interval = int(event.pattern_match.group(2).strip())
    if interval < 5:
        await event.edit("✘ **الحد الأدنى 5 ثوانٍ**")
        return
    
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ **يرجى الرد على الرسالة التي تريد نشرها**")
        return
    
    user_id = event.sender_id
    msg_data = await save_message_data(reply)
    
    await event.edit(f"⎙ **جاري النشر كل {interval} ثوانٍ...**")
    asyncio.create_task(start_publishing(user_id, msg_data, interval, "groups"))


@client.on(events.NewMessage(pattern=r'\.(خاص|اذاعة للخاص|اذاعة)(?:\s+(\d+))?', outgoing=True))
async def publish_to_private(event):
    interval = 5
    if event.pattern_match.group(2):
        interval = int(event.pattern_match.group(2).strip())
        if interval < 5:
            interval = 5
    
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ **يرجى الرد على الرسالة التي تريد نشرها**")
        return
    
    user_id = event.sender_id
    msg_data = await save_message_data(reply)
    
    await event.edit(f"⎙ **جاري النشر في الخاص كل {interval} ثوانٍ...**")
    asyncio.create_task(start_publishing(user_id, msg_data, interval, "private"))


# ==================== أوامر التكرار ====================
@client.on(events.NewMessage(pattern=r'\.(بلش|كرر|كررها)\s+(\d+)', outgoing=True))
async def repeat_message(event):
    interval = int(event.pattern_match.group(2).strip())
    if interval < 5:
        await event.edit("✘ **الحد الأدنى 5 ثوانٍ**")
        return
    
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("✘ **يرجى الرد على الرسالة التي تريد تكرارها**")
        return
    
    user_id = event.sender_id
    chat_id = event.chat_id
    msg_data = await save_message_data(reply)
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    
    publish_settings[user_id]["repeat"] = {
        "active": True,
        "chat_id": chat_id,
        "msg_data": msg_data,
        "interval": interval
    }
    
    await event.edit(f"⎙ **جاري تكرار الرسالة كل {interval} ثوانٍ...**")
    asyncio.create_task(start_repeating(user_id, chat_id, msg_data, interval))


# ==================== دالة بدء النشر العام ====================
async def start_publishing(user_id, msg_data, interval, target_type):
    if user_id not in publish_settings:
        return
    
    settings = publish_settings[user_id]
    settings["active_publish"] = True
    settings["publish_counter"] = 1
    
    protection = settings.get("protection_enabled", False)
    
    target_chats = []
    
    if target_type == "groups":
        if "saved_groups" in settings:
            target_chats = settings["saved_groups"]
        else:
            async for dialog in client.iter_dialogs():
                if dialog.is_group:
                    target_chats.append(dialog.id)
    
    elif target_type == "private":
        async for dialog in client.iter_dialogs():
            if dialog.is_user and not dialog.entity.bot:
                target_chats.append(dialog.id)
    
    for chat_id in target_chats:
        if not settings.get("active_publish", False):
            break
        
        counter = settings["publish_counter"] if protection else None
        await send_saved_message(chat_id, msg_data, counter)
        
        if counter:
            settings["publish_counter"] += 1
        
        wait_time = interval
        if protection:
            wait_time = interval + random.randint(-3, 5)
            if wait_time < 3:
                wait_time = 3
        
        await asyncio.sleep(wait_time)
    
    settings["active_publish"] = False


# ==================== دالة بدء التكرار ====================
async def start_repeating(user_id, chat_id, msg_data, interval):
    if user_id not in publish_settings:
        return
    
    settings = publish_settings[user_id]
    counter = 1
    
    while settings.get("repeat", {}).get("active", False):
        await send_saved_message(chat_id, msg_data, counter)
        counter += 1
        
        wait_time = interval + random.randint(-2, 3)
        if wait_time < 3:
            wait_time = 3
        
        await asyncio.sleep(wait_time)


# ==================== تفعيل النشر (النظام التفاعلي) ====================
@client.on(events.NewMessage(pattern=r'\.تفعيل النشر', outgoing=True))
async def activate_publish_setup(event):
    user_id = event.sender_id
    
    if user_id in publish_settings:
        del publish_settings[user_id]
    if user_id in setup_state:
        del setup_state[user_id]
    
    setup_state[user_id] = {"step": "waiting_for_klisha", "data": {}}
    
    welcome_text = """⌯ **مرحباً بك في نظام النشر التفاعلي**

⌔ **ارسل كليشتك الأولى** يمكنك ارسال صورة موصوفة بنص."""
    
    await event.edit(welcome_text)


# ==================== أمر .الغاء ====================
@client.on(events.NewMessage(pattern=r'\.الغاء', outgoing=True))
async def cancel_setup(event):
    user_id = event.sender_id
    
    if user_id in setup_state:
        del setup_state[user_id]
        await event.edit("⌫ **تم إلغاء عملية إعداد النشر**")
    else:
        await event.edit("⌔ **لا توجد عملية إعداد جارية للإلغاء**\n*استخدم* `.ايقاف النشر` *لإيقاف النشر الفعلي*")


# ==================== أمر .ايقاف النشر ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف النشر', outgoing=True))
async def stop_all_publishing(event):
    user_id = event.sender_id
    
    if user_id in publish_settings:
        publish_settings[user_id]["continuous_publish"] = False
        if "repeat" in publish_settings[user_id]:
            publish_settings[user_id]["repeat"]["active"] = False
    
    await event.edit("⌫ **تم إيقاف جميع عمليات النشر**")


# ==================== معالج خطوات تفعيل النشر ====================
@client.on(events.NewMessage(outgoing=True))
async def handle_setup_steps(event):
    user_id = event.sender_id
    
    if user_id not in setup_state:
        return
    
    text = event.text or ""
    if text.startswith('.'):
        return
    
    ignore_words = ["مرحباً بك", "تم حفظ", "ارسل", "حسناً", "⌔", "⌯", "✓", "✘", "⎙"]
    if any(word in text for word in ignore_words):
        return
    
    state = setup_state[user_id]
    step = state["step"]
    
    if step == "waiting_for_klisha":
        msg_data = await save_message_data(event)
        state["data"]["klisha"] = msg_data
        state["step"] = "waiting_for_interval"
        
        await event.reply("✓ **تم حفظ الكليشة بنجاح**")
        await asyncio.sleep(0.5)
        await client.send_message(event.chat_id, "⌔ **ارسل عدد الثواني بين كل رسالة وأخرى**")
    
    elif step == "waiting_for_interval":
        try:
            interval = int(event.text.strip())
            if interval < 5:
                await event.reply("✘ **الحد الأدنى 5 ثوانٍ، أرسل رقماً أكبر**")
                return
            
            state["data"]["interval"] = interval
            state["step"] = "waiting_for_groups"
            
            await event.reply(f"✓ **تم استلام الفترة:** {interval} ثانية")
            await asyncio.sleep(0.5)
            
            options_text = """⌔ **ارسل روابط المجموعات بأي صيغة او اختر:**

⦁ لمجموعات السوبرات » `.سوبر`
⦁ لمجموعات التبادل » `.تبادل`
⦁ لكل المجموعات » `.الكل`
⦁ للاذاعة خاص » `.للخاص`

⌔ أو اكتب » `.احفظ` **واستخدمها تالياً مع الأمر** » `.بدء`"""
            
            await client.send_message(event.chat_id, options_text)
            
        except ValueError:
            await event.reply("✘ **يرجى إرسال رقم صحيح**")


# ==================== أوامر اختيار نوع المجموعات ====================
@client.on(events.NewMessage(pattern=r'\.سوبر', outgoing=True))
async def select_super_groups(event):
    user_id = event.sender_id
    
    if user_id not in setup_state:
        await event.edit("✘ **لا توجد عملية إعداد جارية**")
        return
    
    state = setup_state[user_id]
    data = state["data"]
    
    super_groups = []
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            super_groups.append(dialog.id)
    
    # التحقق من المجموعات
    valid, ignored = await verify_groups(user_id, super_groups)
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    
    if "ignored_groups" not in publish_settings[user_id]:
        publish_settings[user_id]["ignored_groups"] = {}
    
    publish_settings[user_id]["saved_groups"] = valid
    publish_settings[user_id]["klisha"] = data["klisha"]
    publish_settings[user_id]["interval"] = data["interval"]
    
    # حفظ المتجاهلة
    for gid, title in ignored.items():
        publish_settings[user_id]["ignored_groups"][gid] = title
    
    del setup_state[user_id]
    
    result = f"✓ **تم حفظ {len(valid)} مجموعة سوبر**"
    if ignored:
        result += f"\n\n✘ **تم تجاهل {len(ignored)} مجموعة (غير منضم إليها):**\n"
        for gid, title in ignored.items():
            result += f"⦁ {title}\n"
    result += f"\n⎙ **النشر جاهز، استخدم** `.بدء` **للبدء**"
    
    await event.edit(result)


@client.on(events.NewMessage(pattern=r'\.تبادل', outgoing=True))
async def select_exchange_groups(event):
    user_id = event.sender_id
    
    if user_id not in setup_state:
        await event.edit("✘ **لا توجد عملية إعداد جارية**")
        return
    
    state = setup_state[user_id]
    data = state["data"]
    
    exchange_groups = []
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            title_lower = dialog.name.lower()
            if "تبادل" in title_lower or "exchange" in title_lower:
                exchange_groups.append(dialog.id)
    
    # التحقق من المجموعات
    valid, ignored = await verify_groups(user_id, exchange_groups)
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    
    if "ignored_groups" not in publish_settings[user_id]:
        publish_settings[user_id]["ignored_groups"] = {}
    
    publish_settings[user_id]["saved_groups"] = valid
    publish_settings[user_id]["klisha"] = data["klisha"]
    publish_settings[user_id]["interval"] = data["interval"]
    
    for gid, title in ignored.items():
        publish_settings[user_id]["ignored_groups"][gid] = title
    
    del setup_state[user_id]
    
    result = f"✓ **تم حفظ {len(valid)} مجموعة تبادل**"
    if ignored:
        result += f"\n\n✘ **تم تجاهل {len(ignored)} مجموعة (غير منضم إليها):**\n"
        for gid, title in ignored.items():
            result += f"⦁ {title}\n"
    result += f"\n⎙ **النشر جاهز، استخدم** `.بدء` **للبدء**"
    
    await event.edit(result)


@client.on(events.NewMessage(pattern=r'\.الكل', outgoing=True))
async def select_all_groups(event):
    user_id = event.sender_id
    
    if user_id not in setup_state:
        await event.edit("✘ **لا توجد عملية إعداد جارية**")
        return
    
    state = setup_state[user_id]
    data = state["data"]
    
    all_groups = []
    async for dialog in client.iter_dialogs():
        if dialog.is_group:
            all_groups.append(dialog.id)
    
    # التحقق من المجموعات
    valid, ignored = await verify_groups(user_id, all_groups)
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    
    if "ignored_groups" not in publish_settings[user_id]:
        publish_settings[user_id]["ignored_groups"] = {}
    
    publish_settings[user_id]["saved_groups"] = valid
    publish_settings[user_id]["klisha"] = data["klisha"]
    publish_settings[user_id]["interval"] = data["interval"]
    
    for gid, title in ignored.items():
        publish_settings[user_id]["ignored_groups"][gid] = title
    
    del setup_state[user_id]
    
    result = f"✓ **تم حفظ {len(valid)} مجموعة**"
    if ignored:
        result += f"\n\n✘ **تم تجاهل {len(ignored)} مجموعة (غير منضم إليها):**\n"
        for gid, title in ignored.items():
            result += f"⦁ {title}\n"
    result += f"\n⎙ **النشر جاهز، استخدم** `.بدء` **للبدء**"
    
    await event.edit(result)


@client.on(events.NewMessage(pattern=r'\.للخاص', outgoing=True))
async def select_private_chats(event):
    user_id = event.sender_id
    
    if user_id not in setup_state:
        await event.edit("✘ **لا توجد عملية إعداد جارية**")
        return
    
    state = setup_state[user_id]
    data = state["data"]
    
    private_chats = []
    async for dialog in client.iter_dialogs():
        if dialog.is_user and not dialog.entity.bot:
            private_chats.append(dialog.id)
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    
    publish_settings[user_id]["saved_groups"] = private_chats
    publish_settings[user_id]["klisha"] = data["klisha"]
    publish_settings[user_id]["interval"] = data["interval"]
    publish_settings[user_id]["target_type"] = "private"
    
    del setup_state[user_id]
    
    await event.edit(f"✓ **تم حفظ {len(private_chats)} محادثة خاصة**\n\n⎙ **النشر جاهز، استخدم** `.بدء` **للبدء**")


# ==================== نظام الحفظ المخصص ====================
@client.on(events.NewMessage(pattern=r'\.احفظ', outgoing=True))
async def start_custom_save(event):
    user_id = event.sender_id
    
    if user_id not in setup_state:
        await event.edit("✘ **لا توجد عملية إعداد جارية**\n*استخدم* `.تفعيل النشر` *أولاً*")
        return
    
    setup_state[user_id]["step"] = "custom_save"
    setup_state[user_id]["custom_groups"] = []
    
    await event.edit(
        "⌔ **وضع الحفظ المخصص مفعل**\n\n"
        "⦁ **ارسل ايدي المجموعة** (مثال: `-1001234567890`)\n"
        "⦁ **او ارسل عدة ايديات دفعة واحدة** (كل إيدي في سطر)\n"
        "⦁ **او اكتب** `.خلص` **للإنتهاء**\n\n"
        "⌔ *يمكنك لصق الايديات من `.المجموعات` مباشرة*"
    )


@client.on(events.NewMessage(outgoing=True))
async def handle_custom_save_id(event):
    user_id = event.sender_id
    
    if user_id not in setup_state:
        return
    
    state = setup_state[user_id]
    
    if state.get("step") != "custom_save":
        return
    
    text = event.text.strip() if event.text else ""
    
    if text.startswith('.'):
        return
    
    ids = extract_ids_from_text(text)
    
    if not ids:
        return
    
    if "custom_groups" not in state:
        state["custom_groups"] = []
    
    added = 0
    skipped = 0
    
    for chat_id in ids:
        if chat_id not in state["custom_groups"]:
            state["custom_groups"].append(chat_id)
            added += 1
        else:
            skipped += 1
    
    if added > 0:
        msg = f"✓ **تم حفظ {added} مجموعة**"
        if skipped > 0:
            msg += f"\n⌔ **متجاهلة (مكررة):** {skipped}"
        msg += f"\n⌔ **عدد المجموعات المحفوظة:** {len(state['custom_groups'])}"
        msg += "\n\n⌔ **اضف المزيد او اكتب** `.خلص`"
        
        await event.reply(msg)


@client.on(events.NewMessage(pattern=r'\.خلص', outgoing=True))
async def finish_custom_save(event):
    user_id = event.sender_id
    
    if user_id not in setup_state:
        await event.edit("✘ **لا توجد عملية إعداد جارية**")
        return
    
    state = setup_state[user_id]
    
    if state.get("step") != "custom_save":
        await event.edit("✘ **لست في وضع الحفظ المخصص**")
        return
    
    data = state["data"]
    custom_groups = state.get("custom_groups", [])
    
    if not custom_groups:
        await event.edit("✘ **لم تقم بحفظ أي مجموعة**")
        return
    
    # التحقق من المجموعات
    valid, ignored = await verify_groups(user_id, custom_groups)
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    
    if "ignored_groups" not in publish_settings[user_id]:
        publish_settings[user_id]["ignored_groups"] = {}
    
    publish_settings[user_id]["saved_groups"] = valid
    publish_settings[user_id]["klisha"] = data["klisha"]
    publish_settings[user_id]["interval"] = data["interval"]
    
    for gid, title in ignored.items():
        publish_settings[user_id]["ignored_groups"][gid] = title
    
    del setup_state[user_id]
    
    groups_preview = "\n".join([str(g) for g in valid])
    
    result = f"✓ **تم حفظ {len(valid)} مجموعة مخصصة**\n\n"
    result += f"⌔ **المجموعات:**\n```\n{groups_preview}\n```"
    
    if ignored:
        result += f"\n\n✘ **تم تجاهل {len(ignored)} مجموعة (غير منضم إليها):**\n"
        for gid, title in ignored.items():
            result += f"⦁ {title}\n"
    
    result += f"\n⎙ **النشر جاهز، استخدم** `.بدء` **للبدء**"
    
    await event.edit(result)


# ==================== أمر عرض المجموعات المحفوظة (المجموعات الصالحة فقط) ====================
@client.on(events.NewMessage(pattern=r'\.المجموعات', outgoing=True))
async def show_saved_groups(event):
    user_id = event.sender_id
    
    if user_id not in publish_settings or "saved_groups" not in publish_settings[user_id]:
        await event.edit("⌔ **لا توجد مجموعات محفوظة حاليًا**")
        return
    
    groups = publish_settings[user_id]["saved_groups"]
    
    if not groups:
        await event.edit("⌔ **لا توجد مجموعات صالحة حالياً**")
        return
    
    groups_text = "\n".join([str(g) for g in groups])
    
    text = f"⌔ **المجموعات المحفوظة ({len(groups)}):**\n\n```\n{groups_text}\n```\n\n⌔ **انسخ الايديات أعلاه واستخدمها مع** `.احفظ`"
    
    await event.edit(text)


# ==================== أمر عرض المجموعات المتجاهلة ====================
@client.on(events.NewMessage(pattern=r'\.المجموعات_المتجاهلة', outgoing=True))
async def show_ignored_groups(event):
    user_id = event.sender_id
    
    if user_id not in publish_settings or "ignored_groups" not in publish_settings[user_id]:
        await event.edit("⌔ **لا توجد مجموعات متجاهلة**")
        return
    
    ignored = publish_settings[user_id]["ignored_groups"]
    
    if not ignored:
        await event.edit("⌔ **لا توجد مجموعات متجاهلة**")
        return
    
    text = f"✘ **المجموعات المتجاهلة ({len(ignored)}):**\n\n"
    for gid, title in ignored.items():
        text += f"⦁ {title} (`{gid}`)\n"
    
    text += "\n⌔ **سبب التجاهل:** غير منضم إلى هذه المجموعات"
    
    await event.edit(text)


# ==================== أمر مسح المجموعات المحفوظة ====================
@client.on(events.NewMessage(pattern=r'\.مسح_المجموعات', outgoing=True))
async def clear_saved_groups(event):
    user_id = event.sender_id
    
    if user_id not in publish_settings or "saved_groups" not in publish_settings[user_id]:
        await event.edit("⌔ **لا توجد مجموعات محفوظة لمسحها**")
        return
    
    count = len(publish_settings[user_id]["saved_groups"])
    publish_settings[user_id]["saved_groups"] = []
    
    await event.edit(f"⌫ **تم مسح {count} مجموعة من قائمة النشر**\n\n⌔ *الكليشة والوقت ما زالا محفوظين*")


# ==================== أمر مسح المجموعات المتجاهلة ====================
@client.on(events.NewMessage(pattern=r'\.مسح_المتجاهلة', outgoing=True))
async def clear_ignored_groups(event):
    user_id = event.sender_id
    
    if user_id not in publish_settings or "ignored_groups" not in publish_settings[user_id]:
        await event.edit("⌔ **لا توجد مجموعات متجاهلة لمسحها**")
        return
    
    count = len(publish_settings[user_id]["ignored_groups"])
    publish_settings[user_id]["ignored_groups"] = {}
    
    await event.edit(f"⌫ **تم مسح {count} مجموعة من قائمة المتجاهلة**")


# ==================== أمر .اضف_مجموعة (إضافة أثناء النشر) ====================
@client.on(events.NewMessage(pattern=r'\.اضف_مجموعة\s+([\s\S]+)', outgoing=True))
async def add_groups_during_publish(event):
    user_id = event.sender_id
    input_text = event.pattern_match.group(1).strip()
    
    ids = extract_ids_from_text(input_text)
    
    if not ids:
        await event.edit("✘ **لم يتم العثور على إيديات صحيحة في النص**\n\n⌔ *تأكد من إرسال إيديات تبدأ بـ `-100`*")
        return
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    
    if "saved_groups" not in publish_settings[user_id]:
        publish_settings[user_id]["saved_groups"] = []
    
    if "ignored_groups" not in publish_settings[user_id]:
        publish_settings[user_id]["ignored_groups"] = {}
    
    # التحقق من المجموعات
    valid, ignored = await verify_groups(user_id, ids)
    
    added = 0
    skipped = 0
    
    for gid in valid:
        if gid not in publish_settings[user_id]["saved_groups"]:
            publish_settings[user_id]["saved_groups"].append(gid)
            added += 1
        else:
            skipped += 1
    
    for gid, title in ignored.items():
        publish_settings[user_id]["ignored_groups"][gid] = title
    
    total = len(publish_settings[user_id]["saved_groups"])
    
    result = f"✓ **تمت إضافة {added} مجموعة**"
    if skipped > 0:
        result += f"\n⌔ **متجاهلة (مكررة):** {skipped}"
    if ignored:
        result += f"\n\n✘ **تم تجاهل {len(ignored)} مجموعة (غير منضم إليها):**\n"
        for gid, title in ignored.items():
            result += f"⦁ {title}\n"
    result += f"\n⌔ **إجمالي المجموعات الصالحة:** {total}"
    
    if publish_settings[user_id].get("continuous_publish", False):
        result += "\n\n⎙ **النشر شغال - ستُنشر في الدورة التالية تلقائياً**"
    
    await event.edit(result)


# ==================== دالة بدء النشر المستمر ====================
async def start_publishing_with_data(user_id, msg_data, interval, target_chats):
    if user_id not in publish_settings:
        return
    
    settings = publish_settings[user_id]
    settings["continuous_publish"] = True
    settings["publish_counter"] = 1
    
    protection = settings.get("protection_enabled", False)
    
    while settings.get("continuous_publish", False):
        current_chats = settings.get("saved_groups", target_chats)
        
        for chat_id in current_chats:
            if not settings.get("continuous_publish", False):
                break
            
            try:
                counter = settings["publish_counter"] if protection else None
                await send_saved_message(chat_id, msg_data, counter)
                await asyncio.sleep(random.uniform(1.0, 2.0))
            except Exception:
                await asyncio.sleep(1)
        
        if protection:
            settings["publish_counter"] += 1
        
        await asyncio.sleep(interval)


# ==================== أمر بدء النشر المحفوظ ====================
@client.on(events.NewMessage(pattern=r'\.بدء', outgoing=True))
async def start_saved_publish(event):
    user_id = event.sender_id
    
    if user_id not in publish_settings:
        await event.edit("✘ **لا توجد إعدادات نشر محفوظة**\n*استخدم* `.تفعيل النشر` *أولاً*")
        return
    
    settings = publish_settings[user_id]
    
    if "klisha" not in settings or "saved_groups" not in settings:
        await event.edit("✘ **إعدادات النشر غير مكتملة**")
        return
    
    msg_data = settings["klisha"]
    interval = settings.get("interval", 10)
    target_chats = settings["saved_groups"]
    
    await event.edit(f"⎙ **بدء النشر المستمر كل {interval} ثانية في {len(target_chats)} مجموعة...**\n\n⌔ للتوقف: `.ايقاف النشر`\n⌔ لإضافة مجموعة: `.اضف_مجموعة -100123`")
    
    asyncio.create_task(start_publishing_with_data(user_id, msg_data, interval, target_chats))


# ==================== تفعيل/تعطيل نظام حماية النشر ====================
@client.on(events.NewMessage(pattern=r'\.تفعيل نظام حماية النشر', outgoing=True))
async def enable_protection(event):
    user_id = event.sender_id
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    
    publish_settings[user_id]["protection_enabled"] = True
    
    await event.edit(
        "✓ **تم تفعيل نظام حماية النشر**\n\n"
        "⌔ **الميزات:**\n"
        "⦁ وقت عشوائي بين الرسائل\n"
        "⦁ إضافة رقم تسلسلي للكليشة\n"
        "⦁ حماية من الحظر"
    )


@client.on(events.NewMessage(pattern=r'\.تعطيل نظام حماية النشر', outgoing=True))
async def disable_protection(event):
    user_id = event.sender_id
    
    if user_id not in publish_settings:
        publish_settings[user_id] = {}
    
    publish_settings[user_id]["protection_enabled"] = False
    
    await event.edit("⌫ **تم تعطيل نظام حماية النشر**")