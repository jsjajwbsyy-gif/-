import asyncio
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

# ==================== عرض قائمة الأوامر (.م25) ====================
@client.on(events.NewMessage(pattern=r'\.م25', outgoing=True))
async def show_fake_session_menu(event):
    menu_text = """⟪─── الوهمي والجلسات ───⟫

│ `.وهمي كتابة + ثواني`
│ ← يظهر أنك تكتب
│ ← مثال: .وهمي كتابة 10

│ `.وهمي صوت + ثواني`
│ `.وهمي فيديو + ثواني`

│ `.وهمي لعبة + ثواني`
│ `.وهمي صورة + ثواني`

│ `.وهمي موقع + ثواني`
│ `.وهمي جهات + ثواني`

│ `.وهمي ملف + ثواني`
│ `.وهمي مرئي + ثواني`

│ `.ايقاف الوهمي`
│ ← لإيقاف الحالة الوهمية الحالية

ملاحظة: إذا لم تحدد الوقت، سيتم تعيينه تلقائيًا إلى 15 ثانية

📌 **أوامر الجلسات والتنصيب انتقلت إلى** `.م17`
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== دالة مساعدة: إرسال حالة وهمية ====================
async def send_fake_action(chat_id, action, seconds):
    try:
        async with client.action(chat_id, action):
            await asyncio.sleep(seconds)
    except Exception as e:
        pass

# ==================== 1. أمر .وهمي كتابة ====================
@client.on(events.NewMessage(pattern=r'\.وهمي كتابة(?:\s+(\d+))?', outgoing=True))
async def fake_typing(event):
    seconds = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 15
    chat_id = event.chat_id
    await event.delete()
    await send_fake_action(chat_id, 'typing', seconds)

# ==================== 2. أمر .وهمي صوت ====================
@client.on(events.NewMessage(pattern=r'\.وهمي صوت(?:\s+(\d+))?', outgoing=True))
async def fake_voice(event):
    seconds = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 15
    chat_id = event.chat_id
    await event.delete()
    await send_fake_action(chat_id, 'record-audio', seconds)

# ==================== 3. أمر .وهمي فيديو ====================
@client.on(events.NewMessage(pattern=r'\.وهمي فيديو(?:\s+(\d+))?', outgoing=True))
async def fake_video(event):
    seconds = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 15
    chat_id = event.chat_id
    await event.delete()
    await send_fake_action(chat_id, 'record-video', seconds)

# ==================== 4. أمر .وهمي لعبة ====================
@client.on(events.NewMessage(pattern=r'\.وهمي لعبة(?:\s+(\d+))?', outgoing=True))
async def fake_game(event):
    seconds = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 15
    chat_id = event.chat_id
    await event.delete()
    await send_fake_action(chat_id, 'playing', seconds)

# ==================== 5. أمر .وهمي صورة ====================
@client.on(events.NewMessage(pattern=r'\.وهمي صورة(?:\s+(\d+))?', outgoing=True))
async def fake_photo(event):
    seconds = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 15
    chat_id = event.chat_id
    await event.delete()
    await send_fake_action(chat_id, 'photo', seconds)

# ==================== 6. أمر .وهمي موقع ====================
@client.on(events.NewMessage(pattern=r'\.وهمي موقع(?:\s+(\d+))?', outgoing=True))
async def fake_location(event):
    seconds = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 15
    chat_id = event.chat_id
    await event.delete()
    await send_fake_action(chat_id, 'location', seconds)

# ==================== 7. أمر .وهمي جهات ====================
@client.on(events.NewMessage(pattern=r'\.وهمي جهات(?:\s+(\d+))?', outgoing=True))
async def fake_contact(event):
    seconds = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 15
    chat_id = event.chat_id
    await event.delete()
    await send_fake_action(chat_id, 'contact', seconds)

# ==================== 8. أمر .وهمي ملف ====================
@client.on(events.NewMessage(pattern=r'\.وهمي ملف(?:\s+(\d+))?', outgoing=True))
async def fake_document(event):
    seconds = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 15
    chat_id = event.chat_id
    await event.delete()
    await send_fake_action(chat_id, 'document', seconds)

# ==================== 9. أمر .وهمي مرئي ====================
@client.on(events.NewMessage(pattern=r'\.وهمي مرئي(?:\s+(\d+))?', outgoing=True))
async def fake_video_note(event):
    seconds = int(event.pattern_match.group(1)) if event.pattern_match.group(1) else 15
    chat_id = event.chat_id
    await event.delete()
    await send_fake_action(chat_id, 'record-round', seconds)

# ==================== 10. أمر .ايقاف الوهمي ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف الوهمي', outgoing=True))
async def stop_fake_action(event):
    chat_id = event.chat_id
    try:
        await client.send_message(chat_id, "🛑 **تم إيقاف الحالة الوهمية**")
    except:
        pass
    await event.delete()