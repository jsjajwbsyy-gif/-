import os
import random
from telethon import events
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.functions.photos import GetUserPhotosRequest
from telethon.tl.types import MessageEntityMentionName

from main import client

# قائمة فيديوهات الحيوانات
sts_animal = "https://graph.org/file/720a8d292301289bb7ca4.mp4"  # مطي
sts_animal2 = "https://graph.org/file/fa43723297d16ebccfa94.mp4"  # كلب
sts_animal3 = "https://graph.org/file/bc4c35ca805ab9e4ef8d7.mp4"  # قرد
sts_animal4 = "https://graph.org/file/7cc42816b3e161f7183b6.mp4"  # صخل
sts_animal5 = "https://graph.org/file/8beaf555e0d4e3f00c294.mp4"  # طلي
sts_animal6 = "https://graph.org/file/c34cb870037a4ed2be972.mp4"  # بزون
sts_animal7 = "https://graph.org/file/c499feb6a51dea16a1fe5.mp4"  # ابو بريص
sts_animal8 = "https://graph.org/file/19b193f06d680e3ec79c0.mp4"  # جريذي
sts_animal9 = "https://graph.org/file/cd1fcb86af78d83ba9002.mp4"  # هايشه

# قائمة النسب العشوائية
jjj = [
    "100% مو حيوان غنبله 😱😂",
    "90% مو حيوان ضيم 😱😂",
    "80% 😱😂",
    "70% 😱😂",
    "60% براسه 60 حظ 😂",
    "50% حيوان هجين 😂",
    "40% خوش حيوان 😂",
    "30% 😒😂",
    "20% 😒😂",
    "10% 😒😂",
    "0% 😢😂",
]

# ايديات المطورين (للحماية)
PROTECTED_IDS = [1260465030, 5502537272]

# ==================== عرض قائمة الأوامر (.م52) ====================
@client.on(events.NewMessage(pattern=r'\.م51', outgoing=True))
async def show_animal_menu(event):
    menu_text = """⟪───── أوامر الحيوان ─────⟫

│ `.حيوان` بالرد على شخص
│ ← يعرض فيديو عشوائي لحيوان مع معلومات الشخص

│ `.حيوان` + معرف/ايدي
│ ← يعرض فيديو حيوان للشخص المحدد

│ `.حيوانات`
│ ← عرض قائمة الحيوانات المتاحة

⌔ **ملاحظة:** الأمر للتحشيش والتسلية فقط
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== دالة مساعدة: جلب المستخدم ====================
async def get_user_from_event(event):
    if event.reply_to_msg_id:
        previous_message = await event.get_reply_message()
        user_object = await event.client.get_entity(previous_message.sender_id)
    else:
        user = event.pattern_match.group(1)
        if user.isnumeric():
            user = int(user)
        if not user:
            self_user = await event.client.get_me()
            user = self_user.id
        if event.message.entities:
            probable_user_mention_entity = event.message.entities[0]
            if isinstance(probable_user_mention_entity, MessageEntityMentionName):
                user_id = probable_user_mention_entity.user_id
                user_obj = await event.client.get_entity(user_id)
                return user_obj
        if isinstance(user, int) or user.startswith("@"):
            user_obj = await event.client.get_entity(user)
            return user_obj
        try:
            user_object = await event.client.get_entity(user)
        except (TypeError, ValueError) as err:
            await event.edit(str(err))
            return None
    return user_object


# ==================== دالة مساعدة: جلب معلومات الحيوان ====================
async def fetch_animal_info(replied_user, event):
    FullUser = (await event.client(GetFullUserRequest(replied_user.id))).full_user
    replied_user_profile_photos = await event.client(
        GetUserPhotosRequest(user_id=replied_user.id, offset=42, max_id=0, limit=80)
    )
    replied_user_profile_photos_count = "الحيوان مامخلي بروفايل"
    try:
        replied_user_profile_photos_count = replied_user_profile_photos.count
    except AttributeError:
        pass
    
    user_id = replied_user.id
    first_name = replied_user.first_name or ""
    last_name = replied_user.last_name or ""
    username = f"@{replied_user.username}" if replied_user.username else "لايوجد معرف"
    yoy = random.choice(jjj)
    
    x = random.randrange(1, 10)
    
    if x == 1:
        name = f"مطي زربه 🦓"
        video = sts_animal
    elif x == 2:
        name = f"جلب شوارع 🐕‍🦺"
        video = sts_animal2
    elif x == 3:
        name = f"قرد لزكـه 🐒"
        video = sts_animal3
    elif x == 4:
        name = f"صخل محترم 🐐"
        video = sts_animal4
    elif x == 5:
        name = f"طلي ابو البعرور الوصخ 🐑"
        video = sts_animal5
    elif x == 6:
        name = f"بزون ابوخالد 🐈"
        video = sts_animal6
    elif x == 7:
        name = f"الزاحف ابو بريص 🦎"
        video = sts_animal7
    elif x == 8:
        name = f"جريذي ابو المجاري 🐀"
        video = sts_animal8
    else:
        name = f"هايشه 🐄"
        video = sts_animal9
    
    caption = f"""◈ **╮•🦦 الحيوان ⇦** {first_name} {last_name}
▬▬▬▬▬▬▬▬▬▬▬▬
⦁ **المعرف ⇦** {username}
⦁ **الايدي ⇦** `{user_id}`
⦁ **الصور ⇦** {replied_user_profile_photos_count}
⦁ **النوع ⇦** {name}
⦁ **النسبة ⇦** {yoy}
▬▬▬▬▬▬▬▬▬▬▬▬
⌔ **سورس زيرو**"""
    
    return video, caption


# ==================== أمر .حيوان ====================
@client.on(events.NewMessage(pattern=r'\.حيوان(?: |$)(.*)', outgoing=True))
async def animal_command(event):
    zed = await event.edit("⎙ **جاري التحليل...**")
    
    replied_user = await get_user_from_event(event)
    
    if not replied_user:
        await event.edit("✘ **لم استطع العثور على الشخص**")
        return
    
    # حماية المطورين
    if replied_user.id in PROTECTED_IDS:
        await event.edit("✘ **هذا الشخص لا يمكن استخدام الأمر عليه**")
        return
    
    try:
        video, caption = await fetch_animal_info(replied_user, event)
    except AttributeError:
        await event.edit("✘ **لم استطع العثور على الشخص**")
        return
    
    message_id_to_reply = event.message.reply_to_msg_id
    
    try:
        await event.client.send_file(
            event.chat_id,
            video,
            caption=caption,
            link_preview=False,
            force_document=False,
            reply_to=message_id_to_reply,
            parse_mode="html",
        )
        await zed.delete()
    except TypeError:
        await zed.edit(caption, parse_mode="html")


# ==================== أمر .حيوانات (عرض القائمة) ====================
@client.on(events.NewMessage(pattern=r'\.حيوانات$', outgoing=True))
async def list_animals(event):
    animals_text = """◈ **قائمة الحيوانات المتاحة:**

⦁ 1. مطي زربه 🦓
⦁ 2. جلب شوارع 🐕‍🦺
⦁ 3. قرد لزكه 🐒
⦁ 4. صخل محترم 🐐
⦁ 5. طلي ابو البعرور 🐑
⦁ 6. بزون ابوخالد 🐈
⦁ 7. الزاحف ابو بريص 🦎
⦁ 8. جريذي ابو المجاري 🐀
⦁ 9. هايشه 🐄

⌔ **للاستخدام:** `.حيوان` بالرد على شخص"""
    
    await event.edit(animals_text)