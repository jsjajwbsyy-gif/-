from main import client
from telethon import events

# ========== M38: أوامر الكتابة والتحرير ==========

@client.on(events.NewMessage(pattern=r'\.م38', outgoing=True))
async def show_m38_menu(event):
    menu_text = """⟪───── أوامر الكتابة والتحرير ─────⟫

│ `.تنسيق`
│ ← تنسيق النص بشكل جميل

│ `.قلب`
│ ← قلب النص رأساً على عقب

│ `.عريض`
│ ← تحويل النص إلى خط عريض

│ `.مائل`
│ ← تحويل النص إلى خط مائل

│ `.مسافة`
│ ← إضافة مسافات بين الحروف

│ `.تشكيل`
│ ← إضافة تشكيل عشوائي للنص العربي

│ `.بدون_تشكيل`
│ ← إزالة التشكيل من النص

│ `.صغير`
│ ← تحويل النص إلى أحرف صغيرة علوية

│ `.عكس`
│ ← عكس النص بالكامل

│ `.تكرار + الرقم`
│ ← تكرار النص عدة مرات

│ `.استبدال + كلمة + كلمة`
│ ← استبدال كلمة بأخرى في النص

│ `.حذف + الكلمة`
│ ← حذف كلمة محددة من النص

│ `.تقطيع`
│ ← تقطيع النص إلى أجزاء

│ `.ترقيم`
│ ← إضافة أرقام للأسطر

│ `.ترتيب`
│ ← ترتيب الكلمات أبجدياً

│ `.عشوائي`
│ ← ترتيب عشوائي للكلمات

│ `.بدون_فراغات`
│ ← حذف جميع المسافات من النص

│ `.عد`
│ ← عد الكلمات والحروف في النص

│ `.تشفير`
│ ← تشفير النص بـ Base64

│ `.فك`
│ ← فك تشفير Base64

│ `.مورس`
│ ← تحويل النص إلى شفرة مورس

│ `.فك_مورس`
│ ← فك شفرة مورس إلى نص

│ `.MD5`
│ ← تشفير النص إلى MD5

│ `.بيناري`
│ ← تحويل النص إلى كود ثنائي

│ `.لون`
│ ← كتابة النص بلون محدد

│ `.مربع`
│ ← وضع النص داخل مربع

│ `.تحليل`
│ ← تحليل النص (كلمات، حروف، جمل)

│ `.طول`
│ ← معرفة طول النص

│ `.مقارنة_نص`
│ ← مقارنة نصين

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== المتغيرات المساعدة ==========
import base64
import hashlib
import random

MORSE_CODE = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
    'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
    'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
    'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
    'Y': '-.--', 'Z': '--..', '0': '-----', '1': '.----', '2': '..---',
    '3': '...--', '4': '....-', '5': '.....', '6': '-....', '7': '--...',
    '8': '---..', '9': '----.', ' ': '/'
}
MORSE_REVERSE = {v: k for k, v in MORSE_CODE.items()}

BOLD_MAP = {
    'A': '𝗔', 'B': '𝗕', 'C': '𝗖', 'D': '𝗗', 'E': '𝗘', 'F': '𝗙', 'G': '𝗚', 'H': '𝗛',
    'I': '𝗜', 'J': '𝗝', 'K': '𝗞', 'L': '𝗟', 'M': '𝗠', 'N': '𝗡', 'O': '𝗢', 'P': '𝗣',
    'Q': '𝗤', 'R': '𝗥', 'S': '𝗦', 'T': '𝗧', 'U': '𝗨', 'V': '𝗩', 'W': '𝗪', 'X': '𝗫',
    'Y': '𝗬', 'Z': '𝗭', 'a': '𝗮', 'b': '𝗯', 'c': '𝗰', 'd': '𝗱', 'e': '𝗲', 'f': '𝗳',
    'g': '𝗴', 'h': '𝗵', 'i': '𝗶', 'j': '𝗷', 'k': '𝗸', 'l': '𝗹', 'm': '𝗺', 'n': '𝗻',
    'o': '𝗼', 'p': '𝗽', 'q': '𝗾', 'r': '𝗿', 's': '𝘀', 't': '𝘁', 'u': '𝘂', 'v': '𝘃',
    'w': '𝘄', 'x': '𝘅', 'y': '𝘆', 'z': '𝘇'
}

ITALIC_MAP = {
    'A': '𝘈', 'B': '𝘉', 'C': '𝘊', 'D': '𝘋', 'E': '𝘌', 'F': '𝘍', 'G': '𝘎', 'H': '𝘏',
    'I': '𝘐', 'J': '𝘑', 'K': '𝘒', 'L': '𝘓', 'M': '𝘔', 'N': '𝘕', 'O': '𝘖', 'P': '𝘗',
    'Q': '𝘘', 'R': '𝘙', 'S': '𝘚', 'T': '𝘛', 'U': '𝘜', 'V': '𝘝', 'W': '𝘞', 'X': '𝘟',
    'Y': '𝘠', 'Z': '𝘡', 'a': '𝘢', 'b': '𝘣', 'c': '𝘤', 'd': '𝘥', 'e': '𝘦', 'f': '𝘧',
    'g': '𝘨', 'h': '𝘩', 'i': '𝘪', 'j': '𝘫', 'k': '𝘬', 'l': '𝘭', 'm': '𝘮', 'n': '𝘯',
    'o': '𝘰', 'p': '𝘱', 'q': '𝘲', 'r': '𝘳', 's': '𝘴', 't': '𝘵', 'u': '𝘶', 'v': '𝘷',
    'w': '𝘸', 'x': '𝘹', 'y': '𝘺', 'z': '𝘻'
}

SMALL_MAP = {
    'A': 'ᴀ', 'B': 'ʙ', 'C': 'ᴄ', 'D': 'ᴅ', 'E': 'ᴇ', 'F': 'ғ', 'G': 'ɢ', 'H': 'ʜ',
    'I': 'ɪ', 'J': 'ᴊ', 'K': 'ᴋ', 'L': 'ʟ', 'M': 'ᴍ', 'N': 'ɴ', 'O': 'ᴏ', 'P': 'ᴘ',
    'Q': 'ǫ', 'R': 'ʀ', 'S': 's', 'T': 'ᴛ', 'U': 'ᴜ', 'V': 'ᴠ', 'W': 'ᴡ', 'X': 'x',
    'Y': 'ʏ', 'Z': 'ᴢ', 'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ғ',
    'g': 'ɢ', 'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ',
    'o': 'ᴏ', 'p': 'ᴘ', 'q': 'ǫ', 'r': 'ʀ', 's': 's', 't': 'ᴛ', 'u': 'ᴜ', 'v': 'ᴠ',
    'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'
}

TASHKEEL = ['َ', 'ً', 'ُ', 'ٌ', 'ِ', 'ٍ', 'ْ', 'ّ']


def apply_font(text, font_map):
    return ''.join(font_map.get(c, c) for c in text)


# ========== أمر .تنسيق ==========
@client.on(events.NewMessage(pattern=r'\.تنسيق\s+([\s\S]+)', outgoing=True))
async def format_text(event):
    text = event.pattern_match.group(1).strip()
    result = f"""┏━━━━━━━━━━━━━━━━━━━━┓
┃ {text}
┗━━━━━━━━━━━━━━━━━━━━┛"""
    await event.edit(result)


# ========== أمر .قلب ==========
@client.on(events.NewMessage(pattern=r'\.قلب\s+([\s\S]+)', outgoing=True))
async def flip_text(event):
    text = event.pattern_match.group(1).strip()
    flip_map = str.maketrans(
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
        'ɐqɔpǝɟɓɥıɾʞlɯuopqɹsʇnʌʍxʎz∀𐐒ↃᗡƎℲ⅁HIſ⋊⅂WNOԀΌᴚS⊥∩ΛMX⅄Z'
    )
    await event.edit(f"🔄 **النص المقلوب:**\n{text.translate(flip_map)[::-1]}")


# ========== أمر .عريض ==========
@client.on(events.NewMessage(pattern=r'\.عريض\s+([\s\S]+)', outgoing=True))
async def bold_text(event):
    text = event.pattern_match.group(1).strip()
    await event.edit(f"📝 **عريض:**\n{apply_font(text, BOLD_MAP)}")


# ========== أمر .مائل ==========
@client.on(events.NewMessage(pattern=r'\.مائل\s+([\s\S]+)', outgoing=True))
async def italic_text(event):
    text = event.pattern_match.group(1).strip()
    await event.edit(f"📝 **مائل:**\n{apply_font(text, ITALIC_MAP)}")


# ========== أمر .مسافة ==========
@client.on(events.NewMessage(pattern=r'\.مسافة\s+([\s\S]+)', outgoing=True))
async def space_text(event):
    text = event.pattern_match.group(1).strip()
    await event.edit(f"📝 **بمسافات:**\n{' '.join(text)}")


# ========== أمر .تشكيل ==========
@client.on(events.NewMessage(pattern=r'\.تشكيل\s+([\s\S]+)', outgoing=True))
async def add_tashkeel(event):
    text = event.pattern_match.group(1).strip()
    result = ''.join(c + random.choice(TASHKEEL) if c.strip() else c for c in text)
    await event.edit(f"📝 **مع التشكيل:**\n{result}")


# ========== أمر .بدون_تشكيل ==========
@client.on(events.NewMessage(pattern=r'\.بدون_تشكيل\s+([\s\S]+)', outgoing=True))
async def remove_tashkeel(event):
    text = event.pattern_match.group(1).strip()
    for t in TASHKEEL:
        text = text.replace(t, '')
    await event.edit(f"📝 **بدون تشكيل:**\n{text}")


# ========== أمر .صغير ==========
@client.on(events.NewMessage(pattern=r'\.صغير\s+([\s\S]+)', outgoing=True))
async def small_text(event):
    text = event.pattern_match.group(1).strip()
    await event.edit(f"📝 **صغير:**\n{apply_font(text, SMALL_MAP)}")


# ========== أمر .عكس ==========
@client.on(events.NewMessage(pattern=r'\.عكس\s+([\s\S]+)', outgoing=True))
async def reverse_text(event):
    text = event.pattern_match.group(1).strip()
    await event.edit(f"🔄 **معكوس:**\n{text[::-1]}")


# ========== أمر .تكرار ==========
@client.on(events.NewMessage(pattern=r'\.تكرار\s+(\d+)\s+([\s\S]+)', outgoing=True))
async def repeat_text(event):
    count = int(event.pattern_match.group(1).strip())
    text = event.pattern_match.group(2).strip()
    result = (text + ' ') * count
    await event.edit(f"🔄 **مكرر {count} مرات:**\n{result.strip()}")


# ========== أمر .استبدال ==========
@client.on(events.NewMessage(pattern=r'\.استبدال\s+(\S+)\s+(\S+)', outgoing=True))
async def replace_text(event):
    old = event.pattern_match.group(1).strip()
    new = event.pattern_match.group(2).strip()
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على النص المراد استبدال الكلمة فيه**")
        return
    result = reply.text.replace(old, new)
    await event.edit(f"🔄 **بعد الاستبدال:**\n{result}")


# ========== أمر .حذف ==========
@client.on(events.NewMessage(pattern=r'\.حذف\s+(\S+)', outgoing=True))
async def delete_word(event):
    word = event.pattern_match.group(1).strip()
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على النص المراد حذف الكلمة منه**")
        return
    result = reply.text.replace(word, '')
    await event.edit(f"🗑 **بعد الحذف:**\n{result}")


# ========== أمر .تقطيع ==========
@client.on(events.NewMessage(pattern=r'\.تقطيع\s+([\s\S]+)', outgoing=True))
async def split_text(event):
    text = event.pattern_match.group(1).strip()
    parts = text.split()
    result = '\n'.join(f"• {p}" for p in parts)
    await event.edit(f"✂️ **النص المقطع:**\n{result}")


# ========== أمر .ترقيم ==========
@client.on(events.NewMessage(pattern=r'\.ترقيم\s+([\s\S]+)', outgoing=True))
async def number_lines(event):
    text = event.pattern_match.group(1).strip()
    lines = text.split('\n')
    result = '\n'.join(f"{i}. {line}" for i, line in enumerate(lines, 1))
    await event.edit(f"🔢 **أسطر مرقمة:**\n{result}")


# ========== أمر .ترتيب ==========
@client.on(events.NewMessage(pattern=r'\.ترتيب\s+([\s\S]+)', outgoing=True))
async def sort_words(event):
    text = event.pattern_match.group(1).strip()
    words = text.split()
    words.sort()
    await event.edit(f"🔤 **مرتب أبجدياً:**\n{' '.join(words)}")


# ========== أمر .عشوائي ==========
@client.on(events.NewMessage(pattern=r'\.عشوائي\s+([\s\S]+)', outgoing=True))
async def shuffle_words(event):
    text = event.pattern_match.group(1).strip()
    words = text.split()
    random.shuffle(words)
    await event.edit(f"🎲 **ترتيب عشوائي:**\n{' '.join(words)}")


# ========== أمر .بدون_فراغات ==========
@client.on(events.NewMessage(pattern=r'\.بدون_فراغات\s+([\s\S]+)', outgoing=True))
async def no_spaces(event):
    text = event.pattern_match.group(1).strip()
    await event.edit(f"📝 **بدون فراغات:**\n{text.replace(' ', '')}")


# ========== أمر .عد ==========
@client.on(events.NewMessage(pattern=r'\.عد\s+([\s\S]+)', outgoing=True))
async def count_text(event):
    text = event.pattern_match.group(1).strip()
    chars = len(text)
    chars_no_space = len(text.replace(' ', ''))
    words = len(text.split())
    lines = len(text.split('\n'))
    await event.edit(f"""📊 **إحصائيات النص:**

📝 **الكلمات:** {words}
🔤 **الحروف (مع فراغات):** {chars}
🔤 **الحروف (بدون فراغات):** {chars_no_space}
📄 **الأسطر:** {lines}""")


# ========== أمر .تشفير ==========
@client.on(events.NewMessage(pattern=r'\.تشفير\s+([\s\S]+)', outgoing=True))
async def encrypt_base64(event):
    text = event.pattern_match.group(1).strip()
    encoded = base64.b64encode(text.encode('utf-8')).decode('utf-8')
    await event.edit(f"🔐 **مشفر Base64:**\n`{encoded}`")


# ========== أمر .فك ==========
@client.on(events.NewMessage(pattern=r'\.فك\s+([\s\S]+)', outgoing=True))
async def decrypt_base64(event):
    text = event.pattern_match.group(1).strip()
    try:
        decoded = base64.b64decode(text.encode('utf-8')).decode('utf-8')
        await event.edit(f"🔓 **مفكوك التشفير:**\n{decoded}")
    except:
        await event.edit("❌ **النص المدخل ليس Base64 صالح**")


# ========== أمر .مورس ==========
@client.on(events.NewMessage(pattern=r'\.مورس\s+([\s\S]+)', outgoing=True))
async def to_morse(event):
    text = event.pattern_match.group(1).strip().upper()
    try:
        result = ' '.join(MORSE_CODE.get(c, c) for c in text)
        await event.edit(f"📡 **شفرة مورس:**\n{result}")
    except:
        await event.edit("❌ **يحتوي النص على رموز غير مدعومة**")


# ========== أمر .فك_مورس ==========
@client.on(events.NewMessage(pattern=r'\.فك_مورس\s+([\s\S]+)', outgoing=True))
async def from_morse(event):
    text = event.pattern_match.group(1).strip()
    try:
        result = ''.join(MORSE_REVERSE.get(c, c) for c in text.split())
        await event.edit(f"📡 **فك شفرة مورس:**\n{result}")
    except:
        await event.edit("❌ **شفرة مورس غير صالحة**")


# ========== أمر .MD5 ==========
@client.on(events.NewMessage(pattern=r'\.MD5\s+([\s\S]+)', outgoing=True))
async def md5_hash(event):
    text = event.pattern_match.group(1).strip()
    hash_result = hashlib.md5(text.encode('utf-8')).hexdigest()
    await event.edit(f"🔐 **MD5 Hash:**\n`{hash_result}`")


# ========== أمر .بيناري ==========
@client.on(events.NewMessage(pattern=r'\.بيناري\s+([\s\S]+)', outgoing=True))
async def to_binary(event):
    text = event.pattern_match.group(1).strip()
    result = ' '.join(format(ord(c), '08b') for c in text)
    await event.edit(f"💻 **كود ثنائي:**\n`{result}`")


# ========== أمر .لون ==========
@client.on(events.NewMessage(pattern=r'\.لون\s+(\S+)\s+([\s\S]+)', outgoing=True))
async def colored_text(event):
    color = event.pattern_match.group(1).strip()
    text = event.pattern_match.group(2).strip()
    colors = {
        "أحمر": "🔴", "أزرق": "🔵", "أخضر": "🟢", "أصفر": "🟡", "برتقالي": "🟠",
        "بنفسجي": "🟣", "أسود": "⚫", "أبيض": "⚪", "بني": "🟤"
    }
    emoji = colors.get(color, "🔵")
    await event.edit(f"{emoji} **{color}:**\n{text}")


# ========== أمر .مربع ==========
@client.on(events.NewMessage(pattern=r'\.مربع\s+([\s\S]+)', outgoing=True))
async def box_text(event):
    text = event.pattern_match.group(1).strip()
    lines = text.split('\n')
    max_len = max(len(line) for line in lines)
    border = '┏' + '━' * (max_len + 2) + '┓'
    middle = '\n'.join(f'┃ {line.ljust(max_len)} ┃' for line in lines)
    bottom = '┗' + '━' * (max_len + 2) + '┛'
    await event.edit(f"{border}\n{middle}\n{bottom}")


# ========== أمر .تحليل ==========
@client.on(events.NewMessage(pattern=r'\.تحليل\s+([\s\S]+)', outgoing=True))
async def analyze_text(event):
    text = event.pattern_match.group(1).strip()
    words = text.split()
    chars = len(text)
    chars_no_space = len(text.replace(' ', ''))
    words_count = len(words)
    sentences = len([s for s in text.replace('!', '.').replace('?', '.').split('.') if s.strip()])
    unique_words = len(set(words))
    avg_word_len = chars_no_space / words_count if words_count > 0 else 0
    
    await event.edit(f"""📊 **تحليل النص:**

📝 **عدد الكلمات:** {words_count}
🔤 **عدد الحروف:** {chars}
🔤 **الحروف (بدون فراغات):** {chars_no_space}
📄 **عدد الجمل:** {sentences}
🔄 **الكلمات الفريدة:** {unique_words}
📏 **متوسط طول الكلمة:** {avg_word_len:.1f}""")


# ========== أمر .طول ==========
@client.on(events.NewMessage(pattern=r'\.طول\s+([\s\S]+)', outgoing=True))
async def text_length(event):
    text = event.pattern_match.group(1).strip()
    await event.edit(f"📏 **طول النص:** {len(text)} حرف")


# ========== أمر .مقارنة_نص ==========
@client.on(events.NewMessage(pattern=r'\.مقارنة_نص\s+([\s\S]+)', outgoing=True))
async def compare_texts(event):
    text1 = event.pattern_match.group(1).strip()
    reply = await event.get_reply_message()
    if not reply or not reply.text:
        await event.edit("❌ **يرجى الرد على النص الثاني**")
        return
    text2 = reply.text.strip()
    
    words1 = set(text1.split())
    words2 = set(text2.split())
    common = words1 & words2
    
    similarity = len(common) / max(len(words1), len(words2)) * 100 if max(len(words1), len(words2)) > 0 else 0
    
    await event.edit(f"""📊 **مقارنة النصين:**

📝 **الكلمات المشتركة:** {len(common)}
🔤 **نسبة التشابه:** {similarity:.1f}%
✅ **الكلمات:** {', '.join(list(common)[:10])}""")