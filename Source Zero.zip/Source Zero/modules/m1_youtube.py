import asyncio
import random
import requests
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

group_settings = {}
user_lang = {}

ANIME_IMAGES = [
    "https://i.pinimg.com/736x/2e/78/60/2e7860a7c5b9b5e1a7f3c9d8e4f1a2b3c.jpg",
    "https://i.pinimg.com/736x/8f/a4/44/8fa4445c3d7e2b1e6f5a9c8d3b7e1f2a.jpg",
    "https://i.pinimg.com/736x/3b/7e/9c/3b7e9c1a5f4d8e2b6c9a7f3e5d1b8c2.jpg",
    "https://i.pinimg.com/736x/7c/9d/2e/7c9d2e8a3f6b1c5d4e7a9b2c8f3e6d1.jpg",
    "https://i.pinimg.com/736x/9f/3a/8c/9f3a8c2e7d1b5f6a4c8e9d2b7f1a5c3.jpg",
]

QURAN_AUDIOS = [
    "https://download.quranicaudio.com/quran/mishari_bin_rashid_alafasy/001.mp3",
    "https://download.quranicaudio.com/quran/mishari_bin_rashid_alafasy/036.mp3",
    "https://download.quranicaudio.com/quran/mishari_bin_rashid_alafasy/055.mp3",
    "https://download.quranicaudio.com/quran/mishari_bin_rashid_alafasy/067.mp3",
    "https://download.quranicaudio.com/quran/mishari_bin_rashid_alafasy/078.mp3",
    "https://download.quranicaudio.com/quran/mishari_bin_rashid_alafasy/112.mp3",
]

SONG_AUDIOS = [
    "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/no_curator/Ketsa/Raising_Frequency/Ketsa_-_08_-_Goodbye_Sun.mp3",
    "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/no_curator/Ketsa/Raising_Frequency/Ketsa_-_01_-_Awake.mp3",
    "https://files.freemusicarchive.org/storage-freemusicarchive-org/music/no_curator/Ketsa/Raising_Frequency/Ketsa_-_03_-_Future_Pop.mp3",
]

POETRY_AUDIOS = [
    "https://archive.org/download/msw023_daelayama_alshafii_ay_128kb/msw023_daelayama_alshafii_ay_128kb.mp3",
    "https://archive.org/download/al-mutanabbi-poetry/almutanabbi_01.mp3",
]

kettuet = [  
  "اكثر شي ينرفزك .. ؟!",
  "اخر مكان رحتله ..؟!",
  "سـوي تـاك @ لـ شخص تريـد تعترفلـه بشي ؟",
  "تغار ..؟!",
  "هـل تعتقـد ان في أحـد يراقبـك 👩🏼‍💻..؟!",
  "أشخاص ردتهم يبقون وياك ومن عرفو هلشي سوو العكس صارت معك؟",
  "ولادتك بنفس المكان الي هسة عايش بي او لا؟",
  "اكثر شي ينرفزك ؟",
  "تغار ؟",
  "كم تبلغ ذاكرة هاتفك؟",
  "صندوق اسرارك ؟",
  "شخص @ تعترفلة بشي ؟",
  "يومك ضاع على ؟",
  "اغرب شيء حدث في حياتك ؟",
  " نسبة حبك للاكل ؟",
  " حكمة تأمان بيها ؟",
  " اكثر شي ينرفزك ؟",
  " هل تعرضت للظلم من قبل؟",
  " خانوك ؟",
  " تزعلك الدنيا ويرضيك ؟",
  " تاريخ غير حياتك ؟",
  " أجمل سنة ميلادية مرت عليك ؟",
  " ولادتك بنفس المكان الي هسة عايش بي او لا؟",
  " تزعلك الدنيا ويرضيك ؟",
  " ماهي هوايتك؟",
  " دوله ندمت انك سافرت لها ؟",
  "شخص اذا جان بلطلعة تتونس بوجود؟",
  " تاخذ مليون دولار و تضرب خويك؟",
  " تاريخ ميلادك؟",
  "اشكم مره حبيت ؟",
  " يقولون ان الحياة دروس ، ماهو أقوى درس تعلمته من الحياة ؟",
  " هل تثق في نفسك ؟",
  " كم مره نمت مع واحده ؟",
  " اسمك الثلاثي ؟",
  "كلمة لشخص خذلك؟",
  "هل انت متسامح ؟",
  "طريقتك المعتادة في التخلّص من الطاقة السلبية؟",
  "عصير لو قهوة؟",
  " صديق أمك ولا أبوك. ؟",
  "تثق بـ احد ؟",
  "كم مره حبيت ؟",
  "اكمل الجملة التالية..... قال رسول الله ص،، انا مدينة العلم وعلي ؟",
  " اوصف حياتك بكلمتين ؟",
  " حياتك محلوا بدون ؟",
  " وش روتينك اليومي؟",
  " شي تسوي من تحس بلملل؟",
  " يوم ميلادك ؟",
  " اكثر مشاكلك بسبب ؟",
  " تزعلك الدنيا ويرضيك ؟",
  " تتوقع فيه احد حاقد عليك ويكرهك ؟",
  "كلمة غريبة من لهجتك ومعناها؟",
"   هل تحب اسمك أو تتمنى تغييره وأي الأسماء ستختار" ,
"  كيف تشوف الجيل ذا؟",
"  تاريخ لن تنساه📅؟",
"  هل من الممكن أن تقتل أحدهم من أجل المال؟",
"  تؤمن ان في حُب من أول نظرة ولا لا ؟.",
"  ‏ماذا ستختار من الكلمات لتعبر لنا عن حياتك التي عشتها الى الآن؟💭",
"  طبع يمكن يخليك تكره شخص حتى لو كنت تُحبه🙅🏻‍♀️؟",
"  ما هو نوع الموسيقى المفضل لديك والذي تستمع إليه دائمًا؟ ولماذا قمت باختياره تحديدًا؟",
"  أطول مدة نمت فيها كم ساعة؟",
"  كلمة غريبة من لهجتك ومعناها؟🤓",
"  ردة فعلك لو مزح معك شخص م تعرفه ؟",
"  شخص تحب تستفزه😈؟",
"  تشوف الغيره انانيه او حب؟",
"  مع او ضد : النوم افضل حل لـ مشاكل الحياة؟",
"  اذا اكتشفت أن أعز أصدقائك يضمر لك السوء، موقفك الصريح؟",
"  ‏للشباب | آخر مرة وصلك غزل من فتاة؟🌚",
"  أوصف نفسك بكلمة؟",
"  شيء من صغرك ماتغير فيك؟",
"  ردة فعلك لو مزح معك شخص م تعرفه ؟",
"  | اذا شفت حد واعجبك وعندك الجرأه انك تروح وتتعرف عليه ، مقدمة الحديث شو راح تكون ؟.",
"  كلمة لشخص أسعدك رغم حزنك في يومٍ من الأيام ؟",
"  حاجة تشوف نفسك مبدع فيها ؟",
"  يهمك ملابسك تكون ماركة ؟",
"  يومك ضاع على؟",
"  اذا اكتشفت أن أعز أصدقائك يضمر لك"," السوء، موقفك الصريح؟",
"  هل من الممكن أن تقتل أحدهم من أجل المال؟",
"  كلمه ماسكه معك الفترة هذي ؟",
"  كيف هي أحوال قلبك؟",
"  صريح، مشتاق؟",
"  اغرب اسم مر عليك ؟",
"  تختار أن تكون غبي أو قبيح؟",
"  آخر مرة أكلت أكلتك المفضّلة؟",
"  دوله ندمت انك سافرت لها😁؟",
"  اشياء صعب تتقبلها بسرعه ؟",
"  كلمة لشخص غالي اشتقت إليه؟💕",
"  اكثر شيء تحس انه مات ف مجتمعنا؟",
"  هل يمكنك مسامحة شخص أخطأ بحقك لكنه قدم الاعتذار وشعر بالندم؟",
"  آخر شيء ضاع منك؟",
"  تشوف الغيره انانيه او حب؟",
"  لو فزعت/ي لصديق/ه وقالك مالك دخل وش بتسوي/ين؟",
"  شيء كل م تذكرته تبتسم ...",
"  هل تحبها ولماذا قمت باختيارها؟",
"  هل تنفق مرتبك بالكامل أم أنك تمتلك هدف يجعلك توفر المال؟",
"  متى تكره الشخص الذي أمامك حتى لو كنت مِن أشد معجبينه؟",
"  أقبح القبحين في العلاقة: الغدر أو الإهمال🤷🏼؟", 
"  هل وصلك رسالة غير متوقعة من شخص وأثرت فيك ؟",
"  هل تشعر أن هنالك مَن يُحبك؟",
"  وش الشيء الي تطلع حرتك فيه و زعلت ؟",
"  صوت مغني م تحبه",
"  كم في حسابك البنكي ؟",
"  اذكر موقف ماتنساه بعمرك؟",
"  ردة فعلك لو مزح معك شخص م تعرفه ؟",
"  عندك حس فكاهي ولا نفسية؟",
"  من وجهة نظرك ما هي الأشياء التي تحافظ على قوة وثبات العلاقة؟",
"  ما هو نوع الموسيقى المفضل لديك والذي تستمع إليه دائمًا؟ ولماذا قمت باختياره تحديدًا؟",
"  هل تنفق مرتبك بالكامل أم أنك تمتلك هدف يجعلك توفر المال؟",
"  هل وصلك رسالة غير متوقعة من شخص وأثرت فيك ؟",
"  شيء من صغرك ماتغير فيك؟",
"  هل يمكنك أن تضحي بأكثر شيء تحبه وتعبت للحصول عليه لأجل شخص تحبه؟",
"  هل تحبها ولماذا قمت باختيارها؟",
"  لو فزعت/ي لصديق/ه وقالك مالك دخل وش بتسوي/ين؟",
"  كلمة لشخص أسعدك رغم حزنك في يومٍ من الأيام ؟",
"  كم مره تسبح باليوم",
"  أفضل صفة تحبه بنفسك؟",
"  أجمل شيء حصل معك خلال هاليوم؟",
"  ‏شيء سمعته عالق في ذهنك هاليومين؟",
"  هل يمكنك تغيير صفة تتصف بها فقط لأجل شخص تحبه ولكن لا يحب تلك الصفة؟",
"  ‏أبرز صفة حسنة في صديقك المقرب؟",
"  ما الذي يشغل بالك في الفترة الحالية؟",
"  آخر مرة ضحكت من كل قلبك؟",
"  احقر الناس هو من ...",
"  اكثر دوله ودك تسافر لها🏞؟",
"  آخر خبر سعيد، متى وصلك؟",
"  ‏نسبة احتياجك للعزلة من 10📊؟",
"  هل تنفق مرتبك بالكامل أم أنك تمتلك هدف يجعلك توفر المال؟",
"  أكثر جملة أثرت بك في حياتك؟",
"  لو قالوا لك  تناول صنف واحد فقط من الطعام لمدة شهر .",
"  هل تنفق مرتبك بالكامل أم أنك تمتلك هدف يجعلك توفر المال؟",
"  آخر مرة ضحكت من كل قلبك؟",
"  وش الشيء الي تطلع حرتك فيه و زعلت ؟",
"  تزعلك الدنيا ويرضيك ؟",
"  متى تكره الشخص الذي أمامك حتى لو كنت مِن أشد معجبينه؟",
"  تعتقد فيه أحد يراقبك👩🏼‍💻؟",
"  احقر الناس هو من ...",
"  شيء من صغرك ماتغير فيك؟",
"  وين نلقى السعاده برايك؟",
"  هل تغارين من صديقاتك؟",
"  أكثر جملة أثرت بك في حياتك؟",
"  كم عدد اللي معطيهم بلوك👹؟",
"  أجمل سنة ميلادية مرت عليك ؟",
"  أوصف نفسك بكلمة؟",
    "هل تجرؤ على قول اسم حبيبك السابق؟",
    "ما هو أكثر موقف محرج تعرضت له؟",
    "كم عدد الأشخاص الذين أعجبت بهم في حياتك؟",
    "هل سبق لك أن كذبت اليوم؟",
    "ما هو سر لا يعرفه أحد عنك؟",
    "هل غنيت في الحمام من قبل؟",
    "ما هو آخر حلم رأيته؟",
    "من هو الشخص الذي تثق به أكثر في هذه المجموعة؟",
    "هل سبق لك أن كسرت قواعد المدرسة؟",
    "ما هو أسوأ طعام تذوقته في حياتك؟",
    "هل بكيت مؤخراً؟ ولماذا؟",
    "ما هو أكثر شيء تخجل منه في غرفتك؟",
    "هل سبق لك أن سرقت شيئاً؟",
    "ما هي أسوأ درجة حصلت عليها في المدرسة؟",
    "من هو أكثر شخص يزعجك في العائلة؟",
]

YOUTUBE_BOT = "@W60yBot"

# ========== أمر .يوت ==========
@client.on(events.NewMessage(pattern=r'\.يوت\s+([\s\S]+)', outgoing=True))
async def youtube_search(event):
    query = event.pattern_match.group(1).strip()
    await event.edit(f"🎶 يـتم تـحميـل المـلف ...")
    
    youtube_bot = group_settings.get(event.chat_id, {}).get("youtube_bot", YOUTUBE_BOT)
    
    try:
        await client.send_message(youtube_bot, f"يوت {query}")
        await asyncio.sleep(2)
        
        messages = await client.get_messages(youtube_bot, limit=10)
        
        for msg in messages:
            if msg.media or msg.audio or msg.document:
                await client.forward_messages(event.chat_id, msg)
                await event.delete()
                return
            
            if msg.text and query.lower() in msg.text.lower():
                await asyncio.sleep(3)
                newer_msgs = await client.get_messages(youtube_bot, limit=5)
                for new_msg in newer_msgs:
                    if new_msg.media or new_msg.audio or new_msg.document:
                        await client.forward_messages(event.chat_id, new_msg)
                        await event.delete()
                        return
        
        await event.edit(f"❌ **لم يتم استلام الملف من البوت**")
                    
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")

# ========== أمر .تبديل اليوت ==========
@client.on(events.NewMessage(pattern=r'\.تبديل اليوت\s+(@\w+)', outgoing=True))
async def switch_youtube_bot(event):
    new_bot = event.pattern_match.group(1).strip()
    chat_id = event.chat_id
    
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["youtube_bot"] = new_bot
    
    await event.edit(f"✅ **تم تغيير بوت اليوتيوب إلى:** {new_bot}")

# ========== أمر .تبديل التحميل ==========
@client.on(events.NewMessage(pattern=r'\.تبديل التحميل\s+(@\w+)', outgoing=True))
async def switch_download_bot(event):
    new_bot = event.pattern_match.group(1).strip()
    chat_id = event.chat_id
    
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["download_bot"] = new_bot
    
    await event.edit(f"✅ **تم تغيير بوت التحميل إلى:** {new_bot}")

# ========== أمر .انمي ==========
@client.on(events.NewMessage(pattern=r'\.انمي', outgoing=True))
async def random_anime(event):
    await event.edit("🎴 **جاري جلب صورة أنمي عشوائية...**")
    
    try:
        response = requests.get("https://api.waifu.pics/sfw/waifu", timeout=10)
        if response.status_code == 200:
            img_url = response.json().get("url")
        else:
            img_url = random.choice(ANIME_IMAGES)
    except:
        img_url = random.choice(ANIME_IMAGES)
    
    try:
        await client.send_file(event.chat_id, img_url, caption="🌸 **صورة أنمي عشوائية**")
        await event.delete()
    except:
        await event.edit("❌ **فشل تحميل الصورة، جرب مرة أخرى**")

# ========== أمر .كت ==========
@client.on(events.NewMessage(pattern=r'\.كت', outgoing=True))
async def challenge_question(event):
    question = random.choice(CHALLENGE_QUESTIONS)
    await event.edit(f"🎲 **سؤال التحدي:**\n\n❓ **{question}**\n\n⚡ *جاوب بصراحة!*")

# ========== أوامر القرآن ==========
@client.on(events.NewMessage(pattern=r'\.تفعيل القران', outgoing=True))
async def enable_quran(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["quran_enabled"] = True
    await event.edit("✅ **تم تفعيل إرسال مقاطع القرآن بشكل عشوائي**")

@client.on(events.NewMessage(pattern=r'\.تعطيل القران', outgoing=True))
async def disable_quran(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["quran_enabled"] = False
    await event.edit("❌ **تم تعطيل إرسال مقاطع القرآن**")

@client.on(events.NewMessage(pattern=r'\.قران', outgoing=True))
async def send_quran(event):
    await event.edit("🕋 **جاري إرسال مقطع قرآن...**")
    audio_url = random.choice(QURAN_AUDIOS)
    try:
        await client.send_file(event.chat_id, audio_url, caption="🎙️ تلاوة قرآنية - بصوت مشاري بن راشد العفاسي")
        await event.delete()
    except:
        await event.edit("❌ **فشل تحميل المقطع الصوتي**")

# ========== أوامر غنيلي ==========
@client.on(events.NewMessage(pattern=r'\.تفعيل غنيلي', outgoing=True))
async def enable_sing(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["sing_enabled"] = True
    await event.edit("🎵 **تم تفعيل ميزة غنيلي**")

@client.on(events.NewMessage(pattern=r'\.تعطيل غنيلي', outgoing=True))
async def disable_sing(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["sing_enabled"] = False
    await event.edit("🔇 **تم تعطيل ميزة غنيلي**")

@client.on(events.NewMessage(pattern=r'\.غنيلي', outgoing=True))
async def send_song(event):
    await event.edit("🎶 **جاري إرسال مقطع غنائي...**")
    audio_url = random.choice(SONG_AUDIOS)
    try:
        await client.send_file(event.chat_id, audio_url, caption="🎤 مقطع موسيقي")
        await event.delete()
    except:
        await event.edit("❌ **فشل تحميل الأغنية**")

# ========== أوامر الشعر ==========
@client.on(events.NewMessage(pattern=r'\.تفعيل الشعر', outgoing=True))
async def enable_poetry(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["poetry_enabled"] = True
    await event.edit("📜 **تم تفعيل إرسال المقاطع الشعرية**")

@client.on(events.NewMessage(pattern=r'\.تعطيل الشعر', outgoing=True))
async def disable_poetry(event):
    chat_id = event.chat_id
    if chat_id not in group_settings:
        group_settings[chat_id] = {}
    group_settings[chat_id]["poetry_enabled"] = False
    await event.edit("📜 **تم تعطيل إرسال المقاطع الشعرية**")

@client.on(events.NewMessage(pattern=r'\.شعر', outgoing=True))
async def send_poetry(event):
    await event.edit("📖 **جاري إرسال مقطع شعري...**")
    audio_url = random.choice(POETRY_AUDIOS)
    try:
        await client.send_file(event.chat_id, audio_url, caption="🎭 قصيدة الإمام الشافعي - دع الأيام تفعل ما تشاء")
        await event.delete()
    except:
        await event.edit("❌ **فشل تحميل المقطع الشعري**")

# ========== أمر .تغيير اللهجة ==========
@client.on(events.NewMessage(pattern=r'\.تغيير اللهجة', outgoing=True))
async def change_language(event):
    user_id = event.sender_id
    current = user_lang.get(user_id, "fusha")
    
    if current == "fusha":
        user_lang[user_id] = "khaliji"
        new_lang = "الخليجية 🇸🇦"
    else:
        user_lang[user_id] = "fusha"
        new_lang = "الفصحى 📖"
    
    await event.edit(f"🔄 **تم تغيير لغة الشروحات إلى:** {new_lang}")

# ========== أمر .م1 (عرض القائمة) ==========
@client.on(events.NewMessage(pattern=r'\.م1', outgoing=True))
async def show_m1_menu(event):
    menu_text = """⟪───── أوامر اليوتيوب والترفيه ─────⟫
    
│ `.يوت`
│ ← للبحث عن أغنية على يوتيوب باستخدام الجملة أو الكلمة

│ `.تبديل اليوت` @اليوزر
│ ← لتغيير بوت اليوتيوب في حال توقف عن العمل

│ `.تبديل التحميل` @اليوزر
│ ← لتبديل بوت التحميل لو صار لا يعمل

│ `.انمي`
│ ← يعرض صورة انمي عشوائية

│ `.كت`
│ ← يعرض سؤال عشوائي للتحدي

│ `.تفعيل/تعطيل القران | `.قران
│ ← لإرسال مقطع آية

│ `.تفعيل/تعطيل غنيلي | .غنيلي`
│ ← لإرسال مقطع أغنية

│ `.تفعيل/تعطيل الشعر | `.شعر
│ ← لإرسال مقطع شعري

│ `.تغيير اللهجة`
│ ← لتغيير الشروحات بين الفصحى والخليجية
╰─────────────────────────"""
    await event.edit(menu_text)