import asyncio
import io
import math
import os
import re
import time
from datetime import datetime
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

# تحقق من وجود المجلدات المطلوبة
TMP_DOWNLOAD_DIRECTORY = "./temp"
if not os.path.exists(TMP_DOWNLOAD_DIRECTORY):
    os.makedirs(TMP_DOWNLOAD_DIRECTORY)

FF_MPEG_DOWN_LOAD_MEDIA_PATH = os.path.join(TMP_DOWNLOAD_DIRECTORY, "ffmpeg_media.mp4")
thumb_image_path = os.path.join(TMP_DOWNLOAD_DIRECTORY, "thumb_image.jpg")

# رموز شريط التقدم
FINISHED_PROGRESS_STR = "█"
UN_FINISHED_PROGRESS_STR = "░"


# ==================== عرض قائمة الأوامر (.م47) ====================
@client.on(events.NewMessage(pattern=r'\.م47', outgoing=True))
async def show_ffmpeg_menu(event):
    menu_text = """⟪───── أوامر ضغط وتقطيع الفيديو ─────⟫

│ `.ضغط + الجودة`
│ ← ضغط الفيديو المرفوع وتقليل حجمه
│ ← مثال: .ضغط 30
│ ← ملاحظة: كلما زاد الرقم قلّت الجودة وصغر الحجم

│ `.ضغط_ملف + الجودة`
│ ← ضغط الفيديو وإرساله كملف بالقوة
│ ← مثال: .ضغط_ملف 30

│ `.حفظ_فيديو`
│ ← حفظ الفيديو في البوت لتقطيعه لاحقاً

│ `.تقطيع_فيديو + من إلى`
│ ← تقطيع جزء من الفيديو المحفوظ وحفظه كفيديو
│ ← مثال: .تقطيع_فيديو 00:30 01:00

│ `.لقطة + الوقت`
│ ← أخذ لقطة شاشة من الفيديو المحفوظ
│ ← مثال: .لقطة 00:30

│ `.تقطيع_صوت + من إلى`
│ ← استخراج مقطع صوتي من الفيديو المحفوظ
│ ← مثال: .تقطيع_صوت 00:30 01:00

│ `.مسح_الفيديو`
│ ← حذف الفيديو المحفوظ من البوت
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== دوال مساعدة ====================

def time_formatter(seconds):
    """تنسيق الوقت"""
    minutes, seconds = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    if hours > 0:
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"


def humanbytes(size):
    """تحويل الحجم إلى صيغة مقروءة"""
    if not size:
        return ""
    power = 2**10
    n = 0
    power_labels = {0: "B", 1: "KB", 2: "MB", 3: "GB"}
    while size > power:
        size /= power
        n += 1
    return f"{size:.2f} {power_labels[n]}"


async def progress_callback(current, total, event, start_time, action):
    """عرض تقدم الرفع أو التحميل"""
    percentage = (current / total) * 100
    speed = current / (time.time() - start_time) if (time.time() - start_time) > 0 else 0
    eta = (total - current) / speed if speed > 0 else 0
    
    bar_length = 10
    filled = int(bar_length * current / total)
    bar = FINISHED_PROGRESS_STR * filled + UN_FINISHED_PROGRESS_STR * (bar_length - filled)
    
    progress_text = f"""⎙ **{action}**

⦁ **النسبة:** {percentage:.1f}%
⦁ **الحجم:** {humanbytes(current)} / {humanbytes(total)}
⦁ **السرعة:** {humanbytes(speed)}/s
⦁ **الوقت المتبقي:** {time_formatter(eta)}

[{bar}]"""
    
    try:
        await event.edit(progress_text)
    except:
        pass


async def convert_video(video_file, output_directory, crf, total_time, event):
    """ضغط الفيديو"""
    out_put_file_name = os.path.join(output_directory, f"{round(time.time())}.mp4")
    progress_file = os.path.join(output_directory, "progress.txt")
    
    with open(progress_file, "w") as f:
        pass
    
    COMPRESSION_START_TIME = time.time()
    
    process = await asyncio.create_subprocess_shell(
        f'ffmpeg -hide_banner -loglevel quiet -progress {progress_file} -i """{video_file}""" -preset ultrafast -vcodec libx265 -crf {crf} -c:a copy """{out_put_file_name}"""',
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    
    while process.returncode != 0:
        await asyncio.sleep(3)
        try:
            with open(progress_file, "r+") as file:
                text = file.read()
                frame = re.findall("frame=(\d+)", text)
                time_in_us = re.findall("out_time_ms=(\d+)", text)
                progress = re.findall("progress=(\w+)", text)
                speed = re.findall("speed=(\d+\.?\d*)", text)
                
                if len(frame):
                    frame = int(frame[-1])
                else:
                    frame = 1
                if len(speed):
                    speed = speed[-1]
                else:
                    speed = 1
                if len(time_in_us):
                    time_in_us = time_in_us[-1]
                else:
                    time_in_us = 1
                if len(progress):
                    if progress[-1] == "end":
                        break
                
                elapsed_time = int(time_in_us) / 1000000
                difference = math.floor((total_time - elapsed_time) / float(speed))
                ETA = "-"
                if difference > 0:
                    ETA = time_formatter(difference)
                
                percentage = math.floor(elapsed_time * 100 / total_time)
                bar_length = 10
                filled = int(bar_length * percentage / 100)
                bar = FINISHED_PROGRESS_STR * filled + UN_FINISHED_PROGRESS_STR * (bar_length - filled)
                
                stats = f"""⎙ **جاري الضغط CRF-{crf}...**

⦁ **الوقت المتبقي:** {ETA}
⦁ **النسبة:** {percentage}%

[{bar}]"""
                
                try:
                    await event.edit(text=stats)
                except:
                    pass
        except:
            pass
    
    stdout, stderr = await process.communicate()
    if os.path.lexists(out_put_file_name):
        return out_put_file_name
    return None


async def cult_small_video(video_file, output_directory, start_time, end_time, out_put_file_name=None):
    """تقطيع الفيديو"""
    out_put_file_name = out_put_file_name or os.path.join(output_directory, f"{round(time.time())}.mp4")
    
    process = await asyncio.create_subprocess_shell(
        f'ffmpeg -i """{video_file}""" -ss {start_time} -to {end_time} -async 1 -strict -2 """{out_put_file_name}"""',
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await process.communicate()
    
    if os.path.lexists(out_put_file_name):
        return out_put_file_name
    return None


# ==================== 1. أمر .ضغط ====================
@client.on(events.NewMessage(pattern=r'\.ضغط(?:\s+(\d+))?$', outgoing=True))
async def compress_video(event):
    """ضغط الفيديو"""
    crf = event.pattern_match.group(1) or "23"
    reply_message = await event.get_reply_message()
    
    if not reply_message or not reply_message.media:
        if not os.path.exists(FF_MPEG_DOWN_LOAD_MEDIA_PATH):
            await event.edit("✘ **يرجى الرد على فيديو أولاً**")
            return
        dlpath = FF_MPEG_DOWN_LOAD_MEDIA_PATH
        delete = False
    else:
        if reply_message.video or reply_message.document:
            dlpath = os.path.join(TMP_DOWNLOAD_DIRECTORY, "compress_input.mp4")
            zedevent = await event.edit("⎙ **جاري تحميل الفيديو...**")
            
            try:
                start_time = time.time()
                await reply_message.download_media(
                    file=dlpath,
                    progress_callback=lambda d, t: asyncio.get_event_loop().create_task(
                        progress_callback(d, t, zedevent, start_time, "جاري التحميل")
                    )
                )
            except Exception as e:
                await event.edit(f"✘ **خطأ في التحميل:** {e}")
                return
            
            delete = True
            await zedevent.edit("⎙ **جاري ضغط الفيديو...**")
        else:
            await event.edit("✘ **يرجى الرد على فيديو فقط**")
            return
    
    # حساب مدة الفيديو
    total_time = 60  # افتراضي
    try:
        import subprocess
        result = subprocess.run(
            f'ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "{dlpath}"',
            shell=True, capture_output=True, text=True
        )
        total_time = float(result.stdout.strip()) if result.stdout.strip() else 60
    except:
        pass
    
    compress = await convert_video(dlpath, TMP_DOWNLOAD_DIRECTORY, crf, total_time, zedevent)
    
    if delete:
        os.remove(dlpath)
    
    if compress:
        new_size = os.path.getsize(compress)
        cap = f"""✓ **تم الضغط بنجاح!**

⌔ **معلومات الضغط:**
⦁ **الجودة:** CRF {crf}
⦁ **الحجم الجديد:** {humanbytes(new_size)}
⦁ **الوقت:** {datetime.now().strftime('%I:%M %p')}"""
        
        try:
            await event.client.send_file(
                event.chat_id,
                compress,
                caption=cap,
                thumb=thumb_image_path if os.path.exists(thumb_image_path) else None,
                supports_streaming=True,
                reply_to=reply_message.id if reply_message else None,
                progress_callback=lambda d, t: asyncio.get_event_loop().create_task(
                    progress_callback(d, t, zedevent, time.time(), "جاري الرفع")
                )
            )
            os.remove(compress)
            await zedevent.delete()
        except Exception as e:
            await event.edit(f"✘ **خطأ في الرفع:** {e}")
    else:
        await event.edit("✘ **فشل الضغط. تأكد من تثبيت ffmpeg**")


# ==================== 2. أمر .ضغط_ملف ====================
@client.on(events.NewMessage(pattern=r'\.ضغط_ملف(?:\s+(\d+))?$', outgoing=True))
async def compress_video_file(event):
    """ضغط الفيديو وإرساله كملف"""
    crf = event.pattern_match.group(1) or "23"
    reply_message = await event.get_reply_message()
    
    if not reply_message or not reply_message.media:
        if not os.path.exists(FF_MPEG_DOWN_LOAD_MEDIA_PATH):
            await event.edit("✘ **يرجى الرد على فيديو أولاً**")
            return
        dlpath = FF_MPEG_DOWN_LOAD_MEDIA_PATH
        delete = False
    else:
        if reply_message.video or reply_message.document:
            dlpath = os.path.join(TMP_DOWNLOAD_DIRECTORY, "compress_input.mp4")
            zedevent = await event.edit("⎙ **جاري تحميل الفيديو...**")
            
            try:
                start_time = time.time()
                await reply_message.download_media(
                    file=dlpath,
                    progress_callback=lambda d, t: asyncio.get_event_loop().create_task(
                        progress_callback(d, t, zedevent, start_time, "جاري التحميل")
                    )
                )
            except Exception as e:
                await event.edit(f"✘ **خطأ في التحميل:** {e}")
                return
            
            delete = True
            await zedevent.edit("⎙ **جاري ضغط الفيديو...**")
        else:
            await event.edit("✘ **يرجى الرد على فيديو فقط**")
            return
    
    total_time = 60
    try:
        import subprocess
        result = subprocess.run(
            f'ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "{dlpath}"',
            shell=True, capture_output=True, text=True
        )
        total_time = float(result.stdout.strip()) if result.stdout.strip() else 60
    except:
        pass
    
    compress = await convert_video(dlpath, TMP_DOWNLOAD_DIRECTORY, crf, total_time, zedevent)
    
    if delete:
        os.remove(dlpath)
    
    if compress:
        new_size = os.path.getsize(compress)
        cap = f"""✓ **تم الضغط بنجاح!**

⌔ **معلومات الضغط:**
⦁ **الجودة:** CRF {crf}
⦁ **الحجم الجديد:** {humanbytes(new_size)}
⦁ **الوقت:** {datetime.now().strftime('%I:%M %p')}"""
        
        try:
            await event.client.send_file(
                event.chat_id,
                compress,
                caption=cap,
                force_document=True,
                reply_to=reply_message.id if reply_message else None,
            )
            os.remove(compress)
            await zedevent.delete()
        except Exception as e:
            await event.edit(f"✘ **خطأ في الرفع:** {e}")
    else:
        await event.edit("✘ **فشل الضغط. تأكد من تثبيت ffmpeg**")


# ==================== 3. أمر .حفظ_فيديو ====================
@client.on(events.NewMessage(pattern=r'\.حفظ_فيديو$', outgoing=True))
async def save_video(event):
    """حفظ الفيديو في البوت"""
    reply_message = await event.get_reply_message()
    
    if not reply_message or not reply_message.media:
        await event.edit("✘ **يرجى الرد على فيديو أو ملف صوتي**")
        return
    
    zedevent = await event.edit("⎙ **جاري حفظ الملف...**")
    
    try:
        start_time = time.time()
        await reply_message.download_media(
            file=FF_MPEG_DOWN_LOAD_MEDIA_PATH,
            progress_callback=lambda d, t: asyncio.get_event_loop().create_task(
                progress_callback(d, t, zedevent, start_time, "جاري الحفظ")
            )
        )
        
        file_size = os.path.getsize(FF_MPEG_DOWN_LOAD_MEDIA_PATH)
        await zedevent.edit(f"✓ **تم حفظ الملف بنجاح!**\n⌔ **الحجم:** {humanbytes(file_size)}\n⌔ **المسار:** `{FF_MPEG_DOWN_LOAD_MEDIA_PATH}`")
    except Exception as e:
        await event.edit(f"✘ **خطأ في الحفظ:** {e}")


# ==================== 4. أمر .تقطيع_فيديو ====================
@client.on(events.NewMessage(pattern=r'\.تقطيع_فيديو\s+(\S+)\s+(\S+)$', outgoing=True))
async def trim_video(event):
    """تقطيع الفيديو المحفوظ"""
    start_time_str = event.pattern_match.group(1)
    end_time_str = event.pattern_match.group(2)
    
    if not os.path.exists(FF_MPEG_DOWN_LOAD_MEDIA_PATH):
        await event.edit("✘ **لا يوجد فيديو محفوظ. استخدم** `.حفظ_فيديو` **أولاً**")
        return
    
    zedevent = await event.edit("⎙ **جاري تقطيع الفيديو...**")
    
    output_file = await cult_small_video(
        FF_MPEG_DOWN_LOAD_MEDIA_PATH,
        TMP_DOWNLOAD_DIRECTORY,
        start_time_str,
        end_time_str,
    )
    
    if output_file is None:
        await event.edit("✘ **فشل التقطيع. تأكد من تثبيت ffmpeg**")
        return
    
    try:
        await event.client.send_file(
            event.chat_id,
            output_file,
            caption=f"✓ **تم التقطيع بنجاح!**\n⌔ **من:** {start_time_str}\n⌔ **إلى:** {end_time_str}",
            supports_streaming=True,
            reply_to=event.message.id,
        )
        os.remove(output_file)
        await zedevent.delete()
    except Exception as e:
        await event.edit(f"✘ **خطأ في الرفع:** {e}")


# ==================== 5. أمر .لقطة ====================
@client.on(events.NewMessage(pattern=r'\.لقطة\s+(\S+)$', outgoing=True))
async def screenshot_video(event):
    """أخذ لقطة من الفيديو المحفوظ"""
    start_time_str = event.pattern_match.group(1)
    
    if not os.path.exists(FF_MPEG_DOWN_LOAD_MEDIA_PATH):
        await event.edit("✘ **لا يوجد فيديو محفوظ. استخدم** `.حفظ_فيديو` **أولاً**")
        return
    
    zedevent = await event.edit("⎙ **جاري أخذ اللقطة...**")
    
    output_file = os.path.join(TMP_DOWNLOAD_DIRECTORY, f"screenshot_{round(time.time())}.jpg")
    
    process = await asyncio.create_subprocess_shell(
        f'ffmpeg -i """{FF_MPEG_DOWN_LOAD_MEDIA_PATH}""" -ss {start_time_str} -vframes 1 """{output_file}"""',
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await process.communicate()
    
    if os.path.exists(output_file):
        try:
            await event.client.send_file(
                event.chat_id,
                output_file,
                caption=f"✓ **تم أخذ اللقطة!**\n⌔ **الوقت:** {start_time_str}",
                force_document=True,
                reply_to=event.message.id,
            )
            os.remove(output_file)
            await zedevent.delete()
        except Exception as e:
            await event.edit(f"✘ **خطأ في الرفع:** {e}")
    else:
        await event.edit("✘ **فشل أخذ اللقطة. تأكد من تثبيت ffmpeg**")


# ==================== 6. أمر .تقطيع_صوت ====================
@client.on(events.NewMessage(pattern=r'\.تقطيع_صوت\s+(\S+)\s+(\S+)$', outgoing=True))
async def trim_audio(event):
    """استخراج مقطع صوتي من الفيديو المحفوظ"""
    start_time_str = event.pattern_match.group(1)
    end_time_str = event.pattern_match.group(2)
    
    if not os.path.exists(FF_MPEG_DOWN_LOAD_MEDIA_PATH):
        await event.edit("✘ **لا يوجد فيديو محفوظ. استخدم** `.حفظ_فيديو` **أولاً**")
        return
    
    zedevent = await event.edit("⎙ **جاري استخراج الصوت...**")
    
    output_file = os.path.join(TMP_DOWNLOAD_DIRECTORY, f"audio_{round(time.time())}.mp3")
    output_video = await cult_small_video(
        FF_MPEG_DOWN_LOAD_MEDIA_PATH,
        TMP_DOWNLOAD_DIRECTORY,
        start_time_str,
        end_time_str,
        output_file,
    )
    
    if output_video is None:
        await event.edit("✘ **فشل الاستخراج. تأكد من تثبيت ffmpeg**")
        return
    
    try:
        await event.client.send_file(
            event.chat_id,
            output_file,
            caption=f"✓ **تم استخراج الصوت!**\n⌔ **من:** {start_time_str}\n⌔ **إلى:** {end_time_str}",
            reply_to=event.message.id,
        )
        os.remove(output_file)
        await zedevent.delete()
    except Exception as e:
        await event.edit(f"✘ **خطأ في الرفع:** {e}")


# ==================== 7. أمر .مسح_الفيديو ====================
@client.on(events.NewMessage(pattern=r'\.مسح_الفيديو$', outgoing=True))
async def clear_video(event):
    """حذف الفيديو المحفوظ"""
    if not os.path.exists(FF_MPEG_DOWN_LOAD_MEDIA_PATH):
        await event.edit("✘ **لا يوجد فيديو محفوظ للحذف**")
    else:
        os.remove(FF_MPEG_DOWN_LOAD_MEDIA_PATH)
        await event.edit("⌫ **تم حذف الفيديو المحفوظ بنجاح**")