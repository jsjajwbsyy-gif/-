import asyncio
from telethon import events
from telethon.errors.rpcerrorlist import YouBlockedUserError

from main import client

# البوت الافتراضي لمعاني الأسماء
DEFAULT_MEANING_BOT = "@zzznambot"
BOT_USER_ID = 2045033062


def get_setting(key, default):
    try:
        with open("meaning_bot.txt", "r") as f:
            return f.read().strip()
    except:
        return default


def save_setting(key, value):
    with open("meaning_bot.txt", "w") as f:
        f.write(str(value))


# ==================== عرض قائمة الأوامر (.م56) ====================
@client.on(events.NewMessage(pattern=r'\.م55', outgoing=True))
async def show_meaning_menu(event):
    menu_text = """⟪───── أوامر معاني الأسماء ─────⟫

│ `.معنى` + اسم
│ ← البحث عن معنى الاسم
│ ← مثال: .معنى محمد

│ `.تبديل_بوت_معنى` + @يوزر
│ ← تغيير بوت معاني الأسماء

│ `.عرض_بوت_معنى`
│ ← عرض البوت الحالي
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== أمر .معنى ====================
@client.on(events.NewMessage(pattern=r'\.معنى\s+([\s\S]+)', outgoing=True))
async def name_meaning(event):
    input_str = event.pattern_match.group(1).strip()
    
    if not input_str:
        await event.edit("✘ **يرجى كتابة اسم مع الأمر**\n⌔ **مثال:** `.معنى محمد`")
        return
    
    await event.edit(f"⎙ **جـارِ البحث عن معنى:** {input_str}...")
    
    chat = get_setting("MEANING_BOT", DEFAULT_MEANING_BOT)
    
    try:
        async with client.conversation(chat) as conv:
            try:
                response = conv.wait_event(
                    events.NewMessage(incoming=True, from_users=BOT_USER_ID)
                )
                await conv.send_message(input_str)
                response = await response
                await client.send_read_acknowledge(conv.chat_id)
            except YouBlockedUserError:
                await event.edit(f"✘ **يرجى إلغاء حظر البوت** {chat} **ثم المحاولة مرة أخرى**")
                return
            
            if response.text.startswith("I can't find that"):
                await event.edit("✘ **لم استطع إيجاد معنى هذا الاسم**")
            else:
                await event.delete()
                await client.send_message(event.chat_id, response.message)
    
    except ValueError:
        await event.edit(f"✘ **لا يمكن العثور على البوت** {chat}\n⌔ تأكد من اسم البوت أو استخدم `.تبديل_بوت_معنى`")
    
    except Exception as e:
        await event.edit(f"✘ **خطأ:** {str(e)[:100]}")


# ==================== أمر .تبديل_بوت_معنى ====================
@client.on(events.NewMessage(pattern=r'\.تبديل_بوت_معنى\s+(@\w+)', outgoing=True))
async def change_meaning_bot(event):
    bot_username = event.pattern_match.group(1).strip()
    save_setting("MEANING_BOT", bot_username)
    await event.edit(f"✓ **تم تغيير بوت معاني الأسماء إلى:** {bot_username}")


# ==================== أمر .عرض_بوت_معنى ====================
@client.on(events.NewMessage(pattern=r'\.عرض_بوت_معنى', outgoing=True))
async def show_meaning_bot(event):
    current_bot = get_setting("MEANING_BOT", DEFAULT_MEANING_BOT)
    await event.edit(
        f"⌔ **بوت معاني الأسماء الحالي:** {current_bot}\n\n"
        f"⌔ **للتغيير:** `.تبديل_بوت_معنى` @يوزر_البوت"
    )