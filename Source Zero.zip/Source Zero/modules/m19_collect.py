import asyncio
import re
import random
from datetime import datetime
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

collect_status = {}

# ==================== عرض قائمة الأوامر (.م19) ====================
@client.on(events.NewMessage(pattern=r'\.م19', outgoing=True))
async def show_collect_menu(event):
    menu_text = """⟪───── التجميع التلقائي ─────⟫

│ `.تجميع + يوزر البوت`
│ ← للتجميع من بوت تمويل المليار أو أي بوت مشابه
│ ← مثال: .تجميع @EEObot

│ `.تجميع دعمكم`
│ ← للتجميع من بوت دعمكم لأنه مختلف

│ `.ايقاف التجميع`
│ ← لإيقاف حالة التجميع الحالية

ملاحظة:  
↢ لازم تكون مشترك بالقنوات الإلزامية للبوت قبل البدء
╰─────────────────────────"""
    await event.edit(menu_text)

# ==================== 1. أمر .تجميع ====================
@client.on(events.NewMessage(pattern=r'\.تجميع\s+(@\w+)', outgoing=True))
async def start_collect(event):
    bot_username = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    chat_id = event.chat_id
    
    if user_id in collect_status:
        collect_status[user_id]["active"] = False
        await asyncio.sleep(1)
    
    collect_status[user_id] = {
        "active": True,
        "bot": bot_username,
        "type": "normal",
        "start_time": datetime.now(),
        "cycles": 0,
        "collected": 0
    }
    
    await event.edit(f"🤖 **بدء التجميع من:** {bot_username}\n\n⏳ **جاري التواصل مع البوت...**")
    asyncio.create_task(collect_from_bot(user_id, chat_id, bot_username, "normal"))

# ==================== 2. أمر .تجميع دعمكم ====================
@client.on(events.NewMessage(pattern=r'\.تجميع دعمكم', outgoing=True))
async def start_daamkom_collect(event):
    user_id = event.sender_id
    chat_id = event.chat_id
    bot_username = DAAMKOM_BOT
    
    if user_id in collect_status:
        collect_status[user_id]["active"] = False
        await asyncio.sleep(1)
    
    collect_status[user_id] = {
        "active": True,
        "bot": bot_username,
        "type": "daamkom",
        "start_time": datetime.now(),
        "cycles": 0,
        "collected": 0
    }
    
    await event.edit(f"🤖 **بدء التجميع من بوت دعمكم**\n\n⏳ **جاري التواصل مع البوت...**")
    asyncio.create_task(collect_from_bot(user_id, chat_id, bot_username, "daamkom"))

# ==================== دالة التجميع الرئيسية ====================
async def collect_from_bot(user_id, chat_id, bot_username, bot_type="normal"):
    status_msg = None
    cycles = 0
    collected = 0
    
    while True:
        if user_id not in collect_status or not collect_status[user_id].get("active", False):
            break
        
        cycles += 1
        collect_status[user_id]["cycles"] = cycles
        
        try:
            async with client.conversation(bot_username) as conv:
                await conv.send_message("/start")
                await asyncio.sleep(2)
                
                responses = []
                for _ in range(5):
                    try:
                        resp = await conv.get_response(timeout=5)
                        responses.append(resp)
                    except:
                        break
                
                for resp in responses:
                    if not resp:
                        continue
                    
                    if resp.buttons:
                        buttons = extract_buttons(resp.buttons)
                        collect_button = find_collect_button(buttons, bot_type)
                        
                        if collect_button:
                            try:
                                await resp.click(collect_button)
                                collected += 1
                                collect_status[user_id]["collected"] = collected
                                await asyncio.sleep(2)
                            except:
                                pass
                    
                    elif resp.text:
                        for cmd in COLLECT_COMMANDS:
                            if cmd in resp.text:
                                await conv.send_message(cmd)
                                collected += 1
                                collect_status[user_id]["collected"] = collected
                                await asyncio.sleep(2)
                                break
                        
                        numbers = re.findall(r'(?:^|\s)(\d+)(?:\.|\s|$)', resp.text)
                        if numbers and bot_type == "daamkom":
                            await conv.send_message(numbers[0])
                            await asyncio.sleep(2)
                
                status_text = f"""🤖 **حالة التجميع من** {bot_username}

🔄 **الدورة:** {cycles}
💰 **تم التجميع:** {collected} مرة
⏱️ **الوقت:** {datetime.now().strftime('%I:%M %p')}

📌 **لإيقاف التجميع:** `.ايقاف التجميع`"""
                
                if status_msg:
                    try:
                        await status_msg.edit(status_text)
                    except:
                        status_msg = await client.send_message(chat_id, status_text)
                else:
                    status_msg = await client.send_message(chat_id, status_text)
                
                wait_time = random.randint(30, 60)
                
                for i in range(wait_time, 0, -10):
                    if user_id not in collect_status or not collect_status[user_id].get("active", False):
                        break
                    await asyncio.sleep(10)
                
        except Exception as e:
            error_msg = str(e)
            if "FLOOD_WAIT" in error_msg:
                wait_match = re.search(r"FLOOD_WAIT_(\d+)", error_msg)
                if wait_match:
                    wait_seconds = int(wait_match.group(1))
                    await client.send_message(chat_id, f"⏳ **انتظار {wait_seconds} ثانية بسبب الحماية...**")
                    await asyncio.sleep(wait_seconds)
            else:
                await asyncio.sleep(30)
    
    final_text = f"""🏁 **انتهى التجميع من** {bot_username}

📊 **الإحصائيات النهائية:**
🔄 **عدد الدورات:** {cycles}
💰 **تم التجميع:** {collected} مرة
📅 **الوقت:** {datetime.now().strftime('%I:%M %p')}"""
    
    await client.send_message(chat_id, final_text)
    
    if user_id in collect_status:
        collect_status[user_id]["active"] = False

# ==================== دالة استخراج الأزرار ====================
def extract_buttons(buttons):
    result = []
    for row in buttons:
        for button in row:
            result.append({"text": button.text, "data": button.data})
    return result

# ==================== دالة البحث عن زر التجميع ====================
def find_collect_button(buttons, bot_type="normal"):
    collect_keywords = [
        "تجميع", "جمع", "حصاد", "collect", "gather", "harvest",
        "تمويل", "مليار", "رصيد", "balance", "get", "claim",
        "استلام", "استلم", "احصل", "بدء", "start"
    ]
    
    if bot_type == "daamkom":
        collect_keywords = ["دعم", "دعمكم", "تصويت", "vote", "دعم القناة"]
    
    for button in buttons:
        text = button.get("text", "").lower()
        for keyword in collect_keywords:
            if keyword in text:
                return button.get("data")
    
    if buttons:
        return buttons[0].get("data")
    
    return None

# ==================== 3. أمر .ايقاف التجميع ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف التجميع', outgoing=True))
async def stop_collect(event):
    user_id = event.sender_id
    
    if user_id in collect_status and collect_status[user_id].get("active", False):
        collect_status[user_id]["active"] = False
        
        bot = collect_status[user_id].get("bot", "غير معروف")
        cycles = collect_status[user_id].get("cycles", 0)
        collected = collect_status[user_id].get("collected", 0)
        
        await event.edit(
            f"🛑 **تم إيقاف التجميع من** {bot}\n\n"
            f"📊 **إحصائيات:**\n"
            f"🔄 الدورات: {cycles}\n"
            f"💰 المجمع: {collected}"
        )
    else:
        await event.edit("❌ **لا توجد عملية تجميع نشطة حالياً**")

# ==================== 4. أمر .حالة التجميع ====================
@client.on(events.NewMessage(pattern=r'\.حالة التجميع', outgoing=True))
async def collect_status_cmd(event):
    user_id = event.sender_id
    
    if user_id not in collect_status or not collect_status[user_id].get("active", False):
        await event.edit("📭 **لا توجد عملية تجميع نشطة حالياً**")
        return
    
    status = collect_status[user_id]
    
    bot = status.get("bot", "غير معروف")
    bot_type = status.get("type", "normal")
    cycles = status.get("cycles", 0)
    collected = status.get("collected", 0)
    start_time = status.get("start_time", datetime.now())
    
    elapsed = datetime.now() - start_time
    hours = elapsed.seconds // 3600
    minutes = (elapsed.seconds % 3600) // 60
    
    status_text = f"""🤖 **حالة التجميع الحالية:**

📡 **البوت:** {bot}
📋 **النوع:** {bot_type}
🔄 **الدورات:** {cycles}
💰 **تم التجميع:** {collected}
⏱️ **الوقت المنقضي:** {hours:02d}:{minutes:02d}

📌 **لإيقاف التجميع:** `.ايقاف التجميع`"""
    
    await event.edit(status_text)