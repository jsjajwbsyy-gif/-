import asyncio
from telethon import events

# استيراد المتغيرات من الملف الرئيسي
from main import client

font_settings = {}
translate_settings = {}

# ========== قاموس الخطوط (عربي + إنجليزي) ==========

# الخط الغامق
BOLD_MAP = {
    'A': '𝗔', 'B': '𝗕', 'C': '𝗖', 'D': '𝗗', 'E': '𝗘', 'F': '𝗙', 'G': '𝗚', 'H': '𝗛', 'I': '𝗜', 'J': '𝗝',
    'K': '𝗞', 'L': '𝗟', 'M': '𝗠', 'N': '𝗡', 'O': '𝗢', 'P': '𝗣', 'Q': '𝗤', 'R': '𝗥', 'S': '𝗦', 'T': '𝗧',
    'U': '𝗨', 'V': '𝗩', 'W': '𝗪', 'X': '𝗫', 'Y': '𝗬', 'Z': '𝗭',
    'a': '𝗮', 'b': '𝗯', 'c': '𝗰', 'd': '𝗱', 'e': '𝗲', 'f': '𝗳', 'g': '𝗴', 'h': '𝗵', 'i': '𝗶', 'j': '𝗷',
    'k': '𝗸', 'l': '𝗹', 'm': '𝗺', 'n': '𝗻', 'o': '𝗼', 'p': '𝗽', 'q': '𝗾', 'r': '𝗿', 's': '𝘀', 't': '𝘁',
    'u': '𝘂', 'v': '𝘃', 'w': '𝘄', 'x': '𝘅', 'y': '𝘆', 'z': '𝘇',
    'ا': '𝗮', 'ب': '𝗯', 'ت': '𝘁', 'ث': '𝘁𝗵', 'ج': '𝗷', 'ح': '𝗵', 'خ': '𝗸𝗵',
    'د': '𝗱', 'ذ': '𝗱𝗵', 'ر': '𝗿', 'ز': '𝘇', 'س': '𝘀', 'ش': '𝘀𝗵', 'ص': '𝘀',
    'ض': '𝗱', 'ط': '𝘁', 'ظ': '𝘇', 'ع': '𝗮', 'غ': '𝗴𝗵', 'ف': '𝗳', 'ق': '𝗾',
    'ك': '𝗸', 'ل': '𝗹', 'م': '𝗺', 'ن': '𝗻', 'ه': '𝗵', 'و': '𝘄', 'ي': '𝘆',
    'ة': '𝗵', 'ى': '𝗮', 'أ': '𝗮', 'إ': '𝗶', 'آ': '𝗮', 'ء': '𝗮', 'ؤ': '𝘂', 'ئ': '𝗲',
    'ـ': '', ' ': ' ', '\n': '\n',
    '0': '𝟬', '1': '𝟭', '2': '𝟮', '3': '𝟯', '4': '𝟰', '5': '𝟱', '6': '𝟲', '7': '𝟳', '8': '𝟴', '9': '𝟵',
}

# الخط المشطوب
STRIKE_MAP = {
    'A': 'A̶', 'B': 'B̶', 'C': 'C̶', 'D': 'D̶', 'E': 'E̶', 'F': 'F̶', 'G': 'G̶', 'H': 'H̶', 'I': 'I̶', 'J': 'J̶',
    'K': 'K̶', 'L': 'L̶', 'M': 'M̶', 'N': 'N̶', 'O': 'O̶', 'P': 'P̶', 'Q': 'Q̶', 'R': 'R̶', 'S': 'S̶', 'T': 'T̶',
    'U': 'U̶', 'V': 'V̶', 'W': 'W̶', 'X': 'X̶', 'Y': 'Y̶', 'Z': 'Z̶',
    'a': 'a̶', 'b': 'b̶', 'c': 'c̶', 'd': 'd̶', 'e': 'e̶', 'f': 'f̶', 'g': 'g̶', 'h': 'h̶', 'i': 'i̶', 'j': 'j̶',
    'k': 'k̶', 'l': 'l̶', 'm': 'm̶', 'n': 'n̶', 'o': 'o̶', 'p': 'p̶', 'q': 'q̶', 'r': 'r̶', 's': 's̶', 't': 't̶',
    'u': 'u̶', 'v': 'v̶', 'w': 'w̶', 'x': 'x̶', 'y': 'y̶', 'z': 'z̶',
    'ا': 'ا̶', 'ب': 'ب̶', 'ت': 'ت̶', 'ث': 'ث̶', 'ج': 'ج̶', 'ح': 'ح̶', 'خ': 'خ̶',
    'د': 'د̶', 'ذ': 'ذ̶', 'ر': 'ر̶', 'ز': 'ز̶', 'س': 'س̶', 'ش': 'ش̶', 'ص': 'ص̶',
    'ض': 'ض̶', 'ط': 'ط̶', 'ظ': 'ظ̶', 'ع': 'ع̶', 'غ': 'غ̶', 'ف': 'ف̶', 'ق': 'ق̶',
    'ك': 'ك̶', 'ل': 'ل̶', 'م': 'م̶', 'ن': 'ن̶', 'ه': 'ه̶', 'و': 'و̶', 'ي': 'ي̶',
    'ة': 'ة̶', 'ى': 'ى̶', 'أ': 'أ̶', 'إ': 'إ̶', 'آ': 'آ̶', 'ء': 'ء̶', 'ؤ': 'ؤ̶', 'ئ': 'ئ̶',
    'ـ': '', ' ': ' ', '\n': '\n',
    '0': '0̶', '1': '1̶', '2': '2̶', '3': '3̶', '4': '4̶', '5': '5̶', '6': '6̶', '7': '7̶', '8': '8̶', '9': '9̶',
}

# خط اللافتة
BANNER_MAP = {
    'A': '卂', 'B': '乃', 'C': '匚', 'D': '刀', 'E': '乇', 'F': '下', 'G': '厶', 'H': '卄', 'I': '工', 'J': '丁',
    'K': '长', 'L': '乚', 'M': '从', 'N': '𠘨', 'O': '口', 'P': '尸', 'Q': 'ㇴ', 'R': '尺', 'S': '丂', 'T': '丅',
    'U': '凵', 'V': 'リ', 'W': '山', 'X': '乂', 'Y': '丫', 'Z': '乙',
    'a': '卂', 'b': '乃', 'c': '匚', 'd': '刀', 'e': '乇', 'f': '下', 'g': '厶', 'h': '卄', 'i': '工', 'j': '丁',
    'k': '长', 'l': '乚', 'm': '从', 'n': '𠘨', 'o': '口', 'p': '尸', 'q': 'ㇴ', 'r': '尺', 's': '丂', 't': '丅',
    'u': '凵', 'v': 'リ', 'w': '山', 'x': '乂', 'y': '丫', 'z': '乙',
    'ا': '卂', 'ب': '乃', 'ت': '匕', 'ث': '丅', 'ج': '丂', 'ح': '卄', 'خ': '片',
    'د': '刀', 'ذ': '刁', 'ر': '尺', 'ز': '乙', 'س': '丩', 'ش': '丂', 'ص': '尸',
    'ض': '卩', 'ط': '匕', 'ظ': '乙', 'ع': '卂', 'غ': '厶', 'ف': '下', 'ق': '㇄',
    'ك': '长', 'ل': '乚', 'م': '从', 'ن': '𠘨', 'ه': '卄', 'و': '山', 'ي': '丫',
    'ة': '卄', 'ى': '丫', 'أ': '卂', 'إ': '乚', 'آ': '卂', 'ء': '丶', 'ؤ': '山', 'ئ': '丫',
    'ـ': '', ' ': ' ', '\n': '\n',
    '0': '0', '1': '1', '2': '2', '3': '3', '4': '4', '5': '5', '6': '6', '7': '7', '8': '8', '9': '9',
}

# ==================== عرض قائمة الأوامر (.م14) ====================
@client.on(events.NewMessage(pattern=r'\.م14', outgoing=True))
async def show_font_translate_menu(event):
    menu_text = """⟪───── أوامر الخطوط والترجمة ─────⟫

│ `.خط غامق` 
│ `.خط مشطوب` 
│ `.خط لافتة` 

│ `.طباعة + النص` 
│ ← لطباعة الجملة بأسلوب محدد

│ لإيقاف أي نوع من الخطوط:
│ ← أعد كتابة نفس الأمر مجددًا

 اوامر الترجمة :
 ─ ──────
│ `.مترجم + رمز اللغة` 
│ ← لتفعيل الترجمة التلقائية
│ مثال: .مترجم en للترجمة إلى الإنجليزية

│ `.ترجمة تلقائية`
│ ← تفعيل الترجمة الفلاشية (ترجمة ثم حذف سريع)

│ `.ايقاف المترجم` 
│ ← لإيقاف الترجمة
╰─────────────────────────"""
    
    await event.edit(menu_text)

# ==================== دالة تحويل النص إلى الخط المطلوب ====================
def convert_text(text, font_map):
    result = ""
    for char in text:
        if char in font_map:
            result += font_map[char]
        else:
            result += char
    return result

# ==================== 1. أمر .خط غامق ====================
@client.on(events.NewMessage(pattern=r'\.خط غامق', outgoing=True))
async def toggle_bold_font(event):
    user_id = event.sender_id
    
    if user_id not in font_settings:
        font_settings[user_id] = {}
    
    current = font_settings[user_id].get("bold", False)
    font_settings[user_id]["bold"] = not current
    
    if not current:
        await event.edit("✅ **تم تفعيل الخط الغامق**\n*جميع رسائلك ستتحول إلى خط غامق*")
    else:
        await event.edit("🔴 **تم تعطيل الخط الغامق**")

# ==================== 2. أمر .خط مشطوب ====================
@client.on(events.NewMessage(pattern=r'\.خط مشطوب', outgoing=True))
async def toggle_strike_font(event):
    user_id = event.sender_id
    
    if user_id not in font_settings:
        font_settings[user_id] = {}
    
    current = font_settings[user_id].get("strike", False)
    font_settings[user_id]["strike"] = not current
    
    if not current:
        await event.edit("✅ **تم تفعيل الخط المشطوب**\n*جميع رسائلك ستتحول إلى خط مشطوب*")
    else:
        await event.edit("🔴 **تم تعطيل الخط المشطوب**")

# ==================== 3. أمر .خط لافتة ====================
@client.on(events.NewMessage(pattern=r'\.خط لافتة', outgoing=True))
async def toggle_banner_font(event):
    user_id = event.sender_id
    
    if user_id not in font_settings:
        font_settings[user_id] = {}
    
    current = font_settings[user_id].get("banner", False)
    font_settings[user_id]["banner"] = not current
    
    if not current:
        await event.edit("✅ **تم تفعيل خط اللافتة**\n*جميع رسائلك ستتحول إلى خط لافتة*")
    else:
        await event.edit("🔴 **تم تعطيل خط اللافتة**")

# ==================== 4. أمر .طباعة ====================
@client.on(events.NewMessage(pattern=r'\.طباعة\s+([\s\S]+)', outgoing=True))
async def print_text(event):
    text = event.pattern_match.group(1).strip()
    user_id = event.sender_id
    
    result = text
    if user_id in font_settings:
        if font_settings[user_id].get("bold", False):
            result = convert_text(result, BOLD_MAP)
        if font_settings[user_id].get("strike", False):
            result = convert_text(result, STRIKE_MAP)
        if font_settings[user_id].get("banner", False):
            result = convert_text(result, BANNER_MAP)
    
    await event.edit(result)

# ==================== 5. أمر .مترجم ====================
@client.on(events.NewMessage(pattern=r'\.مترجم\s+(\w+)', outgoing=True))
async def set_translate_lang(event):
    lang_code = event.pattern_match.group(1).strip().lower()
    user_id = event.sender_id
    
    if user_id not in translate_settings:
        translate_settings[user_id] = {}
    
    translate_settings[user_id]["target_lang"] = lang_code
    translate_settings[user_id]["enabled"] = True
    
    lang_name = {"en": "الإنجليزية", "ar": "العربية", "fr": "الفرنسية", "es": "الإسبانية", "tr": "التركية"}.get(lang_code, lang_code)
    
    await event.edit(f"✅ **تم تفعيل المترجم**\n🌐 **الترجمة إلى:** {lang_name}")

# ==================== 6. أمر .ترجمة تلقائية ====================
@client.on(events.NewMessage(pattern=r'\.ترجمة تلقائية', outgoing=True))
async def enable_auto_translate(event):
    user_id = event.sender_id
    
    if user_id not in translate_settings:
        translate_settings[user_id] = {}
    
    translate_settings[user_id]["auto_translate"] = True
    translate_settings[user_id]["flash_translate"] = True
    
    await event.edit(
        "✅ **تم تفعيل الترجمة التلقائية الفلاشية**\n\n"
        "🌐 **الترجمة إلى:** العربية\n"
        "⚡ **الوضع:** ترجمة فورية ثم حذف سريع"
    )

# ==================== 7. أمر .ايقاف المترجم ====================
@client.on(events.NewMessage(pattern=r'\.ايقاف المترجم', outgoing=True))
async def stop_translate(event):
    user_id = event.sender_id
    
    if user_id in translate_settings:
        translate_settings[user_id]["enabled"] = False
        translate_settings[user_id]["auto_translate"] = False
        translate_settings[user_id]["flash_translate"] = False
    
    await event.edit("🔴 **تم إيقاف الترجمة**")

# ==================== معالج تحويل الخطوط للرسائل الصادرة ====================
@client.on(events.NewMessage(outgoing=True))
async def apply_font_to_outgoing(event):
    user_id = event.sender_id
    
    if user_id not in font_settings:
        return
    
    text = event.text
    if not text:
        return
    
    if text.startswith('.'):
        return
    
    original_text = text
    
    if font_settings[user_id].get("bold", False):
        text = convert_text(text, BOLD_MAP)
    if font_settings[user_id].get("strike", False):
        text = convert_text(text, STRIKE_MAP)
    if font_settings[user_id].get("banner", False):
        text = convert_text(text, BANNER_MAP)
    
    if text != original_text:
        await event.edit(text)

# ==================== معالج الترجمة التلقائية الفلاشية ====================
@client.on(events.NewMessage(incoming=True))
async def auto_translate_flash(event):
    if not event.is_private:
        return
    
    my_id = (await client.get_me()).id
    sender_id = event.sender_id
    
    if sender_id == my_id:
        return
    
    if my_id not in translate_settings:
        return
    
    settings = translate_settings[my_id]
    
    if not settings.get("auto_translate", False) and not settings.get("flash_translate", False):
        return
    
    text = event.text
    if not text:
        return
    
    arabic_chars = sum(1 for c in text if '\u0600' <= c <= '\u06FF')
    if arabic_chars > len(text) * 0.3:
        return
    
    try:
        translated = await translate_text(text, "ar")
        
        if translated and translated != text:
            sent_msg = await event.reply(f"🌐 **ترجمة:**\n{translated}")
            await asyncio.sleep(0.3)
            await sent_msg.delete()
            
    except Exception as e:
        pass

async def translate_text(text, target_lang):
    common_words = {
        "hello": "مرحباً", "hi": "أهلاً", "how are you": "كيف حالك",
        "good": "جيد", "bad": "سيء", "thanks": "شكراً", "thank you": "شكراً",
        "yes": "نعم", "no": "لا", "ok": "حسناً", "bye": "وداعاً",
        "love": "حب", "friend": "صديق", "family": "عائلة",
        "happy": "سعيد", "sad": "حزين", "big": "كبير", "small": "صغير",
        "beautiful": "جميل", "ugly": "قبيح", "strong": "قوي", "weak": "ضعيف",
    }
    
    text_lower = text.lower()
    
    for eng, ar in common_words.items():
        if eng in text_lower:
            return f"{text}\n\n*المعنى:* {ar}"
    
    return None