from main import client
from telethon import events

# ========== M33: أوامر المراقبة والتجسس ==========

mimic_settings = {}

@client.on(events.NewMessage(pattern=r'\.م33', outgoing=True))
async def show_m33_menu(event):
    menu_text = """⟪───── أوامر المراقبة والتجسس ─────⟫

│ `.مراقبة`
│ ← بالرد على رسالة الشخص، يصلك نسخة من كل رسائله

│ `.الغاء المراقبة`
│ ← لإيقاف مراقبة الشخص

│ `.اختفاء`
│ ← حذف كل رسائلك من المجموعة الحالية

│ `.معرفة المحظورين`
│ ← قائمة الأشخاص الذين حظروك

│ `.اختبار`
│ ← بالرد على شخص، تعرف إذا كان حاظرك

│ `.سجل المكالمات`
│ ← سجل آخر المكالمات الصوتية

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== أمر .مراقبة ==========
@client.on(events.NewMessage(pattern=r'\.مراقبة', outgoing=True))
async def start_monitor(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص الذي تريد مراقبته**")
        return
    
    target = await reply.get_sender()
    my_id = event.sender_id
    
    if my_id not in mimic_settings:
        mimic_settings[my_id] = {}
    
    mimic_settings[my_id][target.id] = True
    
    await event.edit(f"🕵️ **تم تفعيل المراقبة على:** {target.first_name}\n📩 **سيتم إرسال كل رسائله إلى المحفوظات**")


# ========== أمر .الغاء المراقبة ==========
@client.on(events.NewMessage(pattern=r'\.الغاء المراقبة', outgoing=True))
async def stop_monitor(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return
    
    target = await reply.get_sender()
    my_id = event.sender_id
    
    if my_id in mimic_settings and target.id in mimic_settings[my_id]:
        del mimic_settings[my_id][target.id]
        await event.edit(f"🛑 **تم إيقاف المراقبة عن:** {target.first_name}")
    else:
        await event.edit("❌ **هذا الشخص غير مراقب**")


# ========== معالج المراقبة ==========
@client.on(events.NewMessage(incoming=True))
async def monitor_handler(event):
    if not event.is_private:
        return
    
    sender = await event.get_sender()
    
    for my_id, targets in mimic_settings.items():
        if sender.id in targets and targets[sender.id]:
            try:
                await client.forward_messages(my_id, event.message)
            except:
                pass


# ========== أمر .اختفاء ==========
@client.on(events.NewMessage(pattern=r'\.اختفاء', outgoing=True))
async def disappear(event):
    if not event.is_group:
        await event.edit("❌ **هذا الأمر يعمل في المجموعات فقط**")
        return
    
    chat_id = event.chat_id
    me = await client.get_me()
    
    await event.edit("👻 **جاري الاختفاء...**")
    
    count = 0
    async for msg in client.iter_messages(chat_id, from_user=me.id):
        try:
            await msg.delete()
            count += 1
            await asyncio.sleep(0.3)
        except:
            pass
    
    await event.edit(f"👻 **تم حذف {count} رسالة من رسائلك**")


# ========== أمر .معرفة المحظورين ==========
@client.on(events.NewMessage(pattern=r'\.معرفة المحظورين', outgoing=True))
async def who_blocked_me(event):
    await event.edit("🔍 **جاري فحص المحادثات...**")
    
    blocked = []
    async for dialog in client.iter_dialogs():
        if dialog.is_user and not dialog.entity.bot:
            try:
                await client.send_message(dialog.id, "🔍")
                await asyncio.sleep(0.5)
                messages = await client.get_messages(dialog.id, limit=1)
                if not messages or not messages[0]:
                    blocked.append(dialog.name)
            except:
                blocked.append(dialog.name)
    
    if blocked:
        text = "🚫 **الأشخاص الذين حظروك:**\n\n"
        for i, name in enumerate(blocked[:20], 1):
            text += f"{i}. {name}\n"
        text += f"\n📊 **العدد:** {len(blocked)}"
    else:
        text = "✅ **لا يوجد أحد حظرك**"
    
    await event.edit(text)


# ========== أمر .اختبار ==========
@client.on(events.NewMessage(pattern=r'\.اختبار', outgoing=True))
async def check_block(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return
    
    target = await reply.get_sender()
    await event.edit("🔍 **جاري الاختبار...**")
    
    try:
        await client.send_message(target.id, "🔍 اختبار...")
        await client.delete_messages(target.id, [await client.get_messages(target.id, limit=1)])
        await event.edit(f"✅ **{target.first_name} لم يحظرك**")
    except:
        await event.edit(f"🚫 **{target.first_name} قام بحظرك**")


# ========== أمر .سجل المكالمات ==========
@client.on(events.NewMessage(pattern=r'\.سجل المكالمات', outgoing=True))
async def call_log(event):
    await event.edit("📞 **جاري جلب سجل المكالمات...**")
    
    calls = []
    async for message in client.iter_messages(event.chat_id, limit=100):
        if message.phone_call:
            duration = message.phone_call.duration if message.phone_call.duration else 0
            calls.append({
                "date": message.date,
                "duration": duration,
                "from_me": message.out
            })
    
    if calls:
        text = "📞 **آخر المكالمات:**\n\n"
        for i, call in enumerate(calls[:10], 1):
            direction = "📤 صادرة" if call["from_me"] else "📥 واردة"
            text += f"{i}. {direction} | ⏱ {call['duration']} ثانية | 📅 {call['date'].strftime('%Y-%m-%d')}\n"
    else:
        text = "📭 **لا توجد مكالمات**"
    
    await event.edit(text)