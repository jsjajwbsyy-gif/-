# ========== نظام التحديث التلقائي لسورس Zero ==========

import os
import asyncio
from pathlib import Path
from telethon import events, functions, types
from telethon.tl.types import InputPeerChannel, InputMessagesFilterDocument

from main import client

# ==================== الإعدادات ====================
UPDATE_CHANNEL = -1002540772725
UPDATE_CHANNEL_USERNAME = "@SSSI5I"

# ==================== عرض قائمة الأوامر (.م43) ====================
@client.on(events.NewMessage(pattern=r'\.م43', outgoing=True))
async def show_m43_menu(event):
    menu_text = """⟪───── أوامر التحديث التلقائي ─────⟫

│ `.تحديث الان`
│ ← تحميل التحديثات الجديدة من القناة

│ `.فحص التحديثات`
│ ← عرض التحديثات المتاحة في القناة

│ `.رفع تحديث`
│ ← رفع ملف تحديث جديد إلى القناة (بالرد)

╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== نظام التحميل التلقائي ====================
async def auto_update():
    """تحميل وتثبيت الإضافات الجديدة تلقائياً من القناة"""
    
    try:
        try:
            entity = await client.get_input_entity(UPDATE_CHANNEL)
            if isinstance(entity, InputPeerChannel):
                full_info = await client(functions.channels.GetFullChannelRequest(channel=entity))
            else:
                entity = await client.get_entity(UPDATE_CHANNEL)
                full_info = await client(functions.channels.GetFullChannelRequest(channel=entity))
            
            channel_id = full_info.full_chat.id
        except:
            print("⚠️ لا يمكن الوصول إلى قناة التحديثات")
            return
        
        documents = await client.get_messages(channel_id, None, filter=InputMessagesFilterDocument)
        total = int(documents.total)
        
        if total == 0:
            print("📭 لا توجد تحديثات جديدة")
            return
        
        print(f"📥 جاري تحميل {total} تحديث...")
        
        installed_count = 0
        updated_count = 0
        
        for module in range(total):
            try:
                plugin = documents[module]
                plugin_name = plugin.file.name
                
                if not plugin_name.endswith(".py"):
                    continue
                
                file_path = f"modules/{plugin_name}"
                is_new = not os.path.exists(file_path)
                
                await client.download_media(plugin, "modules/")
                
                if is_new:
                    installed_count += 1
                    print(f"  ✅ جديد: {plugin_name}")
                else:
                    updated_count += 1
                    print(f"  🔄 محدث: {plugin_name}")
                    
            except Exception as e:
                print(f"  ❌ خطأ: {e}")
                continue
        
        if installed_count > 0 or updated_count > 0:
            print(f"\n📊 تم التحديث:")
            print(f"  ✅ جديد: {installed_count}")
            print(f"  🔄 محدث: {updated_count}")
        else:
            print("✅ السورس محدث بالفعل")
            
    except Exception as e:
        print(f"⚠️ خطأ في التحديث: {e}")


# ==================== أوامر التحديث ====================

@client.on(events.NewMessage(pattern=r'\.تحديث الان', outgoing=True))
async def force_update(event):
    """تحديث السورس يدوياً من القناة"""
    await event.edit("🔄 **جاري جلب التحديثات من القناة...**")
    
    try:
        entity = await client.get_input_entity(UPDATE_CHANNEL)
        if isinstance(entity, InputPeerChannel):
            full_info = await client(functions.channels.GetFullChannelRequest(channel=entity))
        else:
            entity = await client.get_entity(UPDATE_CHANNEL)
            full_info = await client(functions.channels.GetFullChannelRequest(channel=entity))
        
        channel_id = full_info.full_chat.id
        documents = await client.get_messages(channel_id, None, filter=InputMessagesFilterDocument)
        total = int(documents.total)
        
        if total == 0:
            await event.edit("📭 **لا توجد تحديثات جديدة**")
            return
        
        await event.edit(f"📥 **جاري تحميل {total} تحديث...**")
        
        installed = 0
        updated = 0
        
        for module in range(total):
            try:
                plugin = documents[module]
                plugin_name = plugin.file.name
                
                if not plugin_name.endswith(".py"):
                    continue
                
                file_path = f"modules/{plugin_name}"
                is_new = not os.path.exists(file_path)
                
                await client.download_media(plugin, "modules/")
                
                if is_new:
                    installed += 1
                else:
                    updated += 1
                    
            except:
                continue
        
        result = f"✅ **تم التحديث بنجاح!**\n\n"
        result += f"📊 **جديد:** {installed}\n"
        result += f"🔄 **محدث:** {updated}\n\n"
        result += f"📌 **قناة التحديثات:** {UPDATE_CHANNEL_USERNAME}"
        
        await event.edit(result)
        
    except Exception as e:
        await event.edit(f"❌ **خطأ في التحديث:** {str(e)[:100]}")


@client.on(events.NewMessage(pattern=r'\.فحص التحديثات', outgoing=True))
async def check_updates(event):
    """فحص إذا كان هناك تحديثات جديدة"""
    await event.edit("🔍 **جاري فحص التحديثات...**")
    
    try:
        entity = await client.get_input_entity(UPDATE_CHANNEL)
        if isinstance(entity, InputPeerChannel):
            full_info = await client(functions.channels.GetFullChannelRequest(channel=entity))
        else:
            entity = await client.get_entity(UPDATE_CHANNEL)
            full_info = await client(functions.channels.GetFullChannelRequest(channel=entity))
        
        channel_id = full_info.full_chat.id
        documents = await client.get_messages(channel_id, None, filter=InputMessagesFilterDocument)
        total = int(documents.total)
        
        if total == 0:
            await event.edit("📭 **لا توجد تحديثات جديدة**")
            return
        
        text = f"📋 **التحديثات المتاحة ({total}):**\n\n"
        text += f"📌 **القناة:** {UPDATE_CHANNEL_USERNAME}\n\n"
        
        for i, module in enumerate(documents[:10], 1):
            plugin_name = module.file.name
            file_path = f"modules/{plugin_name}"
            
            if os.path.exists(file_path):
                text += f"  {i}. ✅ `{plugin_name}` (مثبت)\n"
            else:
                text += f"  {i}. 🆕 `{plugin_name}` (جديد)\n"
        
        text += f"\n📌 **للتحديث:** `.تحديث الان`"
        
        await event.edit(text)
        
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


@client.on(events.NewMessage(pattern=r'\.رفع تحديث', outgoing=True))
async def upload_update(event):
    """رفع ملف تحديث إلى القناة (للمطور فقط)"""
    reply = await event.get_reply_message()
    
    if not reply or not reply.document:
        await event.edit("❌ **يرجى الرد على ملف .py لرفعه كتحديث**")
        return
    
    if not reply.document.file_name.endswith(".py"):
        await event.edit("❌ **الملف يجب أن يكون بصيغة .py**")
        return
    
    await event.edit("📤 **جاري رفع التحديث إلى القناة...**")
    
    try:
        await client.send_file(UPDATE_CHANNEL, reply.document, caption=f"🔄 تحديث جديد: {reply.document.file_name}")
        await event.edit(f"✅ **تم رفع التحديث إلى القناة!**\n📁 **الملف:** `{reply.document.file_name}`\n📌 **القناة:** {UPDATE_CHANNEL_USERNAME}")
        
    except Exception as e:
        await event.edit(f"❌ **خطأ في الرفع:** {str(e)[:100]}")


# ==================== تشغيل التحديث التلقائي عند بدء السورس ====================
async def start_auto_update():
    """بدء التحديث التلقائي عند تشغيل السورس"""
    await asyncio.sleep(10)
    await auto_update()