from main import client
from telethon import events

# ========== M35: أوامر إبداعية وتصميم ==========

@client.on(events.NewMessage(pattern=r'\.م35', outgoing=True))
async def show_m35_menu(event):
    menu_text = """⟪───── أوامر إبداعية وتصميم ─────⟫

│ `.شعار`
│ ← إنشاء شعار احترافي من النص

│ `.QR`
│ ← إنشاء كود QR من أي نص أو رابط

│ `.كلام`
│ ← تحويل الصورة إلى نص مكتوب

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== أمر .شعار ==========
@client.on(events.NewMessage(pattern=r'\.شعار\s+([\s\S]+)', outgoing=True))
async def create_logo(event):
    text = event.pattern_match.group(1).strip()
    await event.edit("🎨 **جاري إنشاء الشعار...**")
    
    try:
        from PIL import Image, ImageDraw, ImageFont
        import os
        
        img = Image.new('RGB', (800, 300), color=(25, 25, 35))
        draw = ImageDraw.Draw(img)
        
        try:
            font = ImageFont.truetype("arial.ttf", 80)
        except:
            font = ImageFont.load_default()
        
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        x = (800 - text_width) // 2
        y = (300 - text_height) // 2
        
        draw.text((x+3, y+3), text, fill=(0, 0, 0), font=font)
        draw.text((x, y), text, fill=(0, 200, 255), font=font)
        
        draw.rectangle([(50, 250), (750, 255)], fill=(0, 200, 255))
        
        path = "logo.png"
        img.save(path)
        
        await client.send_file(event.chat_id, path, caption=f"🎨 **شعار:** {text}")
        await event.delete()
        os.remove(path)
        
    except ImportError:
        await event.edit("❌ **مكتبة Pillow غير مثبتة**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .QR ==========
@client.on(events.NewMessage(pattern=r'\.QR\s+([\s\S]+)', outgoing=True))
async def create_qr(event):
    text = event.pattern_match.group(1).strip()
    await event.edit("📱 **جاري إنشاء كود QR...**")
    
    try:
        qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={text}"
        
        import requests
        response = requests.get(qr_url)
        
        if response.status_code == 200:
            path = "qr.png"
            with open(path, 'wb') as f:
                f.write(response.content)
            
            await client.send_file(event.chat_id, path, caption=f"📱 **كود QR:** {text}")
            await event.delete()
            os.remove(path)
        else:
            await event.edit("❌ **فشل إنشاء كود QR**")
            
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .كلام ==========
@client.on(events.NewMessage(pattern=r'\.كلام', outgoing=True))
async def image_to_text(event):
    reply = await event.get_reply_message()
    
    if not reply or not reply.photo:
        await event.edit("❌ **يرجى الرد على صورة**")
        return
    
    await event.edit("📝 **جاري تحويل الصورة إلى نص...**")
    await event.edit("⚠️ **هذه الميزة تحتاج إلى مكتبة Tesseract OCR**\n📌 قم بتثبيتها: `pip install pytesseract`")