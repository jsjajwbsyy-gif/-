from main import client
from telethon import events

# ========== M37: أوامر الصور والوسائط ==========

import os
import random
import requests
from telethon import events
from main import client

@client.on(events.NewMessage(pattern=r'\.م37', outgoing=True))
async def show_m37_menu(event):
    menu_text = """⟪───── أوامر الصور والوسائط ─────⟫

│ `.خلفية`
│ ← صورة خلفية عشوائية (غير محدودة)

│ `.طبيعة`
│ ← صورة طبيعة خلابة (غير محدودة)

│ `.سيارة`
│ ← صورة سيارة عشوائية (150+ صورة)

│ `.حيوان`
│ ← صورة حيوان عشوائي

│ `.قطة`
│ ← صورة قطة لطيفة

│ `.كلب`
│ ← صورة كلب رائع

│ `.فضاء`
│ ← صورة من الفضاء

│ `.مدينة`
│ ← صورة مدينة عشوائية

│ `.متحرك`
│ ← صورة GIF متحركة عشوائية

│ `.تلوين`
│ ← تلوين الصورة (بالرد)

│ `.فلتر`
│ ← وضع فلتر على الصورة (بالرد)

│ `.رسم`
│ ← تحويل الصورة إلى رسم (بالرد)

│ `.اقتصاص`
│ ← قص الصورة بشكل مربع (بالرد)

│ `.تدوير`
│ ← تدوير الصورة (بالرد)

│ `.كتابة_على_الصورة`
│ ← كتابة نص على الصورة (بالرد)

│ `.ميم`
│ ← إنشاء ميم (نص علوي وسفلي) (بالرد)

│ `.QR`
│ ← إنشاء كود QR من نص أو رابط

│ `.باركود`
│ ← إنشاء باركود من نص أو رابط

│ `.فك رمز`
│ ← فك تشفير QR/Barcode من صورة (بالرد)

╰─────────────────────────"""
    await event.edit(menu_text)


# ========== أوامر الصور (القديمة) ==========
# (احتفظ بجميع الأوامر القديمة: .خلفية, .طبيعة, .سيارة, الخ...)


# ========== أمر .QR (القديم - موجود) ==========
@client.on(events.NewMessage(pattern=r'\.QR\s+([\s\S]+)', outgoing=True))
async def create_qr(event):
    text = event.pattern_match.group(1).strip()
    await event.edit("📱 **جاري إنشاء كود QR...**")
    
    try:
        qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={text}"
        response = requests.get(qr_url)
        
        if response.status_code == 200:
            path = "qr.png"
            with open(path, 'wb') as f:
                f.write(response.content)
            
            await client.send_file(event.chat_id, path, caption=f"📱 **كود QR:** {text}")
            await event.delete()
            os.remove(path)
        else:
            await event.edit("❌ **فشل إنشاء كود QR**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .باركود (جديد) ==========
@client.on(events.NewMessage(pattern=r'\.باركود\s+([\s\S]+)', outgoing=True))
async def create_barcode(event):
    text = event.pattern_match.group(1).strip()
    await event.edit("📊 **جاري إنشاء الباركود...**")
    
    try:
        # استخدام barcode API مجاني
        barcode_url = f"https://barcode.tec-it.com/barcode.ashx?data={text}&code=Code128&dpi=96&imagetype=png"
        response = requests.get(barcode_url)
        
        if response.status_code == 200:
            path = "barcode.png"
            with open(path, 'wb') as f:
                f.write(response.content)
            
            await client.send_file(event.chat_id, path, caption=f"📊 **باركود:** {text}")
            await event.delete()
            os.remove(path)
        else:
            await event.edit("❌ **فشل إنشاء الباركود**")
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")


# ========== أمر .فك رمز (جديد - يفك QR/Barcode) ==========
@client.on(events.NewMessage(pattern=r'\.فك رمز', outgoing=True))
async def decode_qr_barcode(event):
    reply = await event.get_reply_message()
    
    if not reply or not reply.photo:
        await event.edit("❌ **يرجى الرد على صورة تحتوي على QR Code أو Barcode**")
        return
    
    await event.edit("🔍 **جاري فك التشفير...**")
    
    try:
        # تحميل الصورة
        path = await client.download_media(reply.photo)
        
        # استخدام API لفك التشفير
        import requests
        with open(path, 'rb') as f:
            files = {'file': f}
            response = requests.post('https://api.qrserver.com/v1/read-qr-code/', files=files)
        
        if response.status_code == 200:
            result = response.json()
            if result[0]['symbol'][0]['data']:
                decoded_text = result[0]['symbol'][0]['data']
                await event.edit(f"🔓 **تم فك التشفير:**\n\n`{decoded_text}`")
            else:
                await event.edit("❌ **لم يتم العثور على رمز في الصورة**")
        else:
            await event.edit("❌ **فشل فك التشفير**")
        
        os.remove(path)
        
    except Exception as e:
        await event.edit(f"❌ **خطأ:** {str(e)[:100]}")