import html
from telethon import events
from telethon.tl.functions.account import UpdateProfileRequest
from telethon.tl.functions.photos import UploadProfilePhotoRequest, DeletePhotosRequest
from telethon.tl.functions.users import GetFullUserRequest

from main import client

original_profile = {}

# ==================== عرض قائمة الأوامر (.م8) ====================
@client.on(events.NewMessage(pattern=r'\.م8', outgoing=True))
async def show_m8_menu(event):
    menu_text = """⟪───── أوامر الانتحال ─────⟫

│ `.انتحال`
│ ← نسخ اسم وصورة وبايو الشخص (بالرد)

│ `.اعادة`
│ ← ارجاع حسابك لوضعه الاصلي

│ `.حفظ_اصلي`
│ ← حفظ معلومات حسابك الحالية
╰─────────────────────────"""
    await event.edit(menu_text)


# ==================== 1. أمر .انتحال ====================
@client.on(events.NewMessage(pattern=r'\.انتحال', outgoing=True))
async def impersonate_user(event):
    reply = await event.get_reply_message()
    if not reply:
        await event.edit("❌ **يرجى الرد على رسالة الشخص**")
        return

    target_user = await reply.get_sender()
    user_id = target_user.id
    my_id = event.sender_id

    await event.edit("🔄 **جاري نسخ معلومات الحساب...**")

    try:
        # حفظ معلومات الحساب الاصلي
        if my_id not in original_profile:
            me = await client.get_me()
            original_profile[my_id] = {
                "first_name": me.first_name,
                "last_name": me.last_name or "",
                "bio": "",
                "photo": None
            }

            try:
                full_me = await client(GetFullUserRequest(me.id))
                if full_me.full_user.about:
                    original_profile[my_id]["bio"] = full_me.full_user.about
            except:
                pass

            try:
                photos = await client.get_profile_photos(me.id, limit=1)
                if photos:
                    original_profile[my_id]["photo"] = await client.download_file(photos[0])
            except:
                pass

        # تجهيز الاسم
        first_name = html.escape(target_user.first_name or "")
        first_name = first_name.replace("\u2060", "")

        last_name = target_user.last_name
        if last_name:
            last_name = html.escape(last_name)
            last_name = last_name.replace("\u2060", "")
        else:
            last_name = ""

        # نسخ الاسم
        await client(UpdateProfileRequest(first_name=first_name, last_name=last_name))

        # نسخ البايو
        try:
            full_target = await client(GetFullUserRequest(user_id))
            if full_target.full_user.about:
                await client(UpdateProfileRequest(about=full_target.full_user.about))
        except:
            pass

        # نسخ الصورة
        try:
            # تحميل صورة الهدف
            profile_pic = await client.download_profile_photo(user_id, "./temp/")
            if profile_pic:
                # حذف الصورة الحالية
                my_photos = await client.get_profile_photos(my_id, limit=1)
                if my_photos:
                    await client(DeletePhotosRequest(my_photos))

                # رفع الصورة الجديدة
                pfile = await client.upload_file(profile_pic)
                await client(UploadProfilePhotoRequest(pfile))
        except:
            pass

        await event.edit(f"✅ **تم انتحال الحساب بنجاح**\n\n📌 *لارجاع حسابك استخدم* `.اعادة`")

    except Exception as e:
        await event.edit(f"❌ **فشل الانتحال:** {str(e)}")


# ==================== 2. أمر .اعادة ====================
@client.on(events.NewMessage(pattern=r'\.اعادة', outgoing=True))
async def restore_profile(event):
    my_id = event.sender_id

    if my_id not in original_profile:
        await event.edit("❌ **لا توجد معلومات محفوظة**")
        return

    await event.edit("🔄 **جاري استعادة حسابك الاصلي...**")
    original = original_profile[my_id]

    try:
        # استعادة الاسم
        await client(UpdateProfileRequest(
            first_name=original["first_name"],
            last_name=original.get("last_name", "")
        ))

        # استعادة البايو
        try:
            await client(UpdateProfileRequest(about=original.get("bio", "")))
        except:
            pass

        # استعادة الصورة
        try:
            if original.get("photo"):
                my_photos = await client.get_profile_photos(my_id, limit=1)
                if my_photos:
                    await client(DeletePhotosRequest(my_photos))

                uploaded = await client.upload_file(original["photo"])
                await client(UploadProfilePhotoRequest(uploaded))
        except:
            pass

        del original_profile[my_id]

        await event.edit("✅ **تم استعادة حسابك بنجاح**")

    except Exception as e:
        await event.edit(f"❌ **فشل الاستعادة:** {str(e)}")


# ==================== 3. أمر .حفظ_اصلي ====================
@client.on(events.NewMessage(pattern=r'\.حفظ_اصلي', outgoing=True))
async def save_original_profile(event):
    my_id = event.sender_id

    await event.edit("💾 **جاري حفظ معلومات حسابك...**")

    try:
        me = await client.get_me()

        original_profile[my_id] = {
            "first_name": me.first_name,
            "last_name": me.last_name or "",
            "bio": "",
            "photo": None
        }

        try:
            full_me = await client(GetFullUserRequest(me.id))
            if full_me.full_user.about:
                original_profile[my_id]["bio"] = full_me.full_user.about
        except:
            pass

        try:
            photos = await client.get_profile_photos(me.id, limit=1)
            if photos:
                original_profile[my_id]["photo"] = await client.download_file(photos[0])
        except:
            pass

        await event.edit("✅ **تم حفظ معلومات حسابك بنجاح**")

    except Exception as e:
        await event.edit(f"❌ **فشل الحفظ:** {str(e)}")