import os
import asyncio
import sys
import subprocess
from telethon import TelegramClient, events, Button
from telethon.errors import BotMethodInvalidError

# تثبيت المكتبات الأساسية
os.system("pip install tgcalls==0.0.5 pytgcalls==0.0.9 --no-cache-dir")

try:
    import aiohttp
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "aiohttp"])
    import aiohttp

try:
    import google.generativeai as genai
except ImportError:
    genai = None

try:
    from pytgcalls import PyTgCalls
    from pytgcalls.types import AudioPiped, VideoPiped
    import yt_dlp
    PYTGCALLS_AVAILABLE = True
except ImportError:
    PYTGCALLS_AVAILABLE = False

# ==================== الإعدادات ====================
API_ID = 27503848
API_HASH = "a08a570b86888fecda16e0e5e0bdf2a5"
TG_BOT_TOKEN = "8634485120:AAHSi3_ppQb4w34h9ry_bhH4KfavaE0IezA"

# ==================== إنشاء العميل والبوت المساعد ====================
client = TelegramClient('zero_userbot', API_ID, API_HASH)
tgbot = TelegramClient('zero_bot', API_ID, API_HASH)

# ==================== المتغيرات العامة المشتركة ====================
group_settings = {}
private_settings = {}
time_settings = {}
ai_settings = {}
user_api_keys = {}
publish_settings = {}
setup_state = {}
hunt_settings = {}
hunted_usernames = {}
hunt_status = {}
collect_status = {}
custom_settings = {}
font_settings = {}
translate_settings = {}
tts_settings = {}
download_settings = {}
mimic_settings = {}
simulate_settings = {}
force_subscribe_channels = {}
force_subscribe_enabled = {}
self_destruct_settings = {}
flush_status = {}
virtual_members = []
report_status = {}
xo_bot_settings = {}
banned_words = {}
music_players = {}
video_players = {}
music_queues = {}
video_queues = {}
music_enabled = {}
video_enabled = {}
streaks = {"love": {}, "partner": {}, "group": {}}
reaction_settings = {}
last_streak_update = {}
destroy_settings = {}
shortcuts = {}
shortcuts_enabled = {}
original_profile = {}
custom_replies = {}
normal_replies = {}
multi_replies = {}
special_replies = {}
special_multi_replies = {}
group_restrictions = {}
muted_users = {}
warnings_count = {}
warnings_settings = {}
protection_settings = {}
exceptions_list = {}
active_sessions = {}
session_expiry = {}
session_counter = {}
session_permissions = {}
developer_settings = {}
voice_settings = {}
reminders = {}

translation_dict = {
    "hello": "مرحباً", "hi": "أهلاً", "good": "جيد", "bad": "سيء",
    "love": "حب", "thanks": "شكراً", "yes": "نعم", "no": "لا",
    "ok": "حسناً", "bye": "وداعاً", "friend": "صديق", "family": "عائلة",
    "happy": "سعيد", "sad": "حزين", "big": "كبير", "small": "صغير",
    "beautiful": "جميل", "ugly": "قبيح", "strong": "قوي", "weak": "ضعيف",
    "fast": "سريع", "slow": "بطيء",
}

PATTERN_MAP = {
    '1': 'abcdefghijklmnopqrstuvwxyz',
    '2': '0123456789',
    '3': 'abcdefghijklmnopqrstuvwxyz0123456789',
    '4': 'abcdefghijklmnopqrstuvwxyz0123456789',
    '5': 'abcdefghijklmnopqrstuvwxyz',
    '6': '0123456789',
}

REPORT_TYPES = {
    "1": {"name": "سبام", "reason": "spam"},
    "2": {"name": "عنف", "reason": "violence"},
    "3": {"name": "محتوى إباحي", "reason": "pornography"},
    "4": {"name": "انتحال شخصية", "reason": "impersonation"},
    "5": {"name": "حقوق نشر", "reason": "copyright"},
    "6": {"name": "محتوى غير لائق", "reason": "inappropriate"},
    "7": {"name": "احتيال", "reason": "scam"},
    "8": {"name": "خطاب كراهية", "reason": "hate_speech"},
}

INTERNAL_REPORT_TYPES = {
    "1": "إبلاغ عن رسالة",
    "2": "إبلاغ عن قناة",
    "3": "إبلاغ عن مجموعة",
    "4": "إبلاغ عن مستخدم",
    "5": "إبلاغ جماعي",
}

AVAILABLE_MODELS = [
    "gemini-3-flash-preview",
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    "gemini-2.5-pro-preview-05-06",
]

DEFAULT_MODEL = "gemini-3-flash-preview"

# قائمة المفاتيح الاحتياطية (12 مفتاحاً)
BACKUP_API_KEYS = [
    "AIzaSyC54GREVohBro7RIBAwh3HrIqHySH_wIbM",   # 1
    "AIzaSyDtppUt_ns3rxBO9cwJdG7kGa-umC7iuQ8",   # 2
    "AIzaSyB0wzGdwT233ppyq984emOvcSZkRFWvzCc",   # 3
    "AIzaSyCPK79Os0_tgZ0bE6o9g3YcLky_Pro7u90",   # 4
    "AIzaSyDB6DqIsSFuTUIRg2tp26uc5W4wYpXa_Ak",   # 5
    "AIzaSyDKVNUjQtOS_ZmwfKcfp9OgF5UW_HMvCE4",   # 6
    "AIzaSyCrs2vLIWZy_kbcH4FZzW2zrP7LTU7T7IQ",   # 7
    "AIzaSyD4ZVto7JZVT7GP6Ftylgn49XV60bJb9Zc",   # 8
    "AIzaSyBeUWYfU7HBUVy-5Vf1YPhu28utW2xw-RE",   # 9
    "AIzaSyCmV7AG0Ma7X5hqHIDtth36zcv2w1VNMVU",   # 10
    "AIzaSyDLYHKGbcOQD1lvwb_jcgVEWcgQDNSOkT0",   # 11
    "AIzaSyAklL7Si70rmTm7AQtqGJtm6eM3GlFUQio",   # 12
]

YOUTUBE_BOT = "@youtube"
DOWNLOAD_BOT = "@utubebot"
DEFAULT_TTS_BOT = "@ttsbot"
DEFAULT_DOWNLOAD_BOT = "@utubebot"
GAMEE_BOT = "@gamee"
DEFAULT_XO_BOT = "@XOBot"
DAAMKOM_BOT = "@DaamkomBot"
DEFAULT_VOICE_BOT = "@VoiceBot"

COLLECT_COMMANDS = ["/start", "/collect", "/gather", "تجميع", "جمع", "بدء", "حصاد"]

TMDB_API_KEY = "3c3c1c2d2c2c3c3c4c4c5c5c6c6c7c7c"
MUSIC_HEADER_IMAGE = "https://t.me/SSSI5I/6"

DEFAULT_DEVELOPER_TEXT = """👑 **معلومات المطور**

👤 **الاسم:** {name}
📎 **اليوزر:** {username}
🆔 **الآيدي:** {id}
📝 **البايو:** {bio}
📞 **رقم الهاتف:** {phone}
🌐 **اللغة:** {lang}
💎 **الحساب مميز:** {premium}
🤖 **بوت:** {bot}
✅ **موثق:** {verified}
📅 **تاريخ الانضمام:** {joined}

📊 **إحصائيات:**
👥 **المجموعات المشتركة:** {groups_count}
📢 **القنوات:** {channels_count}
💬 **المحادثات الخاصة:** {private_count}

⏰ **آخر تحديث:** {time}"""

# ==================== الرسمات ====================

# وجه الديناصور - يظهر عند طلب رقم الهاتف
dino_art = r"""
─────▄████▀█▄
───▄█████████████████▄
─▄█████.▼.▼.▼.▼.▼.▼▼▼▼
███████𝙕𝙀𝙍𝙊 𝙐𝙎𝙀𝙍𝘽𝙊𝙏
████████▄▄▲.▲▲▲▲▲▲▲
████████████████████▀▀


𝙳𝚎𝚟 : @𝙽_𝚓𝚛𝚛"""

# وجه الجوكر - يظهر بعد تسجيل الدخول بنجاح
joker_art = r"""⌯—————  WELCOME TO MY WORLD —————⌯
⠀⠀   ⠀⣿⣿⣷⣤⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
   ⠀⠀⢀⣿⣿⣿⣿⣿⣿⣆⡀⠀⠀⠀⠀⣠⣴⣦⡄⢤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀   ⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣷⣷⣶⣶⣿⣿⣿⣿⡀⣽⡿⣶⣦⡀⠀⠀⠀⠀⠀
   ⠀⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡿⣿⣿⣿⣿⣆⠀⠀⠀⠀
   ⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣾⣿⣿⣿⣿⣿⣦⠀⠀⠀
   ⠀⠀⢾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣟⣿⣿⣿⣿⣿⡿⢟⣿⣷⡀⠀
   ⠀⠀⠘⣿⣿⣿⣿⣿⣿⣿⣿⣭⣿⣿⣽⣿⣽⣾⣿⣿⣿⠛⠉⠉⠀⢈⣿⣿⡇⠀
   ⠀⠀⠀⢻⣿⣿⠛⠉⠛⠻⣿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠡⠤⠄⠁⠀⠀⢻⣿⡇⠀
   ⠀⠀⠀⠘⣿⣿⠄⠀⠀⠀⠀⠀⣉⠙⠋⢿⣿⣯⠀⠀⠀⠀⠀⠀⣰⣿⣿⡿⡃⠀
   ⠀⠀⠀⠀⢹⣿⣇⣀⠀⠈⠉⠉⠁⠀⣤⢠⣿⣿⣧⡆⣤⣤⡀⣾⣿⣿⣿⢠⡇⠀
   ⠀⠀⠀⠀⠀⣿⣿⣿⣷⣤⠄⣀⣴⣧⣹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⠇⠀
   ⠀⠀⠀⠀⠀⠸⣿⣯⠉⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⡯⠁⡌⠀⠀
⠀   ⠀⠀⠀⠀⠀⠙⢿⡄⢿⣿⣿⣿⣿⣿⣎⠙⠻⠛⣁⣼⣿⣿⡿⠛⠁⡸⠀⠀⠀
   ⠀⠀⠀⠀⠀⠀⠀⠈⢿⡄⠉⣿⡿⣿⣿⣿⣿⣷⣬⣿⡿⠟⠋⢀⣴⡞⠁⠀⠀⠀
   ⠀⠀⠀⠀⠀⠀⠀⠀⠈⢳⠀⠀⠀⠀⠉⠉⠋⠉⠉⠁⠀⢀⣴⣿⡿⠀⠀⠀⠀⠀
   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣿⣿⣿⣿⠿⢃⣴⣿⣿⣿⠃⠀⠀⠀⠀⠀
   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣿⣿⣿⣿⣿⣿⣿⠟⠀⠀⠀⠀⠀⠀
   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠛⠛⠉⠉⠀⠀⠀⠀⠀⠀⠀⠀


𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐭𝐨 𝐒𝐨𝐮𝐫𝐜𝐞 𝐙𝐞𝐫𝐨 ✅ .

𝐃𝐞𝐯 : @𝐍_𝐣𝐫𝐫
"""

# ==================== الأمر الرئيسي .الاوامر ====================
@client.on(events.NewMessage(pattern=r'\.الاوامر', outgoing=True))
async def show_main_menu(event):
    menu_text = """✦ ────『قائمة الأومر』──── ✦
• `.م1`  ➪ اوامــر اليوتـيوب والتـرفيـه
• `.م2`  ➪ اوامــر الذكـاء الاصـطنـاعي
• `.م3`  ➪ اوامــر الـوقتــي
• `.م4`  ➪ اوامــر المجمــوعــه والحماية
• `.م5`  ➪ اوامــر الخــاص والـردود
• `.م6`  ➪ اوامــر المـسح والتدمير
• `.م7`  ➪ اوامــر الاختصارات
• `.م8`  ➪ اوامــر الـانتحـال
• `.م9`  ➪ اوامــر التسليـه والتحشيش
• `.م10` ➪ اوامــر التـقليد والمحاكاة
• `.م11` ➪ اوامــر النشــر التلقــائي
• `.م12` ➪ اوامــر الاشتــراك الاجبــاري
• `.م13` ➪ اوامــر الـذاتيــة والمقيد
• `.م14` ➪ اوامــر الـخطـوط والترجمة
• `.م15` ➪ اوامــر الـنطق والتـحميل
• `.م16` ➪ اوامــر الحماية والتحويل
• `.م17` ➪ اوامــر التنصيب الـداخلي
• `.م18` ➪ اوامــر الصيد
• `.م19` ➪ اوامــر التجميع التلقــائي
• `.م20` ➪ اوامــر التخصيص والتعيين
• `.م21` ➪ اوامــر الزخرفة والرموز
• `.م22` ➪ اوامــر التفليش والإضافة
• `.م23` ➪ اوامــر الإبلاغ الداخلي
• `.م24` ➪ اوامــر الألعاب ووعد
• `.م25` ➪ اوامــر الوهمي
• `.م26` ➪ اوامــر المنع والميزات
• `.م27` ➪ اوامــر العملات والحساب
• `.م28` ➪ اوامــر الميوزك والفيديو
• `.م29` ➪ اوامــر الستريك والتفاعلات
• `.م30` ➪ اوامــر البصمات
• `.م31` ➪ اوامــر عملية ومفيدة
• `.م32` ➪ اوامــر البوتات
• `.م33` ➪ اوامــر المراقبة والتجسس
• `.م34` ➪ اوامــر الإحصائيات والتحليلات
• `.م35` ➪ اوامــر إبداعية وتصميم
• `.م36` ➪ اوامــر اجتماعية وتفاعلية
• `.م37` ➪ اوامــر الصور والوسائط
• `.م38` ➪ اوامــر الكتابة والتحرير
• `.م39` ➪ اوامــر التصنيف والترتيب
• `.م40` ➪ اوامــر الملفات والمرفقات
• `.م41` ➪ اوامــر الاختراق الوهمي
• `.م42` ➪ اوامــر الحب والرومانسية
• `.م43` ➪ اوامــر التحديث التلقائي
• `.م44` ➪ اوامــر نقـل الاعضـاء
• `.م45` ➪ اوامــر الوسائط العشوائية
• `.م46` ➪ اوامــر الحاســبة والمعــادلات
• `.م47` ➪ اوامــر ضغــط وتقطيــع الفيديــو
• `.م48` ➪ اوامــر الصــور المتحــركة
• `.م49` ➪ أوامــر النظــام والــصيانة
• `.م50` ➪ اوامــر البحــث عـن الصــور
• `.م51` ➪ اوامــر الحيــوان للتسلــية
• `.م52` ➪ اوامــر صنــع اللوجوهــات
• `.م53` ➪ اوامــر اللوجوهــات الســريعة
• `.م54` ➪ اوامــر المشــاهير للتسلــية
• `.م55` ➪ اوامــر معــاني الأســماء
• `.م56` ➪ اوامــر المـطـور
✶ مـعلـومـات الـسـورس :
↢ الـمـطـور : @N_jrr"""
    
    await event.edit(menu_text)

# ==================== دالة التشغيل ====================
async def main():
    # تنظيف الشاشة
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # عرض وجه الديناصور فقط
    print(dino_art)
    
    # بدء تشغيل العميل (سيطلب رقم الهاتف هنا)
    await client.start()
    
    # بدء تشغيل البوت المساعد
    await tgbot.start(bot_token=TG_BOT_TOKEN)
    print("تم تشغيل البوت المساعد بنجاح")
    
    if PYTGCALLS_AVAILABLE:
        try:
            call = PyTgCalls(client)
            await call.start()
        except Exception as e:
            pass
    
    # تنظيف الشاشة مرة أخرى
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # عرض وجه الجوكر فقط بعد تسجيل الدخول بنجاح
    print(joker_art)
    
    # تشغيل العميل للأبد
    await client.run_until_disconnected()

if __name__ == '__main__':
    asyncio.run(main())