import os
import sys
import subprocess

# تثبيت المكتبات بدون إظهار أي شيء في الكونسول
packages = ["telethon", "pytz", "aiohttp", "Pillow", "requests", "google-generativeai", "cryptography"]
for pkg in packages:
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--no-cache-dir", pkg], 
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except:
        pass

import asyncio
import main
import modules.m1_youtube
import modules.m2_ai
import modules.m3_time
import modules.m4_group
import modules.m5_private
import modules.m6_delete
import modules.m7_shortcuts
import modules.m8_impersonate
import modules.m9_fun
import modules.m10_mimic
import modules.m11_publish
import modules.m12_force_subscribe
import modules.m13_self_destruct
import modules.m14_font_translate
import modules.m15_tts_download
import modules.m16_protection_convert
import modules.m17_install
import modules.m18_hunt
import modules.m19_collect
import modules.m20_customize
import modules.m21_zakhrafa
import modules.m22_flush
import modules.m23_report
import modules.m24_games
import modules.m25_fake_session
import modules.m26_ban_words
import modules.m27_crypto
import modules.m28_music_video
import modules.m29_streak_reaction
import modules.m30_voice
import modules.m31_useful
import modules.m32_bots
import modules.m33_monitor
import modules.m34_stats
import modules.m35_creative
import modules.m36_social
import modules.m37_media
import modules.m38_editor
import modules.m39_ranking
import modules.m40_files
import modules.m41_hack
import modules.m42_love
import modules.m43_updater
import modules.m44_add_members
import modules.m45_media_random
import modules.m46_calculator
import modules.m47_ffmpeg
import modules.m48_gif
import modules.m49_system
import modules.m50_image_search
import modules.m51_animal
import modules.m52_logo
import modules.m53_logo2
import modules.m54_famous
import modules.m55_meaning
import modules.m56_developer

if __name__ == '__main__':
    asyncio.run(main.main())